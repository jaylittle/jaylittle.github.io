Imports System.Web
Imports System.Web.SessionState

Public Class Global
    Inherits System.Web.HttpApplication

#Region " Component Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        'Initialize Settings and Application Variables
        Dim MySettings As pengine.Data.Settings = New pengine.Data.Settings
        Application.Item("basethemepath") = HttpContext.Current.Request.ApplicationPath() & "/themes/"
        If HttpContext.Current.Request.ApplicationPath.EndsWith("/") = True Then
            Application.Item("basepath") = HttpContext.Current.Request.ApplicationPath()
        Else
            Application.Item("basepath") = HttpContext.Current.Request.ApplicationPath() & "/"
        End If
        Application.Item("cachepath") = Server.MapPath(Application.Item("basepath") & "/cache/")
        Application.Item("temppath") = Server.MapPath(Application.Item("basepath") & "/temp/")
        MySettings.LoadIntoApplication()

        'Set up Directory for XML Caching
        If System.IO.Directory.Exists(Application.Item("cachepath")) Then
            System.IO.Directory.Delete(Application.Item("cachepath"), True)
        End If
        System.IO.Directory.CreateDirectory(Application.Item("cachepath"))

        'Set up Directory for XML Caching of Admin Data
        If System.IO.Directory.Exists(Application.Item("cachepath")) Then
            System.IO.Directory.Delete(Application.Item("cachepath"), True)
        End If
        System.IO.Directory.CreateDirectory(Application.Item("cachepath"))

        'Set up Temporary Directory for Filesystem Operations
        If System.IO.Directory.Exists(Application.Item("temppath")) Then
            System.IO.Directory.Delete(Application.Item("temppath"), True)
        End If
        System.IO.Directory.CreateDirectory(Application.Item("temppath"))

        'Build Application Data Caches
        RebuildNewsCache()
        RebuildQuoteCache()
        RebuildArticleCache()
        RebuildResumeCache()

    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        'Set Per Session Interface Defaults
        Dim MyTheme As pengine.Data.Theme = New pengine.Data.Theme
        MyTheme.LoadTheme(Application.Item("defaulttheme"))
        Session.Item("leetflag") = False
        Session.Item("admin") = False
        Session.Item("god") = False
        Session.Item("forumloggedin") = False
        Session.Item("forumadmin") = False
        If Application.Item("forum") = True Then
            Dim UserData As DataSet
            Dim ForumObj As pengine.Data.Forum = New pengine.Data.Forum(Application("FConnectionString"))
            If Not Request.Cookies("FUser") Is Nothing And Not Request.Cookies("FPass") Is Nothing Then
                UserData = ForumObj.ValidateUserWithEncryptedPassword(Request.Cookies("FUser").Value, Request.Cookies("FPass").Value)
                If UserData.Tables(0).Rows.Count > 0 Then
                    Session("forumloggedin") = True
                    Session("forumadmin") = UserData.Tables(0).Rows(0).Item("ModeratorFlag")
                    Session("forumusername") = UserData.Tables(0).Rows(0).Item("Name")
                    Session("forumuserid") = UserData.Tables(0).Rows(0).Item("ID")
                End If
            End If
            ForumObj.CloseConn()
        End If
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

    Public Shared Sub RebuildResumeCache()
        HttpContext.Current.Application.Item("cachefile_resume_personal") = HttpContext.Current.Application.Item("cachepath") & "\resume_personal.xml"
        HttpContext.Current.Application.Item("cachefile_resume_objective") = HttpContext.Current.Application.Item("cachepath") & "\resume_objective.xml"
        HttpContext.Current.Application.Item("cachefile_resume_skill_types") = HttpContext.Current.Application.Item("cachepath") & "\resume_skill_types.xml"
        HttpContext.Current.Application.Item("cachefile_resume_education") = HttpContext.Current.Application.Item("cachepath") & "\resume_education.xml"
        HttpContext.Current.Application.Item("cachefile_resume_workhistory") = HttpContext.Current.Application.Item("cachepath") & "\resume_workhistory.xml"

        'Rebuild Resume Caches
        Dim MyResume As pengine.Data.ResumeParts = New pengine.Data.ResumeParts(HttpContext.Current.Application.Item("ConnectionString"))
        Dim SkillList As DataSet = MyResume.GetSkillTypes()
        Dim SkillPtr As Integer
        MyResume.WriteXML(MyResume.GetPersonals(), HttpContext.Current.Application.Item("cachefile_resume_personal"))
        MyResume.WriteXML(MyResume.GetObjectives(), HttpContext.Current.Application.Item("cachefile_resume_objective"))
        MyResume.WriteXML(SkillList, HttpContext.Current.Application.Item("cachefile_resume_skill_types"))
        For SkillPtr = 0 To SkillList.Tables(0).Rows.Count - 1
            Dim MyType As String = SkillList.Tables(0).Rows(SkillPtr).Item("Type")
            HttpContext.Current.Application.Item("cachefile_resume_skill_" & MyType) = HttpContext.Current.Application.Item("cachepath") & "\resume_skill_" & MyType & ".xml"
            MyResume.WriteXML(MyResume.GetSkills(MyType), HttpContext.Current.Application.Item("cachefile_resume_skill_" & MyType))
        Next
        MyResume.WriteXML(MyResume.GetEducations(), HttpContext.Current.Application.Item("cachefile_resume_education"))
        MyResume.WriteXML(MyResume.GetWorkHistories(), HttpContext.Current.Application.Item("cachefile_resume_workhistory"))
        MyResume.CloseConn()
    End Sub

    Public Shared Sub RebuildArticleCache()
        HttpContext.Current.Application.Item("cachefile_categories_admin") = HttpContext.Current.Application.Item("cachepath") & "\categories_admin.xml"
        HttpContext.Current.Application.Item("cachefile_categories") = HttpContext.Current.Application.Item("cachepath") & "\categories.xml"

        'Rebuild Category Cache for Menus
        Dim MyArticle As pengine.Data.Article
        Dim CategoryList As DataSet
        Dim CategoryPtr As Integer
        Dim ArticleList As DataSet
        MyArticle = New pengine.Data.Article(HttpContext.Current.Application.Item("ConnectionString"))
        CategoryList = MyArticle.CategoryList(True)
        MyArticle.WriteXML(CategoryList, HttpContext.Current.Application.Item("cachefile_categories_admin"))
        MyArticle.WriteXML(MyArticle.CategoryList(False), HttpContext.Current.Application.Item("cachefile_categories"))

        'Rebuild Category Article Lists Cache
        For CategoryPtr = 0 To CategoryList.Tables(0).Rows.Count - 1
            Dim CategoryName As String = CategoryList.Tables(0).Rows(CategoryPtr).Item("category")
            HttpContext.Current.Application.Item("cachefile_cat_" & CategoryName & "_file_admin") _
            = HttpContext.Current.Application.Item("cachepath") & "\category_" & CategoryName & "_admin.xml"
            HttpContext.Current.Application.Item("cachefile_cat_" & CategoryName & "_file") _
            = HttpContext.Current.Application.Item("cachepath") & "\category_" & CategoryName & ".xml"
            MyArticle.WriteXML(MyArticle.GetArticles(CategoryName, True), HttpContext.Current.Application.Item("cachefile_cat_" & CategoryName & "_file_admin"))
            MyArticle.WriteXML(MyArticle.GetArticles(CategoryName, False), HttpContext.Current.Application.Item("cachefile_cat_" & CategoryName & "_file"))
        Next
        HttpContext.Current.Application.Item("cachefile_cat_all_file_admin") = HttpContext.Current.Application.Item("cachepath") & "\category_all_admin.xml"
        HttpContext.Current.Application.Item("cachefile_cat_all_file") = HttpContext.Current.Application.Item("cachepath") & "\category_all.xml"
        ArticleList = MyArticle.GetArticles("", True)
        MyArticle.WriteXML(ArticleList, HttpContext.Current.Application.Item("cachefile_cat_all_file_admin"))
        MyArticle.WriteXML(MyArticle.GetArticles("", False), HttpContext.Current.Application.Item("cachefile_cat_all_file"))

        'Rebuild Article Section Data Cache
        Dim ArticlePtr As Integer
        Dim ArticleID As String
        For ArticlePtr = 0 To ArticleList.Tables(0).Rows.Count - 1
            ArticleID = ArticleList.Tables(0).Rows(ArticlePtr).Item("ID")
            HttpContext.Current.Application.Item("cachefile_article_" & ArticleID) = HttpContext.Current.Application.Item("cachepath") & "\article_" & ArticleID & ".xml"
            HttpContext.Current.Application.Item("cachefile_article_" & ArticleID & "_sectionlist") = HttpContext.Current.Application.Item("cachepath") & "\article_" & ArticleID & "_sectionlist.xml"
            MyArticle.WriteXML(MyArticle.GetArticle(System.Convert.ToInt32(ArticleID)), HttpContext.Current.Application.Item("cachefile_article_" & ArticleID))
            MyArticle.WriteXML(MyArticle.SectionList(System.Convert.ToInt32(ArticleID)), HttpContext.Current.Application.Item("cachefile_article_" & ArticleID & "_sectionlist"))
            Dim SectionData As DataSet = MyArticle.GetArticleSections(System.Convert.ToInt32(ArticleID))
            Dim SectionPtr = 0
            Dim SectionFileLoc As String
            Dim SectionFile
            For SectionPtr = 0 To SectionData.Tables(0).Rows.Count - 1
                SectionFile = MyArticle.CleanSectionName(SectionData.Tables(0).Rows(SectionPtr).Item("Name"))
                SectionFileLoc = HttpContext.Current.Application.Item("cachepath") & "\article_" & ArticleID & "_section_" & SectionFile & ".xml"
                HttpContext.Current.Application.Item("cachefile_article_" & ArticleID & "_section_" & SectionFile) = SectionFileLoc
                MyArticle.WriteXML(MyArticle.GetArticleSection(System.Convert.ToInt32(ArticleID), SectionData.Tables(0).Rows(SectionPtr).Item("Name")), SectionFileLoc)
            Next
        Next
        MyArticle.CloseConn()
    End Sub

    Public Shared Sub RebuildQuoteCache()
        HttpContext.Current.Application.Item("cachefile_quotes") = HttpContext.Current.Application.Item("cachepath") & "\quotes.xml"

        'Rebuild Quote Cache for Front Page
        Dim MyQuote As pengine.Data.Quote
        MyQuote = New pengine.Data.Quote(HttpContext.Current.Application.Item("ConnectionString"))
        MyQuote.WriteXML(MyQuote.GetAll, HttpContext.Current.Application.Item("cachefile_quotes"))
        MyQuote.CloseConn()
    End Sub

    Public Shared Sub RebuildNewsCache()
        HttpContext.Current.Application.Item("cachefile_news") = HttpContext.Current.Application.Item("cachepath") & "\news.xml"
        HttpContext.Current.Application.Item("cachefile_rss") = HttpContext.Current.Application.Item("cachepath") & "\rss.xml"

        'Rebuild News Cache for Front Page
        Dim MyNews As pengine.Data.News
        Dim NewsData As DataSet
        MyNews = New pengine.Data.News(HttpContext.Current.Application.Item("ConnectionString"))
        MyNews.WriteXML(MyNews.GetCurrentNews(), HttpContext.Current.Application.Item("cachefile_news"))

        'Rebuild News Cache for Archived News
        Dim NewsPtr As Integer
        Dim PagePtr As Integer
        Dim ItemPtr As Integer
        Dim PageID As Integer
        Dim LastID As Integer
        NewsData = MyNews.GetNewsRange(-1, 32000, False)
        PagePtr = 1
        ItemPtr = 0
        PageID = -1
        For NewsPtr = 0 To NewsData.Tables(0).Rows.Count - 1
            ItemPtr = ItemPtr + 1
            If ItemPtr > HttpContext.Current.Application.Item("newssummaryperpage") Then
                'Write Output Page Here
                HttpContext.Current.Application.Item("cachefile_news_page" & PagePtr) = HttpContext.Current.Application.Item("cachepath") & "\news_archive_page" & PagePtr & ".xml"
                MyNews.WriteXML(MyNews.GetNewsRange(PageID, HttpContext.Current.Application.Item("newssummaryperpage"), False), HttpContext.Current.Application.Item("cachefile_news_page" & PagePtr))
                PageID = LastID
                PagePtr = PagePtr + 1
                ItemPtr = 1
            End If
            LastID = NewsData.Tables(0).Rows(NewsPtr).Item("id")
            HttpContext.Current.Application.Item("cachefile_news_story_" & LastID) = HttpContext.Current.Application.Item("cachepath") & "\news_story_" & LastID & ".xml"
            MyNews.WriteXML(MyNews.GetNews(LastID), HttpContext.Current.Application.Item("cachefile_news_story_" & LastID))
        Next
        'Write Final Page
        HttpContext.Current.Application.Item("cachefile_news_page" & PagePtr) = HttpContext.Current.Application.Item("cachepath") & "\news_archive_page" & PagePtr & ".xml"
        MyNews.WriteXML(MyNews.GetNewsRange(PageID, HttpContext.Current.Application.Item("newssummaryperpage"), False), HttpContext.Current.Application.Item("cachefile_news_page" & PagePtr))
        MyNews.CloseConn()
        HttpContext.Current.Application.Item("LastNewsPage") = PagePtr

        'Rebuild RSS Feed for Front Page
        Dim MyRSS As pengine.rss = New pengine.rss
        Dim MyRSSFile As System.IO.FileInfo = New System.IO.FileInfo(HttpContext.Current.Application.Item("cachefile_rss"))
        Dim MyRSSStream As System.IO.TextWriter
        If MyRSSFile.Exists Then
            MyRSSFile.Delete()
        End If
        MyRSSStream = MyRSSFile.CreateText()
        MyRSSStream.Write(MyRSS.Generate(20))
        MyRSSStream.Close()
    End Sub

End Class
