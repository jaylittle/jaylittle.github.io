Imports System.Web.Services

<System.Web.Services.WebService(Namespace:="http://www.jaylittle.com/pengine/rss")> _
Public Class rss
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    <WebMethod(Description:="Generates and returns an RSS feed for the site using the specified number of current stories.")> _
    Public Function Generate(ByVal MaxStories As Integer) As String
        Dim MyNews As pengine.Data.News
        Dim newsitems As DataSet
        Dim framexml As String
        Dim newsptr As Integer
        Dim rssfeed As System.Xml.XmlDocument
        Dim rsswriter As System.Xml.XmlTextWriter
        Dim rsschannel As System.Xml.XmlNode
        Dim xmllocation As String
        Dim location As String
        Dim rnd As Random = New Random
        Dim number As Integer = rnd.Next(100)
        Dim RSSData As System.IO.FileInfo
        Dim filedata As String
        Dim filestream As System.IO.StreamReader
        Dim pubdate As DateTime

        If MaxStories <= 0 Then MaxStories = 5
        location = HttpContext.Current.Request.ServerVariables("SERVER_NAME") & HttpContext.Current.Request.ApplicationPath
        xmllocation = Application.Item("temppath") & "rss" & number & ".xml"
        If System.IO.File.Exists(xmllocation) Then
            System.IO.File.Delete(xmllocation)
        End If
        MyNews = New pengine.Data.News(Application.Item("ConnectionString"))
        rssfeed = New System.Xml.XmlDocument
        rsswriter = New System.Xml.XmlTextWriter(xmllocation, System.Text.Encoding.UTF8)
        If location.EndsWith("/") Then
            location = location.Substring(0, location.Length - 1)
        End If
        framexml = "<rss version=""2.0""><channel><title>" & Application.Item("defaultpagetitle") _
        & "</title>" & "<link>http://" & location & "</link><description>" & Application.Item("defaultpagetitle") _
        & "</description><lastBuildDate>" & String.Format("{0:R}", Now) & " " & "</lastBuildDate>" _
        & "<language>en-us</language>"
        If Application.Item("FrontPageLogo") <> "" Then
            framexml &= "<image>" _
            & "<title>" & Application.Item("defaultpagetitle") & "</title>" _
            & "<link>http://" & location & "</link>" _
            & "<url>http://" & location & "/images/system/" & Application.Item("FrontPageLogo") & "</url>" _
            & "</image>"
        End If
        framexml &= "</channel></rss>"
        rssfeed = New System.Xml.XmlDocument
        rssfeed.LoadXml(framexml)
        rsschannel = rssfeed.SelectSingleNode("/rss/channel")
        newsitems = MyNews.GetNewsRange(-1, MaxStories, False)
        For newsptr = 0 To newsitems.Tables(0).Rows.Count - 1
            pubdate = newsitems.Tables(0).Rows(newsptr).Item("timeposted")
            rsschannel.InnerXml &= "<item><title>" & Server.HtmlEncode(newsitems.Tables(0).Rows(newsptr).Item("title")) & "</title>" _
            & "<link>http://" & location & "/displaynews.aspx?id= " & newsitems.Tables(0).Rows(newsptr).Item("id") & "</link>" _
            & "<pubDate>" & String.Format("{0:R}", pubdate) & "</pubDate>" _
            & "<description>" & Server.HtmlEncode(MyNews.TruncateStory(newsitems.Tables(0).Rows(newsptr).Item("articledata"), -1)) & "</description>" _
            & "</item>"
        Next
        MyNews.CloseConn()
        rssfeed.Save(rsswriter)
        rsswriter.Flush()
        rsswriter.Close()
        'Pull XML data from file and dump into string
        RSSData = New System.IO.FileInfo(xmllocation)
        filestream = RSSData.OpenText
        filedata = filestream.ReadToEnd()
        filestream.Close()
        'Delete existing XML file as it was only temporary
        RSSData.Delete()
        Return filedata
    End Function

End Class
