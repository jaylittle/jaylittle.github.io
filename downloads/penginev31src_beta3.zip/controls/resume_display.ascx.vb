Imports pengine.Data

Public Class resume_display
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptPersonal As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptObjective As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptEducation As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptWorkHistory As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptTypes As System.Web.UI.WebControls.Repeater

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MySkillHTML As String = ""
    Public OldType As String = ""
    Public TypeCtr As Integer = 0
    Private AdminFlag As Boolean
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        AdminFlag = Session.Item("admin")
        Dim PersonalData As DataSet
        Dim ObjectiveData As DataSet
        Dim EducationData As DataSet
        Dim WorkHistoryData As DataSet
        Dim TypeData As DataSet
        Dim MyResume As ResumeParts = New ResumeParts(Application.Item("ConnectionString"))

        PersonalData = MyResume.ReadXML(Application.Item("cachefile_resume_personal"))
        RptPersonal.DataSource = PersonalData
        RptPersonal.DataBind()

        ObjectiveData = MyResume.ReadXML(Application.Item("cachefile_resume_objective"))
        RptObjective.DataSource = ObjectiveData
        RptObjective.DataBind()

        TypeData = MyResume.ReadXML(Application.Item("cachefile_resume_skill_types"))
        RptTypes.DataSource = TypeData
        RptTypes.DataBind()

        EducationData = MyResume.ReadXML(Application.Item("cachefile_resume_education"))
        RptEducation.DataSource = EducationData
        RptEducation.DataBind()

        WorkHistoryData = MyResume.ReadXML(Application.Item("cachefile_resume_workhistory"))
        RptWorkHistory.DataSource = WorkHistoryData
        RptWorkHistory.DataBind()

        MyResume.CloseConn()
    End Sub

    Function GetSkillName(ByVal Type As String, ByVal Name As String) As String
        If Type <> OldType Then
            TypeCtr = 1
            OldType = Type
        Else
            TypeCtr = TypeCtr + 1
        End If
        If TypeCtr = 1 Then
            Return Article.ConvertToElite(Name)
        Else
            Return ", " & Article.ConvertToElite(Name)
        End If
    End Function

    Public Sub PersonalAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=resume&sub=editpersonal&id=" & ID)
                Case "new"
                    Response.Redirect("default.aspx?cmd=resume&sub=editpersonal")
                Case "delete"
                    Dim MyResume As pengine.Data.ResumeParts
                    Dim Result As Boolean
                    MyResume = New ResumeParts(Application.Item("ConnectionString"))
                    Result = MyResume.DeletePersonal(Request.Item("ID"))
                    MyResume.WriteXML(MyResume.GetPersonals(), Application.Item("cachefile_resume_personal"))
                    MyResume.CloseConn()
                    Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Public Sub ObjectiveAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=resume&sub=editobjective&id=" & ID)
                Case "new"
                    Response.Redirect("default.aspx?cmd=resume&sub=editobjective")
                Case "delete"
                    Dim MyResume As ResumeParts
                    Dim Result As Boolean
                    MyResume = New ResumeParts(Application.Item("ConnectionString"))
                    Result = MyResume.DeleteObjective(Request.Item("ID"))
                    MyResume.WriteXML(MyResume.GetObjectives(), Application.Item("cachefile_resume_objective"))
                    MyResume.CloseConn()
                    Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Public Sub EducationAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=resume&sub=editeducation&id=" & ID)
                Case "new"
                    Response.Redirect("default.aspx?cmd=resume&sub=editeducation")
                Case "delete"
                    Dim MyResume As ResumeParts
                    Dim Result As Boolean
                    MyResume = New ResumeParts(Application.Item("ConnectionString"))
                    Result = MyResume.DeleteEducation(Request.Item("ID"))
                    MyResume.WriteXML(MyResume.GetEducations(), Application.Item("cachefile_resume_education"))
                    MyResume.CloseConn()
                    Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Public Sub WorkHistoryAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=resume&sub=editworkhistory&id=" & ID)
                Case "new"
                    Response.Redirect("default.aspx?cmd=resume&sub=editworkhistory")
                Case "delete"
                    Dim MyResume As ResumeParts
                    Dim Result As Boolean
                    MyResume = New ResumeParts(Application.Item("ConnectionString"))
                    Result = MyResume.DeleteWorkHistory(Request.Item("ID"))
                    MyResume.WriteXML(MyResume.GetWorkHistories(), Application.Item("cachefile_resume_workhistory"))
                    MyResume.CloseConn()
                    Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Public Sub SkillAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=resume&sub=editskill&id=" & ID)
                Case "new"
                    Response.Redirect("default.aspx?cmd=resume&sub=editskill")
                Case "delete"
                    Dim MyResume As ResumeParts
                    Dim Result As Boolean
                    MyResume = New ResumeParts(Application.Item("ConnectionString"))
                    Result = MyResume.DeleteSkill(Request.Item("ID"))
                    MyResume.CloseConn()
                    Global.RebuildResumeCache()
                    Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Private Sub RptTypes_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptTypes.ItemDataBound
        Dim RptSkills As Repeater = e.Item.FindControl("RptSkills")
        If Not RptSkills Is Nothing Then
            Dim DR As DataRowView = e.Item.DataItem
            Dim MyResume As ResumeParts
            MyResume = New ResumeParts(Application.Item("ConnectionString"))
            AddHandler RptSkills.ItemDataBound, AddressOf RptSkills_ItemDataBound
            RptSkills.DataSource = MyResume.ReadXML(Application.Item("cachefile_resume_skill_" & DR.Item("Type")))
            RptSkills.DataBind()
        End If
    End Sub

    Private Sub RptSkills_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndeleteskill")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the skill """ & Server.HtmlEncode(data.Item("name")) & """?');")
            End If
        End If
    End Sub

    Private Sub RptEducation_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptEducation.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndeleteeducation")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the education record for """ & Server.HtmlEncode(data.Item("institute")) & """?');")
            End If
        End If
    End Sub

    Private Sub RptObjective_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptObjective.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndeleteobjective")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete this objective?');")
            End If
        End If
    End Sub

    Private Sub RptPersonal_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptPersonal.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndeletepersonal")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete this personal information?');")
            End If
        End If
    End Sub

    Private Sub RptWorkHistory_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptWorkHistory.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndeleteworkhistory")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the work history record for """ & Server.HtmlEncode(data.Item("employer")) & """?');")
            End If
        End If
    End Sub
End Class
