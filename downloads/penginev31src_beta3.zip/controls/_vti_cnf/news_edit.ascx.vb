vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Sep 2004 15:17:51 -0000
vti_extenderversion:SR|4.0.2.8912
