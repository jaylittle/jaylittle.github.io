Imports pengine.Data

Public Class account_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptUsers As System.Web.UI.WebControls.Repeater

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim UserData As DataSet
        Dim MyArticle As Article
        Dim MyForum As Forum
        MyForum = New Forum(Application("FConnectionString"))
        UserData = MyForum.GetUsers()
        RptUsers.DataSource = UserData
        RptUsers.DataBind()
        MyForum.CloseConn()
    End Sub

    Public Sub UserAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim td As HtmlTableCell
        Dim ID As Integer
        td = e.Item.FindControl("tdid")
        If Not td Is Nothing Then
            ID = td.InnerText
        End If
        If ID > 0 Then
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=account&sub=edit&id=" & ID)
            End Select
        End If
    End Sub

End Class
