Imports pengine.Data

Public Class resume_editobjective
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents lblName As System.Web.UI.WebControls.Label
    Protected WithEvents txtdescription As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents btndisplay As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyResume As ResumeParts
        Dim ObjectiveData As DataSet = New DataSet
        Session("standardforward") = "default.aspx?cmd=resume&sub=display"
        MyResume = New ResumeParts(Application.Item("ConnectionString"))
        If txtid.Text = "" Then
            txtid.Text = Request.Item("id")
        End If
        If Not IsPostBack Then
            If (txtid.Text <> "" And IsNumeric(txtid.Text)) Then
                ObjectiveData = MyResume.GetObjective(txtid.Text)
                If ObjectiveData.Tables(0).Rows.Count > 0 Then
                    txtdescription.Text = ObjectiveData.Tables(0).Rows(0).Item("Description")
                End If
            Else
                txtdescription.Text = "Input objective description here."
                txtid.Text = "-1"
            End If
        End If
        If txtid.Text <> "-1" Then
            MyTitle = "Editing Objective Resume Entry #" & txtid.Text
        Else
            MyTitle = "Creating Objective Resume Entry"
        End If
        MyResume.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyResume As ResumeParts
        Dim ErrorText As String
        MyResume = New ResumeParts(Application.Item("ConnectionString"))
        ErrorText = MyResume.SaveObjective(txtid.Text, txtdescription.Text)
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully."
            MyTitle = "Editing Objective Resume Entry #" & txtid.Text
        End If
        MyResume.CloseConn()
        MyResume.WriteXML(MyResume.GetObjectives(), Application.Item("cachefile_resume_objective"))
    End Sub

    Private Sub btndisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay.Click
        Response.Redirect("default.aspx?cmd=resume&sub=display&1=#Objective")
    End Sub
End Class
