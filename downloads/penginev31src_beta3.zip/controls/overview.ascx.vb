Imports pengine.Data

Public Class overview
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents imgpenginelogo As System.Web.UI.WebControls.Image
    Protected WithEvents RptNews As System.Web.UI.WebControls.Repeater
    Protected WithEvents btnArchived As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyNewButtonHTML As String
    Public MyQuoteText As String = ""
    Private AdminFlag As Boolean
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        AdminFlag = Session.Item("admin")
        Dim MyNews As News = New News(Application.Item("ConnectionString"))
        Dim MyArticle As Article = New Article(Application.Item("ConnectionString"))
        If Application.Item("frontpagelogo") <> "" Then
            imgpenginelogo.ImageUrl = "../images/system/" & Application.Item("frontpagelogo")
            imgpenginelogo.Visible = True
        Else
            imgpenginelogo.Visible = False
        End If
        If Session.Item("admin") = True Then
            MyNewButtonHTML = MyArticle.CreateHTMLButton("./admin/editnews.aspx", "New", "")
        End If
        Dim NewsData As DataSet

        'Pull News Data from Generated XML Cache
        NewsData = MyNews.ReadXML(Application.Item("cachefile_news"))
        RptNews.DataSource = NewsData
        RptNews.DataBind()
        If Application.Item("excludequotes") = 0 Then
            Dim MyQuote As Quote
            MyQuote = New Quote(Application.Item("ConnectionString"))
            MyQuoteText = MyArticle.ConvertToElite(MyQuote.GetRandom(Application.Item("cachefile_quotes")))
            MyQuote.CloseConn()
        End If
        MyNews.CloseConn()
    End Sub

    Public Sub NewsAction(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            If ID > 0 Then
                Select Case e.CommandName.ToLower()
                    Case "new"
                        Response.Redirect("default.aspx?cmd=news&sub=edit")
                    Case "edit"
                        Response.Redirect("default.aspx?cmd=news&sub=edit&id=" & ID)
                    Case "delete"
                        Dim MyNews As News = New News(Application.Item("ConnectionString"))
                        MyNews.DeleteNews(ID)
                        MyNews.CloseConn()
                        pengine.Global.RebuildNewsCache()
                        Page_Load(Nothing, Nothing)
                End Select
            End If
        End If
    End Sub

    Private Sub btnArchived_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnArchived.Click
        Response.Redirect("default.aspx?cmd=news&sub=browse")
    End Sub

    Private Sub RptNews_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptNews.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndelete")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the story """ & Server.HtmlEncode(data.Item("title")) & """?');")
            End If
        End If
    End Sub
End Class
