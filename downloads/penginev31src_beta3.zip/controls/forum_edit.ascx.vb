Imports pengine.Data

Public Class forum_edit
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents txtname As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtdescription As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim UserData As DataSet
        Dim MyForum As Forum
        If Not IsPostBack Then
            MyForum = New Forum(Application("FConnectionString"))
            If Request.Item("id") <> "" And IsNumeric(Request.Item("id")) Then
                UserData = MyForum.GetForum(Request.Item("id"))
                If UserData.Tables(0).Rows.Count > 0 Then
                    txtid.Text = UserData.Tables(0).Rows(0).Item("ID")
                    txtname.Text = UserData.Tables(0).Rows(0).Item("Name") & ""
                    txtdescription.Text = UserData.Tables(0).Rows(0).Item("Description") & ""
                    MyTitle = "Edit Forum"
                Else
                    lblerrors.Text = "You specified a forumid that does not exist."
                End If
            Else
                MyTitle = "Add Forum"
                txtid.Text = "-1"
                txtname.Text = "New Forum"
                txtdescription.Text = "This is a new forum"
            End If
            MyForum.CloseConn()
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyForum As Forum
        Dim ErrorText As String = ""
        Dim MyPassword As String = ""
        MyForum = New Forum(Application.Item("FConnectionString"))
        lblerrors.Text = ""
        ErrorText = MyForum.SaveForum(txtid.Text, txtname.Text, txtdescription.Text)
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully."
        End If
        MyForum.CloseConn()
    End Sub
End Class
