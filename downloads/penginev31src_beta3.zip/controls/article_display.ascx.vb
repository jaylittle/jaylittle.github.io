Imports pengine.Data

Public Class article_display
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblsection As System.Web.UI.WebControls.Label
    Protected WithEvents lstsection As System.Web.UI.WebControls.DropDownList
    Protected WithEvents RptArticle As System.Web.UI.WebControls.Repeater
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents btnedit As System.Web.UI.WebControls.Button
    Protected WithEvents btndelete As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public ArticleID As Integer = 0
    Public SectionList As DataSet
    Public SectionPtr As Integer = 0
    Public MyEditButtonHTML As String
    Private MyArticle As Article
    Private SectionData As DataSet
    Private DefaultSection As String
    Private CurrentSection As String
    Private ArticleData As DataSet

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        MyArticle = New Article(Application.Item("ConnectionString"))
        lstsection.Visible = True
        lblsection.Visible = True
        'The following code automatically initializes fields based on querystring input on first access.
        If Not IsPostBack Then
            If txtid.Text = "" Then
                txtid.Text = Request.Item("id")
            End If
            ArticleID = txtid.Text
            ArticleData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID))
            If ArticleData.Tables(0).Rows.Count > 0 Then
                SectionList = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID & "_sectionlist"))
                If ArticleData.Tables(0).Rows(0).Item("defaultsection") <> "" Then
                    DefaultSection = ArticleData.Tables(0).Rows(0).Item("defaultsection")
                ElseIf SectionList.Tables(0).Rows.Count > 0 Then
                    DefaultSection = SectionList.Tables(0).Rows(0).Item("name")
                Else
                    DefaultSection = ""
                End If
                If SectionList.Tables(0).Rows.Count > 1 Then
                    lstsection.Items.Clear()
                    For SectionPtr = 0 To SectionList.Tables(0).Rows.Count - 1
                        lstsection.Items.Add(New ListItem(SectionList.Tables(0).Rows(SectionPtr).Item(0), SectionList.Tables(0).Rows(SectionPtr).Item(0)))
                        If Request.Item("Section") <> "" Then
                            CurrentSection = SectionList.Tables(0).Rows(SectionPtr).Item(0)
                            If CurrentSection.ToUpper = Request.Item("Section").ToUpper Then
                                lstsection.Items(SectionPtr).Selected = True
                            End If
                        Else
                            If SectionList.Tables(0).Rows(SectionPtr).Item(0) = DefaultSection Then
                                lstsection.Items(SectionPtr).Selected = True
                            End If
                        End If
                    Next
                Else
                    lstsection.Visible = False
                    lblsection.Visible = False
                End If
            End If
            If Session.Item("admin") = True Then
                MyEditButtonHTML = MyArticle.CreateHTMLButton("./admin/editarticle.aspx?id=" & txtid.Text, "Edit Article", "")
            End If
            If IsNumeric(txtid.Text) Then
                BindArticle()
            End If
        End If
        'The following code actually binds the article data to the page.
        MyArticle.CloseConn()
    End Sub

    Private Sub BindArticle()
        Dim header As pengine.header
        Dim menu As pengine.menu
        ArticleID = txtid.Text
        If IsPostBack = True Then
            ArticleData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID))
        End If
        header = Me.Page.FindControl("header1")
        menu = Me.Page.FindControl("menu1")
        If Not header Is Nothing And Not menu Is Nothing Then
            menu.ArticleID = txtid.Text
            header.ArticleID = txtid.Text
            header.ArticleCategory = ArticleData.Tables(0).Rows(0).Item("category")
        End If
        If lstsection.SelectedIndex >= 0 Then
            'SectionData = MyArticle.GetArticleSection(ArticleID, lstsection.SelectedItem.Text)
            SectionData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID & "_section_" & MyArticle.CleanSectionName(lstsection.SelectedItem.Text)))
        Else
            'SectionData = MyArticle.GetArticleSection(ArticleID, "")
            If DefaultSection <> "" Then
                SectionData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID & "_section_" & MyArticle.CleanSectionName(DefaultSection)))
            Else
                'As a last resort pull an empty dataset back from the DB so the application doesn't crash because
                'the dataset doesn't contain the structures it expects to see.
                SectionData = MyArticle.GetArticleSection(ArticleID, "")
            End If
        End If
        RptArticle.DataSource = SectionData
        RptArticle.DataBind()
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Dim MyArticle As pengine.Data.Article
        Dim Result As Boolean
        MyArticle = New Article(Application.Item("ConnectionString"))
        Result = MyArticle.DeleteArticle(Request.Item("ID"))
        MyArticle.WriteXML(MyArticle.CategoryList(True), Application.Item("cachefile_categories_admin"))
        MyArticle.WriteXML(MyArticle.CategoryList(False), Application.Item("cachefile_categories"))
        MyArticle.CloseConn()
        pengine.Global.RebuildArticleCache()
        Response.Redirect("default.aspx?cmd=article&sub=browse")
    End Sub

    Private Sub btnedit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnedit.Click
        Response.Redirect("default.aspx?cmd=article&sub=edit&id=" & txtid.Text)
    End Sub

    Private Sub lstsection_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstsection.SelectedIndexChanged
        BindArticle()
    End Sub
End Class
