Imports pengine.Data
Imports System.Web.Security

Public Class login
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents imgpenginelogo As System.Web.UI.WebControls.Image
    Protected WithEvents lblNote As System.Web.UI.WebControls.Label
    Protected WithEvents lblUsername As System.Web.UI.WebControls.Label
    Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblPassword As System.Web.UI.WebControls.Label
    Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents chkcookie As System.Web.UI.WebControls.CheckBox
    Protected WithEvents btnLogin As System.Web.UI.WebControls.Button
    Protected WithEvents lblerror As System.Web.UI.WebControls.Label
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private ForumFlag As Boolean
    Private ArticleFlag As Boolean
    Private MyURL As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        lblerror.Text = ""
        If Application.Item("frontpagelogo") <> "" Then
            imgpenginelogo.ImageUrl = "../images/system/" & Application.Item("frontpagelogo")
            imgpenginelogo.Visible = True
        Else
            imgpenginelogo.Visible = False
        End If
        'If User.Identity.IsAuthenticated = True Then
        '    lblPassword.Text = "Already Authenticated: "
        'Else
        '    lblPassword.Text = "Not Authenticated: "
        'End If
        If Request.Item("mode") <> "" Then
            If Request.Item("mode").ToLower = "forum" Then
                ForumFlag = True
            ElseIf Request.Item("mode").ToLower = "article" Then
                ArticleFlag = True
            Else
                ForumFlag = False
            End If
        Else
            MyURL = Request.Item("ReturnURL")
            If InStr(1, MyURL.ToLower, "forum") > 0 Then
                ForumFlag = True
            Else
                ForumFlag = False
            End If
            'FormsAuthentication.SignOut()
        End If
        lblerror.Text = ""
        If ForumFlag = True Then
            lblNote.Text = "In order to forum edit/admin functionality you must provide a valid username " _
            & "and password in the textbox below:"
        ElseIf ArticleFlag = True Then
            lblNote.Text = "In order to edit this article - you must enter it's password below:"
            lblUsername.Visible = False
            txtUserName.Visible = False
        Else
            lblNote.Text = "In order to access admin functionality you must provide a valid Admin/God " _
            & "password in the textbox below:"
            lblUsername.Visible = False
            txtUserName.Visible = False
        End If
        If ForumFlag = False And ArticleFlag = False Then
            If Not Request.Cookies("APass") Is Nothing Then
                ProcessLogin(True)
            End If
        End If
    End Sub

    Private Sub ProcessLogin(Optional ByVal CookieFlag As Boolean = False)
        If ForumFlag = True Then
            Dim UserData As DataSet
            Dim MyForums As Forum = New Forum(Application.Item("FConnectionString"))
            If txtUserName.Text <> "" Then
                UserData = MyForums.ValidateUser(txtUserName.Text, txtPassword.Text)
                If UserData.Tables(0).Rows.Count > 0 Then
                    If UserData.Tables(0).Rows(0).Item("DisabledFlag") = False Then
                        If MyForums.VerifyIP(Request.ServerVariables("REMOTE_HOST")) = True Then
                            Session("forumloggedin") = True
                            Session("forumadmin") = UserData.Tables(0).Rows(0).Item("ModeratorFlag")
                            Session("forumusername") = UserData.Tables(0).Rows(0).Item("Name")
                            Session("forumuserid") = UserData.Tables(0).Rows(0).Item("ID")
                            If Me.chkcookie.Checked = True Then
                                Response.Cookies("FUser").Value = txtUserName.Text
                                Response.Cookies("FUser").Expires = DateTime.Now().AddDays(30)
                                Response.Cookies("FPass").Value = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(txtPassword.Text, "MD5")
                                Response.Cookies("FPass").Expires = DateTime.Now().AddDays(30)
                            End If
                            If Session("forumadmin") = True Then
                                If MyURL = "" Then
                                    Response.Redirect(Application.Item("basepath") & "default.aspx?cmd=forum&sub=browse")
                                Else
                                    Response.Redirect(MyURL)
                                End If
                            Else
                                If MyURL = "" Then
                                    Response.Redirect(Application.Item("basepath") & "default.aspx?cmd=forum&sub=browse")
                                Else
                                    Response.Redirect(MyURL)
                                End If
                            End If
                        Else
                            lblerror.Text = "Your IP Address has been banned."
                        End If
                    Else
                        lblerror.Text = "Your user account has been disabled."
                    End If
                Else
                    lblerror.Text = "You specified an incorrect username or password.  Please try again."
                End If
            Else
                lblerror.Text = "You must specify both a username and password."
            End If
            MyForums.CloseConn()
        ElseIf ArticleFlag = True Then
            If Session("admin") = True And Session("god") = False Then
                Dim ArticleData As DataSet
                Dim MyArticle As Article = New Article(Application.Item("ConnectionString"))
                ArticleData = MyArticle.GetArticle(Request.Item("id"))
                If ArticleData.Tables(0).Rows(0).Item("adminpass") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(txtPassword.Text, "MD5") Then
                    Session.Item("articleadmin" & Request.Item("id")) = True
                    Response.Redirect(Session.Item("LASTARTICLEEDITED"))
                End If
                MyArticle.CloseConn()
            Else
                lblerror.Text = "The article password you provided was not correct."
            End If
        Else
            If CookieFlag = True Then
                If Application.Item("AdminPass") = Request.Cookies("APass").Value Then
                    Session("admin") = True
                End If
                If Application.Item("GodPass") = Request.Cookies("APass").Value Then
                    Session("admin") = True
                    Session("god") = True
                End If
            Else
                If Application.Item("AdminPass") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(txtPassword.Text, "MD5") Then
                    Session("admin") = True
                End If
                If Application.Item("GodPass") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(txtPassword.Text, "MD5") Then
                    Session("admin") = True
                    Session("god") = True
                End If
            End If
            If Session("admin") = True Then
                If Me.chkcookie.Checked = True Then
                    Response.Cookies("APass").Value = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(txtPassword.Text, "MD5")
                    Response.Cookies("APass").Expires = DateTime.Now().AddDays(30)
                End If
                Cache.Item(Session.SessionID & "ViewMode") = Session.Item("theme") & "-" & Session.Item("leetflag") & "-" & Session.Item("admin")
                If MyURL = "" Then
                    Response.Redirect(Application.Item("basepath") & "default.aspx")
                Else
                    Response.Redirect(MyURL)
                End If
            Else
                lblerror.Text = "The admin/god password you provided was not correct."
            End If
        End If
    End Sub

    Private Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        ProcessLogin()
    End Sub
End Class
