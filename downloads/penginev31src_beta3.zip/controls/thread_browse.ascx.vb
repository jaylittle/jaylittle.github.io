Imports pengine.Data

Public Class thread_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptThreads As System.Web.UI.WebControls.Repeater
    Protected WithEvents btnaddthread As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyForumName As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ThreadsData As DataSet
        Dim MyForum As Forum = New Forum(Application("FConnectionString"))
        If Request.Item("forumid") <> "" And IsNumeric(Request.Item("forumid")) Then
            MyForumName = MyForum.GetForumName(Request.Item("forumid"))
            If Request.Item("page") = "" Or IsNumeric(Request.Item("page")) = False Then
                ThreadsData = MyForum.GetThreads(Request.Item("forumid"), -1, Application.Item("forumpostsperpage"))
            Else
                ThreadsData = MyForum.GetThreads(Request.Item("forumid") _
                , (Request.Item("page") - 1) * Application.Item("forumpostsperpage"), Application.Item("forumpostsperpage"))
            End If
            If Session.Item("forumloggedin") = True Then
                btnaddthread.Visible = True
            Else
                btnaddthread.Visible = False
            End If
            RptThreads.DataSource = ThreadsData
            RptThreads.DataBind()
            'MyArticle.CloseConn()
        End If
        MyForum.CloseConn()
    End Sub

    Private Sub btnaddthread_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaddthread.Click
        Response.Redirect("default.aspx?cmd=msg&sub=edit&forumid=" & Request.Item("forumid"))
    End Sub
End Class
