Imports pengine.Data
Imports System.Web.Security

Public Class logout
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ForumFlag As Boolean
        If Not Request.Item("mode") Is Nothing Then
            If Request.Item("mode").ToLower = "forum" Then
                ForumFlag = True
            Else
                ForumFlag = False
            End If
        Else
            ForumFlag = False
        End If
        If ForumFlag = True Then
            Session("forumadmin") = False
            Session("forumloggedin") = False
            Session("forumusername") = ""
            Session("forumuserid") = 0
            Response.Cookies("FUser").Expires = System.DateTime.Now().AddDays(-1)
            Response.Cookies("FPass").Expires = System.DateTime.Now().AddDays(-1)
            If Request.ServerVariables("HTTP_REFERER") <> "" Then
                Response.Redirect(Request.ServerVariables("HTTP_REFERER"))
            Else
                Response.Redirect(Application.Item("basepath") & "default.aspx?cmd=forum&sub=browse")
            End If
        Else
            Session("admin") = False
            Cache.Item(Session.SessionID & "ViewMode") = Session.Item("theme") & "-" & Session.Item("leetflag") & "-" & Session.Item("admin")
            Response.Cookies("APass").Expires = System.DateTime.Now().AddDays(-1)
            If Session("standardforward") <> "" Then
                Dim TargetURL As String = Session("standardforward")
                Session("standardforward") = ""
                Response.Redirect(TargetURL)
            Else
                Response.Redirect("default.aspx")
            End If
        End If
    End Sub
End Class
