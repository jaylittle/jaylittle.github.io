Imports pengine.Data

Public Class menu_button
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ImgButtonLeft As System.Web.UI.WebControls.Image
    Protected WithEvents ImgButtonRight As System.Web.UI.WebControls.Image

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public URL As String = ""
    Public ButtonText As String = ""
    Public Background As String = ""
    Public MyArticle As Article
    Public LinkHTML As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        MyArticle = New Article(Application("ConnectionString"))
        If Session.Item("MenuLImage") <> "" Then
            ImgButtonLeft.ImageUrl = Session.Item("MenuLImage")
            ImgButtonLeft.Visible = True
        Else
            ImgButtonLeft.Visible = False
        End If
        If Session.Item("MenuRImage") <> "" Then
            ImgButtonRight.ImageUrl = Session.Item("MenuRImage")
            ImgButtonRight.Visible = True
        Else
            ImgButtonRight.Visible = False
        End If
        Background = Session.Item("MenuMImage")
        If URL = "" And ButtonText = "" Then
            ImgButtonRight.Visible = False
            ImgButtonLeft.Visible = False
        End If
        MyArticle.CloseConn()
    End Sub

    Public Sub New()
        ImgButtonLeft = New System.Web.UI.WebControls.Image
        ImgButtonRight = New System.Web.UI.WebControls.Image
    End Sub
End Class
