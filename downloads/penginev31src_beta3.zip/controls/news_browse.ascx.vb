Imports pengine.Data

Public Class news_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptNews As System.Web.UI.WebControls.Repeater
    Protected WithEvents btnprevtop As System.Web.UI.WebControls.Button
    Protected WithEvents btnnexttop As System.Web.UI.WebControls.Button
    Protected WithEvents btnprevbot As System.Web.UI.WebControls.Button
    Protected WithEvents btnnextbot As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyPrevPageURL As String = ""
    Public MyNextPageURL As String = ""
    Public MyNewButtonHTML As String = ""
    Private AdminFlag As Boolean
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        AdminFlag = Session.Item("admin")
        Dim NewsData As DataSet
        Dim RowPtr As Integer = 0
        Dim MyPage As Integer
        Dim MyNews As News = New News(Application.Item("ConnectionString"))
        If IsNumeric(Request.Item("page")) Then
            MyPage = Request.Item("page")
        Else
            MyPage = 1
        End If
        If MyPage > 0 And MyPage <= Application.Item("LastNewsPage") Then
            NewsData = MyNews.ReadXML(Application.Item("cachefile_news_page" & MyPage))
        Else
            NewsData = MyNews.ReadXML(Application.Item("cachefile_news_page1"))
        End If

        If MyPage > 1 Then
            MyPrevPageURL = "default.aspx?cmd=news&sub=browse&page=" & System.Convert.ToString(MyPage - 1)
            btnprevbot.Enabled = True
            btnprevtop.Enabled = True
        Else
            MyPrevPageURL = ""
            btnprevbot.Enabled = False
            btnprevtop.Enabled = False
        End If
        If MyPage < Application.Item("LastNewsPage") Then
            MyNextPageURL = "default.aspx?cmd=news&sub=browse&page=" & System.Convert.ToString(MyPage + 1)
            btnnextbot.Enabled = True
            btnnexttop.Enabled = True
        Else
            MyNextPageURL = ""
            btnnextbot.Enabled = False
            btnnexttop.Enabled = False
        End If
        If Session.Item("admin") = True Then
            MyNewButtonHTML = Article.CreateHTMLButton("./default.aspx?cmd=news&sub=edit", "Create Story", "")
        End If
        viewstate("nextpage") = MyNextPageURL
        viewstate("prevpage") = MyPrevPageURL
        RptNews.DataSource = NewsData
        RptNews.DataBind()
        MyNews.CloseConn()
        Session.Item("LastNewsBrowse") = Request.Url.ToString
    End Sub

    Public Sub NewsAction(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            If ID > 0 Then
                Select Case e.CommandName.ToLower()
                    Case "edit"
                        Response.Redirect("default.aspx?cmd=news&sub=edit&id=" & ID)
                    Case "delete"
                        Dim MyNews As News = New News(Application.Item("ConnectionString"))
                        MyNews.DeleteNews(ID)
                        MyNews.CloseConn()
                        pengine.Global.RebuildNewsCache()
                        Page_Load(Nothing, Nothing)
                End Select
            End If
        End If
    End Sub

    Private Sub btnprevtop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevtop.Click
        Response.Redirect(viewstate("prevpage"))
    End Sub

    Private Sub btnprevbot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprevbot.Click
        Response.Redirect(viewstate("prevpage"))
    End Sub

    Private Sub btnnexttop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnexttop.Click
        Response.Redirect(viewstate("nextpage"))
    End Sub

    Private Sub btnnextbot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnextbot.Click
        Response.Redirect(viewstate("nextpage"))
    End Sub

    Private Sub RptNews_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptNews.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndelete")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the story """ & Server.HtmlEncode(data.Item("title")) & """?');")
            End If
        End If
    End Sub
End Class
