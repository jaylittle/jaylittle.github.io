Imports pengine.Data

Public Class file_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblerror As System.Web.UI.WebControls.Label
    Protected WithEvents lstlocation As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lblsublocation As System.Web.UI.WebControls.Label
    Protected WithEvents lstsublocation As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtcurrentlocation As System.Web.UI.WebControls.TextBox
    Protected WithEvents btncut As System.Web.UI.WebControls.Button
    Protected WithEvents btnpaste As System.Web.UI.WebControls.Button
    Protected WithEvents btndelete As System.Web.UI.WebControls.Button
    Protected WithEvents txtcreate As System.Web.UI.WebControls.TextBox
    Protected WithEvents btncreate As System.Web.UI.WebControls.Button
    Protected WithEvents txtrename As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnrename As System.Web.UI.WebControls.Button
    Protected WithEvents btnupload As System.Web.UI.WebControls.Button
    Protected WithEvents File1 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents rptfiles As System.Web.UI.WebControls.Repeater
    Protected WithEvents lblstats As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyOutputHTML As String
    Public MyCurrentLocation As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyArticle As Article
        Dim CurDir As System.IO.DirectoryInfo
        Dim FileList() As System.IO.FileInfo
        Dim DirList() As System.IO.DirectoryInfo
        Dim DirPtr As Integer
        Dim FilePtr As Integer
        Dim CSSCellID As String
        Dim CSSTextID As String
        lblerror.Text = ""
        MyOutputHTML = ""
        MyCurrentLocation = ""
        MyArticle = New Article(Application.Item("ConnectionString"))
        If Not IsPostBack Then
            lstlocation.Items.Add(New ListItem("icons", Application("basepath") & "images/icons/"))
            lstlocation.Items.Add(New ListItem("article images", Application("basepath") & "images/articles/"))
            lstlocation.Items.Add(New ListItem("system images", Application("basepath") & "images/system/"))
            lstlocation.Items.Add(New ListItem("downloads", Application("basepath") & "downloads/"))
            If Session("lastuploadlocationindex") > -1 And Session("lastuploadlocation") <> "" Then
                lstlocation.Items(Session("lastuploadlocationindex")).Selected = True
                txtcurrentlocation.Text = Session("lastuploadlocation")
                Session.Item("lastuploadlocationindex") = -1
                Session.Item("lastuploadlocation") = ""
            Else
                lstlocation.Items(0).Selected = True
                txtcurrentlocation.Text = Server.MapPath(lstlocation.SelectedItem.Value)
            End If
            If txtcurrentlocation.Text.EndsWith("\") = False Then
                txtcurrentlocation.Text &= "\"
            End If
            lstsublocation.Visible = False
            lblsublocation.Visible = False
            CurDir = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
            DirList = CurDir.GetDirectories
            If txtcurrentlocation.Text.Replace(Server.MapPath(lstlocation.SelectedItem.Value), "") <> "" Then
                FillSubLocations(DirList, True)
            Else
                FillSubLocations(DirList, False)
            End If
        End If
        CurDir = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
        DirList = CurDir.GetDirectories
        FileList = CurDir.GetFiles
        MyCurrentLocation = txtcurrentlocation.Text.Replace(Server.MapPath(Application("basepath")), "./").Replace("\", "/")
        If MyCurrentLocation.EndsWith("/") = False Then
            MyCurrentLocation &= "/"
        End If
        Session.Item("lastuploadlocation") = txtcurrentlocation.Text
        Session.Item("lastuploadlocationindex") = lstlocation.SelectedIndex
        rptfiles.DataSource = FileList
        rptfiles.DataBind()
        lblstats.Text = System.Convert.ToString(DirList.GetUpperBound(0) + 1) & " sub-directories found.<br>"
        lblstats.Text &= System.Convert.ToString(FileList.GetUpperBound(0) + 1) & " files found.<br>"
        MyArticle.CloseConn()
        If Session.Item("uploadcopylocation") <> "" And Session.Item("uploadcopytype") <> "" Then
            btnpaste.Enabled = True
        Else
            btnpaste.Enabled = False
        End If
        FileList = Nothing
        DirList = Nothing
        CurDir = Nothing
    End Sub

    Public Function GetFileURL(ByVal FileName As String) As String
        Return Application.Item("basepath") & MyCurrentLocation & FileName
    End Function

    Private Sub lstlocation_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstlocation.SelectedIndexChanged
        Dim CurDir As System.IO.DirectoryInfo
        Dim DirList() As System.IO.DirectoryInfo
        txtcurrentlocation.Text = Server.MapPath(lstlocation.SelectedItem.Value)
        CurDir = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
        DirList = CurDir.GetDirectories()
        Call FillSubLocations(DirList, False)
        Call Page_Load(sender, e)
    End Sub

    Private Sub lstsublocation_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstsublocation.SelectedIndexChanged
        Dim DirInfo As System.IO.DirectoryInfo = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
        Dim CurDir As System.IO.DirectoryInfo
        Dim DirList() As System.IO.DirectoryInfo
        If lstsublocation.SelectedItem.Text = ".." Then
            txtcurrentlocation.Text = DirInfo.Parent.FullName & "\"
        ElseIf lstsublocation.SelectedItem.Text <> "" Then
            txtcurrentlocation.Text = DirInfo.GetDirectories(lstsublocation.SelectedItem.Text)(0).FullName
        End If
        CurDir = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
        DirList = CurDir.GetDirectories()
        If txtcurrentlocation.Text.Replace(Server.MapPath(lstlocation.SelectedItem.Value), "") <> "" Then
            Call FillSubLocations(DirList, True)
        Else
            Call FillSubLocations(DirList, False)
        End If
        Call Page_Load(sender, e)
        CurDir = Nothing
    End Sub

    Private Sub btnupload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupload.Click
        Dim FileInfo As System.IO.FileInfo
        If Request.Files.Count > 0 Then
            Request.Files(0).SaveAs(txtcurrentlocation.Text & GetFileName(Request.Files(0).FileName))
        End If
        Call Page_Load(sender, e)
    End Sub

    Sub FillSubLocations(ByVal DirList() As System.IO.DirectoryInfo, ByVal ShowParentFlag As Boolean)
        Dim DirPtr As Integer
        lstsublocation.Visible = True
        lblsublocation.Visible = True
        lstsublocation.Items.Clear()
        lstsublocation.Items.Add("")
        If ShowParentFlag = True Then
            lstsublocation.Items.Add("..")
            btndelete.Enabled = True
            btncut.Enabled = True
        Else
            btndelete.Enabled = False
            btncut.Enabled = False
        End If
        For DirPtr = 0 To DirList.GetUpperBound(0)
            lstsublocation.Items.Add(New ListItem(DirList(DirPtr).Name, DirList(DirPtr).Name))
        Next
        lstsublocation.Items(0).Selected = True
    End Sub

    Function GetFileName(ByVal FullPath As String)
        Dim CharPtr As Integer
        CharPtr = InStrRev(FullPath, "\")
        If CharPtr > -1 Then
            GetFileName = FullPath.Substring(CharPtr, FullPath.Length - CharPtr)
        Else
            GetFileName = FullPath
        End If
    End Function

    Private Sub btnpaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpaste.Click
        If Session.Item("uploadcopytype") = "file" Then
            Dim FileInfo As System.IO.FileInfo
            Dim TargetInfo As System.IO.FileInfo
            Dim TargetFileName As String
            FileInfo = New System.IO.FileInfo(Session.Item("uploadcopylocation") & Session.Item("uploadcopyfile"))
            TargetInfo = New System.IO.FileInfo(txtcurrentlocation.Text & Session.Item("uploadcopyfile"))
            TargetFileName = Session("uploadcopyfile")
            If FileInfo.Exists Then
                While TargetInfo.Exists
                    TargetFileName = "Copy of " & TargetFileName
                    TargetInfo = New System.IO.FileInfo(txtcurrentlocation.Text & TargetFileName)
                End While
                FileInfo.CopyTo(txtcurrentlocation.Text & TargetFileName)
            End If
        Else
            Dim DirInfo As System.IO.DirectoryInfo
            DirInfo = New System.IO.DirectoryInfo(Session.Item("uploadcopylocation"))
            DirInfo.MoveTo(txtcurrentlocation.Text & DirInfo.Name)
            DirInfo = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
            If txtcurrentlocation.Text.Replace(Server.MapPath(lstlocation.SelectedItem.Value), "") <> "" Then
                FillSubLocations(DirInfo.GetDirectories, True)
            Else
                FillSubLocations(DirInfo.GetDirectories, False)
            End If
        End If
        Session("uploadcopyfile") = ""
        Session("uploadcopylocation") = ""
        Session("uploadcopytype") = ""
        Call Page_Load(Nothing, Nothing)
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Dim DirInfo As System.IO.DirectoryInfo
        Dim NewLocation As String
        DirInfo = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
        NewLocation = DirInfo.Parent.FullName
        If DirInfo.Exists = True Then
            DirInfo.Delete(True)
            Session("lastuploadlocation") = NewLocation
            Session("lastuploadlocationindex") = lstlocation.SelectedIndex
            Response.Redirect(Application.Item("basepath") & "admin/browsefiles.aspx")
        End If
    End Sub

    Private Sub btncut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncut.Click
        Session("uploadcopytype") = "folder"
        Session("uploadcopylocation") = txtcurrentlocation.Text
        Session("uploadcopyfile") = ""
    End Sub

    Private Sub btncreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncreate.Click
        Dim DirInfo As System.IO.DirectoryInfo
        If txtcreate.Text <> "" Then
            DirInfo = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
            DirInfo.CreateSubdirectory(txtcreate.Text)
            txtcreate.Text = ""
            If txtcurrentlocation.Text.Replace(Server.MapPath(lstlocation.SelectedItem.Value), "") <> "" Then
                FillSubLocations(DirInfo.GetDirectories, True)
            Else
                FillSubLocations(DirInfo.GetDirectories, False)
            End If
            Call Page_Load(sender, e)
        Else
            lblerror.Text = "You must specify a name for the new directory.|"
        End If
    End Sub

    Private Sub btnrename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrename.Click
        Dim DirInfo As System.IO.DirectoryInfo
        Dim TempInfo As System.IO.DirectoryInfo
        Dim NewLocation As String
        Dim TargetLocation As String
        Dim TempLocation As String
        TempLocation = Server.MapPath(Application("basepath")) & "\temp"
        DirInfo = New System.IO.DirectoryInfo(txtcurrentlocation.Text)
        TempInfo = New System.IO.DirectoryInfo(TempLocation)
        If TempInfo.Exists = False Then
            System.IO.Directory.CreateDirectory(TempLocation)
        End If
        NewLocation = DirInfo.Parent.FullName
        If txtrename.Text <> "" Then
            TargetLocation = NewLocation & "\" & txtrename.Text
            If DirInfo.Exists = True Then
                System.IO.Directory.Move(txtcurrentlocation.Text, TempLocation & "\" & txtrename.Text)
                System.IO.Directory.Move(TempLocation & "\" & txtrename.Text, TargetLocation)
                Session("lastuploadlocation") = TargetLocation & "\"
                Session("lastuploadlocationindex") = lstlocation.SelectedIndex
                Response.Redirect(Application.Item("basepath") & "admin/browsefiles.aspx")
            End If
        Else
            lblerror.Text = "You must specify what the new name for the directory will be.|"
        End If
    End Sub

    Public Sub FileAction(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim File As String = e.CommandArgument
        If File.Length > 0 Then
            Select Case e.CommandName.ToLower()
                Case "rename"
                    Response.Redirect("default.aspx?cmd=file&sub=edit&file=" & File)
                Case "copy"
                    Session("uploadcopytype") = "file"
                    Session("uploadcopylocation") = txtcurrentlocation.Text
                    Session("uploadcopyfile") = File
                Case "delete"
                    IO.File.Delete(txtcurrentlocation.Text & File)
                    Call Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Private Sub rptfiles_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptfiles.ItemDataBound
        Dim btndelete As Button
        Dim data As IO.FileInfo = e.Item.DataItem
        btndelete = e.Item.FindControl("btnfiledelete")
        If Not btndelete Is Nothing Then
            btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the file """ & Server.HtmlEncode(data.Name) & """?');")
        End If
    End Sub
End Class
