Imports pengine.Data

Public Class msg_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptMessages As System.Web.UI.WebControls.Repeater
    Protected WithEvents btnReply As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyForum As Forum
    Public MyAddReplyButtonHTML As String = ""
    Public MyForumName As String = ""
    Public MyForumLinkHTML As String = ""
    Public MyForumID As Integer
    Public MyThreadName As String = ""
    Public MyThreadPosts As Integer
    Public MyThreadID As Integer
    Public MyPage As Integer = -1
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MessageData As DataSet
        Dim FoundPostFlag As Boolean
        MyForum = New Forum(Application("FConnectionString"))
        If Request.Item("threadid") <> "" And IsNumeric(Request.Item("threadid")) Then
            MyThreadID = Request.Item("threadid")
            MyThreadName = MyForum.GetThreadName(Request.Item("threadid"))
            MyThreadPosts = MyForum.GetThreadPosts(Request.Item("threadid"))
            MyForumID = MyForum.GetThreadForumID(Request.Item("threadid"))
            MyForumName = MyForum.GetForumName(MyForumID)
            viewstate("forumid") = MyForumID
            viewstate("threadid") = MyThreadID
            MyForumLinkHTML = "<a href=""default.aspx?cmd=thread&sub=browse&forumid=" & System.Convert.ToString(MyForumID) & """>" & MyForumName & "</a>"
            If Request.Item("page") = "" Or IsNumeric(Request.Item("page")) = False Then
                If Request.Item("postid") <> "" And IsNumeric(Request.Item("page")) Then
                    MyPage = MyForum.GetMessagePageNum(Request.Item("postid"), Application.Item("forumpostsperpage"))
                    MessageData = MyForum.GetMessages(Request.Item("threadid") _
                    , (MyPage - 1) * Application.Item("forumpostsperpage"), Application.Item("forumpostsperpage"))
                Else
                    MyPage = 1
                    MessageData = MyForum.GetMessages(Request.Item("threadid"), -1, Application.Item("forumpostsperpage"))
                End If
            Else
                MyPage = Request.Item("page")
                MessageData = MyForum.GetMessages(Request.Item("threadid") _
                , (MyPage - 1) * Application.Item("forumpostsperpage"), Application.Item("forumpostsperpage"))
            End If
            If Session.Item("forumloggedin") = True Then
                btnReply.Visible = True
            Else
                btnReply.Visible = False
            End If
            RptMessages.DataSource = MessageData
            RptMessages.DataBind()
        End If
        MyForum.CloseConn()
    End Sub

    Public Sub MessageAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim td As HtmlTableCell
        Dim ID As Integer
        Dim ParentID As Integer
        Dim ForumID As Integer
        td = e.Item.FindControl("tdid")
        If Not td Is Nothing Then
            ID = td.InnerText
        End If
        td = e.Item.FindControl("tdthreadid")
        If Not td Is Nothing Then
            ParentID = td.InnerText
        End If
        td = e.Item.FindControl("tdforumid")
        If Not td Is Nothing Then
            ForumID = td.InnerText
        End If
        If ID > 0 And ParentID > 0 And ForumID > 0 Then
            Select Case e.CommandName.ToLower()
                Case "edit"
                    Response.Redirect("default.aspx?cmd=msg&sub=edit&id=" & ID)
                Case "reply"
                    Response.Redirect("default.aspx?cmd=msg&sub=edit&forumid=" & ForumID & "&parentid=" & ParentID & "&replyid=" & ID)
            End Select
        End If
    End Sub

    Public Function CanEditMessage(ByVal UserIDA As Integer, ByVal UserIDB As Integer, ByVal AdminFlag As Boolean)
        If UserIDA = UserIDB Or AdminFlag = True Then
            Return True
        End If
        Return False
    End Function

    Private Sub btnReply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReply.Click
        Response.Redirect("default.aspx?cmd=msg&sub=edit&forumid=" & System.Convert.ToString(viewstate("forumid")) & "&parentid=" & System.Convert.ToString(viewstate("threadid")))
    End Sub
End Class
