Imports pengine.Data

Public Class news_edit
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents lbltitle As System.Web.UI.WebControls.Label
    Protected WithEvents txttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbliconfilename As System.Web.UI.WebControls.Label
    Protected WithEvents lsticonfilename As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbldatetime As System.Web.UI.WebControls.Label
    Protected WithEvents txtdatetime As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbltext As System.Web.UI.WebControls.Label
    Protected WithEvents txttext As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyNews As News
        Dim NewsData As DataSet = New DataSet
        Dim IconList As ArrayList = New ArrayList
        Dim IconPtr As Integer = 0
        MyNews = New News(Application.Item("ConnectionString"))
        If txtid.Text = "" Then
            txtid.Text = Request.Item("id")
        End If
        If Not IsPostBack Then
            Session("standardforward") = ""
            IconList = MyNews.GetIconList
            lsticonfilename.Items.Clear()
            lsticonfilename.Items.Add("")
            For IconPtr = 0 To IconList.Count - 1
                lsticonfilename.Items.Add(New ListItem(IconList.Item(IconPtr)))
            Next
            If (txtid.Text <> "" And IsNumeric(txtid.Text)) Then
                Session("standardforward") = "default.aspx?cmd=news&sub=display&id=" & txtid.Text
                NewsData = MyNews.GetNews(txtid.Text)
                If NewsData.Tables(0).Rows.Count > 0 Then
                    txttitle.Text = NewsData.Tables(0).Rows(0).Item("title")
                    txtdatetime.Text = NewsData.Tables(0).Rows(0).Item("timeposted")
                    txttext.Text = NewsData.Tables(0).Rows(0).Item("articledata")
                    For IconPtr = 0 To lsticonfilename.Items.Count - 1
                        If lsticonfilename.Items(IconPtr).Text = NewsData.Tables(0).Rows(0).Item("iconfilename") Then
                            lsticonfilename.Items(IconPtr).Selected = True
                        End If
                    Next
                End If
            Else
                txttitle.Text = ""
                txtdatetime.Text = DateTime.Now
                txttext.Text = ""
                txtid.Text = "-1"
            End If
        End If
        If txtid.Text <> "-1" Then
            MyTitle = "Editing News Story #" & txtid.Text
        Else
            MyTitle = "Creating a News Story"
        End If
        MyNews.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyNews As News
        Dim ErrorText As String
        Dim CacheFlag As Boolean
        MyNews = New News(Application.Item("ConnectionString"))
        If IsDate(txtdatetime.Text) And txtdatetime.Text <> "" Then
            ErrorText = MyNews.SaveNews(txtid.Text, txttitle.Text, txtdatetime.Text, txttext.Text, lsticonfilename.SelectedItem.Text)
            If ErrorText <> "" Then
                lblerrors.Text = ErrorText.Replace("|", "<br>")
            Else
                lblerrors.Text = "Your changes were saved successfully."
                MyTitle = "Editing News Story #" & txtid.Text
                CacheFlag = True
            End If
        Else
            lblerrors.Text = "The Date/Time value you provided is in an incorrect format.  It should be (MM/DD/YYYY HH:MM:SS)."
        End If
        MyNews.CloseConn()
        If CacheFlag = True Then
            pengine.Global.RebuildNewsCache()
        End If
    End Sub
End Class
