Imports pengine.Data
Imports System.Data.OleDB
Public Class menu
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PLHButtons As System.Web.UI.WebControls.PlaceHolder

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyMenuSize As Integer = 0
    Public ArticleID As Integer = 0
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ctlButton As Control
        Dim DtrCats As DataSet
        Dim MyArticle As Article = New Article(Application.Item("ConnectionString"))
        Dim ArticleData As DataSet
        Dim ArticleSectionList As DataSet
        Dim ArticleMenuIsHidden As Boolean
        Dim SectionPtr As Integer
        Dim RowPtr As Integer = 0

        MyMenuSize = Application.Item("menusize")

        'Display Home Button
        ctlButton = LoadControl("menu_button.ascx")
        CType(ctlButton, menu_button).ButtonText = Application.Item("homelabel")
        CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx"
        PLHButtons.Controls.Add(ctlButton)

        'Display Theme Button
        If Application.Item("ExcludeTheme") = 0 Then
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = Application.Item("themelabel")
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=theme&sub=select"
            PLHButtons.Controls.Add(ctlButton)
        End If

        'Display Resume Button
        If Application.Item("ExcludeResume") = 0 Then
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = Application.Item("resumelabel")
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=resume&sub=display"
            PLHButtons.Controls.Add(ctlButton)
        End If

        'Display Article Category buttons
        If Session.Item("admin") = True Then
            DtrCats = MyArticle.ReadXML(Application.Item("cachefile_categories_admin"))
        Else
            DtrCats = MyArticle.ReadXML(Application.Item("cachefile_categories"))
        End If
        While RowPtr < DtrCats.Tables(0).Rows.Count
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = DtrCats.Tables(0).Rows(RowPtr).Item("category")
            If DtrCats.Tables(0).Rows(RowPtr).Item("http") & "" <> "" Then
                CType(ctlButton, menu_button).URL = DtrCats.Tables(0).Rows(RowPtr).Item("http")
            Else
                CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=article&sub=browse&category=" & Server.UrlEncode(DtrCats.Tables(0).Rows(RowPtr)("category"))
            End If
            PLHButtons.Controls.Add(ctlButton)
            RowPtr += 1
        End While

        'Display Admin mode Buttons
        If Session.Item("admin") = False Then
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = Application.Item("adminlabel")
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=login&mode=admin"
            PLHButtons.Controls.Add(ctlButton)
        Else
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = ""
            CType(ctlButton, menu_button).URL = ""
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = "New Article"
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=article&sub=edit"
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = "Settings"
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=settings&sub=edit"
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = "Uploader"
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=file&sub=browse"
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = Application.Item("adminlabel2")
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=logout"
            PLHButtons.Controls.Add(ctlButton)
        End If

        'Display Other Functionality Buttons (Forums and Elite)
        If Application.Item("forum") = True Then
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = ""
            CType(ctlButton, menu_button).URL = ""
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = "Forums"
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=forum&sub=browse"
            PLHButtons.Controls.Add(ctlButton)
        End If

        If Application.Item("excludeleet") = 0 Then
            ctlButton = LoadControl("menu_button.ascx")
            If Session("leetflag") = False Then
                CType(ctlButton, menu_button).ButtonText = Application.Item("leetlabel")
            Else
                CType(ctlButton, menu_button).ButtonText = Application.Item("leetlabel2")
            End If
            CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=elite"
            PLHButtons.Controls.Add(ctlButton)
        End If

        If ArticleID > 0 Then
            'Display Article Section buttons
            ArticleData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID))
            ArticleMenuIsHidden = ArticleData.Tables(0).Rows(0).Item("hidebuttons")
            If ArticleMenuIsHidden = False Then
                ArticleSectionList = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID & "_sectionlist"))
                ctlButton = LoadControl("menu_button.ascx")
                CType(ctlButton, menu_button).ButtonText = ""
                CType(ctlButton, menu_button).URL = ""
                PLHButtons.Controls.Add(ctlButton)
                If ArticleSectionList.Tables(0).Rows.Count > 1 Then
                    For SectionPtr = 0 To ArticleSectionList.Tables(0).Rows.Count - 1
                        ctlButton = LoadControl("menu_button.ascx")
                        CType(ctlButton, menu_button).ButtonText = ArticleSectionList.Tables(0).Rows(SectionPtr).Item("Name")
                        CType(ctlButton, menu_button).URL = Application.Item("basepath") & "default.aspx?cmd=article&sub=display&id=" _
                        & System.Convert.ToString(ArticleID) & "&section=" & ArticleSectionList.Tables(0).Rows(SectionPtr).Item("Name")
                        PLHButtons.Controls.Add(ctlButton)
                    Next
                End If
            End If
        End If
        MyArticle.CloseConn()

        'Display Quote Button if applicable
        If Application.Item("excludequotes") = 0 And Request.RawUrl.ToLower().EndsWith("default.aspx") Then
            ctlButton = LoadControl("menu_button.ascx")
            CType(ctlButton, menu_button).ButtonText = Application.Item("themelabel")
            CType(ctlButton, menu_button).LinkHTML = "<a href=""#"" onClick=""javascript:flipObject('divQuote',event);"" " _
            & "><span class=""menutext"">Quote</span></a>"
            '"onMouseOut=""javascript:hideObject('divQuote',event);""
            PLHButtons.Controls.Add(ctlButton)
        End If
    End Sub

End Class
