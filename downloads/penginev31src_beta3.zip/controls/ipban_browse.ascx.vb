Imports pengine.Data

Public Class ipban_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptIPBans As System.Web.UI.WebControls.Repeater
    Protected WithEvents btnnewipban As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim IPBanData As DataSet
        Dim MyForum As Forum
        MyForum = New Forum(Application("FConnectionString"))
        IPBanData = MyForum.GetIPBans
        RptIPBans.DataSource = IPBanData
        RptIPBans.DataBind()
        MyForum.CloseConn()
    End Sub

    Public Sub IPBanAction(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        Dim td As HtmlTableCell
        Dim IP As String = ""
        td = e.Item.FindControl("tdip")
        If Not td Is Nothing Then
            IP = td.InnerText
        End If
        If IP.Length > 0 Then
            Select Case e.CommandName.ToLower()
                Case "delete"
                    Dim MyForum As Forum
                    Dim Result As Boolean
                    MyForum = New Forum(Application.Item("FConnectionString"))
                    Result = MyForum.DeleteIPBan(IP)
                    MyForum.CloseConn()
                    Page_Load(Nothing, Nothing)
            End Select
        End If
    End Sub

    Private Sub btnnewipban_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnewipban.Click
        Response.Redirect("default.aspx?cmd=ipban&sub=edit")
    End Sub

    Private Sub RptIPBans_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptIPBans.ItemDataBound
        Dim btndelete As Button
        Dim data As DataRowView = e.Item.DataItem
        btndelete = e.Item.FindControl("btndeleteipban")
        If Not btndelete Is Nothing Then
            btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the ban for IP " & data.Item("IP") & "?');")
        End If
    End Sub
End Class
