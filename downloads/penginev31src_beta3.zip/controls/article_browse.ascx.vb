Imports pengine.Data

Public Class article_browse
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptArticles As System.Web.UI.WebControls.Repeater
    Protected WithEvents btnnew As System.Web.UI.WebControls.Button
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyNewButtonHTML As String
    Private AdminFlag As Boolean
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        AdminFlag = Session.Item("admin")
        Dim ArticlesData As DataSet
        Dim ArticlesInCategory As Integer = 0
        Dim ArticleID As Integer = 0
        Dim RowPtr As Integer = 0
        Dim CategoryName As String
        Dim header As pengine.header
        If Request.Item("category") <> "" Then
            CategoryName = Request.Item("category")
        Else
            CategoryName = "all"
        End If
        Dim MyArticle As Article = New Article(Application("ConnectionString"))
        If Session.Item("admin") = True Then
            ArticlesData = MyArticle.ReadXML(Application.Item("cachefile_cat_" & CategoryName & "_file_admin"))
        Else
            ArticlesData = MyArticle.ReadXML(Application.Item("cachefile_cat_" & CategoryName & "_file"))
        End If
        ArticlesInCategory = ArticlesData.Tables(0).Rows.Count
        If Session.Item("admin") = True Then
            MyNewButtonHTML = MyArticle.CreateHTMLButton("./default.aspx?cmd=article&sub=edit", "Create Article", "")
        End If
        If ArticlesInCategory > 1 Or Session.Item("admin") = True Then
            RptArticles.DataSource = ArticlesData
            RptArticles.DataBind()
        Else
            While RowPtr < ArticlesData.Tables(0).Rows.Count
                ArticleID = ArticlesData.Tables(0).Rows(RowPtr).Item("ID")
                RowPtr += 1
            End While
            If Session.Item("admin") = False Then
                Response.Redirect("default.aspx?cmd=article&sub=display&id=" & System.Convert.ToString(ArticleID))
            End If
        End If
        Session.Item("LastArticlesBrowse") = Request.Url.ToString
        header = Me.Page.FindControl("header1")
        If Not header Is Nothing Then
            header.ArticleCategory = Request.Item("category")
        End If
        MyArticle.CloseConn()
    End Sub

    Public Sub ArticleAction(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs)
        If AdminFlag = True Then
            Dim ID As Integer = e.CommandArgument
            If ID > 0 Then
                Select Case e.CommandName.ToLower()
                    Case "edit"
                        Response.Redirect("default.aspx?cmd=article&sub=edit&id=" & ID)
                    Case "delete"
                        Dim MyArticle As pengine.Data.Article
                        Dim Result As Boolean
                        MyArticle = New Article(Application.Item("ConnectionString"))
                        Result = MyArticle.DeleteArticle(Request.Item("ID"))
                        MyArticle.WriteXML(MyArticle.CategoryList(True), Application.Item("cachefile_categories_admin"))
                        MyArticle.WriteXML(MyArticle.CategoryList(False), Application.Item("cachefile_categories"))
                        MyArticle.CloseConn()
                        pengine.Global.RebuildArticleCache()
                        Page_Load(Nothing, Nothing)
                End Select
            End If
        End If
    End Sub

    Private Sub RptArticles_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles RptArticles.ItemDataBound
        If AdminFlag = True Then
            Dim btndelete As Button
            Dim data As DataRowView = e.Item.DataItem
            btndelete = e.Item.FindControl("btndelete")
            If Not btndelete Is Nothing Then
                btndelete.Attributes.Add("OnClick", "javascript:return confirmform('" & "Are you sure you want to delete the article """ & Server.HtmlEncode(data.Item("name")) & """?');")
            End If
        End If
    End Sub
End Class
