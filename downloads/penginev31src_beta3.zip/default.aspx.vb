Public Class _default1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents plcContent As System.Web.UI.WebControls.PlaceHolder

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim cmd As String = ""
        Dim scmd As String = ""
        Dim CurControl As UserControl
        If Not Request.Item("cmd") Is Nothing Then
            cmd = CType(Request.Item("cmd"), String).Trim().ToLower()
        End If
        If Not Request.Item("sub") Is Nothing Then
            scmd = CType(Request.Item("sub"), String).Trim().ToLower()
        End If
        Select Case cmd
            Case "", "overview"
                CurControl = LoadControl("./controls/overview.ascx")
            Case "news"
                Select Case scmd
                    Case "", "display"
                        CurControl = LoadControl("./controls/news_display.ascx")
                    Case "edit"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/news_edit.ascx")
                    Case "browse"
                        CurControl = LoadControl("./controls/news_browse.ascx")
                End Select
            Case "article"
                Select Case scmd
                    Case "", "display"
                        CurControl = LoadControl("./controls/article_display.ascx")
                    Case "edit"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/article_edit.ascx")
                    Case "browse"
                        CurControl = LoadControl("./controls/article_browse.ascx")
                End Select
            Case "file"
                Select Case scmd
                    Case "", "edit"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/file_edit.ascx")
                    Case "browse"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/file_browse.ascx")
                End Select
            Case "resume"
                Select Case scmd
                    Case "", "display"
                        CurControl = LoadControl("./controls/resume_display.ascx")
                    Case "editskill"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/resume_editskill.ascx")
                    Case "editeducation"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/resume_editeducation.ascx")
                    Case "editobjective"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/resume_editobjective.ascx")
                    Case "editpersonal"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/resume_editpersonal.ascx")
                    Case "editworkhistory"
                        CheckSecurity(Access.Admin)
                        CurControl = LoadControl("./controls/resume_editworkhistory.ascx")
                End Select
            Case "theme"
                Select Case scmd
                    Case "", "select"
                        CurControl = LoadControl("./controls/theme_select.ascx")
                End Select
            Case "settings"
                Select Case scmd
                    Case "", "edit"
                        CurControl = LoadControl("./controls/settings_edit.ascx")
                End Select
            Case "forum"
                Select Case scmd
                    Case "edit"
                        CheckSecurity(Access.ForumAdmin)
                        CurControl = LoadControl("./controls/forum_edit.ascx")
                    Case "browse"
                        CurControl = LoadControl("./controls/forum_browse.ascx")
                End Select
            Case "thread"
                CurControl = LoadControl("./controls/thread_browse.ascx")
            Case "account"
                Select Case scmd
                    Case "browse"
                        CheckSecurity(Access.ForumAdmin)
                        CurControl = LoadControl("./controls/account_browse.ascx")
                    Case "create"
                        CurControl = LoadControl("./controls/account_create.ascx")
                    Case "edit"
                        CheckSecurity(Access.ForumAdmin)
                        CurControl = LoadControl("./controls/account_edit.ascx")
                End Select
            Case "ipban"
                Select Case scmd
                    Case "browse", ""
                        CheckSecurity(Access.ForumAdmin)
                        CurControl = LoadControl("./controls/ipban_browse.ascx")
                    Case "edit"
                        CheckSecurity(Access.ForumAdmin)
                        CurControl = LoadControl("./controls/ipban_edit.ascx")
                End Select
            Case "msg"
                Select Case scmd
                    Case "edit"
                        CheckSecurity(Access.Forum)
                        CurControl = LoadControl("./controls/msg_edit.ascx")
                    Case "browse"
                        CurControl = LoadControl("./controls/msg_browse.ascx")
                End Select
            Case "profile"
                Select Case scmd
                    Case "display"
                        CurControl = LoadControl("./controls/profile_display.ascx")
                    Case "edit"
                        CheckSecurity(Access.Forum)
                        CurControl = LoadControl("./controls/profile_edit.ascx")
                End Select
            Case "search"
                CurControl = LoadControl("./controls/search_display.ascx")
            Case "login"
                CurControl = LoadControl("./controls/login.ascx")
            Case "logout"
                CurControl = LoadControl("./controls/logout.ascx")
            Case "elite"
                CurControl = LoadControl("./controls/elite.ascx")
            Case "denied"
                CurControl = LoadControl("./controls/denied.ascx")
            Case Else
                CurControl = LoadControl("./controls/notfound.ascx")
        End Select
        If Not CurControl Is Nothing Then
            CheckViewState(cmd, scmd)
            plcContent.Controls.Add(CurControl)
        End If
    End Sub

    Enum Access
        Admin
        Forum
        ForumAdmin
    End Enum

    Sub CheckSecurity(ByVal ALevel As Access)
        Dim DenyFlag As Boolean = True
        Select Case ALevel
            Case Access.Admin
                If Not Session("admin") Is Nothing Then
                    If Session("admin") = True Then
                        DenyFlag = False
                    End If
                End If
            Case Access.Forum
                If Not Session("forumloggedin") Is Nothing Then
                    If Session("forumloggedin") = True Then
                        DenyFlag = False
                    End If
                End If
            Case Access.ForumAdmin
                If Not Session("forumadmin") Is Nothing Then
                    If Session("forumadmin") = True Then
                        DenyFlag = False
                    End If
                End If
        End Select
        If DenyFlag = True Then
            Response.Redirect("default.aspx?cmd=denied")
        End If
    End Sub

    Sub CheckViewState(ByVal cmd As String, ByVal scmd As String)
        Dim AdminFlag As Boolean = False
        Dim ViewStateFlag As Boolean = False
        If Not Session("admin") Is Nothing Then
            If Session("admin") = True Then
                AdminFlag = True
            End If
        End If
        If AdminFlag = True Then
            ViewStateFlag = True
        Else
            Select Case cmd
                Case "forum", "msg", "thread", "login", "logout"
                    Me.EnableViewState = True
                Case "profile"
                    Select Case scmd
                        Case "edit"
                            ViewStateFlag = True
                    End Select
                Case "account"
                    Select Case scmd
                        Case "create"
                            ViewStateFlag = True
                    End Select
                Case "article"
                    Select Case scmd
                        Case "display", ""
                            ViewStateFlag = True
                    End Select
                Case "theme"
                    Select Case scmd
                        Case "select", ""
                            ViewStateFlag = True
                    End Select
            End Select
        End If
        Me.EnableViewState = ViewStateFlag
    End Sub

End Class
