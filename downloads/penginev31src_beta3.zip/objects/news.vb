Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class News
        Inherits pengine.Data.DBAccess

        Function GetNews(ByVal ID As Integer) As DataSet
            GetNews = GetDataset("Select TOP 1 * from SystemNews where id = " & System.Convert.ToString(ID) & " order by timeposted DESC")
        End Function
        Function GetCurrentNews() As DataSet
            GetCurrentNews = GetDataset("Select TOP 5 * from SystemNews order by timeposted DESC")
        End Function
        Function GetNewsRange(ByVal LastStoryID As Integer, ByVal StoryCount As Integer, ByVal ReverseFlag As Boolean) As DataSet
            Dim StartStoryID As Integer = -1
            Dim RowPtr As Integer = 0
            If LastStoryID > 0 And ReverseFlag = True Then
                GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                & " * from SystemNews where ID > " & System.Convert.ToString(LastStoryID) & " order by timeposted ASC")
                If GetNewsRange.Tables(0).Rows.Count > 0 Then
                    While RowPtr < GetNewsRange.Tables(0).Rows.Count
                        StartStoryID = GetNewsRange.Tables(0).Rows(RowPtr).Item("ID")
                        RowPtr += 1
                    End While
                    GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                    & " * from SystemNews where ID <= " & System.Convert.ToString(StartStoryID) & " order by timeposted DESC")
                End If
            Else
                StartStoryID = LastStoryID
                If StartStoryID > 0 Then
                    GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                    & " * from SystemNews where ID < " & System.Convert.ToString(StartStoryID) & " order by timeposted DESC")
                Else
                    GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                    & " * from SystemNews order by timeposted DESC")
                End If

            End If
        End Function
        Function GetTopNewsID() As Integer
            GetTopNewsID = GetScalar("Select TOP 1 ID from SystemNews order by timeposted DESC")
        End Function
        Function GetBottomNewsID() As Integer
            GetBottomNewsID = GetScalar("Select TOP 1 ID from SystemNews order by timeposted ASC")
        End Function
        Function Title(ByVal ID As Integer) As String
            Title = GetScalar("Select TOP 1 title from SystemNews where id = " & System.Convert.ToString(ID) & " order by timeposted ASC")
        End Function
        Shared Function TruncateStory(ByVal StoryData As String, Optional ByVal Length As Integer = 75) As String
            Dim StrPtr As Integer
            StoryData = Replace(StoryData, "[", "")
            StoryData = Replace(StoryData, "]", "")
            StoryData = Replace(StoryData, "<", "")
            StoryData = Replace(StoryData, ">", "")
            If Length > 0 Then
                If StoryData.Length > Length Then
                    StoryData = Left(StoryData, Length) & "..."
                End If
            Else
                StrPtr = StoryData.IndexOf(System.Environment.NewLine)
                If StrPtr > 0 Then
                    StoryData = StoryData.Substring(0, StrPtr)
                End If
            End If
            Return StoryData
        End Function
        Function SaveNews(ByRef ID As Integer, ByVal Title As String, ByVal DateTime As Date, ByVal Text As String, ByVal IconFileName As String) As String
            Dim NewsRecord As DataRow
            Dim NewsData As DataSet
            If Title = "" Then
                SaveNews &= "You must supply a title for this news posting.|"
            End If
            If Text = "" Then
                SaveNews &= "You must input some text for this news posting.|"
            End If
            If SaveNews = "" Then
                If ID > 0 Then
                    NewsData = GetDataset("Select * from SystemNews where ID = " & System.Convert.ToString(ID))
                    NewsRecord = NewsData.Tables(0).Rows(0)
                    'NewsRecord.BeginEdit()
                Else
                    NewsData = GetDataset("Select * from SystemNews")
                    NewsRecord = NewsData.Tables(0).NewRow
                End If
                NewsRecord.Item("Title") = Title
                NewsRecord.Item("ArticleData") = Text
                NewsRecord.Item("timeposted") = DateTime.ToString
                NewsRecord.Item("IconFileName") = IconFileName
                If ID > 0 Then
                    'NewsRecord.AcceptChanges()
                    SetDataset(NewsData.Tables(0).TableName, NewsData)
                Else
                    NewsData.Tables(0).Rows.Add(NewsRecord)
                    SetDataset(NewsData.Tables(0).TableName, NewsData)
                    ID = GetScalar("SELECT @@IDENTITY")
                End If
            End If
        End Function
        Function DeleteNews(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from SystemNews where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetIconList() As ArrayList
            GetIconList = New ArrayList
            Dim FSInfo As System.IO.DirectoryInfo
            Dim FileList() As System.IO.FileInfo
            Dim FilePtr As Integer
            If Current.Application.Item("basepath") <> "" Then
                FSInfo = New System.IO.DirectoryInfo(Current.Server.MapPath(Current.Application.Item("basepath") & "/images/icons/"))
            Else
                FSInfo = New System.IO.DirectoryInfo(Current.Server.MapPath("./images/icons/"))
            End If
            FileList = FSInfo.GetFiles("*")
            For FilePtr = FileList.GetLowerBound(0) To FileList.GetUpperBound(0)
                GetIconList.Add(FileList(FilePtr).Name)
            Next
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)

        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class
End Namespace