Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class DBAccess
        Dim conPEngine As OleDbConnection
        Dim dapPEngine As OleDbDataAdapter
        Protected MyConnString As String
        Private ConnFlag As Boolean
        Public Sub SetConnString(ByVal ConnString As String)
            MyConnString = ConnString
            ConnFlag = False
        End Sub
        Public Sub OpenConn()
            If ConnFlag = True Then
                Call CloseConn()
            End If
            conPEngine = New OleDbConnection(MyConnString)
            conPEngine.Open()
            ConnFlag = True
        End Sub
        Public Function GetDataset(ByVal SQL As String) As DataSet
            If ConnFlag = False Then
                OpenConn()
            End If
            GetDataset = New DataSet
            dapPEngine = New OleDbDataAdapter(SQL, conPEngine)
            dapPEngine.Fill(GetDataset)
        End Function
        Public Sub SetDataset(ByVal TableName As String, ByRef MyDataset As DataSet)
            Dim cmdPEngine As OleDbCommandBuilder
            If ConnFlag = False Then
                OpenConn()
            End If
            cmdPEngine = New OleDbCommandBuilder(dapPEngine)
            dapPEngine.Update(MyDataset, TableName)
        End Sub
        Public Sub WriteXML(ByRef MyData As DataSet, ByVal FilePath As String)
            If System.IO.File.Exists(FilePath) Then
                System.IO.File.Delete(FilePath)
            End If
            'Replace Generic Dataset Names to make Output XML more readable
            MyData.DataSetName = "Data"
            MyData.Tables(0).TableName = "Row"
            MyData.WriteXml(FilePath, XmlWriteMode.WriteSchema)
        End Sub
        Public Function ReadXML(ByVal FilePath As String) As DataSet
            ReadXML = New DataSet
            If System.IO.File.Exists(FilePath) Then
                ReadXML.ReadXml(FilePath, XmlReadMode.ReadSchema)
            End If
        End Function
        Public Function GetScalar(ByVal SQL As String) As Object
            Dim cmdPEngine As OleDbCommand
            If ConnFlag = False Then
                OpenConn()
            End If
            cmdPEngine = New OleDbCommand(SQL, conPEngine)
            GetScalar = cmdPEngine.ExecuteScalar
            cmdPEngine = Nothing
        End Function
        Public Function ExecuteSQL(ByVal SQL As String) As Integer
            Dim cmdPEngine As OleDbCommand
            If ConnFlag = False Then
                OpenConn()
            End If
            cmdPEngine = New OleDbCommand(SQL, conPEngine)
            cmdPEngine.ExecuteNonQuery()
            cmdPEngine = Nothing
        End Function
        Public Sub CloseConn()
            dapPEngine = Nothing
            Try
                conPEngine.Close()
                conPEngine = Nothing
            Catch
            End Try
            ConnFlag = False
        End Sub
        Public Sub New(ByVal ConnectionString As String)
            MyConnString = ConnectionString
            'If ConnFlag = False Then
            'Call OpenConn()
            'End If
        End Sub
        Protected Overloads Overrides Sub Finalize()
            If ConnFlag = True Then
                Call CloseConn()
            End If
        End Sub
    End Class
End Namespace
