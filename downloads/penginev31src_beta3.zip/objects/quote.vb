Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class Quote
        Inherits DBAccess
        Public Function Count() As Integer
            Count = GetScalar("Select Max(ID) from QuoteList")
        End Function
        Public Function GetRandom(Optional ByVal XMLFilePath As String = "") As String
            Dim QuoteCount As Integer
            Dim QuoteID As Integer
            Dim QuoteData As DataSet
            Dim Randomizer As System.Random = New System.Random(DateTime.Now.Millisecond)
            If System.IO.File.Exists(XMLFilePath) = False Then
                XMLFilePath = ""
            End If
            If XMLFilePath <> "" Then
                QuoteData = Current.Cache.Item("QuoteData")
                If QuoteData Is Nothing Then
                    Current.Cache.Item("QuoteData") = ReadXML(XMLFilePath)
                    QuoteData = Current.Cache.Item("QuoteData")
                End If
                QuoteCount = QuoteData.Tables(0).Rows.Count
            Else
                QuoteCount = Count()
            End If
            If QuoteCount > 0 Then
                QuoteID = (Randomizer.Next() Mod QuoteCount)
                If XMLFilePath <> "" Then
                    GetRandom = QuoteData.Tables(0).Rows(QuoteID).Item("Text")
                Else
                    GetRandom = GetScalar("Select Text from QuoteList where ID = " & System.Convert.ToString(QuoteID))
                End If
            Else
                GetRandom = "There are no quotes available to choose from."
            End If
        End Function
        Public Function GetAll() As DataSet
            GetAll = GetDataset("Select * from QuoteList")
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

End Namespace