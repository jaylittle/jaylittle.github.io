Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class Forum
        Inherits pengine.Data.DBAccess

        Public Function GetForumName(ByVal ForumID As Integer) As String
            GetForumName = GetScalar("Select Name from Forums where ID = " & System.Convert.ToString(ForumID))
        End Function
        Public Function GetThreadName(ByVal ThreadID As Integer) As String
            GetThreadName = GetScalar("Select Title from Messages where ID = " & System.Convert.ToString(ThreadID))
        End Function
        Public Function GetThreadPosts(ByVal ThreadID As Integer) As Integer
            GetThreadPosts = GetScalar("Select Posts from Messages where ID = " & System.Convert.ToString(ThreadID))
        End Function
        Public Function GetThreadForumID(ByVal ThreadID As Integer) As Integer
            GetThreadForumID = GetScalar("Select ForumID from Messages where ID = " & System.Convert.ToString(ThreadID))
        End Function
        Public Function GetForums() As DataSet
            GetForums = GetDataset("Select ID,Name,Description, (Select count(*) from Messages where Forums.ID = Messages.ForumID) as Posts " _
            & ", (Select max(TimePosted) from Messages where Forums.ID = Messages.ForumID) as LastPost " _
            & "from Forums order by Name ASC")
        End Function
        Public Function GetForum(ByVal ID As Integer) As DataSet
            GetForum = GetDataset("Select * from Forums where ID = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveForum(ByRef ID As Integer, ByVal Name As String, ByVal Description As String) As String
            Dim ForumRecord As DataRow
            Dim ForumData As DataSet
            If Description = "" Then
                SaveForum &= "You must supply a description for this forum.|"
            End If
            If Name = "" Then
                SaveForum &= "You must supply a name for the forum.|"
            End If
            If SaveForum = "" Then
                If ID > 0 Then
                    ForumData = GetDataset("Select * from Forums where ID = " & System.Convert.ToString(ID))
                    ForumRecord = ForumData.Tables(0).Rows(0)
                Else
                    ForumData = GetDataset("Select * from Forums")
                    ForumRecord = ForumData.Tables(0).NewRow
                End If
                ForumRecord.Item("Name") = Name
                ForumRecord.Item("Description") = Description
                If ID <= 0 Then
                    ForumData.Tables(0).Rows.Add(ForumRecord)
                    SetDataset(ForumData.Tables(0).TableName, ForumData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(ForumData.Tables(0).TableName, ForumData)
                End If
            End If
        End Function
        Function DeleteForum(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Forums where ID = " & System.Convert.ToString(ID))
                ExecuteSQL("Delete from Messages where ForumID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetThreads(ByVal ForumID As Integer, ByVal StartPoint As Integer, ByVal Count As Integer) As DataSet
            Dim TempDataset As DataSet
            Dim StartID As Integer
            If StartPoint > 0 And Count > 0 Then
                GetThreads = New DataSet
                TempDataset = GetDataset("Select TOP " & System.Convert.ToString(StartPoint) _
                & " ID from Messages where ForumID = " & System.Convert.ToString(ForumID) _
                & " and ParentID = Messages.ID order by TimePosted DESC")
                If TempDataset.Tables(0).Rows.Count > 0 Then
                    StartID = TempDataset.Tables(0).Rows(TempDataset.Tables(0).Rows.Count - 1).Item("ID")
                    GetThreads = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                    & " Messages.*,Users.Name as UserName from Messages,Users where UserID = Users.ID and ForumID = " _
                    & System.Convert.ToString(ForumID) & " and ParentID = ID and Messages.ID <= " _
                    & System.Convert.ToString(StartID) & " order by TimePosted DESC")
                End If
            ElseIf Count > 0 Then
                GetThreads = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                & " Messages.*,Users.Name as UserName from Messages,Users where UserID = Users.ID and ForumID = " _
                & System.Convert.ToString(ForumID) & " and ParentID = Messages.ID order by TimePosted DESC")
            Else
                GetThreads = GetDataset("Select Messages.*,Users.Name as UserName from Messages,Users where " _
                & "UserID = Users.ID and ForumID = " & System.Convert.ToString(ForumID) _
                & " and ParentID = Messages.ID order by TimePosted DESC")
            End If
        End Function
        Public Function GetMessagePageNum(ByVal MessageID As Integer, ByVal Count As Integer) As Integer
            Dim TempDataset As DataSet
            Dim PostCount As Integer
            TempDataset = GetDataset("Select ID from Messages where ID <= " & System.Convert.ToString(MessageID) & " order by TimePosted ASC")
            PostCount = TempDataset.Tables(0).Rows.Count
            GetMessagePageNum = (PostCount - (PostCount Mod Count)) / Count
        End Function
        Public Function GetMessages(ByVal ThreadID As Integer, ByVal StartPoint As Integer, ByVal Count As Integer) As DataSet
            Dim TempDataset As DataSet
            Dim StartID As Integer
            If StartPoint > 0 And Count > 0 Then
                GetMessages = New DataSet
                TempDataset = GetDataset("Select TOP " & System.Convert.ToString(StartPoint) _
                & " ID from ParentID = " & System.Convert.ToString(ThreadID) & " order by TimePosted ASC")
                If TempDataset.Tables(0).Rows.Count > 0 Then
                    StartID = TempDataset.Tables(0).Rows(TempDataset.Tables(0).Rows.Count - 1).Item("ID")
                    GetMessages = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                    & " Messages.*,User.Name as UserName,User.Title as UserTitle from Messages,Users where" _
                    & " Messages.UserID = Users.ID and ParentID = " & System.Convert.ToString(ThreadID) _
                    & " and Messages.ID <= " & System.Convert.ToString(StartID) & " order by TimePosted ASC")
                End If
            ElseIf Count > 0 Then
                GetMessages = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                & " Messages.*,Users.Name as username, Users.Title as UserTitle from Messages, Users where " _
                & "Messages.UserID = Users.ID and ParentID = " & System.Convert.ToString(ThreadID) _
                & " order by TimePosted ASC")
            Else
                GetMessages = GetDataset("Select Messages.*, User.Name as UserName, User.Title as UserTitle " _
                & "from Messages,Users where Messages.UserID = Users.ID and ParentID = " _
                & System.Convert.ToString(ThreadID) & " order by TimePosted ASC")
            End If
        End Function
        Public Shared Function CreateThreadPageHTML(ByVal ThreadID As Integer, ByVal Posts As Integer _
        , ByVal PostsPerPage As Integer, ByVal URLStart As String, ByVal URLEnd As String _
        , ByVal CSSID As String, Optional ByVal CurrentPage As Integer = 0) As String
            Dim PostPtr As Integer
            For PostPtr = 0 To Posts Step PostsPerPage
                If PostPtr > 0 Then
                    CreateThreadPageHTML &= " "
                End If
                If CurrentPage <= 0 Or CurrentPage <> (PostPtr + PostsPerPage) / PostsPerPage Then
                    If CSSID <> "" Then
                        CreateThreadPageHTML &= "<a class=""" & CSSID & """ href="""
                    Else
                        CreateThreadPageHTML &= "<a href="""
                    End If
                    CreateThreadPageHTML &= URLStart & System.Convert.ToString(ThreadID)
                    CreateThreadPageHTML &= URLEnd & System.Convert.ToString((PostPtr + PostsPerPage) / PostsPerPage)
                    CreateThreadPageHTML &= """>" & System.Convert.ToString((PostPtr + PostsPerPage) / PostsPerPage)
                    CreateThreadPageHTML &= "</a>"
                Else
                    CreateThreadPageHTML &= System.Convert.ToString((PostPtr + PostsPerPage) / PostsPerPage)
                End If
            Next
        End Function
        Public Shared Function CreateTitleHTML(ByVal TitleData As String)
            If TitleData <> "" Then
                CreateTitleHTML = """" & TitleData & """"
            Else
                CreateTitleHTML = ""
            End If
        End Function
        Public Function ValidateUser(ByVal UserName As String, ByVal Password As String) As DataSet
            If Password = "" Then
                ValidateUser = GetDataset("Select * from Users where Name = '" & Current.Server.HtmlEncode(UserName) & "' and (UserPass = '' or UserPass is null)")
            Else
                ValidateUser = GetDataset("Select * from Users where Name = '" & Current.Server.HtmlEncode(UserName) & "' and UserPass = '" & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(Password, "MD5") & "'")
            End If
        End Function
        Public Function ValidateUserWithEncryptedPassword(ByVal UserName As String, ByVal Password As String) As DataSet
            If Password = "" Then
                ValidateUserWithEncryptedPassword = GetDataset("Select * from Users where Name = '" & Current.Server.HtmlEncode(UserName) & "' and (UserPass = '' or UserPass is null)")
            Else
                ValidateUserWithEncryptedPassword = GetDataset("Select * from Users where Name = '" & Current.Server.HtmlEncode(UserName) & "' and UserPass = '" & Password & "'")
            End If
        End Function
        Public Function GetLastPostTime(ByVal UserID As Integer) As String
            GetLastPostTime = GetScalar("Select TOP 1 timeposted from messages where userid = " & System.Convert.ToString(UserID) & " order by timeposted DESC")
        End Function
        Public Function GetLastIP(ByVal UserID As Integer) As String
            GetLastIP = GetScalar("Select TOP 1 ipaddress from messages where userid = " & System.Convert.ToString(UserID) & " order by timeposted DESC")
        End Function
        Public Function GetUsers() As DataSet
            GetUsers = GetDataset("Select * from Users")
        End Function
        Public Function GetUser(ByVal UserID As Integer) As DataSet
            GetUser = GetDataset("Select * from Users where ID = " & System.Convert.ToString(UserID))
        End Function
        Public Function GetUserName(ByVal UserID As Integer) As String
            GetUserName = GetScalar("Select Name from Users where ID = " & System.Convert.ToString(UserID))
        End Function
        Public Function SaveUser(ByRef ID As Integer, ByVal Name As String, ByVal FullName As String _
        , ByVal Title As String, ByVal Description As String, ByVal PublicEmail As String _
        , ByVal PrivateEmail As String, ByVal HomeURL As String, ByVal AIMAccount As String _
        , ByVal ICQAccount As String, ByVal YahooAccount As String, ByVal MSNAccount As String _
        , ByVal ModeratorFlag As Boolean, ByVal DisableFlag As Boolean, ByVal NewPassword As String)
            Dim UserRecord As DataRow
            Dim UserData As DataSet
            If Name = "" Then
                SaveUser &= "You must supply a name for this user"
            End If
            If PrivateEmail = "" Then
                SaveUser &= "You must supply a private email address.|"
            End If
            If ID <= 0 And NewPassword = "" Then
                SaveUser &= "You must provide a password for this user.|"
            End If
            If SaveUser = "" Then
                If ID > 0 Then
                    UserData = GetDataset("Select * from Users where ID = " & System.Convert.ToString(ID))
                    UserRecord = UserData.Tables(0).Rows(0)
                Else
                    UserData = GetDataset("Select * from Users")
                    UserRecord = UserData.Tables(0).NewRow
                    UserRecord.Item("JoinDate") = DateTime.Now.ToShortDateString
                    UserRecord.Item("PostCount") = 0
                End If
                UserRecord.Item("Name") = Name
                UserRecord.Item("FullName") = FullName
                UserRecord.Item("Title") = Title
                UserRecord.Item("Description") = Description
                UserRecord.Item("Name") = Name
                If NewPassword <> "" Then
                    UserRecord.Item("UserPass") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(NewPassword, "MD5")
                End If
                UserRecord.Item("PublicEmail") = PublicEmail
                UserRecord.Item("PrivateEmail") = PrivateEmail
                UserRecord.Item("HomeURL") = HomeURL
                UserRecord.Item("AIMAccount") = AIMAccount
                UserRecord.Item("ICQAccount") = ICQAccount
                UserRecord.Item("YahooAccount") = YahooAccount
                UserRecord.Item("MSNAccount") = MSNAccount
                UserRecord.Item("ModeratorFlag") = ModeratorFlag
                UserRecord.Item("DisabledFlag") = DisableFlag
                If ID <= 0 Then
                    UserData.Tables(0).Rows.Add(UserRecord)
                    SetDataset(UserData.Tables(0).TableName, UserData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(UserData.Tables(0).TableName, UserData)
                End If
            End If
        End Function
        Public Function DeleteUser(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Users where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function VerifyIP(ByVal IP As String) As Boolean
            Dim LookupIP As String
            LookupIP = GetScalar("Select IP from IPBanList where IP = '" & IP & "'")
            If LookupIP <> "" Then
                VerifyIP = False
            Else
                VerifyIP = True
            End If
        End Function
        Public Function GetIPBans() As DataSet
            GetIPBans = GetDataset("Select * from IPBanList")
        End Function
        Public Function SaveIPBan(ByRef IP As String)
            Dim IPBanRecord As DataRow
            Dim IPBanData As DataSet
            If IP = "" Then
                SaveIPBan &= "You must provide an IP address.|"
            End If
            If SaveIPBan = "" Then
                IPBanData = GetDataset("Select * from IPBanList")
                IPBanRecord = IPBanData.Tables(0).NewRow
                IPBanRecord.Item("IP") = IP
                IPBanData.Tables(0).Rows.Add(IPBanRecord)
                SetDataset(IPBanData.Tables(0).TableName, IPBanData)
            End If
        End Function
        Public Function DeleteIPBan(ByVal IP As String) As Boolean
            If IP <> "" Then
                ExecuteSQL("Delete from IPBanList where IP = '" & IP & "'")
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetMessage(ByVal ID As Integer) As DataSet
            GetMessage = GetDataset("Select * from Messages where ID = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveMessage(ByRef ID As Integer, ByVal Title As String, ByVal Body As String _
        , ByVal IPAddress As String, ByVal ForumID As Integer, ByVal UserID As Integer _
        , ByRef ParentID As Integer) As String
            Dim MessageRecord As DataRow
            Dim MessageData As DataSet
            Dim ThreadFlag As Boolean = False
            Dim TimeStamp As String
            TimeStamp = DateTime.Now.ToString
            If Title = "" Then
                SaveMessage &= "You must supply a title for this post/thread.|"
            End If
            If Body = "" Then
                SaveMessage &= "You must supply content for this post/thread.|"
            End If
            If SaveMessage = "" Then
                If ID > 0 Then
                    MessageData = GetDataset("Select * from Messages where ID = " & System.Convert.ToString(ID))
                    MessageRecord = MessageData.Tables(0).Rows(0)
                Else
                    MessageData = GetDataset("Select TOP 1 * from Messages")
                    MessageRecord = MessageData.Tables(0).NewRow
                    MessageRecord.Item("TimePosted") = TimeStamp
                End If
                MessageRecord.Item("Title") = Title
                MessageRecord.Item("Body") = Body
                MessageRecord.Item("IPAddress") = IPAddress
                MessageRecord.Item("ForumID") = ForumID
                MessageRecord.Item("UserID") = UserID
                If ParentID > 0 Then
                    MessageRecord.Item("ParentID") = ParentID
                    MessageRecord.Item("Posts") = 0
                Else
                    MessageRecord.Item("Posts") = 1
                    ThreadFlag = True
                End If
                If ID <= 0 Then
                    MessageData.Tables(0).Rows.Add(MessageRecord)
                    SetDataset(MessageData.Tables(0).TableName, MessageData)
                    ID = GetScalar("SELECT @@IDENTITY")
                    If ThreadFlag = True Then
                        ExecuteSQL("Update Messages set ParentID = ID where ID = " & System.Convert.ToString(ID))
                        ParentID = ID
                    Else
                        ExecuteSQL("Update Messages set Posts = Posts + 1 where ID = " & System.Convert.ToString(ParentID))
                        ExecuteSQL("Update Messages set LastUpdated = '" & TimeStamp & "' where ID = " & System.Convert.ToString(ParentID))
                    End If
                Else
                    SetDataset(MessageData.Tables(0).TableName, MessageData)
                End If
            End If
        End Function
        Function DeleteMessage(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Messages where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Shared Function CreateMessageOptionButtons(ByVal MyUserID As Integer, ByVal ForumID As Integer, ByVal MessageID As Integer, ByVal ThreadID As Integer, ByVal MessageUserID As Integer, ByVal AdminFlag As Boolean) As String
            CreateMessageOptionButtons &= "<table><tr>"
            If MyUserID = MessageUserID Or AdminFlag = True Then
                CreateMessageOptionButtons &= "<td>" & pengine.Data.Article.CreateHTMLButton("forumedit/editpost.aspx?id=" & System.Convert.ToString(MessageID), "Edit Post", "") & "</td>"
            End If
            CreateMessageOptionButtons &= "<td>" & pengine.Data.Article.CreateHTMLButton("forumedit/editpost.aspx?forumid=" & System.Convert.ToString(ForumID) & "&parentid=" & System.Convert.ToString(ThreadID) & "&replyid=" & System.Convert.ToString(MessageID), "Reply to Post", "") & "</td>"
            CreateMessageOptionButtons &= "</tr></table>"
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)

        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class
End Namespace