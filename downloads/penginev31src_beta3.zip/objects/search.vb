Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class Search
        Inherits pengine.Data.DBAccess

        Public Shared Function BuildLink(ByVal ID As Integer, ByVal Type As String, Optional ByVal ExtraHTML As String = "") As String
            Select Case Type.ToUpper
                Case "ARTICLE"
                    BuildLink = "default.aspx?cmd=article&sub=display&id=" & System.Convert.ToString(ID) & ExtraHTML
                Case "NEWS"
                    BuildLink = "default.aspx?cmd=news&sub=display&id=" & System.Convert.ToString(ID)
                Case "FORUM"
                    BuildLink = "default.aspx?cmd=msg&sub=browse&threadid=" & System.Convert.ToString(ID) & ExtraHTML
            End Select
        End Function
        Public Function Query(ByVal QueryTerm As String, ByVal UserID As Integer, ByVal ForumFlag As Boolean) As DataSet
            Dim sql As String
            If ForumFlag = True Then
                sql = "SELECT Distinct ""FORUM"" as Type, Parent.Title as SectionName,messages.ID,Messages.Title as Name" _
                & ",messages.body as content,messages.timeposted as created, parent.id as parentid, parent.forumid as forumid" _
                & ",users.name as username from messages,messages as parent,users where messages.userid = users.id " _
                & "and messages.parentid = parent.id"
                If QueryTerm <> "" Then
                    sql = sql & " and (messages.body like ""%" & QueryTerm & "%"" or messages.title like ""%" & QueryTerm & "%"")"
                End If
                If UserID > 0 Then
                    sql = sql & " and users.id = " & System.Convert.ToString(UserID)
                End If
                sql = sql & " order by messages.timeposted DESC,messages.id DESC"
                Query = GetDataset(sql)
            ElseIf QueryTerm <> "" Then
                sql = "SELECT Distinct ""ARTICLE"" as Type,ArticleSection.Name as SectionName,ID,Articles.Name" _
                & ",description as content,#1/1/1990# as created from Articles,ArticleSection where " _
                & "Articles.ID = ArticleSection.ArticleID and (data like ""%" & QueryTerm & "%"" " _
                & "or ArticleSection.Name like ""%" & QueryTerm & "%"" or Articles.Name like ""%" & QueryTerm & "%"") " _
                & "and visible = true " _
                & "UNION Select Distinct ""NEWS"" as Type,""-NA-"" as SectionName,ID,Title as Name,ArticleData as content " _
                & ",TimePosted as created from SystemNews where (ArticleData like ""%" & QueryTerm & "%"" " _
                & "or title like ""%" & QueryTerm & "%"") order by Type ASC,created DESC,id DESC"
                Query = GetDataset(sql)
            Else
                Query = New DataSet
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)

        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

End Namespace