Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class Settings

        Public Shared Sub LoadIntoApplication()
            Current.Trace.Write("Loading Settings into Application Collection")
            'Code here should be replaced to pull settings from some external source such as a CSV file.
            Dim SettingData As System.IO.StreamReader
            Dim FSInfo As System.IO.FileInfo
            Dim FSStream As System.IO.TextReader
            Dim DataRecord As String
            Dim DataFields() As String
            If Current.Application.Item("basepath") <> "" Then
                FSInfo = New System.IO.FileInfo(Current.Server.MapPath(Current.Application.Item("basepath")) & "settings.asp")
            Else
                FSInfo = New System.IO.FileInfo(Current.Server.MapPath("./") & "\settings.asp")
            End If
            If FSInfo.Exists Then
                Current.Trace.Write("Settings file located - parsing settings from this file.")
                FSStream = FSInfo.OpenText
                While FSStream.Peek() >= 0
                    DataRecord = FSStream.ReadLine()
                    If DataRecord.StartsWith("'") Then
                        'Remove Leading Comment from Line
                        DataRecord = DataRecord.Substring(1, DataRecord.Length - 1)
                        DataFields = DataRecord.Split(",")
                        Current.Application.Item(DataFields(0).ToLower()) = DataFields(1)
                    End If
                End While
                FSStream.Close()
            Else
                Current.Trace.Write("Settings file could not be found - loading default settings.")
                Current.Application.Item("ownername") = "PEngine User"
                Current.Application.Item("owneremail") = "pengineuser@pengine.com"
                Current.Application.Item("defaultpagetitle") = "Presentation Engine 3.0"
                Current.Application.Item("defaulttheme") = "default"
                Current.Application.Item("frontpagelogo") = "penginelogo.png"
                Current.Application.Item("newssummaryperpage") = 10
                Current.Application.Item("newsperpage") = 5
                Current.Application.Item("searchresultsperpage") = 20
                Current.Application.Item("forumpostsperpage") = 15
                Current.Application.Item("forumeditlimit") = 30
                Current.Application.Item("pagesize") = 0
                Current.Application.Item("menusize") = 150
                Current.Application.Item("excluderesume") = 0
                Current.Application.Item("excludetheme") = 0
                Current.Application.Item("excludeleet") = 0
                Current.Application.Item("excludequotes") = 0
                Current.Application.Item("excludesearch") = 0
                Current.Application.Item("homelabel") = "Home"
                Current.Application.Item("themelabel") = "Theme"
                Current.Application.Item("resumelabel") = "Resume"
                Current.Application.Item("leetlabel") = "I am Elite"
                Current.Application.Item("leetlabel2") = "I am a Loser"
                Current.Application.Item("adminlabel") = "Admin"
                Current.Application.Item("adminlabel2") = "Standard"
                Current.Application.Item("dbrelativepath") = "./data"
                Current.Application.Item("dbfilename") = "pengine.mdb"
                Current.Application.Item("timeout") = 30
                Current.Application.Item("adminpass") = ""
                Current.Application.Item("godpass") = ""
            End If
            'Build Connection String
            Current.Application.Item("ConnectionString") = "PROVIDER=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Locking Mode=1;Data Source=" & Current.Server.MapPath(Current.Application("basepath")) _
            & Current.Application.Item("dbrelativepath") & "/" & Current.Application.Item("dbfilename")
            FSInfo = New System.IO.FileInfo(Current.Server.MapPath(Current.Application("basepath")) & Current.Application.Item("dbrelativepath") & "/forum.mdb")
            If FSInfo.Exists Then
                Current.Application.Item("FConnectionString") = "PROVIDER=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Locking Mode=1;Data Source=" & Current.Server.MapPath(Current.Application("basepath")) _
                & Current.Application.Item("dbrelativepath") & "/forum.mdb"
                Current.Application.Item("forum") = True
            Else
                Current.Application.Item("forum") = False
            End If
            Current.Application.Item("settings") = 1
        End Sub
        Public Shared Function SaveIntoASPFile(ByVal OwnerName As String, ByVal OwnerEmail As String, ByVal DefaultPageTitle As String _
        , ByVal DefaultTheme As String, ByVal FrontPageLogo As String, ByVal NewsSummaryPerPage As String, ByVal NewsPerPage As String _
        , ByVal SearchResultsPerPage As String, ByVal ForumPostsPerPage As String, ByVal ForumEditLimit As String _
        , ByVal PageSize As String, ByVal MenuSize As String, ByVal ExcludeResume As Integer, ByVal ExcludeTheme As Integer _
        , ByVal ExcludeLeet As Integer, ByVal ExcludeQuotes As Integer, ByVal ExcludeSearch As Integer, ByVal HomeLabel As String _
        , ByVal ThemeLabel As String, ByVal ResumeLabel As String, ByVal LeetLabel As String, ByVal LeetLabel2 As String _
        , ByVal AdminLabel As String, ByVal AdminLabel2 As String, ByVal DbRelativePath As String, ByVal DbFileName As String _
        , ByVal Timeout As String, ByVal AdminPass As String, ByVal GodPass As String) As String
            Dim SettingsFile As System.IO.FileInfo
            Dim DBFile As System.IO.FileInfo
            Dim OutputStream As System.IO.TextWriter
            If Not IsNumeric(NewsSummaryPerPage) Or Not IsNumeric(NewsPerPage) Or Not IsNumeric(SearchResultsPerPage) _
            Or Not IsNumeric(ForumPostsPerPage) Or Not IsNumeric(ForumEditLimit) Or Not IsNumeric(PageSize) _
            Or Not IsNumeric(MenuSize) Or Not IsNumeric(Timeout) Then
                SaveIntoASPFile &= "You provide a non-numeric value for a numeric field.  Please recheck your input values.|"
            End If
            DBFile = New System.IO.FileInfo(Current.Server.MapPath(Current.Application.Item("basepath")) & DbRelativePath & "/" & DbFileName)
            If DBFile.Exists = False Then
                SaveIntoASPFile &= "The combination of the Database Relative Path and the Database filename you provided points to a non-existant file.|"
            End If
            If SaveIntoASPFile = "" Then
                SettingsFile = New System.IO.FileInfo(Current.Server.MapPath(Current.Application.Item("basepath")) & "settings.asp")
                If SettingsFile.Exists Then
                    SettingsFile.Delete()
                End If
                OutputStream = SettingsFile.AppendText
                OutputStream.WriteLine("<%")
                OutputStream.WriteLine("'ownername," & OwnerName)
                OutputStream.WriteLine("'owneremail," & OwnerEmail)
                OutputStream.WriteLine("'defaultpagetitle," & DefaultPageTitle)
                OutputStream.WriteLine("'defaulttheme," & DefaultTheme)
                OutputStream.WriteLine("'frontpagelogo," & FrontPageLogo)
                OutputStream.WriteLine("'newsperpage," & NewsPerPage)
                OutputStream.WriteLine("'newssummaryperpage," & NewsSummaryPerPage)
                OutputStream.WriteLine("'newsperpage," & NewsPerPage)
                OutputStream.WriteLine("'searchresultsperpage," & SearchResultsPerPage)
                OutputStream.WriteLine("'forumpostsperpage," & ForumPostsPerPage)
                OutputStream.WriteLine("'forumeditlimit," & ForumEditLimit)
                OutputStream.WriteLine("'pagesize," & PageSize)
                OutputStream.WriteLine("'menusize," & MenuSize)
                OutputStream.WriteLine("'excluderesume," & ExcludeResume)
                OutputStream.WriteLine("'excludetheme," & ExcludeTheme)
                OutputStream.WriteLine("'excludeleet," & ExcludeLeet)
                OutputStream.WriteLine("'excludequotes," & ExcludeQuotes)
                OutputStream.WriteLine("'excludesearch," & ExcludeSearch)
                OutputStream.WriteLine("'homelabel," & HomeLabel)
                OutputStream.WriteLine("'themelabel," & ThemeLabel)
                OutputStream.WriteLine("'resumelabel," & ResumeLabel)
                OutputStream.WriteLine("'leetlabel," & LeetLabel)
                OutputStream.WriteLine("'leetlabel2," & LeetLabel2)
                OutputStream.WriteLine("'adminlabel," & AdminLabel)
                OutputStream.WriteLine("'adminlabel2," & AdminLabel2)
                OutputStream.WriteLine("'dbrelativepath," & DbRelativePath)
                OutputStream.WriteLine("'dbfilename," & DbFileName)
                OutputStream.WriteLine("'timeout," & Timeout)
                If AdminPass <> "" Then
                    OutputStream.WriteLine("'adminpass," & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(AdminPass, "MD5"))
                Else
                    OutputStream.WriteLine("'adminpass," & Current.Application.Item("adminpass"))
                End If
                If GodPass <> "" Then
                    OutputStream.WriteLine("'godpass," & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(GodPass, "MD5"))
                Else
                    OutputStream.WriteLine("'godpass," & Current.Application.Item("godpass"))
                End If
                OutputStream.WriteLine("%>")
                OutputStream.Close()
            End If
        End Function
        Public Sub New()
        End Sub
    End Class

End Namespace