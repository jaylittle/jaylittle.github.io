Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data
    Public Class ResumeParts
        Inherits pengine.Data.DBAccess

        Public Function GetPersonals() As DataSet
            GetPersonals = GetDataset("Select * from ResumePersonal")
        End Function
        Public Function GetPersonal(ByVal ID As Integer) As DataSet
            GetPersonal = GetDataset("Select TOP 1 * from ResumePersonal where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SavePersonal(ByRef ID As Integer, ByVal Name As String, ByVal Address As String, ByVal City As String _
        , ByVal State As String, ByVal Zip As String, ByVal Phone As String, ByVal Fax As String _
        , ByVal Email As String, ByVal Web As String) As String
            Dim PersonalRecord As DataRow
            Dim PersonalData As DataSet
            If Name = "" Then
                SavePersonal &= "You must supply a name for the personal information.|"
            End If
            If Email = "" Then
                SavePersonal &= "You must supply an email address for the personal information.|"
            End If
            If SavePersonal = "" Then
                If ID > 0 Then
                    PersonalData = GetDataset("Select * from ResumePersonal where ID = " & System.Convert.ToString(ID))
                    PersonalRecord = PersonalData.Tables(0).Rows(0)
                Else
                    PersonalData = GetDataset("Select * from ResumePersonal")
                    PersonalRecord = PersonalData.Tables(0).NewRow
                End If
                PersonalRecord.Item("Name") = Name
                PersonalRecord.Item("Address") = Address
                PersonalRecord.Item("City") = City
                PersonalRecord.Item("State") = State
                PersonalRecord.Item("Zip") = Zip
                PersonalRecord.Item("Phone") = Phone
                PersonalRecord.Item("Fax") = Fax
                PersonalRecord.Item("Email") = Email
                PersonalRecord.Item("Web") = Web
                If ID <= 0 Then
                    PersonalData.Tables(0).Rows.Add(PersonalRecord)
                    SetDataset(PersonalData.Tables(0).TableName, PersonalData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(PersonalData.Tables(0).TableName, PersonalData)
                End If
            End If
        End Function
        Function DeletePersonal(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumePersonal where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetObjectives() As DataSet
            GetObjectives = GetDataset("Select * from ResumeObjective")
        End Function
        Public Function GetObjective(ByVal ID As Integer) As DataSet
            GetObjective = GetDataset("Select TOP 1 * from ResumeObjective where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveObjective(ByRef ID As Integer, ByVal Description As String) As String
            Dim ObjectiveRecord As DataRow
            Dim ObjectiveData As DataSet
            If Description = "" Then
                SaveObjective &= "You must at least fill in the description field for this objective.|"
            End If
            If SaveObjective = "" Then
                If ID > 0 Then
                    ObjectiveData = GetDataset("Select * from ResumeObjective where ID = " & System.Convert.ToString(ID))
                    ObjectiveRecord = ObjectiveData.Tables(0).Rows(0)
                Else
                    ObjectiveData = GetDataset("Select * from ResumeObjective")
                    ObjectiveRecord = ObjectiveData.Tables(0).NewRow
                End If
                ObjectiveRecord.Item("Description") = Description
                If ID <= 0 Then
                    ObjectiveData.Tables(0).Rows.Add(ObjectiveRecord)
                    SetDataset(ObjectiveData.Tables(0).TableName, ObjectiveData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(ObjectiveData.Tables(0).TableName, ObjectiveData)
                End If
            End If
        End Function
        Function DeleteObjective(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeObjective where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetSkills() As DataSet
            GetSkills = GetDataset("Select * from ResumeSkills order by Type ASC")
        End Function
        Public Function GetSkills(ByVal Type As String) As DataSet
            GetSkills = GetDataset("Select * from ResumeSkills where Type = '" & Type & "' order by Type ASC")
        End Function
        Public Function GetSkillTypes() As DataSet
            GetSkillTypes = GetDataset("Select Distinct Type from ResumeSkills order by Type ASC")
        End Function
        Public Function GetSkill(ByVal ID As Integer) As DataSet
            GetSkill = GetDataset("Select TOP 1 * from ResumeSkills where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveSkill(ByRef ID As Integer, ByVal Name As String, ByVal Type As String) As String
            Dim SkillRecord As DataRow
            Dim SkillData As DataSet
            If Name = "" Then
                SaveSkill &= "You must supply a name for the skill.|"
            End If
            If Type = "" Then
                SaveSkill &= "You must supply a type for the skill to be listed with.|"
            End If
            If SaveSkill = "" Then
                If ID > 0 Then
                    SkillData = GetDataset("Select * from ResumeSkills where ID = " & System.Convert.ToString(ID))
                    SkillRecord = SkillData.Tables(0).Rows(0)
                Else
                    SkillData = GetDataset("Select * from ResumeSkills")
                    SkillRecord = SkillData.Tables(0).NewRow
                End If
                SkillRecord.Item("Name") = Name
                SkillRecord.Item("Type") = Type
                If ID <= 0 Then
                    SkillData.Tables(0).Rows.Add(SkillRecord)
                    SetDataset(SkillData.Tables(0).TableName, SkillData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(SkillData.Tables(0).TableName, SkillData)
                End If
            End If
        End Function
        Function DeleteSkill(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeSkills where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetEducations() As DataSet
            GetEducations = GetDataset("Select * from ResumeEducation order by DateStarted DESC")
        End Function
        Public Function GetEducation(ByVal ID As Integer) As DataSet
            GetEducation = GetDataset("Select TOP 1 * from ResumeEducation where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveEducation(ByRef ID As Integer, ByVal Institute As String, ByVal HTTP As String _
        , ByVal Program As String, ByVal DateStarted As DateTime, ByVal DateLeft As DateTime) As String
            Dim EducationRecord As DataRow
            Dim EducationData As DataSet
            If Institute = "" Then
                SaveEducation &= "You must supply the name of an institute for this education record.|"
            End If
            If Program = "" Then
                SaveEducation &= "You must supply a program of study for this education record.|"
            End If
            If HTTP = "" Then
                SaveEducation &= "You must provide a URL for the institute.|"
            End If
            If SaveEducation = "" Then
                If ID > 0 Then
                    EducationData = GetDataset("Select * from ResumeEducation where ID = " & System.Convert.ToString(ID))
                    EducationRecord = EducationData.Tables(0).Rows(0)
                Else
                    EducationData = GetDataset("Select * from ResumeEducation")
                    EducationRecord = EducationData.Tables(0).NewRow
                End If
                EducationRecord.Item("Institute") = Institute
                EducationRecord.Item("HTTP") = HTTP
                EducationRecord.Item("Program") = Program
                EducationRecord.Item("DateStarted") = DateStarted.ToShortDateString
                EducationRecord.Item("DateLeft") = DateStarted.ToShortDateString
                If ID <= 0 Then
                    EducationData.Tables(0).Rows.Add(EducationRecord)
                    SetDataset(EducationData.Tables(0).TableName, EducationData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(EducationData.Tables(0).TableName, EducationData)
                End If
            End If
        End Function
        Function DeleteEducation(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeEducation where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetWorkHistories() As DataSet
            GetWorkHistories = GetDataset("Select * from ResumeWorkHistory order by DateStarted DESC")
        End Function
        Public Function GetWorkHistory(ByVal ID As Integer) As DataSet
            GetWorkHistory = GetDataset("Select TOP 1 * from ResumeWorkHistory where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveWorkHistory(ByRef ID As Integer, ByVal Employer As String, ByVal HTTP As String _
        , ByVal Title As String, ByVal DateStarted As DateTime, ByVal DateLeft As DateTime _
        , ByVal Description As String) As String
            Dim WorkHistoryRecord As DataRow
            Dim WorkHistoryData As DataSet
            If Employer = "" Then
                SaveWorkHistory &= "You must supply an employer name for this work history record.|"
            End If
            If Title = "" Then
                SaveWorkHistory &= "You must supply a title name for this work history record.|"
            End If
            If Description = "" Then
                SaveWorkHistory &= "You must supply a description for this work history record.|"
            End If
            If SaveWorkHistory = "" Then
                If ID > 0 Then
                    WorkHistoryData = GetDataset("Select * from ResumeWorkHistory where ID = " & System.Convert.ToString(ID))
                    WorkHistoryRecord = WorkHistoryData.Tables(0).Rows(0)
                Else
                    WorkHistoryData = GetDataset("Select * from ResumeWorkHistory")
                    WorkHistoryRecord = WorkHistoryData.Tables(0).NewRow
                End If
                WorkHistoryRecord.Item("Employer") = Employer
                WorkHistoryRecord.Item("HTTP") = HTTP
                WorkHistoryRecord.Item("Title") = Title
                WorkHistoryRecord.Item("DateStarted") = DateStarted.ToShortDateString
                WorkHistoryRecord.Item("DateLeft") = DateLeft.ToShortDateString
                WorkHistoryRecord.Item("Description") = Description
                If ID <= 0 Then
                    WorkHistoryData.Tables(0).Rows.Add(WorkHistoryRecord)
                    SetDataset(WorkHistoryData.Tables(0).TableName, WorkHistoryData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(WorkHistoryData.Tables(0).TableName, WorkHistoryData)
                End If
            End If
        End Function
        Function DeleteWorkHistory(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeWorkHistory where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)

        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

End Namespace