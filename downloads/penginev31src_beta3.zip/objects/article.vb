Imports System.Data.OleDB
Imports System.Web.HttpContext

Namespace Data

    Public Class Article
        Inherits pengine.Data.DBAccess

        Public Shared Function ProcessDate(ByVal DateString As String) As String
            Dim MyDate As DateTime
            Dim CurDate As DateTime = DateTime.Now
            MyDate = System.Convert.ToDateTime(DateString)
            If MyDate > CurDate Then
                ProcessDate = "Present"
            Else
                ProcessDate = MyDate.ToShortDateString
            End If
        End Function
        Function CategoryList(ByVal AdminFlag As Boolean) As DataSet
            If AdminFlag = True Then
                Return GetDataset("Select category,http from Articles Group By category,http")
            Else
                Return GetDataset("Select category,http from Articles where visible = true group by category,http")
            End If
        End Function
        Function GetArticles(ByVal Category As String, ByVal AdminFlag As Boolean) As DataSet
            If AdminFlag = False Then
                If Category <> "" Then
                    GetArticles = GetDataset("Select ID,Name,Description from Articles where category='" & Category & "' and visible=true order by name ASC")
                Else
                    GetArticles = GetDataset("Select ID,Name,Description from Articles where visible=true order by name ASC")
                End If
            Else
                If Category <> "" Then
                    GetArticles = GetDataset("Select ID,Name,Description from Articles where category='" & Category & "' order by name ASC")
                Else
                    GetArticles = GetDataset("Select ID,Name,Description from Articles order by name ASC")
                End If
            End If
        End Function
        Function GetArticle(ByVal ID As Integer)
            Dim ArticleData As DataSet
            ArticleData = GetDataset("Select * From Articles where id = " & System.Convert.ToString(ID))
            Return ArticleData
        End Function
        Function SaveArticle(ByRef ID As Integer, ByVal Name As String, ByVal Description As String, ByVal Category As String, ByVal http As String, ByVal DefaultSection As String, ByVal Visible As Boolean, ByVal HideDropDown As Boolean, ByVal HideButtons As Boolean, ByVal AdminPass As String) As String
            Dim ArticleRecord As DataRow
            Dim ArticleData As DataSet
            If Name = "" Then
                SaveArticle &= "You must supply a name for this article.|"
            End If
            If Description = "" Then
                SaveArticle &= "You must supply a description for this article.|"
            End If
            If Category = "" Then
                SaveArticle &= "You must supply a category for this article.|"
            End If
            If SaveArticle = "" Then
                If ID > 0 Then
                    ArticleData = GetDataset("Select * from Articles where ID = " & System.Convert.ToString(ID))
                    ArticleRecord = ArticleData.Tables(0).Rows(0)
                Else
                    ArticleData = GetDataset("Select * from Articles")
                    ArticleRecord = ArticleData.Tables(0).NewRow
                End If
                ArticleRecord.Item("Name") = Name
                ArticleRecord.Item("Description") = Description
                ArticleRecord.Item("Category") = Category
                If http.Trim <> "" Then
                    ArticleRecord.Item("http") = http
                Else
                    ArticleRecord.Item("http") = ""
                End If
                ArticleRecord.Item("DefaultSection") = DefaultSection
                ArticleRecord.Item("Visible") = Visible
                ArticleRecord.Item("HideButtons") = HideButtons
                ArticleRecord.Item("HideDropDown") = HideDropDown
                ArticleRecord.Item("AdminPass") = AdminPass
                If ID > 0 Then
                    SetDataset(ArticleData.Tables(0).TableName, ArticleData)
                Else
                    ArticleData.Tables(0).Rows.Add(ArticleRecord)
                    SetDataset(ArticleData.Tables(0).TableName, ArticleData)
                    ID = GetScalar("SELECT @@IDENTITY")
                End If
            End If
        End Function
        Function DeleteArticle(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Articles where ID = " & System.Convert.ToString(ID))
                ExecuteSQL("Delete from ArticleSection where ArticleID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Function GetArticleSection(ByVal ID As Integer, ByVal Section As String) As DataSet
            Dim DefaultSection As String
            Dim ArticleData As DataSet
            Dim HideDropDownFlag As Boolean
            ArticleData = GetDataset("Select * from Articles where id = " & System.Convert.ToString(ID))
            If ArticleData.Tables(0).Rows.Count > 0 Then
                'If ArticleData.Read Then
                If Section = "" Then
                    DefaultSection = ArticleData.Tables(0).Rows(0).Item("DefaultSection") & ""
                Else
                    DefaultSection = Section
                End If
                'HideDropDownFlag = ArticleData.Item("HideDropDown")
                'ArticleData.Close()
                If DefaultSection = "" Then
                    ArticleData = GetDataset("Select TOP 1 * from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " order by sortorder,name")
                Else
                    ArticleData = GetDataset("Select TOP 1 * from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " and name = '" & DefaultSection & "' order by sortorder,name")
                End If
            Else
                'Article Data not Found.
            End If
            'Invalid data provided for Article ID.
            Return ArticleData
        End Function
        Function GetArticleSections(ByVal ID As Integer) As DataSet
            GetArticleSections = GetDataset("Select * from ArticleSection where ArticleID = " & System.Convert.ToString(ID))
        End Function
        Function SaveArticleSection(ByRef ArticleID As Integer, ByVal OldName As String, ByVal Name As String, ByVal Data As String, ByVal SortOrder As Integer) As String
            Dim SectionRecord As DataRow
            Dim SectionData As DataSet
            If Name = "" Then
                SaveArticleSection &= "You must supply a name for this section.|"
            End If
            If Data = "" Then
                SaveArticleSection &= "You must supply data for this section.|"
            End If
            If SaveArticleSection = "" Then
                If OldName <> "" Then
                    SectionData = GetDataset("Select * from ArticleSection where Name = '" & OldName & "' and ArticleID = " & System.Convert.ToString(ArticleID))
                    SectionRecord = SectionData.Tables(0).Rows(0)
                Else
                    SectionData = GetDataset("Select * from ArticleSection")
                    SectionRecord = SectionData.Tables(0).NewRow
                End If
                SectionRecord.Item("ArticleID") = ArticleID
                SectionRecord.Item("Name") = Name
                SectionRecord.Item("Data") = Data
                SectionRecord.Item("SortOrder") = SortOrder
                If OldName = "" Then
                    SectionData.Tables(0).Rows.Add(SectionRecord)
                End If
                SetDataset(SectionData.Tables(0).TableName, SectionData)
            End If
        End Function
        Public Shared Function CleanSectionName(ByVal SectionName As String) As String
            Dim BannedChars() As Char = {"/", "\", "?", "!", ";", ":", """", "'", "(", ")", "&", "$", "%", "#" _
            , "@", "*", "|", ",", "-"}
            Dim CharPtr As Integer
            SectionName = SectionName.Replace(" ", "_")
            For CharPtr = 0 To BannedChars.GetUpperBound(0)
                SectionName = SectionName.Replace(BannedChars(CharPtr), "")
            Next
            SectionName = SectionName.ToLower
            Return SectionName
        End Function
        Function DeleteArticleSection(ByVal ArticleID As Integer, ByVal SectionName As String) As Boolean
            If ArticleID > 0 And SectionName <> "" Then
                ExecuteSQL("Delete from ArticleSection where Name = '" & SectionName & "' and ArticleID = " & System.Convert.ToString(ArticleID))
                Return True
            Else
                Return False
            End If
        End Function
        Function SectionList(ByVal ID As Integer) As DataSet
            SectionList = GetDataset("Select Name from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " order by sortorder,name")
        End Function
        Function DefaultSection(ByVal ID As Integer) As String
            DefaultSection = GetScalar("Select defaultsection from Articles where ID = " & System.Convert.ToString(ID))
            If DefaultSection = "" Then
                DefaultSection = GetScalar("Select top 1 name from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " order by sortorder,name asc")
            End If
        End Function
        Function CategoryCount(ByVal Category As String, ByVal AdminFlag As Boolean) As Integer
            If AdminFlag = False Then
                If Category <> "" Then
                    CategoryCount = GetScalar("Select count(*) from Articles where category='" & Category & "' and visible=true")
                Else
                    CategoryCount = GetScalar("Select count(*) from Articles where visible=true")
                End If
            Else
                If Category <> "" Then
                    CategoryCount = GetScalar("Select count(*) from Articles where category='" & Category & "'")
                Else
                    CategoryCount = GetScalar("Select count(*) from Articles")
                End If
            End If
        End Function
        Function Category(ByVal ID As Integer) As String
            Category = GetScalar("Select category from Articles where id = " & System.Convert.ToString(ID))
        End Function
        Function MenuIsHidden(ByVal ID As Integer) As Boolean
            MenuIsHidden = GetScalar("Select hidebuttons from Articles where id = " & System.Convert.ToString(ID))
        End Function
        Function Title(ByVal ID As Integer) As String
            Title = GetScalar("Select name from Articles where id = " & System.Convert.ToString(ID))
        End Function
        Public Shared Function ConverttoHTML(ByVal secdata As String, ByVal forumflag As Boolean, Optional ByVal ArticleID As Integer = 0) As String
            Dim cpos As Integer = 0
            Dim lpos As Integer = 0
            Dim tag As String
            Dim tagname As String
            Dim tagdata As String
            Dim tagspace As Integer = 0
            Dim tagelements() As String
            Dim rawhtmlflag As Boolean = False
            Dim rawhtmlstart As Integer
            Dim rawhtmlend As Integer
            Dim outdata As String
            Dim resforumtags() As String = {"SCRIPT", "/SCRIPT", "IFRAME", "/IFRAME", "EMBED", "BLINK", "TR", "TD", "TABLE", "/TR", "/TD", "/TABLE", "FRAMESET", "/FRAMESET"}
            Dim restagflag As Boolean
            Dim OutputHTML As String = ""
            'Filter for obfusacated tags if Forum Flag is True
            'Remove HTML Content if Forum Flag is True
            If forumflag = True Then
                While InStr(1, secdata, "[" & vbNewLine) > 0
                    secdata = secdata.Replace("[" & vbNewLine, "[ ")
                End While
                While InStr(1, secdata, "<" & vbNewLine) > 0
                    secdata = secdata.Replace("<" & vbNewLine, "< ")
                End While
                While InStr(1, secdata, "[ ") > 0
                    secdata = secdata.Replace("[ ", "[")
                End While
                While InStr(1, secdata, "< ") > 0
                    secdata = secdata.Replace("< ", "<")
                End While
                cpos = InStr(1, secdata, "<")
                While cpos > 0
                    lpos = InStr(cpos + 1, secdata, ">")
                    If lpos > 0 Then
                        secdata = Left(secdata, cpos - 1) & Right(secdata, Len(secdata) - lpos)
                        'OutputHTML &= secdata
                        'response.end
                    End If
                    cpos = InStr(cpos, secdata, "<")
                End While
            End If
            lpos = 0
            cpos = InStr(1, secdata, "[")
            While cpos > 0
                If rawhtmlflag = False Then
                    outdata = Mid(secdata, lpos + 1, (cpos - 1) - lpos)
                    OutputHTML &= Replace(ConvertToElite(outdata), vbNewLine, "<br>" & vbNewLine)
                End If
                lpos = InStr(cpos + 1, secdata, "]")
                tag = Mid(secdata, cpos + 1, lpos - (cpos + 1))
                tagspace = InStr(1, tag, " ")
                If tagspace > 0 Then
                    tagname = Mid(tag, 1, tagspace - 1)
                    tagdata = Mid(tag, tagspace + 1, Len(tag) - (tagspace))
                Else
                    tagname = tag
                End If
                If rawhtmlflag = False Or UCase(tagname) = "/RAWHTML" Then
                    Select Case Trim(UCase(tagname))
                        Case "IMAGE"
                            If InStr(1, UCase(tagdata), "HTTP") > 0 Or Left(tagdata, 2) = "./" Or Left(tagdata, 1) = "/" Then
                                OutputHTML &= "<img src=""" & tagdata & """>"
                            Else
                                If Current.Application.Item("basepath") <> "" Then
                                    OutputHTML &= "<img src=""" & Current.Application.Item("basepath") & "/images/articles/" & tagdata & """>"
                                Else
                                    OutputHTML &= "<img src=""./images/articles/" & tagdata & """>"
                                End If

                            End If
                        Case "SUBHEADER"
                            If forumflag = False Then
                                OutputHTML &= CreateHTMLSubHeader(tagdata)
                            End If
                        Case "LINK"
                            tagelements = Split(tagdata, " ")
                            OutputHTML &= "<a href=""" & tagelements(0) & """>"
                            Dim i As Integer
                            For i = 0 To UBound(tagelements)
                                If i > 0 Then
                                    If i > 1 Then
                                        OutputHTML &= " "
                                    End If
                                    OutputHTML &= tagelements(i)
                                End If
                            Next
                            If UBound(tagelements) < 1 Then OutputHTML &= (tagelements(0))
                            OutputHTML &= "</A>"
                        Case "ICON"
                            If Current.Application.Item("basepath") <> "" Then
                                OutputHTML &= "<img src=""" & Current.Application.Item("basepath") & "/images/icons/" & tagdata & """>"
                            Else
                                OutputHTML &= "<img src=""./images/icons/" & tagdata & """>"
                            End If
                        Case "SYSTEMIMAGE"
                            If Current.Application.Item("basepath") <> "" Then
                                OutputHTML &= "<img src=""" & Current.Application.Item("basepath") & "/images/system/" & tagdata & """>"
                            Else
                                OutputHTML &= "<img src=""./images/system/" & tagdata & """>"
                            End If
                        Case "SECTION"
                            If forumflag = False Then
                                If ArticleID > 0 Then
                                    OutputHTML &= CreateHTMLButton("default.aspx?cmd=article&sub=display&id=" & ArticleID & "&section=" & tagdata, tagdata, "")
                                End If
                            End If
                        Case "RAWHTML"
                            'This tag indicates that any code enclosed within this tag is raw HTML and NOT to be touched
                            'If forumflag = false then
                            rawhtmlflag = True
                            rawhtmlstart = cpos + 9
                            rawhtmlend = rawhtmlstart
                            'End If
                        Case "/RAWHTML"
                            'This tag indicates that any code following it should be processed as if it was not HTML.
                            'If forumflag = false then
                            rawhtmlflag = False
                            rawhtmlend = cpos
                            OutputHTML &= Mid(secdata, rawhtmlstart, rawhtmlend - rawhtmlstart)
                            'End If
                        Case "QUOTE"
                            'This tag indicates that the content inside is to be quoted
                            OutputHTML &= "<blockquote><table border=1><tr><td class=""contenttext"">"
                        Case "/QUOTE"
                            'This closes out the quotes
                            OutputHTML &= "</td></tr></table></blockquote>"
                        Case Else
                            restagflag = False
                            If forumflag = True Then
                                Dim i As Integer
                                For i = LBound(resforumtags) To UBound(resforumtags)
                                    If UCase(resforumtags(i)) = UCase(tagname) Then
                                        restagflag = True
                                    End If
                                Next
                            End If
                            If restagflag = False Then
                                OutputHTML &= "<" & tag & ">"
                            End If
                    End Select
                End If
                cpos = InStr(lpos + 1, secdata, "[")
            End While
            If lpos <> 0 Then
                outdata = Mid(secdata, lpos + 1, Len(secdata) - lpos)
                If rawhtmlflag = False Then
                    OutputHTML &= Replace(ConvertToElite(outdata), vbNewLine, "<br>" & vbNewLine)
                Else
                    OutputHTML &= outdata
                End If
            Else
                OutputHTML &= Replace(ConvertToElite(secdata), vbNewLine, "<br>" & vbNewLine)
            End If
            If OutputHTML <> "" Then
                Return OutputHTML
            Else
                Return "There was no data to convert."
            End If
        End Function
        Public Shared Function CreateHTMLSubHeader(ByVal text As String) As String
            Dim OutputHTML As String = ""
            OutputHTML &= "<a name=""" & text.Replace(" ", "") & """>"
            OutputHTML &= "<table id width=""100%"" cellspacing=""0"" cellpadding=""0"">" & System.Environment.NewLine
            OutputHTML &= "<tr>" & System.Environment.NewLine
            OutputHTML &= "<td class=""sheaderleftcell"">"
            If Current.Session.Item("SHeaderLImage") <> "" Then
                OutputHTML &= "<img src=""" & Current.Session.Item("SHeaderLImage") & """>"
            End If
            OutputHTML &= "</td>" & System.Environment.NewLine
            OutputHTML &= "<td class=""sheadermidcell"" width=""100%"">"
            OutputHTML &= "<span class=""sheadermidtext"">" & ConvertToElite(text) & "</span>"
            OutputHTML &= "</td>" & System.Environment.NewLine
            OutputHTML &= "<td class=""sheaderrightcell"">"
            If Current.Session.Item("SHeaderRImage") <> "" Then
                OutputHTML &= "<img src=""" & Current.Session.Item("SHeaderRImage") & """>"
            End If
            OutputHTML &= "</td>" & System.Environment.NewLine
            OutputHTML &= "</tr>" & System.Environment.NewLine
            OutputHTML &= "</table>" & System.Environment.NewLine
            Return OutputHTML
        End Function
        Public Shared Function CreateHTMLIcon(ByVal URL As String) As String
            Dim OutputHTML As String = ""
            If URL <> "" Then
                OutputHTML &= "<img src=""./images/icons/" & URL & """ align=right hspace=20 vspace=10>"
            End If
            Return OutputHTML
        End Function
        Public Shared Function CreateHTMLButton(ByVal URL As String, ByVal Text As String, ByVal ConfirmMessage As String) As String
            Dim OutputHTML As String = ""
            If ConfirmMessage <> "" Then
                ConfirmMessage = ConfirmMessage.Replace("'", "\'")
                ConfirmMessage = ConfirmMessage.Replace("(", "\(")
                ConfirmMessage = ConfirmMessage.Replace(")", "\)")
            End If
            If URL <> "" Then
                OutputHTML &= "<table><tr><form action=""" & URL & """ method=""post"" "
                If ConfirmMessage <> "" Then
                    OutputHTML &= "onsubmit=""javascript:return confirmform('" & ConfirmMessage & "');"""
                End If
                OutputHTML &= "><td><input type=""submit"" value=""" & Text & """></td></form></tr></table>"
            Else
                OutputHTML &= "<table><tr><td><input type=button disabled value=""" & Text & """></td></tr></table>"
            End If
            Return OutputHTML
        End Function
        Public Shared Function ConvertToElite(ByVal OrigText As String) As String
            'This function was originally stolen from somewhere on the internet.
            'I translated the original Javascript version into VBScript and now into VB.NET
            'Due to all of the work I've put into it I am now claiming ownership of it.
            'Note:  I can't remember where in the hell it came from anyway.
            Dim words() As String
            Dim wordptr As Integer
            Dim cword As String
            Dim charptr As Integer
            Dim curchar As String
            Dim newword As String
            Dim Randomizer As System.Random = New System.Random(Date.Now.Millisecond)
            If Current.Session.Item("leetflag") = False Then
                ConvertToElite = OrigText
            Else
                words = OrigText.ToLower.Split(" ")
                For wordptr = words.GetLowerBound(0) To words.GetUpperBound(0)
                    cword = words(wordptr)
                    'Process special words
                    Select Case words(wordptr)
                        Case "am"
                            If wordptr < words.GetUpperBound(0) Then
                                If words(wordptr + 1) = "good" Then
                                    cword = "ownz0r"
                                    wordptr = wordptr + 1
                                End If
                            End If
                        Case "is"
                            If wordptr < words.GetUpperBound(0) Then
                                If words(wordptr + 1) = "good" Then
                                    cword = "ownz0rz"
                                    wordptr = wordptr + 1
                                End If
                            End If
                        Case "cool"
                            cword = "k3wl"
                        Case "dude"
                            cword = "d00d"
                        Case "dudes"
                            cword = "d00dz"
                        Case "elite"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "l33t"
                            Else
                                cword = "31337"
                            End If
                        Case "hacker"
                            cword = "hax0r"
                        Case "hacked"
                            cword = "hax0red"
                        Case "the"
                            If Randomizer.Next Mod 100 < 60 Then
                                cword = "teh"
                            End If
                        Case "mp3s"
                            cword = "mp3z"
                        Case "own"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "pwn"
                            Else
                                cword = "0wnzor"
                            End If
                        Case "owned"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "pwned"
                            Else
                                cword = "0wnzored"
                            End If
                        Case "porn"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "pr0n"
                            End If
                        Case "quake"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaek"
                            End If
                        Case "quake2"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaek2"
                            End If
                        Case "quake3"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaek3"
                            End If
                        Case "quakeworld"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaekworld"
                            End If
                        Case "rock"
                            cword = "r0x0r"
                        Case "rocks"
                            cword = "r0x0rez"
                        Case "you"
                            cword = "j00"
                    End Select

                    'Process Special Characters
                    newword = ""
                    For charptr = 1 To cword.Length
                        curchar = cword.Substring(charptr - 1, 1)
                        Select Case curchar
                            Case "a"
                                If Randomizer.Next Mod 100 < 30 Then
                                    curchar = "@"
                                Else
                                    curchar = "4"
                                End If
                            Case "b"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "8"
                                End If
                            Case "d"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|)"
                                End If
                            Case "e"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "3"
                                End If
                            Case "f"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "ph"
                                End If
                            Case "g"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "9"
                                End If
                            Case "h"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|-|"
                                End If
                            Case "i"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "1"
                                End If
                            Case "k"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|&lt;"
                                End If
                            Case "m"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|\\\/|"
                                End If
                            Case "n"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|\\|"
                                End If
                            Case "o"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "0"
                                End If
                            Case "q"
                                If charptr < cword.Length Then
                                    If curchar = "q" And cword.Substring(charptr, 1) = "u" Then
                                        curchar = "kw"
                                        charptr = charptr + 1
                                    End If
                                End If
                            Case "s"
                                If Randomizer.Next Mod 100 < 30 Then
                                    curchar = "$"
                                Else
                                    curchar = "5"
                                End If
                            Case "t"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "+"
                                End If
                            Case "v"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "\\\/"
                                End If
                            Case "w"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "\\\/\\\/"
                                End If
                            Case "x"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "&gt;&lt;"
                                End If
                        End Select
                        'Randomize case
                        If Randomizer.Next Mod 100 < 50 Then
                            curchar = curchar.ToUpper
                        End If
                        newword = newword & curchar
                    Next
                    ConvertToElite = ConvertToElite & newword & " "
                Next
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

End Namespace