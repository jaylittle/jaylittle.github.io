Imports System.Web.HttpContext

Namespace Data

    Public Class Theme

        Public CSSCode As String
        Public Function GetThemeList() As ArrayList
            GetThemeList = New ArrayList
            Dim FSInfo As System.IO.DirectoryInfo
            Dim DirList() As System.IO.DirectoryInfo
            Dim DirPtr As Integer
            If Current.Application.Item("basepath") <> "" Then
                FSInfo = New System.IO.DirectoryInfo(Current.Server.MapPath(Current.Application.Item("basepath") & "/themes/"))
            Else
                FSInfo = New System.IO.DirectoryInfo(Current.Server.MapPath("./themes/"))
            End If
            DirList = FSInfo.GetDirectories("*")
            For DirPtr = DirList.GetLowerBound(0) To DirList.GetUpperBound(0)
                GetThemeList.Add(DirList(DirPtr).Name)
            Next
        End Function
        Public Sub LoadTheme(ByVal ThemeName As String)
            Dim FSInfo As System.IO.FileInfo
            Dim FSStream As System.IO.TextReader
            Dim DataRecord As String
            Dim DataFields() As String
            If Current.Application.Item("basethemepath") <> "" Then
                FSInfo = New System.IO.FileInfo(Current.Server.MapPath(Current.Application.Item("basethemepath") & ThemeName & "/" & ThemeName & ".csv"))
            Else
                FSInfo = New System.IO.FileInfo(Current.Server.MapPath("./themes/" & ThemeName & "/" & ThemeName & ".csv"))
            End If
            If FSInfo.Exists Then
                Current.Trace.Write("Theme file located - parsing settings from this file.")
                FSStream = FSInfo.OpenText
                While FSStream.Peek() >= 0
                    DataRecord = FSStream.ReadLine()
                    DataFields = DataRecord.Split(",")
                    DataFields(0) = DataFields(0).ToUpper.Trim
                    DataFields(1) = DataFields(1).Trim
                    If DataFields(0).StartsWith("PAGE") Or DataFields(0).StartsWith("HEADER") _
                    Or DataFields(0).StartsWith("SHEADER") Or DataFields(0).StartsWith("CONTENT") _
                    Or DataFields(0).StartsWith("FOOTER") Or DataFields(0).StartsWith("MENU") Then
                        If DataFields(1) = "TRUE" Then
                            Current.Session(DataFields(0).ToLower) = True
                        ElseIf DataFields(1) = "FALSE" Then
                            Current.Session(DataFields(0).ToLower) = False
                        Else
                            Current.Session(DataFields(0).ToLower) = DataFields(1)
                        End If
                    End If
                End While
                FSStream.Close()
                Current.Session.Item("theme") = ThemeName
                Current.Cache.Item(Current.Session.SessionID & "theme") = ThemeName
                MapThemeImages()
                CSSCode = BuildCSS()
                Current.Session.Item("themecss") = CSSCode
            Else
                Current.Trace.Write("Theme file not located. Throwing an Error.")
            End If
        End Sub
        Private Sub MapThemeImages()
            Dim themeroot As String
            Dim listptr As Integer
            Dim imagelist() As String = {"PageLImage", "PageRImage", "PageBGImage", "HeaderLImage", "HeaderMImage", "HeaderRImage" _
            , "SHeaderLImage", "SHeaderMImage", "SHeaderRImage", "FooterLImage", "FooterRImage", "FooterMImage", "MenuLImage" _
            , "MenuMImage", "MenuRImage", "ContentBGImage", "MenuBarBGImage"}
            If Current.Application.Item("basethemepath") <> "" Then
                themeroot = Current.Application.Item("basethemepath") & Current.Session("theme") & "/"
            Else
                themeroot = "./themes/" & Current.Session.Item("theme") & "/"
            End If
            For listptr = LBound(imagelist) To UBound(imagelist)
                If Current.Session.Item(imagelist(listptr)) <> "" Then
                    Current.Session.Item(imagelist(listptr)) = themeroot & Current.Session.Item(imagelist(listptr))
                End If
            Next
        End Sub
        Private Function BuildCSS() As String
            Dim MyCSS As String
            MyCSS = "textarea {width:100%;} " & System.Environment.NewLine
            MyCSS &= "A:link {color: " & Current.Session.Item("pagelinkcolor") & "}" & System.Environment.NewLine
            MyCSS &= "A:visited {color: " & Current.Session.Item("pagevlinkcolor") & "}" & System.Environment.NewLine
            MyCSS &= "A:active {color: " & Current.Session.Item("pagealinkcolor") & "}" & System.Environment.NewLine
            MyCSS &= "B {color: " & Current.Session.Item("contentboldcolor") & "}" & System.Environment.NewLine

            MyCSS &= ".pagebody {"
            MyCSS &= "margin-top: " & Current.Session.Item("pagetopmargin") & "; "
            MyCSS &= "margin-left: " & Current.Session.Item("pageleftmargin") & "; "
            MyCSS &= "margin-right: " & Current.Session.Item("pagerightmargin") & "; "
            If Current.Session.Item("PageBGImage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("pagebgimage") & """); "
            End If
            MyCSS &= "background-color: " & Current.Session.Item("pagebgcolor") & "; }" & System.Environment.NewLine

            MyCSS &= ".contentbody {"
            If Current.Session.Item("contentfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("contentfont") & "; "
            End If
            If IsNumeric(Current.Session.Item("contentfontsize")) Then
                MyCSS &= "font-size: " & Current.Session.Item("contentfontsize") & "px; "
            End If
            MyCSS &= "color: " & Current.Session.Item("ContentFGColor") & "; "
            If Current.Session.Item("contentbgimage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("contentbgimage") & """); "
            End If
            MyCSS &= "background-color: " & Current.Session.Item("ContentBGColor") & "; }" & System.Environment.NewLine

            MyCSS &= ".contenttext {"
            If Current.Session.Item("contentfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("contentfont") & "; "
            End If
            If IsNumeric(Current.Session.Item("contentfontsize")) Then
                MyCSS &= "font-size: " & Current.Session.Item("contentfontsize") & "px; "
            End If
            MyCSS &= "color: " & Current.Session.Item("ContentFGColor") & "; }" & System.Environment.NewLine


            MyCSS &= ".menubody {"
            If Current.Session.Item("menubarbgimage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("menubarbgimage") & """); "
            End If
            MyCSS &= "background-color: " & Current.Session.Item("menubarbgcolor") & "; }" & System.Environment.NewLine

            MyCSS &= ".headerleftcell {"
            If Current.Session.Item("headerbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("headerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".headermidcell {"
            If Current.Session.Item("headermimage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("headermimage") & """); "
            End If
            If Current.Session.Item("headerbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("headerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".headermidtext {"
            If Current.Session.Item("headerfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("headerfont") & "; "
            End If
            If Current.Session.Item("headerfontsize") <> "" Then
                MyCSS &= "font-size: " & Current.Session.Item("headerfontsize") & "px; "
            End If
            If Current.Session.Item("headerfgcolor") <> "" Then
                MyCSS &= "color: " & Current.Session.Item("headerfgcolor") & "; "
            End If
            MyCSS &= "font-weight:bold; }" & System.Environment.NewLine

            MyCSS &= ".headerrightcell {"
            If Current.Session.Item("headerbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("headerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".sheaderleftcell {"
            If Current.Session.Item("sheaderbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("sheaderbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".sheadermidcell {"
            If Current.Session.Item("sheadermimage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("sheadermimage") & """); "
            End If
            If Current.Session.Item("sheaderbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("sheaderbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".sheadermidtext {"
            If Current.Session.Item("sheaderfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("sheaderfont") & "; "
            End If
            If Current.Session.Item("sheaderfontsize") <> "" Then
                MyCSS &= "font-size: " & Current.Session.Item("sheaderfontsize") & "; "
            End If
            If Current.Session.Item("sheaderfgcolor") <> "" Then
                MyCSS &= "color: " & Current.Session.Item("sheaderfgcolor") & "; "
            End If
            MyCSS &= "font-weight:bold; }" & System.Environment.NewLine

            MyCSS &= ".sheaderrightcell {"
            If Current.Session.Item("sheaderbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("sheaderbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".footerleftcell {"
            If Current.Session.Item("footerbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("footerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".footermidcell {"
            If Current.Session.Item("footermimage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("footermimage") & """); "
            End If
            If Current.Session.Item("footerbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("footerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".footerrightcell {"
            If Current.Session.Item("footerbgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("footerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".lheadercell {"
            MyCSS &= "background-color: " & Current.Session.Item("contentlheadbgcolor") & "; "
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".lheadertext {"
            MyCSS &= "color: " & Current.Session.Item("contentlheadfgcolor") & "; "
            If Current.Session.Item("contentfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("contentfont") & "; "
            End If
            If IsNumeric(Current.Session.Item("contentfontsize")) Then
                MyCSS &= "font-size: " & Current.Session.Item("contentfontsize") & "px; "
            End If
            MyCSS &= "font-weight: bold }" & System.Environment.NewLine

            MyCSS &= ".lcontentcell {"
            MyCSS &= "background-color: " & Current.Session.Item("contentlistbgcolor1") & "; "
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".lcontenttext {"
            MyCSS &= "color: " & Current.Session.Item("contentlistfgcolor1") & "; "
            If Current.Session.Item("contentfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("contentfont") & "; "
            End If
            If IsNumeric(Current.Session.Item("contentfontsize")) Then
                MyCSS &= "font-size: " & Current.Session.Item("contentfontsize") & "px; "
            End If
            MyCSS &= "font-weight: normal }" & System.Environment.NewLine

            MyCSS &= ".lcontentcellb {"
            MyCSS &= "background-color: " & Current.Session.Item("contentlistbgcolor2") & "; "
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".lcontenttextb {"
            MyCSS &= "color: " & Current.Session.Item("contentlistfgcolor2") & "; "
            If Current.Session.Item("contentfont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("contentfont") & "; "
            End If
            If IsNumeric(Current.Session.Item("contentfontsize")) Then
                MyCSS &= "font-size: " & Current.Session.Item("contentfontsize") & "px; "
            End If
            MyCSS &= "font-weight: normal }" & System.Environment.NewLine

            MyCSS &= ".menutable {"
            If Current.Session.Item("menuborder") = "" Or Current.Session("menuborder") = 0 Then
                MyCSS &= "border-style: none; border-collapse: collapse; "
            Else
                MyCSS &= "border: " & Current.Session.Item("menuborder") & "px; border-style: solid; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".menurow {"
            If Current.Session.Item("menubgcolor") <> "" Then
                MyCSS &= "background-color: " & Current.Session.Item("menubgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".menumidrow {"
            If Current.Session.Item("menumimage") <> "" Then
                MyCSS &= "background-image:url(""" & Current.Session.Item("menumimage") & """); "
            End If
            If Current.Session.Item("MenuFontCenter") = 1 Then
                MyCSS &= "text-align: center; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= ".menutext {"
            If Current.Session.Item("menufont") <> "" Then
                MyCSS &= "font-family: " & Current.Session.Item("menufont") & "; "
            End If
            If Current.Session.Item("menufontsize") <> "" Then
                MyCSS &= "font-size: " & Current.Session.Item("menufontsize") & "; "
            End If
            If Current.Session.Item("menufgcolor") <> "" Then
                MyCSS &= "color: " & Current.Session.Item("menufgcolor") & "; "
            End If
            'MyCSS &= "text-decoration: none; "
            MyCSS &= "font-weight:bold; }" & System.Environment.NewLine

            Return MyCSS
        End Function
        Public Sub New()

        End Sub
    End Class

End Namespace