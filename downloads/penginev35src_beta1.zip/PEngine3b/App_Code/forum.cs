using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

/// <summary>
/// Summary description for forum
/// </summary>
namespace pengine
{
    public class forum : pengine.dbaccess
    {
        public forum(string mycstring)
            : base(mycstring)
        {
        }

        public string forum_getname(int id)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select Name from Forums where ID = " + id.ToString());
            return retvalue;
        }

        public string thread_getname(int id)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select Title from Messages where ID = " + id.ToString());
            return retvalue;
        }

        public int thread_getposts(int id)
        {
            int retvalue = 0;
            retvalue = (int)scalar_get("Select Posts from Messages where ID = " + id.ToString());
            return retvalue;
        }

        public int thread_getforumid(int id)
        {
            int retvalue = 0;
            retvalue = (int)scalar_get("Select ForumID from Messages where ID = " + id.ToString());
            return retvalue;
        }

        public DataTable forum_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select ID,Name,Description, (Select count(*) from Messages where Forums.ID = Messages.ForumID) as Posts "
                + ", (Select max(TimePosted) from Messages where Forums.ID = Messages.ForumID) as LastPost "
                + "from Forums order by Name ASC"
                , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            return retvalue;
        }

        public DataTable forum_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from Forums where ID = " + id.ToString()
                , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            return retvalue;
        }

        public List<string> forum_save(ref int id, string name, string description)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(name))
            {
                errors.Add("You must supply a name for the forum.");
            }
            if (string.IsNullOrEmpty(description))
            {
                errors.Add("You must supply a description for the forum.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from Forums where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from Forums"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Name"] = name;
                record["Description"] = description;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
            }
            return errors;
        }

        bool forum_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from Forums where ID = " + id.ToString());
                sql_execute("Delete from Messages where ForumID = " + id.ToString());
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable thread_list(int forumid, int start, int count)
        {
            DataTable retvalue = null;
            int startid = 0;
            if ((start > 0) && (count > 0))
            {
                DataTable temp = data_load("Select TOP " + start.ToString()
                    + " ID from Messages where ForumID = " + forumid.ToString()
                    + " and ParentID = Messages.ID order by TimePosted DESC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                if (temp.Rows.Count > 0)
                {
                    startid = (int)temp.Rows[temp.Rows.Count - 1]["ID"];
                    retvalue = data_load("Select TOP " + count.ToString()
                        + " Messages.*,Users.Name as UserName from Messages,Users where UserID = Users.ID and ForumID = "
                        + forumid.ToString() + " and ParentID = ID and Messages.ID <= "
                        + startid.ToString() + " order by TimePosted DESC"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                }
            }
            else if (count > 0)
            {
                retvalue = data_load("Select TOP " + count.ToString()
                    + " Messages.*,Users.Name as UserName from Messages,Users where UserID = Users.ID and ForumID = "
                    + forumid.ToString() + " and ParentID = Messages.ID order by TimePosted DESC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            else
            {
                retvalue = data_load("Select Messages.*,Users.Name as UserName from Messages,Users where "
                    + "UserID = Users.ID and ForumID = " + forumid.ToString()
                    + " and ParentID = Messages.ID order by TimePosted DESC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            return retvalue;
        }

        public int message_pagenum(int messageid, int count)
        {
            int retvalue = 0;
            int postcount = (int)scalar_get("Select count(*) from Messages where ID <= "
                + messageid.ToString() + " order by TimePosted ASC");
            retvalue = (postcount - (postcount % count)) / count;
            return retvalue;
        }

        public DataTable message_list(int threadid, int start, int count)
        {
            DataTable retvalue = null;
            int startid = 0;
            if ((start > 0) && (count > 0))
            {
                DataTable temp = data_load("Select TOP " + start.ToString()
                    + " ID from ParentID = " + threadid.ToString() + " order by TimePosted ASC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                if (temp.Rows.Count > 0)
                {
                    startid = (int)temp.Rows[temp.Rows.Count - 1]["ID"];
                    retvalue = data_load("Select TOP " + count.ToString()
                        + " Messages.*,User.Name as UserName,User.Title as UserTitle from Messages,Users where"
                        + " Messages.UserID = Users.ID and ParentID = " + threadid.ToString()
                        + " and Messages.ID <= " + startid.ToString() + " order by TimePosted ASC"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                }
            }
            else if (count > 0)
            {
                retvalue = data_load("Select TOP " + count.ToString()
                    + " Messages.*,Users.Name as username, Users.Title as UserTitle from Messages, Users where "
                    + "Messages.UserID = Users.ID and ParentID = " + threadid.ToString()
                    + " order by TimePosted ASC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            else
            {
                retvalue = data_load("Select Messages.*, User.Name as UserName, User.Title as UserTitle "
                    + "from Messages,Users where Messages.UserID = Users.ID and ParentID = "
                    + threadid.ToString() + " order by TimePosted ASC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            return retvalue;
        }

        static public string thread_pagerhtml(int threadid, int posts, int postsperpage, string urlstart, string urlend, string cssid)
        {
            return thread_pagerhtml(threadid, posts, postsperpage, urlstart, urlend, cssid, 0);
        }

        static public string thread_pagerhtml(int threadid, int posts, int postsperpage, string urlstart, string urlend, string cssid, int currentpage)
        {
            string retvalue = string.Empty;
            for (int pptr = 0; pptr <= posts; pptr += postsperpage)
            {
                int tpage = (pptr + postsperpage) / postsperpage;
                if (pptr > 0)
                {
                    retvalue += " ";
                }
                if ((currentpage <= 0) || (currentpage != tpage))
                {
                    if (cssid != string.Empty)
                    {
                        retvalue += "<a class=\"" + cssid + "\" href=\"";
                    }
                    else
                    {
                        retvalue += "<a href=\"";
                    }
                    retvalue += urlstart + threadid.ToString() + urlend
                        + tpage.ToString() + "\">" + tpage.ToString() + "</a>";
                }
                else
                {
                    retvalue += tpage.ToString();
                }
            }
            return retvalue;
        }

        static public string thread_titlehtml(string title)
        {
            string retvalue = string.Empty;
            if (!string.IsNullOrEmpty(title))
            {
                retvalue = "\"" + title + "\"";
            }
            return retvalue;
        }

        public DataTable user_validate(string username, string password, bool encflag)
        {
            DataTable retvalue = null;
            string encpass = string.Empty;
            if (encflag)
            {
                encpass = password;
            }
            else
            {
                encpass = system.pass_encrypt(password);
            }
            if (string.IsNullOrEmpty(password))
            {
                retvalue = data_load("Select * from Users where Name = '"
                    + HttpContext.Current.Server.HtmlEncode(username)
                    + "' and (UserPass = '' or UserPass is null)"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            else
            {
                retvalue = data_load("Select * from Users where Name = '"
                    + HttpContext.Current.Server.HtmlEncode(username)
                    + "' and UserPass = '" + encpass + "'"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            return retvalue;
        }

        public DateTime user_lastpost(int userid)
        {
            DateTime retvalue = DateTime.MinValue;
            string dtstring = (string)scalar_get("Select TOP 1 timeposted from messages where userid = "
                + userid.ToString() + " order by timeposted DESC");
            retvalue = DateTime.Parse(dtstring);
            return retvalue;
        }

        public string user_lastip(int userid)
        {
            string retvalue = (string)scalar_get("Select TOP 1 ipaddress from messages where userid = "
                + userid.ToString() + " order by timeposted DESC");
            return retvalue;
        }

        public string user_name(int userid)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select * from Users where ID = " + userid.ToString());
            return retvalue;
        }

        public DataTable user_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from Users"
                , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            return retvalue;
        }

        public DataTable user_get(int userid)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from Users where ID = " + userid.ToString()
                , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            return retvalue;
        }

        public List<string> user_save(ref int id, string name, string fullname, string title
            , string description, string publicemail, string privateemail, string homeurl
            , string aimaccount, string icqaccount, string yahooaccount, string msnaccount
            , bool moderator, bool disable, string newpassword)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(name))
            {
                errors.Add("You must supply a name for this user account.");
            }
            if (string.IsNullOrEmpty(privateemail))
            {
                errors.Add("You must supply a private email address.");
            }
            if ((id <= 0) && (string.IsNullOrEmpty(newpassword)))
            {
                errors.Add("You must provide a password for a new account.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from Users where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from Users"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                    record["JoinDate"] = DateTime.Now.ToShortDateString();
                    record["PostCount"] = 0;
                }
                record["Name"] = name;
                record["Fullname"] = fullname;
                record["Title"] = title;
                record["Description"] = description;
                if (!string.IsNullOrEmpty(newpassword))
                {
                    record["UserPass"] = system.pass_encrypt(newpassword);
                }
                record["PublicEmail"] = publicemail;
                record["PrivateEmail"] = privateemail;
                record["HomeURL"] = homeurl;
                record["AIMAccount"] = aimaccount;
                record["ICQAccount"] = icqaccount;
                record["YahooAccount"] = yahooaccount;
                record["MSNAccount"] = msnaccount;
                record["ModeratorFlag"] = moderator;
                record["DisabledFlag"] = disable;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
            }
            return errors;
        }

        public bool user_delete(int userid)
        {
            if (userid > 0)
            {
                sql_execute("Delete from Users where ID = " + userid.ToString());
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ipban_verify(string ip)
        {
            bool retvalue = false;
            object temp = scalar_get("Select IP from IPBanList where IP = '" + ip + "'");
            if ((temp != null) || ((string)temp != string.Empty))
            {
                retvalue = false;
            }
            else
            {
                retvalue = true;
            }
            return retvalue;
        }

        public DataTable ipban_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from IPBanList"
                , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            return retvalue;
        }

        public List<string> ipban_save(ref string ip)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(ip))
            {
                errors.Add("You must provide an IP address.");
            }
            if (errors.Count == 0)
            {
                table = data_load("Select TOP 1 * from IPBanList"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                record = table.NewRow();
                record["IP"] = ip;
                table.Rows.Add(record);
                data_update(ref table);
            }
            return errors;
        }

        public bool ipban_delete(string ip)
        {
            if (!string.IsNullOrEmpty(ip))
            {
                sql_execute("Delete from IPBanList where IP = '" + ip + "'");
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable message_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from Messages where ID = " + id.ToString()
                , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            return retvalue;
        }

        public List<string> message_save(ref int id, string title, string body, string ipaddress, int forumid, int userid, ref int parentid)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            bool thread = false;
            string timestamp = DateTime.Now.ToString();
            if (string.IsNullOrEmpty(title))
            {
                errors.Add("You must supply a title for this post/thread.");
            }
            if (string.IsNullOrEmpty(body))
            {
                errors.Add("You must supply content for this post/thread.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from Messages where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from Messages"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                    record["TimePosted"] = timestamp;
                }
                record["Title"] = title;
                record["Body"] = body;
                record["IPAddress"] = ipaddress;
                record["ForumID"] = forumid;
                record["UserID"] = userid;
                if (parentid > 0)
                {
                    record["ParentID"] = parentid;
                    record["Posts"] = 0;
                }
                else
                {
                    record["Posts"] = 1;
                    thread = true;
                }
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                    if (thread)
                    {
                        sql_execute("Update Messages set ParentID = ID where ID = " + id.ToString());
                        parentid = id;
                    }
                    else
                    {
                        sql_execute("Update Messages set Posts = Posts + 1 where ID = " + parentid.ToString());
                        sql_execute("Update Messages set LastUpdated = '" + timestamp + "' where ID = " + parentid.ToString());
                    }
                }
            }
            return errors;
        }

        public bool message_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from Messages where ID = " + id.ToString());
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}