using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

/// <summary>
/// Summary description for quote
/// </summary>
namespace pengine
{
    public class quote : pengine.dbaccess
    {
        public quote(string mycstring)
            : base(mycstring)
        {
        }

        public int quote_count()
        {
            int retvalue = 0;
            retvalue = (int)scalar_get("Select Max(ID) from QuoteList");
            return retvalue;
        }

        public string quote_random()
        {
            string retvalue = "Quotes Unavailable";
            int count = 0;
            int id = -1;
            DataTable list = quote_list();
            if (list != null)
            {
                Random rand = new Random(DateTime.Now.Millisecond);
                count = list.Rows.Count;
                if (count > 0)
                {
                    while ((id < 0) || (id >= count))
                    {
                        id = rand.Next(count - 1);
                    }
                    retvalue = (string)list.Rows[id]["Text"];
                }
            }
            return retvalue;
        }

        public DataTable quote_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from QuoteList"
                , true, cache.cache_type.quote, cache.cache_subtype.list, string.Empty);
            return retvalue;
        }
    }
}