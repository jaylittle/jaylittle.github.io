using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace pengine
{
    public static class theme
    {
        public static string csscode = string.Empty;

        public static List<string> theme_list()
        {
            List<string> retvalue = new List<string>();
            if (System.IO.Directory.Exists(system.path_theme))
            {
                System.IO.DirectoryInfo themedir = new DirectoryInfo(system.path_theme);
                System.IO.DirectoryInfo[] dirlist = themedir.GetDirectories();
                for (int dirptr = 0; dirptr < dirlist.Length; dirptr++)
                {
                    if (System.IO.File.Exists(theme_path(dirlist[dirptr].Name)))
                    {
                        retvalue.Add(dirlist[dirptr].Name);
                    }
                }
            }
            return retvalue;
        }

        public static bool theme_valid(string themename)
        {
            if (System.IO.File.Exists(theme_path(themename)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string theme_path(string themename)
        {
            return system.path_theme + themename + "\\" + themename + ".css";
        }

        public static string theme_url(string themename)
        {
            return system.url_theme + themename + "/" + themename + ".css";
        }
    }
}