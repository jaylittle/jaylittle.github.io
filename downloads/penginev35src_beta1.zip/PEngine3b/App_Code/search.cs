using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for search
/// </summary>
namespace pengine
{
    public class search : pengine.dbaccess
    {
        public search(string mycstring)
            : base(mycstring)
        {
        }

        public enum search_type
        {
            Article,
            News,
            Forum
        }

        static public string search_link(int id, search_type type)
        {
            return search_link(id, type, string.Empty);
        }

        static public string search_link(int id, search_type type, string extrahtml)
        {
            string retvalue = string.Empty;
            switch (type)
            {
                case search_type.Article:
                    retvalue = "?cmd=article&sub=display&id=" + id.ToString() + extrahtml;
                    break;
                case search_type.News:
                    retvalue = "?cmd=news&sub=display&id=" + id.ToString() + extrahtml;
                    break;
                case search_type.Forum:
                    retvalue = "?cmd=msg&sub=browse&threadid=" + id.ToString() + extrahtml;
                    break;
            }
            return retvalue;
        }

        public DataTable search_exec(string term, int userid, bool forum)
        {
            DataTable retvalue = null;
            if (forum)
            {
                string sql = "SELECT DISTINCT \"FORUM\" as Type, Parent.Title as SectionName"
                    + ", Messages.ID, Messages.Title as Name, Messages.Body as Content"
                    + ", Messages.TimePosted as Created, Parent.ID as ParentID, Parent.ForumID as ForumID"
                    + ", Users.Name as UserName FROM Messages, Messages as Parent"
                    + ", Users WHERE Messages.UserID = Users.ID and Messages.ParentID = Parent.ID";
                if (!string.IsNullOrEmpty(term))
                {
                    sql += " and (Messages.Body like \"%" + term
                        + "%\" or Messages.Title like \"%" + term + "%\")";
                }
                if (userid > 0)
                {
                    sql += " and Users.ID = " + userid.ToString();
                }
                sql += " ORDER BY Messages.TimePosted DESC, Messages.ID DESC";
                retvalue = data_load(sql, false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            else if (!string.IsNullOrEmpty(term))
            {
                string sql = "SELECT DISTINCT \"ARTICLE\" as Type, ArticleSection.Name as SectionName"
                    + ",ID,Articles.Name,Description as Content,#1/1/1990# as Created FROM"
                    + " Articles, ArticleSection WHERE Articles.ID = ArticleSection.ArticleID"
                    + " and (data like \"%" + term + "%\" or ArticleSection.Name like \"%"
                    + term + "%\" or Articles.Name like \"%" + term + "%\") and visible = true"
                    + " UNION SELECT DISTINCT \"NEWS\" as Type, \"-NA-\" as SectionName"
                    + ", ID, Title as Name, ArticleData as Content, TimePosted as Created"
                    + " FROM SystemNews WHERE (ArticleData like \"%" + term + "%\" or title"
                    + " like \"%" + term + "%\") ORDER BY Type ASC, Created DESC, ID DESC";
                retvalue = data_load(sql, false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
            }
            return retvalue;
        }
    }
}