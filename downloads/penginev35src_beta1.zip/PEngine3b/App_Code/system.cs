using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

namespace pengine
{
    /// <summary>
    /// Summary description for standard
    /// </summary>
    public static class system
    {
        public static string path_base = string.Empty;
        public static string path_cache = string.Empty;
        public static string path_temp = string.Empty;
        public static string path_theme = string.Empty;
        public static string path_db = string.Empty;

        public static string url_base = string.Empty;
        public static string url_olddb = string.Empty;
        public static string url_theme = string.Empty;
        public static string url_rss = string.Empty;

        public static bool flag_loaded = false;

        public static string conn_forum = string.Empty;
        public static string conn_pengine = string.Empty;

        public static bool active_forum = false;

        public static char[] banned = { '/', '\\', '?', '!', ';', ':', '\"'
            , '\'', '(', ')', '&', '$', '%', '#', '@', '*', '|', ',', '-' };

        public enum screen_type
        {
            none,
            article,
            admin,
            elite,
            forum,
            news,
            quote,
            resume,
            search,
            theme
        }

        public enum action_type
        {
            none,
            edit,
            list,
            view
        }

        public enum access_level
        {
            none,
            forum,
            forumadmin,
            admin,
            god
        }

        public enum login_type
        {
            none,
            system,
            forum,
            article
        }

        public enum button_type
        {
            list,
            action,
            inline
        }

        public static bool IsNumeric(string value)
        {
            double temp = 0;
            bool retvalue = Double.TryParse(value, out temp);
            return retvalue;
        }

        public static bool directory_delete(string path)
        {
            System.IO.DirectoryInfo pathinfo = new System.IO.DirectoryInfo(path);
            if (System.IO.Directory.Exists(path))
            {
                try
                {
                    if ((pathinfo.GetFiles().Length > 0) || (pathinfo.GetDirectories().Length > 0))
                    {
                        pathinfo.Delete(true);
                    }
                    else
                    {
                        pathinfo.Delete(false);
                    }
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public static string path_olddb()
        {
            string olddbpath = string.Empty;
            if (!string.IsNullOrEmpty(url_olddb))
            {
                olddbpath = HttpContext.Current.Server.MapPath(url_olddb);
                if (!olddbpath.EndsWith("\\"))
                {
                    olddbpath += "\\";
                }
            }
            return olddbpath;
        }

        public static bool data_move()
        {
            //Moves data from the old location to the new App_Data one
            string olddbpath = path_olddb();
            if (!string.IsNullOrEmpty(olddbpath))
            {
                
                if (System.IO.Directory.Exists(olddbpath))
                {
                    System.IO.DirectoryInfo olddbdir = new System.IO.DirectoryInfo(olddbpath);
                    System.IO.FileSystemInfo[] dbfiles = olddbdir.GetFileSystemInfos();
                    for (int dbfptr = 0; dbfptr < dbfiles.Length; dbfptr++)
                    {
                        System.IO.File.Move(olddbpath + dbfiles[dbfptr].Name, path_db + dbfiles[dbfptr].Name);
                    }
                    directory_delete(olddbpath);
                    url_olddb = string.Empty;
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string format_date(object dateobj)
        {
            DateTime tempobj = DateTime.MinValue;
            if (dateobj is DateTime)
            {
                tempobj = (DateTime)dateobj;
            }
            else if (dateobj is string)
            {
                tempobj = DateTime.Parse((string)dateobj);
            }
            if (tempobj != DateTime.MinValue)
            {
                return tempobj.ToShortDateString() + " " + tempobj.ToShortTimeString();
            }
            else
            {
                return string.Empty;
            }
        }

        static public void error_display(Label lbloutput, List<string> errors)
        {
            if ((errors != null) && (errors.Count > 0))
            {
                for (int errptr = 0; errptr < errors.Count; errptr++)
                {
                    if (errptr == 0)
                    {
                        lbloutput.Text += "<ul>";
                    }
                    lbloutput.Text += "<li>" + errors[errptr] + "</li>";
                }
                lbloutput.Text += "</ul>";
            }
            else
            {
                lbloutput.Text = string.Empty;
                lbloutput.Visible = false;
            }
        }

        static public void grid_sortfield(StateBag viewstate, ref DataTable sourcedata, GridViewSortEventArgs e, string dirkey, string expkey)
        {
            SortDirection cdirection = SortDirection.Descending;
            if (viewstate[dirkey] != null)
            {
                cdirection = (SortDirection)viewstate[dirkey];
            }
            string cexpression = (string)viewstate[expkey];
            if ((cexpression != e.SortExpression) || (cdirection == SortDirection.Descending))
            {
                sourcedata.DefaultView.Sort = e.SortExpression + " ASC";
                cdirection = SortDirection.Ascending;
            }
            else
            {
                sourcedata.DefaultView.Sort = e.SortExpression + " DESC";
                cdirection = SortDirection.Descending;
            }
            viewstate[dirkey] = cdirection;
            viewstate[expkey] = e.SortExpression;
        }

        static public string javascript_escape(string js)
        {
            return js.Replace("'", "\\'");
        }

        static public string html_subheader(string text)
        {
            string retvalue = string.Empty;
            retvalue += "<a name=\"" + text.Replace(" ", string.Empty) + "\"></a>";
            retvalue += "<div class=\"sheader\">";
            retvalue += "<div class=\"sheaderleft\">";
            retvalue += "<div class=\"sheaderright\">";
            retvalue += "<div class=\"sheadertext\">" + elite_convert(text);
            retvalue += "</div></div></div></div>";
            return retvalue;
        }

        static public string html_icon(string url)
        {
            string retvalue = string.Empty;
            if (!string.IsNullOrEmpty(url))
            {
                retvalue += "<img src=\"./images/icons/" + url + "\" class=\"newsicon\" alt=\"newsicon\" />";
            }
            return retvalue;
        }

        static public string html_button(button_type btype, string url, string text)
        {
            return html_button(btype, url, text, string.Empty);
        }

        static public string html_button(button_type btype, string url, string text, string confirm)
        {
            string retvalue = "<input type=\"button\" value=\"" + text + "\" ";
            switch (btype)
            {
                case button_type.action:
                    retvalue += "class=\"actionbutton\" ";
                    break;
                case button_type.inline:
                    retvalue += "class=\"inlinebutton\" ";
                    break;
                case button_type.list:
                    retvalue += "class=\"listbutton\" ";
                    break;
            }
            if (!string.IsNullOrEmpty(url))
            {
                if (!string.IsNullOrEmpty(confirm))
                {
                    retvalue += " onclick=\"click_confirm_go('" + javascript_escape(HttpContext.Current.Server.HtmlEncode(text))
                        + "', '" + javascript_escape(HttpContext.Current.Server.HtmlEncode(url)) + "');\" ";
                }
                else
                {
                    retvalue += " onclick=\"window.location='" + javascript_escape(HttpContext.Current.Server.HtmlEncode(url)) + "';\" ";
                }
            }
            else
            {
                retvalue += "disabled ";
            }
            retvalue += "/>";
            return retvalue;
        }

        static public string date_process(DateTime date)
        {
            string retvalue = string.Empty;
            if (date.Subtract(DateTime.Now).TotalDays > 0)
            {
                retvalue = "Present";
            }
            else
            {
                retvalue = date.ToShortDateString();
            }
            return retvalue;
        }

        static public string date_process(string date)
        {
            string retvalue = string.Empty;
            try
            {
                DateTime mydt = DateTime.Parse(date);
                retvalue = date_process(mydt);
            }
            catch
            {
                retvalue = null;
            }
            return retvalue;
        }

        static public string elite_convert(string origtext)
        {
            Dictionary<string, string> hword = new Dictionary<string, string>();
            hword.Add("cool", "k3wl");
            hword.Add("dude", "d00d");
            hword.Add("dudes", "d00dz");
            hword.Add("hacker", "hax0r");
            hword.Add("hacked", "hax0red");
            hword.Add("mp3s", "mp3z");
            hword.Add("rock", "r0x0r");
            hword.Add("rocks", "r0x0rez");
            hword.Add("you", "j00");
            hword.Add("elite", "l33t|31337");
            hword.Add("the", "teh|the");
            hword.Add("own", "pwn|0wnzor");
            hword.Add("porn", "porn|pr0n");
            Dictionary<string, string> hchar = new Dictionary<string, string>();
            hchar.Add("a", "@:4");
            hchar.Add("b", "b:8");
            hchar.Add("d", "d:|)");
            hchar.Add("e", "e:3");
            hchar.Add("f", "f:ph");
            hchar.Add("g", "g:9");
            hchar.Add("h", "h:|-|");
            hchar.Add("i", "i:1");
            hchar.Add("k", "k:|&lt;");
            hchar.Add("m", "m:|\\\\\\/|");
            hchar.Add("n", "n:|\\\\|");
            hchar.Add("o", "o:0");
            hchar.Add("s", "$:5");
            hchar.Add("t", "t:+");
            hchar.Add("v", "v:\\\\\\/");
            hchar.Add("w", "w:\\\\\\/\\\\\\/");
            hchar.Add("x", "x:&gt;&lt;");
            string retvalue = string.Empty;
            System.Random Randomizer = new Random(DateTime.Now.Millisecond);
            if ((HttpContext.Current.Session["leetflag"] == null) || ((bool)HttpContext.Current.Session["leetflag"] == false))
            {
                retvalue = origtext;
            }
            else
            {
                string[] words = origtext.ToLower().Split(' ');
                for (int wordptr = 0; wordptr < words.Length; wordptr++)
                {
                    string cword = words[wordptr];
                    string newword = string.Empty;
                    switch (cword)
                    {
                        case "am":
                            if ((wordptr < words.Length - 1) && (words[wordptr + 1] == "good"))
                            {
                                cword = "ownz0r";
                                wordptr++;
                            }
                            break;
                        case "is":
                            if ((wordptr < words.Length - 1) && (words[wordptr + 1] == "good"))
                            {
                                cword = "ownz0rz";
                                wordptr++;
                            }
                            break;
                        default:
                            if (hword.ContainsKey(words[wordptr]))
                            {
                                string[] tword = hword[words[wordptr]].Split('|');
                                cword = tword[Randomizer.Next(0, tword.Length - 1)];
                            }
                            break;
                    }
                    for (int charptr = 0; charptr < cword.Length; charptr++)
                    {
                        string curchar = cword[charptr].ToString();
                        if (hchar.ContainsKey(curchar))
                        {
                            string[] tchar = hchar[curchar].Split(':');
                            curchar = tchar[Randomizer.Next(0, tchar.Length - 1)];
                        }
                        if (Randomizer.Next(0, 100) > 50)
                        {
                            curchar = curchar.ToUpper();
                        }
                        newword += curchar;
                    }
                    retvalue += newword + " ";
                }
            }
            return retvalue;
        }

        public static string pass_encrypt(string pass)
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pass, "MD5");
        }

        public static string logo_link()
        {
            return system.url_base + "images/system/" + (string)settings.query(settings.app_setting_key.app_logo_frontpage);
        }

        public static bool logo_enable()
        {
            if (logo_link().Length > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}