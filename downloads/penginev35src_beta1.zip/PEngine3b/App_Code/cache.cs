using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Threading;
using pengine;

/// <summary>
/// Summary description for cache
/// </summary>
namespace pengine
{
    public static class cache
    {
        private static Dictionary<string, string> files = new Dictionary<string, string>();
        private static DataTable idx = new DataTable();
        private static int idx_chg_ctr = 0;
        private static Thread idx_mon = null;
        private static bool idx_abort_flag = false;

        public enum cache_type
        {
            all,
            resume,
            article,
            news,
            quote,
            category,
            section,
            rss
        }

        public enum cache_subtype
        {
            all,
            none,
            personal,
            objective,
            skill,
            skill_types,
            education,
            workhistory,
            list,
            listadmin,
            current
        }

        public static void index_startup()
        {
            index_shutdown();
            idx = new DataTable();
            idx.TableName = "row";
            idx.Columns.Add("id", typeof(long));
            idx.Columns["id"].AutoIncrement = true;
            idx.Columns["id"].AutoIncrementSeed = 1;
            idx.Columns["id"].AutoIncrementStep = 1;
            idx.Columns.Add("query", typeof(string));
            idx.Columns.Add("type", typeof(string));
            idx.Columns.Add("subtype", typeof(string));
            idx.Columns.Add("parameter", typeof(string));
            index_readfile();
            idx_mon = new Thread(new ThreadStart(index_monitor));
            idx_mon.Start();
        }

        public static void index_shutdown()
        {
            if ((idx_mon != null) && (idx_mon.ThreadState != ThreadState.Aborted))
            {
                idx_abort_flag = true;
                while ((idx_mon.ThreadState != ThreadState.Aborted)
                    && (idx_mon.ThreadState != ThreadState.Stopped))
                {
                    //Loop until index thread terminates
                }
                idx_mon = null;
            }
        }

        public static void index_readfile()
        {
            string path = system.path_cache + "index.xml";
            if (System.IO.File.Exists(path))
            {
                idx = new DataTable();
                idx.ReadXml(path);
            }
        }

        public static void index_writefile()
        {
            string path = system.path_cache + "index.xml";
            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }
            idx.WriteXml(path, XmlWriteMode.WriteSchema);
        }

        public static void index_add(cache_type type, cache_subtype subtype, string query, string parameter, DataTable results)
        {
            if ((type == cache_type.all) || (subtype == cache_subtype.all))
            {
                throw new Exception("All cache type and subtype may not be applied to actual items.");
            }
            DataRow idxitem = idx.NewRow();
            idxitem["query"] = query.Replace("'", "\"");
            idxitem["type"] = type.ToString();
            idxitem["subtype"] = subtype.ToString();
            idxitem["parameter"] = parameter;
            idx.Rows.Add(idxitem);
            //Get newly assigned ID and write actual cache file now
            long id = (long) idxitem["id"];
            string idxitem_path = index_path(id);
            results.TableName = "row";
            if (results.DataSet != null)
            {
                results.DataSet.DataSetName = "data";
            }
            results.WriteXml(idxitem_path, XmlWriteMode.WriteSchema);
            idx_chg_ctr++;
        }

        public static string index_path(long id)
        {
            return system.path_cache + "index_" + id.ToString() + ".xml";
        }

        public static void index_del(cache_type type, cache_subtype subtype, string query, string parameter, long id)
        {
            DataRow[] results = index_find(type, subtype, query, parameter, id);
            for (int resptr = 0; resptr < results.Length; resptr++)
            {
                long resid = (long)results[resptr]["id"];
                string respath = index_path(resid);
                idx.Rows.Remove(results[resptr]);
                idx_chg_ctr++;
                if (System.IO.File.Exists(respath))
                {
                    System.IO.File.Delete(respath);
                }
            }
        }

        public static DataTable index_retrieve(string query)
        {
            DataTable retvalue = null;
            DataRow[] results = index_find(cache_type.all, cache_subtype.all, query, string.Empty, 0);
            if (results.Length > 0)
            {
                long id = (long)results[0]["id"];
                string path = index_path(id);
                retvalue = new DataTable();
                retvalue.ReadXml(path);
            }
            return retvalue;
        }

        public static int index_count(string query)
        {
            DataRow[] results = index_find(cache_type.all, cache_subtype.all, query, string.Empty, 0);
            return results.Length;
        }

        public static DataRow[] index_find(cache_type type, cache_subtype subtype, string query, string parameter, long id)
        {
            string filter = string.Empty;
            if (id > 0)
            {
                filter = "id = " + id.ToString();
            }
            else
            {
                if (type != cache_type.all)
                {
                    filter += "type = '" + type + "'";
                }
                if (subtype != cache_subtype.all)
                {
                    if (filter != string.Empty)
                    {
                        filter += " and ";
                    }
                    filter += "subtype = '" + subtype + "'";
                }
                if (query != string.Empty)
                {
                    if (filter != string.Empty)
                    {
                        filter += " and ";
                    }
                    filter += "query = '" + query.Replace("'","\"") + "'";
                }
                if (parameter != string.Empty)
                {
                    if (filter != string.Empty)
                    {
                        filter += " and ";
                    }
                    filter += "parameter = '" + parameter + "'";
                }
            }
            return idx.Select(filter);
        }

        public static void index_monitor()
        {
            //This code is meant to run as it's own thread and periodically
            //synchronize the index on disk with the index in memory
            bool killflag = false;
            while (!killflag)
            {
                if (idx_chg_ctr > 0)
                {
                    //Write Current in Memory Index to Disk
                    index_writefile();
                    idx_chg_ctr = 0;
                }
                if (idx_abort_flag == false)
                {
                    System.Threading.Thread.Sleep(15000);
                }
                else
                {
                    killflag = true;
                }
            }
            //System.Threading.Thread.CurrentThread.Abort();
        }
    }
}