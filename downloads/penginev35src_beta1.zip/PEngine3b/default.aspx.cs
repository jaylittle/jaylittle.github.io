using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class _default : System.Web.UI.Page 
{
    private string m_theme = string.Empty;
    private string m_themecss = string.Empty;
    private access m_token = null;
    private bool m_popup = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page_Set();
        Access_Set();
        Theme_Set();
        if (!m_popup)
        {
            pnlLayout.Controls.Add(LoadControl("~/controls/layout/header.ascx"));
        }
        pnlLayout.Controls.Add(LoadControl("~/controls/layout/content.ascx"));
        if (!m_popup)
        {
            pnlLayout.Controls.Add(LoadControl("~/controls/layout/footer.ascx"));
        }
    }

    private void Access_Set()
    {
        string accesstext = string.Empty;
        if (Session["token"] == null)
        {
            Session["token"] = new access();
        }
        m_token = (access) Session["token"];
        string[] anames = Enum.GetNames(typeof(system.access_level));
        for (int aptr = 0; aptr < anames.Length; aptr++)
        {
            system.access_level alevel = (system.access_level) Enum.Parse(typeof(system.access_level), anames[aptr], true);
            if ((alevel != system.access_level.none) && (m_token.has(alevel)))
            {
                if (accesstext != string.Empty)
                {
                    accesstext += ", ";
                }
                accesstext += alevel.ToString();
            }
        }
        if (accesstext != string.Empty)
        {
            this.Page.Title += " (" + accesstext + ")";
        }
    }

    private void Theme_Set()
    {
        int tctr = 0;
        while (((m_theme == string.Empty) || (pengine.theme.theme_valid(m_theme) == false)) && (tctr < 4))
        {
            switch (tctr)
            {
                case 0:
                    if (!string.IsNullOrEmpty((string)Session["theme"]))
                    {
                        m_theme = (string)Session["theme"];
                    }
                    break;
                case 1:
                    if (Request.Cookies["theme"] != null)
                    {
                        m_theme = (string)Request.Cookies["theme"].Value;
                    }
                    break;
                case 2:
                    string deftheme = (string)pengine.settings.query(pengine.settings.app_setting_key.app_default_theme);
                    if (!string.IsNullOrEmpty(deftheme))
                    {
                        m_theme = deftheme;
                    }
                    break;
                case 3:
                    List<string> themes = pengine.theme.theme_list();
                    if (themes.Count > 0)
                    {
                        m_theme = themes[0];
                    }
                    break;
            }
            tctr++;
        }
        if (!string.IsNullOrEmpty(m_theme))
        {
            Session["theme"] = m_theme;
            Response.Cookies.Add(new HttpCookie("theme", m_theme));
            m_themecss = pengine.theme.theme_url(m_theme);
        }

        LiteralControl litLink = new LiteralControl();
        litLink.Text = "<link rel=\"stylesheet\" type=\"text/css\" href=\"./default.css\" />";
        if (!string.IsNullOrEmpty(m_themecss))
        {
            litLink.Text += "<link rel=\"stylesheet\" type=\"text/css\" href=\"" + m_themecss + "\" />";
            litLink.Text += "<link rel=\"alternate\" type=\"application/rss+xml\" title=\"News\" href=\"" + system.url_base + "rss.xml\" />";
        }
        litLink.EnableViewState = false;
        Page.Header.Controls.Add(litLink);
    }

    private void Page_Set()
    {
        Page.Title = (string) settings.query(settings.app_setting_key.app_default_title);
        if (!string.IsNullOrEmpty(Request["popup"]))
        {
            m_popup = true;
        }
        if ((!string.IsNullOrEmpty(Request["cmd"])) && (Request["cmd"].ToLower() == "file"))
        {
            this.frmMain.Enctype = "multipart/form-data";
        }
    }
}