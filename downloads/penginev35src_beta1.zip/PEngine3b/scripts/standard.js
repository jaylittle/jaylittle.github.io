﻿var OVRspellURL = "./spellcheck/SpellCheck.aspx";
function toggle_ctl(id, state)
{
    var ctl = document.getElementById(id);
    if (ctl != null)
    {
        if (ctl.style.display != state)
        {
            ctl.style.display = state;
        }
        else
        {
            ctl.style.display = "none";
        }
    }
}

function click_confirm_pass(text)
{
    if (confirm(text)) {
        return true;
    }
    else
    {
        return false;
    }
}

function click_confirm_go(text, url)
{
	if (confirm(text)) {
		window.location = url;
	}
}

function click_window_go(url)
{
    window.open(url, 'subwin');
}

function click_go(url)
{
    window.location = url;
}