using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_layout_footer : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            if (search_enable())
            {
                this.lstSearchType.Items.Add(new ListItem("Articles & News", "ARTICLE"));
                if (forum_enable())
                {
                    this.lstSearchType.Items.Add(new ListItem("Forum", "FORUM"));
                }
            }
        }
    }

    public bool forum_enable()
    {
        return !((bool)settings.query(settings.app_setting_key.app_exclude_forum));
    }

    public bool search_enable()
    {
        return !((bool)settings.query(settings.app_setting_key.app_exclude_search));
    }

    public bool rss_enable()
    {
        return !((bool) settings.query(settings.app_setting_key.app_exclude_rss));
    }

    public string rss_link()
    {
        return system.url_rss;
    }

    public bool email_enable()
    {
        if (!string.IsNullOrEmpty((string)settings.query(settings.app_setting_key.app_owner_email)))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public string email_link()
    {
        return (string)settings.query(settings.app_setting_key.app_owner_email);
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (this.txtSearchText.Text != string.Empty)
        {
            string source = string.Empty;
            switch (this.lstSearchType.SelectedValue)
            {
                case "ARTICLE":
                    source = "&source=article";
                    break;
                case "FORUM":
                    source = "&source=forum";
                    break;
            }
            Response.Redirect(system.url_base + "?cmd=search&queryterm=" + Server.UrlEncode(this.txtSearchText.Text) + source);
        }
    }
}
