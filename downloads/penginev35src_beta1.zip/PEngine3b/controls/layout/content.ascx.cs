using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_layout_content : System.Web.UI.UserControl
{
    private string m_cmd = string.Empty;
    private string m_sub = string.Empty;
    private string m_curl = string.Empty;
    private string m_rurl = string.Empty;
    private bool m_popup = false;
    private system.access_level m_access = system.access_level.none;
    private system.screen_type m_screentype = system.screen_type.none;
    //private system.action_type m_actiontype = system.action_type.none;

    private access token = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(Request["popup"]))
        {
            m_popup = true;
        }
    }

    protected bool IsPopup()
    {
        return m_popup;
    }

    protected void updcontent_Load(object sender, EventArgs e)
    {
        if (!m_popup)
        {
            this.pnlMenu.Controls.Add(LoadControl("~/controls/layout/menu.ascx"));
        }
        token = (access)Session["token"];
        ProcessURL();
    }

    private void ProcessURL()
    {
        if (!string.IsNullOrEmpty((string)Request["cmd"]))
        {
            m_cmd = (string)Request["cmd"];
        }
        if (!string.IsNullOrEmpty((string)Request["sub"]))
        {
            m_sub = (string)Request["sub"];
        }
        switch (m_cmd.ToLower())
        {
            case "":
            case "news":
                m_screentype = system.screen_type.news;
                switch (m_sub.ToLower())
                {
                    case "":
                    case "display":
                        //m_actiontype = system.action_type.view;
                        m_curl = "~/controls/news/view.ascx";
                        break;
                    case "edit":
                        m_access = system.access_level.admin;
                        //m_actiontype = system.action_type.edit;
                        m_curl = "~/controls/news/edit.ascx";
                        break;
                    case "browse":
                        //m_actiontype = system.action_type.list;
                        m_curl = "~/controls/news/list.ascx";
                        break;
                }
                break;
            case "article":
                m_screentype = system.screen_type.article;
                switch (m_sub.ToLower())
                {
                    case "":
                    case "display":
                        //m_actiontype = system.action_type.view;
                        m_curl = "~/controls/article/view.ascx";
                        break;
                    case "edit":
                        if ((ArticleHasPassword()) && (!token.article_has(Convert.ToInt32(Request["id"]))))
                        {
                            m_access = system.access_level.god;
                        }
                        else
                        {
                            m_access = system.access_level.admin;
                        }
                        //m_actiontype = system.action_type.edit;
                        m_curl = "~/controls/article/edit.ascx";
                        break;
                    case "browse":
                        //m_actiontype = system.action_type.list;
                        m_curl = "~/controls/article/list.ascx";
                        break;
                }
                break;
            case "file":
                m_screentype = system.screen_type.admin;
                m_access = system.access_level.god;
                m_curl = "~/controls/admin/filemanager.ascx";
                break;
            case "resume":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_resume) == false)
                {
                    m_screentype = system.screen_type.resume;
                    switch (m_sub.ToLower())
                    {
                        case "":
                        case "display":
                            //m_actiontype = system.action_type.view;
                            m_curl = "~/controls/resume/view.ascx";
                            break;
                        case "edit":
                        case "editobjective":
                        case "editworkhistory":
                        case "editeducation":
                        case "editpersonal":
                        case "editskill":
                            m_screentype = system.screen_type.resume;
                            //m_actiontype = system.action_type.edit;
                            m_access = system.access_level.admin;
                            m_curl = "~/controls/resume/edit.ascx";
                            break;
                    }
                }
                break;
            case "theme":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_theme) == false)
                {
                    m_screentype = system.screen_type.theme;
                    switch (m_sub.ToLower())
                    {
                        case "":
                        case "select":
                            //m_actiontype = system.action_type.view;
                            m_curl = "~/controls/theme/select.ascx";
                            break;
                    }
                }
                break;
            case "settings":
                m_screentype = system.screen_type.admin;
                m_access = system.access_level.god;
                m_curl = "~/controls/admin/settings.ascx";
                break;
            case "forum":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
                {
                    m_screentype = system.screen_type.forum;
                }
                break;
            case "thread":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
                {
                    m_screentype = system.screen_type.forum;
                }
                break;
            case "account":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
                {
                    m_screentype = system.screen_type.forum;
                }
                break;
            case "ipban":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
                {
                    m_screentype = system.screen_type.admin;
                    m_access = system.access_level.forumadmin;
                }
                break;
            case "msg":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
                {
                    m_screentype = system.screen_type.forum;
                }
                break;
            case "profile":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
                {
                    m_screentype = system.screen_type.forum;
                }
                break;
            case "search":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_search) == false)
                {
                    m_screentype = system.screen_type.search;
                    m_curl = "~/controls/search/list.ascx";
                }
                break;
            case "login":
                m_screentype = system.screen_type.admin;
                m_curl = "~/controls/admin/login.ascx";
                break;
            case "logout":
                m_screentype = system.screen_type.admin;
                m_curl = "~/controls/admin/logout.ascx";
                break;
            case "elite":
                if ((bool)settings.query(settings.app_setting_key.app_exclude_leet) == false)
                {
                    m_screentype = system.screen_type.elite;
                }
                break;
            case "denied":
                m_screentype = system.screen_type.none;
                //m_actiontype = system.action_type.none;
                m_curl = "~/controls/generic/denied.ascx";
                break;
            default:
                m_screentype = system.screen_type.news;
                //m_actiontype = system.action_type.view;
                m_curl = "~/controls/news/view.ascx";
                break;
        }

        //Check for broken settings on load and force admin login for settings update if so
        if (system.flag_loaded == false)
        {
            if (token.has(system.access_level.god))
            {
                m_screentype = system.screen_type.admin;
                m_access = system.access_level.god;
                m_curl = "~/controls/admin/settings.ascx";
            }
            else
            {
                m_screentype = system.screen_type.admin;
                m_curl = "~/controls/admin/login.ascx";
            }
        }

        if (!CheckAccess(m_access))
        {
            switch (m_access)
            {
                case system.access_level.none:
                    m_curl = "~/controls/generic/denied.ascx";
                    break;
                case system.access_level.admin:
                case system.access_level.god:
                    m_rurl = system.url_base + "?cmd=login&type=system&sendurl=" + Server.UrlEncode(Request.Url.ToString());
                    break;
                case system.access_level.forum:
                case system.access_level.forumadmin:
                    m_rurl = system.url_base + "?cmd=login&type=forum&sendurl=" + Server.UrlEncode(Request.Url.ToString());
                    break;
            }
        }
        if (!string.IsNullOrEmpty(m_rurl))
        {
            Response.Redirect(m_rurl);
        }
        else if (!string.IsNullOrEmpty(m_curl))
        {
            this.pnlContent.Controls.Add(LoadControl(m_curl));
        }
        else
        {
            switch (m_screentype)
            {
                case system.screen_type.elite:
                    if (Session["leetflag"] != null)
                    {
                        Session["leetflag"] = !((bool)Session["leetflag"]);
                    }
                    else
                    {
                        Session["leetflag"] = true;
                    }
                    Response.Redirect(system.url_base);
                    break;
            }
        }
    }

    private bool CheckAccess(system.access_level reqaccess)
    {
        bool retvalue = false;
        if (token.has(reqaccess))
        {
            retvalue = true;
        }
        return retvalue;
    }

    private bool ArticleHasPassword()
    {
        bool retvalue = false;
        int artid = 0;
        if ((!string.IsNullOrEmpty(Request["id"])) && (system.IsNumeric(Request["id"])))
        {
            artid = Convert.ToInt32(Request["id"]);
        }
        if (artid > 0)
        {
            article artobj = new article(system.conn_pengine);
            DataTable artdata = artobj.article_get(artid);
            if ((artdata != null) && (artdata.Rows.Count > 0))
            {
                if ((!Convert.IsDBNull(artdata.Rows[0]["AdminPass"])) && ((string) artdata.Rows[0]["AdminPass"] != string.Empty))
                {
                    retvalue = true;
                }
            }
            artobj.close();
        }
        return retvalue;
    }
}
