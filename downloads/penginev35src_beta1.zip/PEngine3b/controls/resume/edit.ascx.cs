using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_resume_edit : System.Web.UI.UserControl
{
    private enum LoadType
    {
        All,
        Personal,
        Objective,
        Skill,
        Education,
        WorkHistory
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.lblHeader.Text = "Editing Resume Information";
            this.btnEducationDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this education entry?')");
            this.btnObjectiveDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this objective entry?')");
            this.btnPersonalDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this personal entry?')");
            this.btnSkillDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this skill entry?')");
            this.btnWorkHistoryDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this work history entry?')");
            Resume_Load(LoadType.All);
        }
    }

    private void Resume_Load()
    {
        Resume_Load(LoadType.All);
    }

    private void Resume_Load(LoadType ops)
    {
        resumeparts resobj = new resumeparts(system.conn_pengine);
        if ((ops == LoadType.All) || (ops == LoadType.Personal))
        {
            DataTable perlist = resobj.personal_list();
            this.lstPersonal.Items.Clear();
            this.lstPersonal.Items.Insert(0, new ListItem("New", string.Empty));
            if ((perlist != null) && (perlist.Rows.Count > 0))
            {
                for (int perptr = 0; perptr < perlist.Rows.Count; perptr++)
                {
                    this.lstPersonal.Items.Add(new ListItem((string)perlist.Rows[perptr]["Name"]
                        , ((int)perlist.Rows[perptr]["ID"]).ToString()));
                }
            }
            this.lstPersonal.SelectedIndex = 0;
            resobj.close();
            Personal_Load();
        }

        if ((ops == LoadType.All) || (ops == LoadType.Objective))
        {
            DataTable objlist = resobj.objective_list();
            this.lstObjective.Items.Clear();
            this.lstObjective.Items.Insert(0, new ListItem("New", string.Empty));
            if ((objlist != null) && (objlist.Rows.Count > 0))
            {
                for (int objptr = 0; objptr < objlist.Rows.Count; objptr++)
                {
                    this.lstObjective.Items.Add(new ListItem(((int)(objptr + 1)).ToString()
                        , ((int)objlist.Rows[objptr]["ID"]).ToString()));
                }
            }
            this.lstObjective.SelectedIndex = 0;
            resobj.close();
            Objective_Load();
        }

        if ((ops == LoadType.All) || (ops == LoadType.Skill))
        {
            DataTable typlist = resobj.skill_type_list();
            this.lstSkillType.Items.Clear();
            this.lstSkillType.Items.Insert(0, new ListItem("New", string.Empty));
            if ((typlist != null) && (typlist.Rows.Count > 0))
            {
                for (int typptr = 0; typptr < typlist.Rows.Count; typptr++)
                {
                    this.lstSkillType.Items.Add(new ListItem((string)typlist.Rows[typptr]["Type"]
                        , (string)typlist.Rows[typptr]["Type"]));
                }
            }
            this.lstSkillType.SelectedIndex = 0;
            resobj.close();
            SkillType_Load();
        }

        if ((ops == LoadType.All) || (ops == LoadType.Education))
        {
            DataTable edulist = resobj.education_list();
            this.lstEducation.Items.Clear();
            this.lstEducation.Items.Insert(0, new ListItem("New", string.Empty));
            if ((edulist != null) && (edulist.Rows.Count > 0))
            {
                for (int eduptr = 0; eduptr < edulist.Rows.Count; eduptr++)
                {
                    this.lstEducation.Items.Add(new ListItem((string)edulist.Rows[eduptr]["Institute"]
                        + " - " + (string)edulist.Rows[eduptr]["Program"]
                        , ((int)edulist.Rows[eduptr]["ID"]).ToString()));
                }
            }
            this.lstEducation.SelectedIndex = 0;
            resobj.close();
            Education_Load();
        }

        if ((ops == LoadType.All) || (ops == LoadType.WorkHistory))
        {
            DataTable whlist = resobj.workhistory_list();
            this.lstWorkHistory.Items.Clear();
            this.lstWorkHistory.Items.Insert(0, new ListItem("New", string.Empty));
            if ((whlist != null) && (whlist.Rows.Count > 0))
            {
                for (int whptr = 0; whptr < whlist.Rows.Count; whptr++)
                {
                    this.lstWorkHistory.Items.Add(new ListItem((string)whlist.Rows[whptr]["Employer"]
                        + " - " + (string)whlist.Rows[whptr]["Title"]
                        , ((int)whlist.Rows[whptr]["ID"]).ToString()));
                }
            }
            this.lstWorkHistory.SelectedIndex = 0;
            resobj.close();
            WorkHistory_Load();
        }
    }

    private void Resume_Save()
    {
        List<string> errors = new List<string>();
        resumeparts resobj = new resumeparts(system.conn_pengine);
        int cctr = 0;
        int id = 0;
        if ((errors.Count <= 0) && ((this.lstPersonal.SelectedIndex != 0) || (this.txtPersonalName.Text != string.Empty)))
        {
            if (lstPersonal.SelectedIndex != 0)
            {
                id = Convert.ToInt32(lstPersonal.SelectedValue);
            }
            else
            {
                id = 0;
            }
            errors = resobj.personal_save(ref id, this.txtPersonalName.Text, this.txtPersonalAddress.Text
                , this.txtPersonalCity.Text, this.txtPersonalState.Text, this.txtPersonalZip.Text
                , this.txtPersonalPhone.Text, this.txtPersonalFax.Text, this.txtPersonalEmail.Text
                , this.txtPersonalWeb.Text);
            resobj.close();
            if (errors.Count <= 0)
            {
                Resume_Load(LoadType.Personal);
                cctr++;
            }
        }
        if ((errors.Count <= 0) && ((this.lstObjective.SelectedIndex != 0) || (this.txtObjectiveDescription.Text != string.Empty)))
        {
            if (lstObjective.SelectedIndex != 0)
            {
                id = Convert.ToInt32(lstObjective.SelectedValue);
            }
            else
            {
                id = 0;
            }
            errors = resobj.objective_save(ref id, this.txtObjectiveDescription.Text);
            resobj.close();
            if (errors.Count <= 0)
            {
                Resume_Load(LoadType.Objective);
                cctr++;
            }
        }
        if ((errors.Count <= 0) && ((this.lstSkillName.SelectedIndex != 0) || (this.txtSkillName.Text != string.Empty)))
        {
            if (lstSkillName.SelectedIndex != 0)
            {
                id = Convert.ToInt32(lstSkillName.SelectedValue);
            }
            else
            {
                id = 0;
            }
            errors = resobj.skill_save(ref id, txtSkillName.Text, txtSkillType.Text);
            resobj.close();
            if (errors.Count <= 0)
            {
                Resume_Load(LoadType.Skill);
                cctr++;
            }
        }
        if ((errors.Count <= 0) && ((this.lstEducation.SelectedIndex != 0) || (this.txtEducationInstitute.Text != string.Empty)))
        {
            if (lstEducation.SelectedIndex != 0)
            {
                id = Convert.ToInt32(lstEducation.SelectedValue);
            }
            else
            {
                id = 0;
            }
            errors = resobj.education_save(ref id, this.txtEducationInstitute.Text
                , this.txtEducationHTTP.Text, this.txtEducationProgram.Text, this.txtEducationStarted.Text
                , this.txtEducationLeft.Text);
            resobj.close();
            if (errors.Count <= 0)
            {
                Resume_Load(LoadType.Education);
                cctr++;
            }
        }
        if ((errors.Count <= 0) && ((this.lstWorkHistory.SelectedIndex != 0) || (this.txtWorkHistoryEmployer.Text != string.Empty)))
        {
            if (lstWorkHistory.SelectedIndex != 0)
            {
                id = Convert.ToInt32(lstWorkHistory.SelectedValue);
            }
            else
            {
                id = 0;
            }
            errors = resobj.workhistory_save(ref id, this.txtWorkHistoryEmployer.Text
                , this.txtWorkHistoryHTTP.Text, this.txtWorkHistoryTitle.Text, this.txtWorkHistoryStarted.Text
                , this.txtWorkHistoryLeft.Text, this.txtWorkHistoryDescription.Text);
            resobj.close();
            if (errors.Count <= 0)
            {
                Resume_Load(LoadType.WorkHistory);
                cctr++;
            }
        }
        resobj.close();
        system.error_display(lblErrors, errors);
    }

    private void Personal_Clear()
    {
        this.txtPersonalEmail.Text = string.Empty;
        this.txtPersonalAddress.Text = string.Empty;
        this.txtPersonalCity.Text = string.Empty;
        this.txtPersonalFax.Text = string.Empty;
        this.txtPersonalName.Text = string.Empty;
        this.txtPersonalPhone.Text = string.Empty;
        this.txtPersonalState.Text = string.Empty;
        this.txtPersonalWeb.Text = string.Empty;
        this.txtPersonalZip.Text = string.Empty;
    }

    private void Personal_Delete()
    {
        if (lstPersonal.SelectedIndex != 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            resobj.personal_delete(Convert.ToInt32(lstPersonal.SelectedValue));
            resobj.close();
            Resume_Load(LoadType.Personal);
        }
    }

    private void Personal_Load()
    {
        if (lstPersonal.SelectedIndex > 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            int perid = Convert.ToInt32(lstPersonal.SelectedValue);
            DataTable perdata = resobj.personal_get(perid);
            resobj.close();
            if ((perdata != null) && (perdata.Rows.Count > 0))
            {
                this.txtPersonalAddress.Text = (string)perdata.Rows[0]["Address"];
                this.txtPersonalCity.Text = (string)perdata.Rows[0]["City"];
                this.txtPersonalFax.Text = (string)perdata.Rows[0]["Fax"];
                this.txtPersonalName.Text = (string)perdata.Rows[0]["Name"];
                this.txtPersonalPhone.Text = (string)perdata.Rows[0]["Phone"];
                this.txtPersonalState.Text = (string)perdata.Rows[0]["State"];
                this.txtPersonalWeb.Text = (string)perdata.Rows[0]["Web"];
                this.txtPersonalZip.Text = (string)perdata.Rows[0]["Zip"];
                this.txtPersonalEmail.Text = (string)perdata.Rows[0]["Email"];
            }
        }
        else
        {
            Personal_Clear();
        }
    }

    private void Objective_Clear()
    {
        this.txtObjectiveDescription.Text = string.Empty;
    }

    private void Objective_Load()
    {
        if (lstObjective.SelectedIndex > 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            int objid = Convert.ToInt32(lstObjective.SelectedValue);
            DataTable objdata = resobj.objective_get(objid);
            resobj.close();
            if ((objdata != null) && (objdata.Rows.Count > 0))
            {
                this.txtObjectiveDescription.Text = (string)objdata.Rows[0]["Description"];
            }
        }
        else
        {
            Objective_Clear();
        }
    }

    private void Objective_Delete()
    {
        if (lstObjective.SelectedIndex != 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            resobj.objective_delete(Convert.ToInt32(lstObjective.SelectedValue));
            resobj.close();
            Resume_Load(LoadType.Objective);
        }
    }

    private void SkillType_Clear()
    {
        this.txtSkillType.Text = string.Empty;
        this.lstSkillName.Items.Clear();
        this.lstSkillName.Items.Insert(0, new ListItem("New", string.Empty));
    }

    private void SkillType_Load()
    {
        if (lstSkillType.SelectedIndex > 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            DataTable namedata = resobj.skill_list(lstSkillType.SelectedValue);
            resobj.close();
            this.txtSkillType.Text = lstSkillType.SelectedValue;
            this.lstSkillName.Items.Clear();
            this.lstSkillName.Items.Insert(0, new ListItem("New", string.Empty));
            if ((namedata != null) && (namedata.Rows.Count > 0))
            {
                for (int nameptr = 0; nameptr < namedata.Rows.Count; nameptr++)
                {
                    this.lstSkillName.Items.Add(new ListItem((string)namedata.Rows[nameptr]["Name"]
                        , ((int)namedata.Rows[nameptr]["ID"]).ToString()));
                }
            }
            this.lstSkillName.SelectedIndex = 0;
            SkillName_Load();
        }
        else
        {
            SkillType_Clear();
            SkillName_Clear();
        }
    }

    private void SkillName_Clear()
    {
        this.txtSkillName.Text = string.Empty;
    }

    private void SkillName_Load()
    {
        if (lstSkillName.SelectedIndex > 0)
        {
            this.txtSkillName.Text = lstSkillName.Items[lstSkillName.SelectedIndex].Text;
        }
        else
        {
            SkillName_Clear();
        }
    }

    private void SkillName_Delete()
    {
        if (lstSkillName.SelectedIndex != 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            resobj.skill_delete(Convert.ToInt32(lstSkillName.SelectedValue));
            resobj.close();
            Resume_Load(LoadType.Skill);
        }
    }

    private void Education_Clear()
    {
        this.txtEducationHTTP.Text = string.Empty;
        this.txtEducationInstitute.Text = string.Empty;
        this.txtEducationLeft.Text = string.Empty;
        this.txtEducationProgram.Text = string.Empty;
        this.txtEducationStarted.Text = string.Empty;
    }

    private void Education_Delete()
    {
        if (lstEducation.SelectedIndex != 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            resobj.education_delete(Convert.ToInt32(lstEducation.SelectedValue));
            resobj.close();
            Resume_Load(LoadType.Education);
        }
    }

    private void Education_Load()
    {
        if (lstEducation.SelectedIndex > 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            int eduid = Convert.ToInt32(lstEducation.SelectedValue);
            DataTable edudata = resobj.education_get(eduid);
            resobj.close();
            if ((edudata != null) && (edudata.Rows.Count > 0))
            {
                this.txtEducationHTTP.Text = (string)edudata.Rows[0]["HTTP"];
                this.txtEducationInstitute.Text = (string)edudata.Rows[0]["Institute"];
                this.txtEducationLeft.Text = ((DateTime)edudata.Rows[0]["DateLeft"]).ToShortDateString();
                this.txtEducationProgram.Text = (string)edudata.Rows[0]["Program"];
                this.txtEducationStarted.Text = ((DateTime)edudata.Rows[0]["DateStarted"]).ToShortDateString();
            }
        }
        else
        {
            Education_Clear();
        }
    }

    private void WorkHistory_Clear()
    {
        this.txtWorkHistoryDescription.Text = string.Empty;
        this.txtWorkHistoryEmployer.Text = string.Empty;
        this.txtWorkHistoryHTTP.Text = string.Empty;
        this.txtWorkHistoryLeft.Text = string.Empty;
        this.txtWorkHistoryStarted.Text = string.Empty;
        this.txtWorkHistoryTitle.Text = string.Empty;
    }

    private void WorkHistory_Delete()
    {
        if (lstWorkHistory.SelectedIndex != 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            resobj.workhistory_delete(Convert.ToInt32(lstWorkHistory.SelectedValue));
            resobj.close();
            Resume_Load(LoadType.WorkHistory);
        }
    }

    private void WorkHistory_Load()
    {
        if (lstWorkHistory.SelectedIndex > 0)
        {
            resumeparts resobj = new resumeparts(system.conn_pengine);
            int whid = Convert.ToInt32(lstWorkHistory.SelectedValue);
            DataTable whdata = resobj.workhistory_get(whid);
            resobj.close();
            if ((whdata != null) && (whdata.Rows.Count > 0))
            {
                this.txtWorkHistoryDescription.Text = (string)whdata.Rows[0]["Description"];
                this.txtWorkHistoryEmployer.Text = (string)whdata.Rows[0]["Employer"];
                this.txtWorkHistoryHTTP.Text = (string)whdata.Rows[0]["HTTP"];
                this.txtWorkHistoryLeft.Text = ((DateTime)whdata.Rows[0]["DateLeft"]).ToShortDateString();
                this.txtWorkHistoryStarted.Text = ((DateTime)whdata.Rows[0]["DateStarted"]).ToShortDateString();
                this.txtWorkHistoryTitle.Text = (string)whdata.Rows[0]["Title"];
            }
        }
        else
        {
            WorkHistory_Clear();
        }
    }

    protected void btnPersonalDelete_Click(object sender, EventArgs e)
    {
        Personal_Delete();
    }

    protected void btnObjectiveDelete_Click(object sender, EventArgs e)
    {
        Objective_Delete();
    }

    protected void btnSkillDelete_Click(object sender, EventArgs e)
    {
        SkillName_Delete();
    }

    protected void btnEducationDelete_Click(object sender, EventArgs e)
    {
        Education_Delete();
    }

    protected void btnWorkHistoryDelete_Click(object sender, EventArgs e)
    {
        WorkHistory_Delete();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Resume_Save();
    }

    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        Response.Redirect(system.url_base + "?cmd=resume&sub=display");
    }

    protected void lstPersonal_SelectedIndexChanged(object sender, EventArgs e)
    {
        Personal_Load();
    }

    protected void lstObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        Objective_Load();
    }

    protected void lstSkillType_SelectedIndexChanged(object sender, EventArgs e)
    {
        SkillType_Load();
    }

    protected void lstSkillName_SelectedIndexChanged(object sender, EventArgs e)
    {
        SkillName_Load();
    }

    protected void lstEducation_SelectedIndexChanged(object sender, EventArgs e)
    {
        Education_Load();
    }

    protected void lstWorkHistory_SelectedIndexChanged(object sender, EventArgs e)
    {
        WorkHistory_Load();
    }
}
