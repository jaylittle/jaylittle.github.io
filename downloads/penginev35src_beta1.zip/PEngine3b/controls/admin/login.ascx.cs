using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_admin_login : System.Web.UI.UserControl
{

    private system.login_type m_type = system.login_type.none;
    private int m_loginid = 0;
    private string m_context = string.Empty;
    private string m_sendurl = string.Empty;
    private bool m_passonly = false;

    private access token = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        token = (access) Session["token"];
        Type_Setup();
        if (!string.IsNullOrEmpty(Request["loginid"]))
        {
            m_loginid = Convert.ToInt32(m_loginid);
        }
        if (!string.IsNullOrEmpty(Request["sendurl"]))
        {
            m_sendurl = Request["sendurl"];
        }
        else
        {
            m_sendurl = system.url_base;
        }
        if (!this.IsPostBack)
        {
            this.lblLoginContext.Text = m_context;
            if (m_passonly)
            {
                this.txtUser.Visible = false;
            }
        }
        this.lblError.Visible = false;
        this.lblError.Text = string.Empty;
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        List<string> errors = User_Login();
        if (errors.Count <= 0)
        {
            Response.Redirect(m_sendurl);
        }
        else
        {
            system.error_display(lblError, errors);
        }
    }

    private List<string> User_Login()
    {
        List<string> errors = new List<string>();
        string user = string.Empty;
        string pass = string.Empty;
        string encpass = string.Empty;
        bool cookie = chkcookie.Checked;
        if (!m_passonly)
        {
            user = txtUser.Text;
        }
        pass = txtPass.Text;
        encpass = system.pass_encrypt(pass);
        switch (m_type)
        {
            case system.login_type.article:
                article artobj = new article(system.conn_pengine);
                DataTable artdata = artobj.article_get(m_loginid);
                if ((artdata != null) && (artdata.Rows.Count > 0) && ((string)artdata.Rows[0]["AdminPass"] == encpass))
                {
                    token.article_add(m_loginid, cookie);
                    errors.Add("Incorrect credentials were provided for this article.");
                }
                break;
            case system.login_type.forum:
                forum frmobj = new forum(system.conn_forum);
                frmobj.open();
                DataTable userdata = frmobj.user_validate(user, encpass, true);
                if ((userdata != null) && (userdata.Rows.Count > 0))
                {
                    int userid = (int)userdata.Rows[0]["ID"];
                    token.add(system.access_level.forum, cookie, userid);
                    if (Convert.ToBoolean(userdata.Rows[0]["ModeratorFlag"]))
                    {
                        token.add(system.access_level.forumadmin, false, userid);
                    }
                }
                else
                {
                    errors.Add("Incorrect credentials were provided for forum access.");
                }
                frmobj.close();
                break;
            case system.login_type.system:
                if (encpass == (string)settings.query(settings.app_setting_key.app_pass_god))
                {
                    token.add(system.access_level.god, cookie);
                    token.add(system.access_level.admin, false);
                }
                else if (encpass == (string)settings.query(settings.app_setting_key.app_pass_admin))
                {
                    token.add(system.access_level.admin, cookie);
                }
                else
                {
                    errors.Add("Incorrect credentials were provided for system access.");
                }
                break;
        }
        return errors;
    }

    private void Type_Setup()
    {
        if (!string.IsNullOrEmpty(Request["type"]))
        {
            switch (Request["type"])
            {
                case "forum":
                    m_type = system.login_type.forum;
                    break;
                case "article":
                    m_type = system.login_type.article;
                    break;
                case "system":
                    m_type = system.login_type.system;
                    break;
            }
        }
        else
        {
            m_type = system.login_type.system;
        }
        switch (m_type)
        {
            case system.login_type.article:
                m_context = "In order to edit this article - you must enter it's assigned password below.";
                m_passonly = true;
                break;
            case system.login_type.forum:
                m_context = "In order to access extended forum functionality - you must login in with"
                + " your username and password.";
                break;
            case system.login_type.system:
                if (system.flag_loaded == false)
                {
                    m_context = "Presentation Engine failed to load it's settings from your runtime.config file"
                        + " therefore you must log in with a god level account to fix the issues.  Check the"
                        + " database connection settings (i.e. mdb filename) specifically.";
                }
                else
                {
                    m_context = "In order to administer this installation you must provide either the admin"
                    + " or the god password.";
                }
                m_passonly = true;
                break;
        }
    }

    public bool User_Visible()
    {
        return this.txtUser.Visible;
    }
}
