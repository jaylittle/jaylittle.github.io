using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_admin_logout : System.Web.UI.UserControl
{
    private system.login_type m_type = system.login_type.none;
    private int m_loginid = 0;
    private access token = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        token = (access)Session["token"];
        Type_Setup();
        if (!string.IsNullOrEmpty(Request["loginid"]))
        {
            m_loginid = Convert.ToInt32(m_loginid);
        }
        User_Logout();
        Response.Redirect(system.url_base);
    }

    private void User_Logout()
    {
        switch (m_type)
        {
            case system.login_type.article:
                token.article_remove(m_loginid);
                break;
            case system.login_type.forum:
                token.remove(system.access_level.forumadmin);
                token.remove(system.access_level.forum);
                break;
            case system.login_type.system:
                token.remove(system.access_level.admin);
                token.remove(system.access_level.god);
                break;
        }
    }

    private void Type_Setup()
    {
        if (!string.IsNullOrEmpty(Request["type"]))
        {
            switch (Request["type"])
            {
                case "forum":
                    m_type = system.login_type.forum;
                    break;
                case "article":
                    m_type = system.login_type.article;
                    break;
                case "system":
                    m_type = system.login_type.system;
                    break;
            }
        }
        else
        {
            m_type = system.login_type.system;
        }
    }
}
