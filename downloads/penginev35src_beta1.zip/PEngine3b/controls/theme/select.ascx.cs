using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_theme_select : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            string ctheme = (string) Session["theme"];
            this.lblHeader.Text = "Presentation Engine Theme Selection";
            this.lblThemeDisclaimer.Text = "The current look and feel of this site can be changed "
                + "by selecting a \"theme\" from the dropdown listbox below.";

            List<string> tlist = theme.theme_list();
            this.lstTheme.Items.Clear();
            for (int tptr = 0; tptr < tlist.Count; tptr++)
            {
                this.lstTheme.Items.Add(new ListItem(tlist[tptr]));
            }
            if (this.lstTheme.Items.FindByValue(ctheme) != null)
            {
                this.lstTheme.SelectedValue = ctheme;
            }
            else
            {
                this.lstTheme.SelectedIndex = 0;
            }
        }
        lblErrors.Text = string.Empty;
    }

    protected void lstTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        List<string> messages = new List<string>();
        Session["theme"] = lstTheme.SelectedValue;
        HttpCookie theme = new HttpCookie("theme", lstTheme.SelectedValue);
        theme.Expires = DateTime.Now.AddDays(30);
        Response.Cookies.Add(theme);
        messages.Add("The theme has been changed and will be switched on the next request.");
        system.error_display(this.lblErrors, messages);
        //Response.Redirect(Request.Url.ToString());
    }
}
