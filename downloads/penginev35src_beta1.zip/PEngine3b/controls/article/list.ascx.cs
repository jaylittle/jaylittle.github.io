using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_article_list : System.Web.UI.UserControl
{
    private access token = null;
    private string m_category = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        token = (access)Session["token"];
        if (!string.IsNullOrEmpty(Request["category"]))
        {
            m_category = Request["category"];
        }
        if (!this.IsPostBack)
        {
            if (m_category != string.Empty)
            {
                lblHeader.Text = "Articles for Category '" + m_category + "'";
            }
            else
            {
                lblHeader.Text = "All Articles";
            }
            Article_Load();
        }
    }

    protected void grdarticles_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdarticles.PageIndex = e.NewPageIndex;
        Article_Load();
    }

    protected void grdarticles_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (token.has(system.access_level.admin))
        {
            switch (e.CommandName.ToLower())
            {
                case "editarticle":
                    Response.Redirect(system.url_base + "?cmd=article&sub=edit&id=" + e.CommandArgument);
                    break;
                case "deletearticle":
                    article artobj = new article(system.conn_pengine);
                    artobj.article_delete(Convert.ToInt32(e.CommandArgument));
                    artobj.close();
                    Article_Load();
                    break;
            }
        }
    }

    protected void grdarticles_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView RecData = (DataRowView)e.Row.DataItem;
            Button btnDelete = (Button)e.Row.FindControl("btnDelete");
            if ((btnDelete != null) && (RecData != null))
            {
                btnDelete.Attributes.Add("onclick", Confirm_Delete((string) RecData["Name"]));
            }
        }
    }

    protected void grdarticles_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable src = Article_Get();
        system.grid_sortfield(ViewState, ref src, e, "articledir", "articlekey");
        Article_Bind(src);
    }

    public string Article_Link(int id)
    {
        return system.url_base + "?cmd=article&sub=display&id=" + id.ToString();
    }

    private void Article_Load()
    {
        Article_Bind(Article_Get());
    }

    private void Article_Bind(DataTable src)
    {
        if (token.has(system.access_level.admin))
        {
            this.grdarticles.Columns[grdarticles.Columns.Count - 1].Visible = true;
        }
        else
        {
            if (src.Rows.Count > 1)
            {
                this.grdarticles.Columns[grdarticles.Columns.Count - 1].Visible = false;
            }
            else if (src.Rows.Count == 1)
            {
                Response.Redirect(Article_Link((int) src.Rows[0]["id"]));
            }
        }
        this.grdarticles.DataSource = src;
        this.grdarticles.DataBind();
    }

    private DataTable Article_Get()
    {
        article artobj = new article(system.conn_pengine);
        DataTable retvalue = artobj.article_list(m_category, token.has(system.access_level.admin));
        artobj.close();
        return retvalue;
    }

    protected string Confirm_Delete(string title)
    {
        return "return click_confirm_pass('Are you sure you wish to delete \\'"
            + system.javascript_escape(title) + "\\'?');";
    }
}
