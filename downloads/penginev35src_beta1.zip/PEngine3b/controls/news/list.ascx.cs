using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_news_list : System.Web.UI.UserControl
{
    private access token = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        token = (access) Session["token"];
        if (!this.IsPostBack)
        {
            News_Load();
        }
    }

    protected void grdnews_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdnews.PageIndex = e.NewPageIndex;
        News_Load();
    }

    protected void grdnews_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (token.has(system.access_level.admin))
        {
            switch (e.CommandName.ToLower())
            {
                case "editnews":
                    Response.Redirect(system.url_base + "?cmd=news&sub=edit&id=" + e.CommandArgument);
                    break;
                case "deletenews":
                    news newobj = new news(system.conn_pengine);
                    newobj.news_delete(Convert.ToInt32(e.CommandArgument));
                    newobj.close();
                    News_Load();
                    break;
            }
        }
    }

    protected void grdnews_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable src = News_Get();
        system.grid_sortfield(ViewState, ref src, e, "newsdir", "newskey");
        News_Bind(src);
    }

    protected void grdnews_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView RecData = (DataRowView)e.Row.DataItem;
            Button btnDelete = (Button)e.Row.FindControl("btnDelete");
            if ((btnDelete != null) && (RecData != null))
            {
                btnDelete.Attributes.Add("onclick", Confirm_Delete((string) RecData["Title"]));
            }
        }
    }

    public string News_Link(int id)
    {
        return system.url_base + "?cmd=news&sub=display&id=" + id.ToString();
    }

    private void News_Load()
    {
        News_Bind(News_Get());
    }

    private void News_Bind(DataTable src)
    {
        this.grdnews.PageSize = (int)settings.query(settings.app_setting_key.app_recpage_news_summary);
        if (token.has(system.access_level.admin))
        {
            this.grdnews.Columns[grdnews.Columns.Count - 1].Visible = true;
        }
        else
        {
            this.grdnews.Columns[grdnews.Columns.Count - 1].Visible = false;
        }
        this.grdnews.DataSource = src;
        this.grdnews.DataBind();
    }

    private DataTable News_Get()
    {
        news newsobj = new news(system.conn_pengine);
        DataTable retvalue = newsobj.news_list();
        newsobj.close();
        return retvalue;
    }

    protected string Confirm_Delete(string title)
    {
        return "return click_confirm_pass('Are you sure you wish to delete \\'"
            + system.javascript_escape(title) + "\\'?');";
    }
}
