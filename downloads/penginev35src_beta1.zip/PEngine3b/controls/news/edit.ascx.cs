using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_news_edit : System.Web.UI.UserControl
{

    private int m_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((!string.IsNullOrEmpty(Request["id"])) && (system.IsNumeric(Request["id"])))
        {
            m_id = Convert.ToInt32(Request["id"]);
        }
        if (!this.IsPostBack)
        {
            Icon_Setup();
            if (m_id > 0)
            {
                lblHeader.Text = "Editing Existing News Update #" + m_id.ToString();
            }
            else
            {
                lblHeader.Text = "Adding News Update";
            }
            News_Load();
            btnDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this news item?')");
        }
        lblErrors.Visible = false;
        lblErrors.Text = string.Empty;
    }

    private void Icon_Setup()
    {
        string[] icons = news.icon_list();
        Array.Sort(icons);
        this.lstIcon.Items.Clear();
        this.lstIcon.Items.Add(new ListItem(string.Empty, string.Empty));
        for (int icnptr = 0; icnptr < icons.Length; icnptr++)
        {
            this.lstIcon.Items.Add(new ListItem(icons[icnptr], icons[icnptr]));
        }
    }

    private void News_Load()
    {
        List<string> errors = new List<string>();
        if (m_id > 0)
        {
            news newobj = new news(system.conn_pengine);
            DataTable newdata = newobj.news_get(m_id);
            if ((newdata != null) && (newdata.Rows.Count > 0))
            {
                this.btnDelete.Enabled = true;
                this.txtTitle.Text = (string) newdata.Rows[0]["Title"];
                this.txtText.Text = (string)newdata.Rows[0]["ArticleData"];
                this.txtDate.Text = ((DateTime)newdata.Rows[0]["timeposted"]).ToShortDateString();
                this.txtTime.Text = ((DateTime)newdata.Rows[0]["timeposted"]).ToShortTimeString();
                if ((!Convert.IsDBNull(newdata.Rows[0]["IconFileName"]))
                    && (this.lstIcon.Items.FindByValue((string)newdata.Rows[0]["IconFileName"]) != null))
                {
                    this.lstIcon.SelectedValue = (string)newdata.Rows[0]["IconFileName"];
                }
                else
                {
                    this.lstIcon.SelectedIndex = 0;
                }
            }
            else
            {
                errors.Add("The specified news record with an id of " + m_id.ToString() + " does not exist.");
            }
            newobj.close();
        }
        else
        {
            News_Clear();
        }
        system.error_display(lblErrors, errors);
    }

    private void News_Clear()
    {
        this.txtTitle.Text = string.Empty;
        this.txtDate.Text = DateTime.Now.ToShortDateString();
        this.txtTime.Text = DateTime.Now.ToShortTimeString();
        this.txtText.Text = string.Empty;
        this.btnDelete.Enabled = false;
    }

    private void News_Delete()
    {
        if (m_id > 0)
        {
            news newobj = new news(system.conn_pengine);
            newobj.news_delete(m_id);
            newobj.close();
            Response.Redirect(system.url_base + "?cmd=news&sub=browse");
        }
    }

    private void News_Save()
    {
        List<string> errors = new List<string>();
        news newobj = new news(system.conn_pengine);
        errors = newobj.news_save(ref m_id, this.txtTitle.Text, this.txtDate.Text, this.txtTime.Text, this.txtText.Text, this.lstIcon.SelectedValue);
        newobj.close();
        if (errors.Count > 0)
        {
            system.error_display(lblErrors, errors);
            lblErrors.Visible = true;
        }
        else
        {
            News_Edit();
        }

    }

    private void News_Display()
    {
        Response.Redirect(system.url_base + "?cmd=news&sub=display&id=" + m_id.ToString());
    }

    private void News_Edit()
    {
        Response.Redirect(system.url_base + "?cmd=news&sub=edit&id=" + m_id.ToString());
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        News_Save();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        News_Delete();
    }

    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        News_Display();
    }
}
