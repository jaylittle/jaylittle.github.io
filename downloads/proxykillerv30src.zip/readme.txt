Proxykiller Version 3.0 Notes:

Changes from version 2.3:

	(1) HTML Processing Engine was rewritten from sratch.  Old one was too buggy and
	    complicated.
	(2) Moved all HTML Processing Code into the backend JayInet DLL.  This results in
	    large speed increases as well as easy debugging.
	(3) Began to use Microsoft URL Cancolization functions.  These allow me to complete
	    relative URLs with a much larger degree of accuracy.

Commentary:

To be honest I just dont have the time to document this code right now - so take your best 
shot at wading through it (more up to date info can probably be found on my website 
http://www.jaylittle.com)  Here is a quick synopsis of each file in the archive:

readme.txt	
		DUH
address.asp	
		The address bar portion of the application
browse.asp	
		The portion of the application that handles browse requests
default.asp	
		Generates a two level frameset and passes requests to browse.asp
encrypter.vbs	
		The crappy algorithim used to encode URLs in ProxyKiller (this program
		will both encode and decode - to decode: enter the encoded URL with
		the letters ENC in front of it (it should already be there if PKiller
		generated the address)
error404.html
		The play error404 HTML page for generating fake errors.  This is shown
		on logout and when unsuccessful attempts are made to log into the
		system.
global.asa
		DuH - intializes application/session settings (you must set PKiller up
		as an application in IIS)
stream.asp
		Streams binary data from the web - uses jayinet.dll for grunt work.
inc\functions.inc
		Contains some general functions used by Proxykiller
inc\globalvar.inc
		Contains Global (refreshable) legacy variables for Proxykiller
jayinet\jayinet.vbp
		Visual Basic Project containing code for JayInet.dll (used to download
		binary data from the web using HTTP, FTP, and GOPHER protocols.)  The HTML
		processing engine is now included in this library.


Installation & Special Notes:

PKiller MUST be set up as an application in IIS.  Global.asa must be run.

You must register jayinet.dll in Windows before this application will function. Use
the command "regsvr32 jayinet.dll" to accomplish this.


To Do:

Improve the encryption used in ProxyKiller.

Allow handkeyed address in the address form to be encrypted automatically rather than
having the user perform encryption manually.  (Use Javascript to accomplish this) Note
certain proxy servers check for pieces of the address as well as the ENTIRE address.
For example my company wont let anything with the phrase www.napster go out to the
net. The way around this is to encrypt the address before sending the request to PKiller.

Look into adding limited Javascript support.

Add Cookie support to Proxykiller

Add more complete MultiUser support to Proxykiller

Thanks alot - and please try not to puke too much when looking through my code.

Jay (jaylittle@jaylittle.com)