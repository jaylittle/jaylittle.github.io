﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;
using PEngine4.Core.TempClasses;

namespace PEngine4.Core.Services
{
    public class ArticleService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();

        public List<Category> CategoryList(bool adminFlag)
        {
            List<Model.Article> articles = _dbContext.Articles
                .Where(o => o.VisibleFlag == true || adminFlag)
                .ToList();
            return articles.OrderBy(o => o.Category)
                .Select(o => new Category(o.Category, o.ContentURL))
                .Distinct(new CategoryComparer())
                .ToList();
        }

        public List<Model.Article> ArticleList(string category, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ArticleList(category, start, count, "Name", true, ref totalRecs, adminFlag);
        }

        public List<Model.Article> ArticleList(string category,int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.Articles
                .Where(o => o.Category.ToLower() == category.ToLower() && (o.VisibleFlag || adminFlag))
                .Count();
            IEntitySorter<Model.Article> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.Article>.OrderBy(sortBy) : EntitySorter<Model.Article>.OrderByDescending(sortBy);
            List<Model.Article> retvalue = sorter.Sort(_dbContext.Articles)
                .Where(o => o.Category.ToLower() == category.ToLower() && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public Model.Article ArticleGet(Guid articleGuid, bool adminFlag)
        {
            return _dbContext.Articles.Where(o => o.Guid == articleGuid && (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public Model.Article ArticleGet(string uniqueName, bool adminFlag)
        {
            return _dbContext.Articles.Where(o => o.UniqueName == uniqueName && (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public Model.Article ArticleGet(int articleId, bool adminFlag)
        {
            return _dbContext.Articles.Where(o => o.LegacyID == articleId && (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public void ArticleDelete(Guid articleGuid)
        {
            Model.Article target = ArticleGet(articleGuid, true);
            if (target != null)
            {
                _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid)
                    .ToList().ForEach(o => { _dbContext.ArticleSections.Remove(o); });
                _dbContext.Articles.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public Model.Article ArticleSave(Model.Article entity, ref List<string> errors)
        {
            Model.Article retvalue = null;
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Article Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Description))
            {
                errors.Add("Article Description is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Category))
            {
                errors.Add("Article Category is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.Article();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Name);
                    List<Model.Article> dupes = _dbContext.Articles
                        .Where(o => o.UniqueName.StartsWith(retvalue.UniqueName))
                        .ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = ArticleGet(entity.Guid, true);
                }
                retvalue.Name = entity.Name;
                retvalue.Description = entity.Description;
                retvalue.Category = entity.Category;
                retvalue.DefaultSection = entity.DefaultSection;
                retvalue.ContentURL = entity.ContentURL;
                retvalue.HideButtonsFlag = entity.HideButtonsFlag;
                retvalue.HideDropDownFlag = entity.HideDropDownFlag;
                retvalue.VisibleFlag = entity.VisibleFlag;
                if (!string.IsNullOrEmpty(entity.AdminPass))
                {
                    if (entity.AdminPass.ToLower() != "[none]")
                    {
                        retvalue.AdminPass = Helpers.PasswordEncrypt(entity.AdminPass);
                    }
                    else
                    {
                        retvalue.AdminPass = string.Empty;
                    }
                }
                else if (retvalue.AdminPass == null)
                {
                    retvalue.AdminPass = string.Empty;
                }
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.Articles.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        public Model.ArticleSection SectionGet(Guid articleGuid, string sectionName, bool adminFlag)
        {
            if (string.IsNullOrEmpty(sectionName))
            {
                Model.Article article = ArticleGet(articleGuid, adminFlag);
                sectionName = article.DefaultSection;
            }
            if (!string.IsNullOrEmpty(sectionName))
            {
                return _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid && o.Name == sectionName).FirstOrDefault();
            }
            else
            {
                return null;
            }
        }

        public Model.ArticleSection SectionGet(int articleId, string sectionName, bool adminFlag)
        {
            Guid articleGuid = Guid.Empty;
            Model.Article article = ArticleGet(articleId, adminFlag);
            if (article != null)
            {
                articleGuid = article.Guid;
                if (string.IsNullOrEmpty(sectionName))
                {
                    sectionName = article.DefaultSection;
                }
                if (articleGuid != Guid.Empty)
                {
                    if (!string.IsNullOrEmpty(sectionName))
                    {
                        return _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid && o.Name == sectionName).FirstOrDefault();
                    }
                    else
                    {
                        return _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid).OrderBy(o => o.SortOrder).FirstOrDefault();
                    }
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public Model.ArticleSection SectionGet(Guid sectionGuid)
        {
            return _dbContext.ArticleSections.Where(o => o.Guid == sectionGuid).FirstOrDefault();
        }

        public ArticleWithSection ArticleSectionGet(string articleUniqueName, string sectionUniqueName, bool adminFlag)
        {
            string sectionName = string.Empty;
            Model.Article article = ArticleGet(articleUniqueName, adminFlag);
            if (article != null)
            {
                Model.ArticleSection section = null;
                if (string.IsNullOrEmpty(sectionUniqueName))
                {
                    sectionName = article.DefaultSection;
                    if (!string.IsNullOrEmpty(sectionName))
                    {
                        section = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid &&
                            o.Name == sectionName).FirstOrDefault();
                    }
                    else
                    {
                        section = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid)
                            .OrderBy(o => o.SortOrder).FirstOrDefault();
                    }
                }
                else
                {
                    section = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid &&
                        o.UniqueName == sectionUniqueName).FirstOrDefault();
                }
                if (section != null)
                {
                    return new ArticleWithSection(article, section);
                }
            }
            return null;
        }

        public Model.ArticleSection SectionGet(string articleUniqueName, string sectionUniqueName, bool adminFlag)
        {
            string sectionName = string.Empty;
            Model.Article article = ArticleGet(articleUniqueName, adminFlag);
            if (article != null)
            {
                if (string.IsNullOrEmpty(sectionUniqueName))
                {
                    sectionName = article.DefaultSection;
                }
                return _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid &&
                    (o.UniqueName == sectionUniqueName || o.Name == sectionName)).FirstOrDefault();
            }
            return null;
        }

        public List<Model.ArticleSection> SectionList(Guid articleGuid)
        {
            return _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid).ToList();
        }

        public void SectionDelete(Guid sectionGuid)
        {
            Model.ArticleSection target = SectionGet(sectionGuid);
            if (target != null)
            {
                _dbContext.ArticleSections.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public void SectionInvertDelete(Guid articleGuid, List<Guid> currentSectionGuids)
        {
            _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid)
                .ToList().ForEach(o =>
            {
                if (!currentSectionGuids.Contains(o.Guid))
                {
                    SectionDelete(o.Guid);
                }
            });
        }

        public Model.ArticleSection SectionSave(Model.ArticleSection entity, ref List<string> errors)
        {
            Model.ArticleSection retvalue = null;
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Section Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Data))
            {
                errors.Add("Section Content is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ArticleSection();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.ArticleGuid = entity.ArticleGuid;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Name);
                    List<Model.ArticleSection> dupes = _dbContext.ArticleSections
                        .Where(o => o.ArticleGuid == retvalue.ArticleGuid && o.UniqueName.StartsWith(retvalue.UniqueName))
                        .ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = SectionGet(entity.Guid);
                }
                retvalue.Name = entity.Name;
                retvalue.Data = entity.Data;
                retvalue.SortOrder = entity.SortOrder;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ArticleSections.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
