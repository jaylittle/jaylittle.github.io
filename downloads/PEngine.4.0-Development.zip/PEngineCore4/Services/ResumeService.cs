﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;

namespace PEngine4.Core.Services
{
    public class ResumeService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();

        public Model.ResumePersonal PersonalGet(Guid personalGuid)
        {
            return _dbContext.ResumePersonals.Where(o => o.Guid == personalGuid).FirstOrDefault();
        }

        public List<Model.ResumePersonal> PersonalList()
        {
            return _dbContext.ResumePersonals.OrderBy(o => o.CreatedUTC).ThenBy(o => o.FullName).ToList();
        }

        public void PersonalDelete(Guid personalGuid)
        {
            Model.ResumePersonal target = PersonalGet(personalGuid);
            if (target != null)
            {
                _dbContext.ResumePersonals.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public Model.ResumePersonal PersonalSave(Model.ResumePersonal entity, ref List<string> errors)
        {
            Model.ResumePersonal retvalue = null;
            if (string.IsNullOrEmpty(entity.FullName))
            {
                errors.Add("Personal: Name is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Email))
            {
                errors.Add("Personal: Email is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumePersonal();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = PersonalGet(entity.Guid);
                }
                retvalue.Address1 = entity.Address1;
                retvalue.Address2 = entity.Address2;
                retvalue.City = entity.City;
                retvalue.Email = entity.Email;
                retvalue.Fax = entity.Fax;
                retvalue.FullName = entity.FullName;
                retvalue.Phone = entity.Phone;
                retvalue.State = entity.State;
                retvalue.WebsiteURL = entity.WebsiteURL;
                retvalue.Zip = entity.Zip;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumePersonals.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        public Model.ResumeEducation EducationGet(Guid educationGuid)
        {
            return _dbContext.ResumeEducations.Where(o => o.Guid == educationGuid).FirstOrDefault();
        }

        public List<Model.ResumeEducation> EducationList()
        {
            return _dbContext.ResumeEducations.OrderByDescending(o => o.Started).ThenByDescending(o => o.Completed).ToList();
        }

        public void EducationDelete(Guid educationGuid)
        {
            Model.ResumeEducation target = EducationGet(educationGuid);
            if (target != null)
            {
                _dbContext.ResumeEducations.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public void EducationInvertDelete(List<Guid> currentEducationGuids)
        {
            _dbContext.ResumeEducations
                .ToList().ForEach(o =>
                {
                    if (!currentEducationGuids.Contains(o.Guid))
                    {
                        EducationDelete(o.Guid);
                    }
                });
        }

        public Model.ResumeEducation EducationSave(Model.ResumeEducation entity, ref List<string> errors)
        {
            Model.ResumeEducation retvalue = null;
            if (string.IsNullOrEmpty(entity.Institute))
            {
                errors.Add("Education: Institute is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Program))
            {
                errors.Add("Education: Program is a required field!");
            }
            if (!entity.Started.HasValue || entity.Started.Value == DateTime.MinValue)
            {
                errors.Add("Education: Date Started is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeEducation();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = EducationGet(entity.Guid);
                }
                retvalue.Completed = entity.Completed;
                retvalue.Institute = entity.Institute;
                retvalue.InstituteURL = entity.InstituteURL;
                retvalue.Program = entity.Program;
                retvalue.Started = entity.Started;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeEducations.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        public Model.ResumeObjective ObjectiveGet(Guid objectiveGuid)
        {
            return _dbContext.ResumeObjectives.Where(o => o.Guid == objectiveGuid).FirstOrDefault();
        }

        public List<Model.ResumeObjective> ObjectiveList()
        {
            return _dbContext.ResumeObjectives.OrderBy(o => o.CreatedUTC).ToList();
        }

        public void ObjectiveDelete(Guid objectiveGuid)
        {
            Model.ResumeObjective target = ObjectiveGet(objectiveGuid);
            if (target != null)
            {
                _dbContext.ResumeObjectives.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public Model.ResumeObjective ObjectiveSave(Model.ResumeObjective entity, ref List<string> errors)
        {
            Model.ResumeObjective retvalue = null;
            if (string.IsNullOrEmpty(entity.Data))
            {
                errors.Add("Objective: Content is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeObjective();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = ObjectiveGet(entity.Guid);
                }
                retvalue.Data = entity.Data;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeObjectives.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        public Model.ResumeSkill SkillGet(Guid skillGuid)
        {
            return _dbContext.ResumeSkills.Where(o => o.Guid == skillGuid).FirstOrDefault();
        }

        public List<Model.ResumeSkill> SkillList()
        {
            return _dbContext.ResumeSkills.OrderBy(o => o.Type).ThenBy(o => o.Name).ToList();
        }

        public void SkillDelete(Guid skillGuid)
        {
            Model.ResumeSkill target = SkillGet(skillGuid);
            if (target != null)
            {
                _dbContext.ResumeSkills.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public void SkillInvertDelete(List<Guid> currentSkillGuids)
        {
            _dbContext.ResumeSkills
                .ToList().ForEach(o =>
                {
                    if (!currentSkillGuids.Contains(o.Guid))
                    {
                        SkillDelete(o.Guid);
                    }
                });
        }

        public Model.ResumeSkill SkillSave(Model.ResumeSkill entity, ref List<string> errors)
        {
            Model.ResumeSkill retvalue = null;
            if (string.IsNullOrEmpty(entity.Type))
            {
                errors.Add("Skill: Type is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Skill: Name is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeSkill();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = SkillGet(entity.Guid);
                }
                retvalue.Hint = entity.Hint != null ? entity.Hint : string.Empty;
                retvalue.Name = entity.Name;
                retvalue.Type = entity.Type;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeSkills.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        public Model.ResumeWorkHistory WorkHistoryGet(Guid workHistoryGuid)
        {
            return _dbContext.ResumeWorkHistories.Where(o => o.Guid == workHistoryGuid).FirstOrDefault();
        }

        public List<Model.ResumeWorkHistory> WorkHistoryList()
        {
            return _dbContext.ResumeWorkHistories.OrderByDescending(o => o.Started).ThenBy(o => o.Completed).ThenBy(o => o.Employer).ToList();
        }

        public void WorkHistoryDelete(Guid workHistoryGuid)
        {
            Model.ResumeWorkHistory target = WorkHistoryGet(workHistoryGuid);
            if (target != null)
            {
                _dbContext.ResumeWorkHistories.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public void WorkHistoryInvertDelete(List<Guid> currentWorkHistoryGuids)
        {
            _dbContext.ResumeWorkHistories
                .ToList().ForEach(o =>
                {
                    if (!currentWorkHistoryGuids.Contains(o.Guid))
                    {
                        WorkHistoryDelete(o.Guid);
                    }
                });
        }

        public Model.ResumeWorkHistory WorkHistorySave(Model.ResumeWorkHistory entity, ref List<string> errors)
        {
            Model.ResumeWorkHistory retvalue = null;
            if (string.IsNullOrEmpty(entity.Employer))
            {
                errors.Add("Work History: Employer is a required field!");
            }
            if (string.IsNullOrEmpty(entity.JobTitle))
            {
                errors.Add("Work History: Job Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.JobDescription))
            {
                errors.Add("Work History: Job Description is a required field!");
            }
            if (!entity.Started.HasValue || entity.Started.Value == DateTime.MinValue)
            {
                errors.Add("Work History: Date Started is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeWorkHistory();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = WorkHistoryGet(entity.Guid);
                }
                retvalue.Completed = entity.Completed;
                retvalue.Employer = entity.Employer;
                retvalue.EmployerURL = entity.EmployerURL;
                retvalue.JobDescription = entity.JobDescription;
                retvalue.JobTitle = entity.JobTitle;
                retvalue.Started = entity.Started;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeWorkHistories.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
