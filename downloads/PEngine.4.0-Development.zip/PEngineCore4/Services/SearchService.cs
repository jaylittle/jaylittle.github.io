﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;
using System.Web;

namespace PEngine4.Core.Services
{
    public class SearchService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();

        public List<TempClasses.SearchResult> Search(string query, string postUrlTemplate, string articleUrlTemplate, bool adminFlag, int start, int count, string sortBy, bool sortAsc, ref int totalRecs)
        {
            List<TempClasses.SearchResult> results = null;
            string cachekey = "search_results_" + query.ToLower() + "_" + adminFlag.ToString().ToLower();
            results = (List<TempClasses.SearchResult>) HttpContext.Current.Cache[cachekey];
            if (results == null)
            {
                results = new List<TempClasses.SearchResult>();
                string[] queryTerms = query.Split(' ').Where(o => !string.IsNullOrEmpty(o)).Select(o => o).ToArray();
                string queryTermA = queryTerms.Length > 0 ? queryTerms[0] : string.Empty;
                string queryTermB = queryTerms.Length > 1 ? queryTerms[1] : string.Empty;
                string queryTermC = queryTerms.Length > 2 ? queryTerms[2] : string.Empty;
                bool skipTermA = string.IsNullOrEmpty(queryTermA) ? true : false;
                bool skipTermB = string.IsNullOrEmpty(queryTermB) ? true : false;
                bool skipTermC = string.IsNullOrEmpty(queryTermC) ? true : false;
                _dbContext.Posts.Where(o => (
                         (adminFlag || o.VisibleFlag) &&
                         (skipTermA || o.Title.Contains(queryTermA) || o.Data.Contains(queryTermA)) &&
                         (skipTermB || o.Title.Contains(queryTermB) || o.Data.Contains(queryTermB)) &&
                         (skipTermC || o.Title.Contains(queryTermC) || o.Data.Contains(queryTermC))
                    )).ToList().ForEach(o =>
                    {
                        results.Add(new TempClasses.SearchResult(
                            o.Guid,
                            postUrlTemplate.Replace("PostYear", o.CreatedUTC.Value.Year.ToString())
                                .Replace("PostMonth", o.CreatedUTC.Value.Month.ToString())
                                .Replace("PostUniqueName", o.UniqueName),
                            Helpers.ResourceType.Post,
                            o.Title,
                            string.Empty,
                            o.Data,
                            o.CreatedUTC
                        ));
                    });

                _dbContext.Articles
                    .Join(_dbContext.ArticleSections, o => o.Guid, o => o.ArticleGuid
                        , (o, p) => new { Guid = o.Guid, Title = o.Name, UniqueName = o.UniqueName, SubTitle = p.Name, Data = p.Data, SubUniqueName = p.UniqueName, VisibleFlag = o.VisibleFlag, CreatedUTC = o.CreatedUTC }
                    ).Where(o => (
                        (adminFlag || o.VisibleFlag) &&
                        (skipTermA || o.Title.Contains(queryTermA) || o.SubTitle.Contains(queryTermA) || o.Data.Contains(queryTermA)) &&
                        (skipTermB || o.Title.Contains(queryTermB) || o.SubTitle.Contains(queryTermB) || o.Data.Contains(queryTermB)) &&
                        (skipTermC || o.Title.Contains(queryTermC) || o.SubTitle.Contains(queryTermC) || o.Data.Contains(queryTermC))
                    )).ToList().ForEach(o =>
                    {
                        results.Add(new TempClasses.SearchResult(
                            o.Guid,
                            articleUrlTemplate.Replace("ArticleUniqueName", o.UniqueName)
                                .Replace("SectionUniqueName", o.SubUniqueName),
                            Helpers.ResourceType.Article,
                            o.Title,
                            o.SubTitle,
                            o.Data,
                            o.CreatedUTC
                        ));
                    });
                HttpContext.Current.Cache.Insert(cachekey, results, null, System.Web.Caching.Cache.NoAbsoluteExpiration, new TimeSpan(0, 15, 0));
            }

            totalRecs = results.Count;

            IEntitySorter<TempClasses.SearchResult> sorter = null;
            sorter = sortAsc ? EntitySorter<TempClasses.SearchResult>.OrderBy(sortBy) : EntitySorter<TempClasses.SearchResult>.OrderByDescending(sortBy);
            return sorter.Sort(results.AsQueryable()).Skip(start - 1).Take(count).ToList();
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
