﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;

namespace PEngine4.Core.Services
{
    public class PostService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();

        public Model.Post PostGet(Guid postGuid, bool adminFlag)
        {
            return _dbContext.Posts.Where(o => o.Guid == postGuid && (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public Model.Post PostGet(int postId, bool adminFlag)
        {
            return _dbContext.Posts.Where(o => o.LegacyID == postId && (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public Model.Post PostGet(int year, int month, string uniqueName, bool adminFlag)
        {
            DateTime startDate = new DateTime(year, month, 1);
            DateTime endDate = new DateTime(year, month, 1).AddMonths(1).AddSeconds(-1);
            return _dbContext.Posts.Where(o => (!o.CreatedUTC.HasValue ||
                (o.CreatedUTC.Value >= startDate && o.CreatedUTC.Value <= endDate)) &&
                o.UniqueName == uniqueName &&
                (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public List<Model.Post> PostList(int start, int count, ref int totalRecs, bool adminFlag)
        {
            return PostList(start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }


        public List<Model.Post> PostList(int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.Posts.Where(o => o.VisibleFlag || adminFlag).Count();
            IEntitySorter<Model.Post> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.Post>.OrderBy(sortBy) : EntitySorter<Model.Post>.OrderByDescending(sortBy);
            List<Model.Post> retvalue = sorter.Sort(_dbContext.Posts).Where(o => o.VisibleFlag || adminFlag)
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public void PostDelete(Guid postGuid)
        {
            Model.Post target = PostGet(postGuid, true);
            if (target != null)
            {
                _dbContext.Posts.Remove(target);
                _dbContext.SaveChanges();
            }
        }

        public Model.Post PostSave(Model.Post entity, ref List<string> errors)
        {
            Model.Post retvalue = null;
            if (string.IsNullOrEmpty(entity.Title))
            {
                errors.Add("Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Data))
            {
                errors.Add("Content is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.Post();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Title);
                    DateTime startDate = new DateTime(retvalue.CreatedUTC.Value.Year, retvalue.CreatedUTC.Value.Month, 1);
                    DateTime endDate = new DateTime(retvalue.CreatedUTC.Value.Year, retvalue.CreatedUTC.Value.Month, 1).AddMonths(1).AddSeconds(-1);
                    List<Model.Post> dupes = _dbContext.Posts.Where(o => (!o.CreatedUTC.HasValue ||
                        (o.CreatedUTC.Value >= startDate && o.CreatedUTC.Value <= endDate)) &&
                        o.UniqueName.StartsWith(retvalue.UniqueName)).ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = PostGet(entity.Guid, true);
                }
                retvalue.IconFileName = entity.IconFileName;
                retvalue.Title = entity.Title;
                retvalue.Data = entity.Data;
                retvalue.VisibleFlag = entity.VisibleFlag;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.Posts.Add(retvalue);
                }
                _dbContext.SaveChanges();
            }
            return retvalue;
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
