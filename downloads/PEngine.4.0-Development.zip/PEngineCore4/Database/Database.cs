﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlServerCe;
using System.Web;
using System.Data.OleDb;

namespace PEngine4.Core
{
    public class Database
    {
        public static string DbPath()
        {
            HttpContext context = HttpContext.Current;
            return context.Server.MapPath("~/App_Data/").TrimEnd('/') + "/pengine.sdf";
        }
        
        public static string ConnectionString()
        {
            HttpContext context = HttpContext.Current;
            return "Data Source=" + DbPath() + "; Persist Security Info=False;";
        }

        public static string EntityManagerConnectionString()
        {
            string emTemplate = "metadata=res://*/Model.EntityModel.csdl|res://*/Model.EntityModel.ssdl|res://*/Model.EntityModel.msl;provider=System.Data.SqlServerCe.4.0;provider connection string='{0}'";
            return string.Format(emTemplate, ConnectionString());
        }

        public static string LegacyConnectionString()
        {
            if (!string.IsNullOrEmpty((string)Settings.Query(Settings.AppSettingKey.app_db_name)))
            {
                return "Provider=Microsoft.Jet.OLEDB.4.0;" +
                    "Jet OLEDB:Database Locking Mode=1;Data Source=" +
                    HttpContext.Current.Server.MapPath("~/App_Data/"
                    + (string)Settings.Query(Settings.AppSettingKey.app_db_name)) + ";";
            }
            else
            {
                return string.Empty;
            }
        }

        public static SqlCeConnection Connection()
        {
            return new SqlCeConnection(ConnectionString());
        }

        public static Model.PEngineContext Context()
        {
            Model.PEngineContext dbContext = new Model.PEngineContext(EntityManagerConnectionString());
            return dbContext;
        }

        public static OleDbConnection LegacyConnection()
        {
            return new OleDbConnection(LegacyConnectionString());
        }

        public static bool Exists() {
            if (System.IO.File.Exists(DbPath()))
            {
                SqlCeConnection conn = Connection();
                try
                {
                    conn.Open();
                    conn.Close();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
            
        }

        public static bool LegacyExists()
        {
            if (!string.IsNullOrEmpty(LegacyConnectionString()))
            {
                OleDbConnection conn = new OleDbConnection(LegacyConnectionString());
                try
                {
                    conn.Open();
                    conn.Close();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }

        public static void Create()
        {
            if (!System.IO.File.Exists(DbPath()))
            {
                SqlCeEngine engine = new SqlCeEngine(ConnectionString());
                engine.CreateDatabase();
            }
            Update();
            Conversion.ConvertData();
        }

        public static void Update()
        {
            HttpContext context = HttpContext.Current;
            int major = 0;
            int minor = 0;
            int build = 0;
            int key = 0;
            GetVersion(ref major, ref minor, ref build, ref key);
            string[] scripts = System.IO.Directory.GetFiles(context.Server.MapPath("~/SQL/")).OrderBy(o => o).ToArray();
            foreach (string script in scripts)
            {
                string fileName = System.IO.Path.GetFileName(script);
                string[] elements = fileName.Split('.');
                if (elements.Length > 3)
                {
                    int sMajor = 0;
                    int sMinor = 0;
                    int sBuild = 0;
                    bool valid = true;
                    valid = int.TryParse(elements[0], out sMajor) ? valid : false;
                    valid = int.TryParse(elements[1], out sMinor) ? valid : false;
                    valid = int.TryParse(elements[2], out sBuild) ? valid : false;
                    if (valid)
                    {
                        int sKey = Convert.ToInt32(sMajor.ToString("00") + sMinor.ToString("00") + sBuild.ToString("00"));
                        if (sKey > key)
                        {
                            ExecuteScript(fileName);
                            SetVersion(sMajor, sMinor, sBuild);
                            key = sKey;
                        }
                    }
                }
            }
        }

        public static void GetVersion(ref int major, ref int minor, ref int build, ref int key)
        {
            try
            {
                SqlCeConnection conn = Connection();
                conn.Open();
                SqlCeCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT TOP 1 * FROM Version ORDER BY Major DESC, Minor DESC, Build DESC";
                SqlCeDataReader rdr = cmd.ExecuteReader();
                major = 0;
                minor = 0;
                build = 0;
                if (rdr.Read())
                {
                    major = !Convert.IsDBNull(rdr["Major"]) ? (int)rdr["Major"] : 0;
                    minor = !Convert.IsDBNull(rdr["Minor"]) ? (int)rdr["Minor"] : 0;
                    build = !Convert.IsDBNull(rdr["Build"]) ? (int)rdr["Build"] : 0;
                }
                key = Convert.ToInt32(major.ToString("00") + minor.ToString("00") + build.ToString("00"));
                rdr.Close();
                conn.Close();
            }
            catch
            {
                //Version table does not exist set all by reference parms to 0
                major = 0;
                minor = 0;
                build = 0;
                key = 0;
            }
        }

        public static void SetVersion(int Major, int Minor, int Build)
        {
            SqlCeConnection conn = Connection();
            conn.Open();
            SqlCeCommand cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT Version (Guid, Major, Minor, Build, CreatedUTC, ModifiedUTC) VALUES (NEWID(), @Major, @Minor, @Build, @CreatedUTC, @ModifiedUTC)";
            cmd.Parameters.Add(new SqlCeParameter("@Major", Major));
            cmd.Parameters.Add(new SqlCeParameter("@Minor", Minor));
            cmd.Parameters.Add(new SqlCeParameter("@Build", Build));
            cmd.Parameters.Add(new SqlCeParameter("@CreatedUTC", DateTime.UtcNow));
            cmd.Parameters.Add(new SqlCeParameter("@ModifiedUTC", DateTime.UtcNow));
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static void ExecuteScript(string fileName)
        {
            HttpContext context = HttpContext.Current;
            SqlCeConnection conn = Connection();
            conn.Open();
            SqlCeTransaction trans = conn.BeginTransaction();
            StringBuilder curCommand = new StringBuilder();
            try
            {
                string[] scriptLines = System.IO.File.ReadAllLines(context.Server.MapPath("~/SQL/" + fileName));
                for (int lptr = 0; lptr < scriptLines.Length; lptr++)
                {
                    if (scriptLines[lptr].Trim().ToUpper() == "GO")
                    {
                        if (curCommand.Length > 0)
                        {
                            SqlCeCommand cmd = conn.CreateCommand();
                            cmd.Transaction = trans;
                            cmd.CommandText = curCommand.ToString();
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                        }
                        curCommand.Clear();
                    }
                    else
                    {
                        curCommand.AppendLine(scriptLines[lptr]);
                    }
                }
                if (curCommand.Length > 0)
                {
                    SqlCeCommand cmd = conn.CreateCommand();
                    cmd.Transaction = trans;
                    cmd.CommandText = curCommand.ToString();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
                trans.Commit();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                throw new Exception("Update Script failed on: " + curCommand.ToString(), ex);
            }
            conn.Close();
        }
    }
}
