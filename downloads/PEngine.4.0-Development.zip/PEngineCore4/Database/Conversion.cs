﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlServerCe;
using System.Data.OleDb;

namespace PEngine4.Core
{
    public class Conversion
    {
        public static void ConvertData()
        {
            if (Database.Exists() && Database.LegacyExists())
            {
                //Proceed as both source and target databases exist
                ConvertSystemNews();
                ConvertArticles();
                ConvertQuotes();
                ConvertResume();
            }
        }

        private static void ConvertSystemNews()
        {
            Dictionary<string, int> uniqueNames = new Dictionary<string, int>();
            PEngine4.Core.Model.PEngineContext tContext = Database.Context();
            OleDbConnection sConn = Database.LegacyConnection();
            sConn.Open();
            OleDbCommand sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM SystemNews ORDER BY ID ASC";
            OleDbDataReader sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.Post tPost = new Model.Post();
                tPost.Guid = Guid.NewGuid();
                tPost.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tPost.Title = !Convert.IsDBNull(sDr["Title"]) ? (string)sDr["Title"] : string.Empty;
                tPost.CreatedUTC = !Convert.IsDBNull(sDr["TimePosted"]) ? (DateTime?)((DateTime)sDr["TimePosted"]).ToUniversalTime() : null;
                tPost.ModifiedUTC = tPost.CreatedUTC;
                tPost.Data = !Convert.IsDBNull(sDr["ArticleData"]) ? (string)sDr["ArticleData"] : string.Empty;
                tPost.IconFileName = !Convert.IsDBNull(sDr["IconFileName"]) ? (string)sDr["IconFileName"] : string.Empty;
                tPost.UniqueName = Helpers.GenerateUniqueName(tPost.Title);
                tPost.VisibleFlag = true;
                string uKey = tPost.CreatedUTC.Value.ToString("yyyyMM") + tPost.UniqueName;
                if (uniqueNames.ContainsKey(uKey))
                {
                    uniqueNames[uKey] = uniqueNames[uKey] + 1;
                    tPost.UniqueName = tPost.UniqueName + "-" + uniqueNames[uKey].ToString();
                }
                else
                {
                    uniqueNames.Add(uKey, 1);
                }
                tContext.Posts.Add(tPost);
            }
            sDr.Close();
            sDr.Dispose();
            sConn.Close();
            sConn.Dispose();
            tContext.SaveChanges();
            tContext.Dispose();
        }

        private static void ConvertArticles()
        {
            Dictionary<string, int> uniqueNames = new Dictionary<string, int>();
            Dictionary<int, Guid> IDMap = new Dictionary<int, Guid>();
            PEngine4.Core.Model.PEngineContext tContext = Database.Context();
            OleDbConnection sConn = Database.LegacyConnection();
            sConn.Open();
            OleDbCommand sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM Articles ORDER BY ID ASC";
            OleDbDataReader sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.Article tArticle = new Model.Article();
                tArticle.Guid = Guid.NewGuid();
                tArticle.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tArticle.Name = !Convert.IsDBNull(sDr["Name"]) ? (string)sDr["Name"] : string.Empty;
                tArticle.Description = !Convert.IsDBNull(sDr["Description"]) ? (string)sDr["Description"] : string.Empty;
                tArticle.Category = !Convert.IsDBNull(sDr["Category"]) ? (string)sDr["Category"] : string.Empty;
                tArticle.ContentURL = !Convert.IsDBNull(sDr["http"]) ? (string)sDr["http"] : string.Empty;
                tArticle.DefaultSection = !Convert.IsDBNull(sDr["DefaultSection"]) ? (string)sDr["DefaultSection"] : string.Empty;
                tArticle.VisibleFlag = !Convert.IsDBNull(sDr["Visible"]) ? (bool)sDr["Visible"] : false;
                tArticle.HideButtonsFlag = !Convert.IsDBNull(sDr["HideButtons"]) ? (bool)sDr["HideButtons"] : false;
                tArticle.HideDropDownFlag = !Convert.IsDBNull(sDr["HideDropDown"]) ? (bool)sDr["HideDropDown"] : false;
                tArticle.AdminPass = !Convert.IsDBNull(sDr["AdminPass"]) ? (string)sDr["AdminPass"] : string.Empty;
                tArticle.CreatedUTC = null;
                tArticle.ModifiedUTC = null;
                tArticle.UniqueName = Helpers.GenerateUniqueName(tArticle.Name);
                string uKey = tArticle.UniqueName;
                if (uniqueNames.ContainsKey(uKey))
                {
                    uniqueNames[uKey] = uniqueNames[uKey] + 1;
                    tArticle.UniqueName = tArticle.UniqueName + "-" + uniqueNames[uKey].ToString();
                }
                else
                {
                    uniqueNames.Add(uKey, 1);
                }
                tContext.Articles.Add(tArticle);
                if (tArticle.LegacyID.HasValue)
                {
                    IDMap.Add(tArticle.LegacyID.Value, tArticle.Guid);
                }
            }
            sDr.Close();
            sDr.Dispose();
            sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM ArticleSection ORDER BY ArticleID ASC, SortOrder ASC";
            sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                int articleId = !Convert.IsDBNull(sDr["ArticleID"]) ? (int)sDr["ArticleID"] : 0;
                if (IDMap.ContainsKey(articleId))
                {
                    Model.ArticleSection tArticleSection = new Model.ArticleSection();
                    tArticleSection.Guid = Guid.NewGuid();
                    tArticleSection.ArticleGuid = IDMap[articleId];
                    tArticleSection.Name = !Convert.IsDBNull(sDr["Name"]) ? (string)sDr["Name"] : string.Empty;
                    tArticleSection.Data = !Convert.IsDBNull(sDr["Data"]) ? (string)sDr["Data"] : string.Empty;
                    tArticleSection.SortOrder = !Convert.IsDBNull(sDr["SortOrder"]) ? (int)sDr["SortOrder"] : 0;
                    tArticleSection.CreatedUTC = null;
                    tArticleSection.ModifiedUTC = null;
                    tArticleSection.UniqueName = Helpers.GenerateUniqueName(tArticleSection.Name);
                    string uKey = tArticleSection.ArticleGuid + tArticleSection.UniqueName;
                    if (uniqueNames.ContainsKey(uKey))
                    {
                        uniqueNames[uKey] = uniqueNames[uKey] + 1;
                        tArticleSection.UniqueName = tArticleSection.UniqueName + "-" + uniqueNames[uKey].ToString();
                    }
                    else
                    {
                        uniqueNames.Add(uKey, 1);
                    }
                    tContext.ArticleSections.Add(tArticleSection);
                }

            }
            sDr.Close();
            sDr.Dispose();
            sConn.Close();
            sConn.Dispose();
            tContext.SaveChanges();
            tContext.Dispose();
        }

        private static void ConvertQuotes()
        {
            PEngine4.Core.Model.PEngineContext tContext = Database.Context();
            OleDbConnection sConn = Database.LegacyConnection();
            sConn.Open();
            OleDbCommand sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM QuoteList ORDER BY ID ASC";
            OleDbDataReader sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.Quote tQuote = new Model.Quote();
                tQuote.Guid = Guid.NewGuid();
                tQuote.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tQuote.Data = !Convert.IsDBNull(sDr["Text"]) ? (string)sDr["Text"] : string.Empty;
                tContext.Quotes.Add(tQuote);
            }
            sDr.Close();
            sDr.Dispose();
            sConn.Close();
            sConn.Dispose();
            tContext.SaveChanges();
            tContext.Dispose();
        }

        private static void ConvertResume()
        {
            PEngine4.Core.Model.PEngineContext tContext = Database.Context();
            OleDbConnection sConn = Database.LegacyConnection();
            sConn.Open();
            OleDbCommand sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM ResumeObjective ORDER BY ID ASC";
            OleDbDataReader sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.ResumeObjective tObjective = new Model.ResumeObjective();
                tObjective.Guid = Guid.NewGuid();
                tObjective.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tObjective.Data = !Convert.IsDBNull(sDr["Description"]) ? (string)sDr["Description"] : string.Empty;
                tObjective.CreatedUTC = null;
                tObjective.ModifiedUTC = null;
                tContext.ResumeObjectives.Add(tObjective);
            }
            sDr.Close();
            sDr.Dispose();
            sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM ResumePersonal ORDER BY ID ASC";
            sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.ResumePersonal tPersonal = new Model.ResumePersonal();
                tPersonal.Guid = Guid.NewGuid();
                tPersonal.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tPersonal.FullName = !Convert.IsDBNull(sDr["Name"]) ? (string)sDr["Name"] : string.Empty;
                tPersonal.Address1 = !Convert.IsDBNull(sDr["Address"]) ? (string)sDr["Address"] : string.Empty;
                tPersonal.Address2 = string.Empty;
                tPersonal.City = !Convert.IsDBNull(sDr["City"]) ? (string)sDr["City"] : string.Empty;
                tPersonal.State = !Convert.IsDBNull(sDr["State"]) ? (string)sDr["State"] : string.Empty;
                tPersonal.Zip = !Convert.IsDBNull(sDr["Zip"]) ? (string)sDr["Zip"] : string.Empty;
                tPersonal.Phone = !Convert.IsDBNull(sDr["Phone"]) ? (string)sDr["Phone"] : string.Empty;
                tPersonal.Fax = !Convert.IsDBNull(sDr["Fax"]) ? (string)sDr["Fax"] : string.Empty;
                tPersonal.Email = !Convert.IsDBNull(sDr["Email"]) ? (string)sDr["Email"] : string.Empty;
                tPersonal.WebsiteURL = !Convert.IsDBNull(sDr["Web"]) ? (string)sDr["Web"] : string.Empty;
                tPersonal.CreatedUTC = null;
                tPersonal.ModifiedUTC = null;
                tContext.ResumePersonals.Add(tPersonal);

            }
            sDr.Close();
            sDr.Dispose();
            sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM ResumeEducation ORDER BY ID ASC";
            sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.ResumeEducation tEducation = new Model.ResumeEducation();
                tEducation.Guid = Guid.NewGuid();
                tEducation.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tEducation.Institute = !Convert.IsDBNull(sDr["Institute"]) ? (string)sDr["Institute"] : string.Empty;
                tEducation.InstituteURL = !Convert.IsDBNull(sDr["HTTP"]) ? (string)sDr["HTTP"] : string.Empty;
                tEducation.Program = !Convert.IsDBNull(sDr["Program"]) ? (string)sDr["Program"] : string.Empty;
                tEducation.Started = !Convert.IsDBNull(sDr["DateStarted"]) ? (DateTime?)sDr["DateStarted"] : null;
                tEducation.Completed = !Convert.IsDBNull(sDr["DateLeft"]) ? (DateTime?)sDr["DateLeft"] : null;
                tEducation.CreatedUTC = null;
                tEducation.ModifiedUTC = null;
                tContext.ResumeEducations.Add(tEducation);
            }
            sDr.Close();
            sDr.Dispose();
            sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM ResumeWorkHistory ORDER BY ID ASC";
            sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.ResumeWorkHistory tWorkHistory = new Model.ResumeWorkHistory();
                tWorkHistory.Guid = Guid.NewGuid();
                tWorkHistory.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tWorkHistory.Employer = !Convert.IsDBNull(sDr["Employer"]) ? (string)sDr["Employer"] : string.Empty;
                tWorkHistory.EmployerURL = !Convert.IsDBNull(sDr["HTTP"]) ? (string)sDr["HTTP"] : string.Empty;
                tWorkHistory.JobTitle = !Convert.IsDBNull(sDr["Title"]) ? (string)sDr["Title"] : string.Empty;
                tWorkHistory.Started = !Convert.IsDBNull(sDr["DateStarted"]) ? (DateTime?)sDr["DateStarted"] : null;
                tWorkHistory.Completed = !Convert.IsDBNull(sDr["DateLeft"]) ? (DateTime?)sDr["DateLeft"] : null;
                tWorkHistory.JobDescription = !Convert.IsDBNull(sDr["Description"]) ? (string)sDr["Description"] : string.Empty;
                tWorkHistory.CreatedUTC = null;
                tWorkHistory.ModifiedUTC = null;
                tContext.ResumeWorkHistories.Add(tWorkHistory);
            }
            sDr.Close();
            sDr.Dispose();
            sCmd = sConn.CreateCommand();
            sCmd.CommandText = "SELECT * FROM ResumeSkills ORDER BY ID ASC";
            sDr = sCmd.ExecuteReader();
            while (sDr.Read())
            {
                Model.ResumeSkill tSkill = new Model.ResumeSkill();
                tSkill.Guid = Guid.NewGuid();
                tSkill.LegacyID = !Convert.IsDBNull(sDr["ID"]) ? (int?)sDr["ID"] : null;
                tSkill.Type = !Convert.IsDBNull(sDr["Type"]) ? (string)sDr["Type"] : string.Empty;
                tSkill.Name = !Convert.IsDBNull(sDr["Name"]) ? (string)sDr["Name"] : string.Empty;
                tSkill.Hint = string.Empty;
                tSkill.CreatedUTC = null;
                tSkill.ModifiedUTC = null;
                tContext.ResumeSkills.Add(tSkill);
            }
            sDr.Close();
            sDr.Dispose();
            sConn.Close();
            sConn.Dispose();
            tContext.SaveChanges();
            tContext.Dispose();
        }
    }
}
