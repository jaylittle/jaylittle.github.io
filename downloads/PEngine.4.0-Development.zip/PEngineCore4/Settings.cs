﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace PEngine4.Core
{
    public class Settings
    {
        public enum AppSettingType
        {
            none,
            type_int,
            type_string,
            type_bool
        }

        public enum AppSettingKey
        {
            none,
            old_db_path,
            app_owner_name,
            app_owner_email,
            app_default_title,
            app_default_theme,
            app_logo_frontpage,
            app_recpage_news_summary,
            app_recpage_news,
            app_recpage_search_results,
            app_recpage_forum_posts,
            app_recpage_rss,
            app_timelimit_forum_edit,
            app_timelimit_forum_login,
            app_timelimit_admin_login,
            app_exclude_resume,
            app_exclude_theme,
            app_exclude_leet,
            app_exclude_quotes,
            app_exclude_search,
            app_exclude_forum,
            app_exclude_rss,
            app_exclude_print,
            app_exclude_clippy_shortcut,
            app_exclude_clippy_button,
            app_clippy_quote_mode,
            app_clippy_random_chance,
            app_clippy_shortcut_keycode,
            app_clippy_shortcut_keycount,
            app_label_home,
            app_label_theme,
            app_label_resume,
            app_label_leet,
            app_label_leet2,
            app_label_admin,
            app_label_admin2,
            app_label_print,
            app_label_quote,
            app_label_clippy_button,
            app_notoggle_quote,
            app_mapping_location,
            app_db_name,
            app_pass_admin,
            app_pass_god
        }

        public static void Reset(ref System.Collections.Specialized.NameValueCollection config, bool noOverwrite)
        {
            Update(AppSettingKey.app_owner_name, "PEngine User", ref config, noOverwrite);
            Update(AppSettingKey.app_owner_email, "pengineuser@pengine.com", ref config, noOverwrite);
            Update(AppSettingKey.app_default_title, "Presentation Engine 3.5b", ref config, noOverwrite);
            Update(AppSettingKey.app_default_theme, "default", ref config, noOverwrite);
            Update(AppSettingKey.app_logo_frontpage, "penginelogo.png", ref config, noOverwrite);
            Update(AppSettingKey.app_recpage_news_summary, 10, ref config, noOverwrite);
            Update(AppSettingKey.app_recpage_news, 5, ref config, noOverwrite);
            Update(AppSettingKey.app_recpage_search_results, 20, ref config, noOverwrite);
            Update(AppSettingKey.app_recpage_forum_posts, 15, ref config, noOverwrite);
            Update(AppSettingKey.app_recpage_rss, 20, ref config, noOverwrite);
            Update(AppSettingKey.app_timelimit_forum_edit, 30, ref config, noOverwrite);
            Update(AppSettingKey.app_timelimit_admin_login, 30, ref config, noOverwrite);
            Update(AppSettingKey.app_timelimit_forum_login, 30, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_resume, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_theme, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_leet, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_quotes, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_search, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_forum, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_rss, false, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_print, false, ref config, noOverwrite);
            Update(AppSettingKey.app_label_home, "Home", ref config, noOverwrite);
            Update(AppSettingKey.app_label_theme, "Theme", ref config, noOverwrite);
            Update(AppSettingKey.app_label_leet, "I am Elite", ref config, noOverwrite);
            Update(AppSettingKey.app_label_leet2, "I am a Loser", ref config, noOverwrite);
            Update(AppSettingKey.app_label_admin, "Admin", ref config, noOverwrite);
            Update(AppSettingKey.app_label_admin2, "Standard", ref config, noOverwrite);
            Update(AppSettingKey.app_label_print, "Print", ref config, noOverwrite);
            Update(AppSettingKey.app_label_quote, "Quote of the Day", ref config, noOverwrite);
            Update(AppSettingKey.app_label_clippy_button, "Help!", ref config, noOverwrite);
            Update(AppSettingKey.app_notoggle_quote, false, ref config, noOverwrite);
            Update(AppSettingKey.app_db_name, "pengine.mdb", ref config, noOverwrite);
            Update(AppSettingKey.app_pass_admin, string.Empty, ref config, noOverwrite);
            Update(AppSettingKey.app_pass_god, string.Empty, ref config, noOverwrite);
            Update(AppSettingKey.old_db_path, string.Empty, ref config, noOverwrite);
            Update(AppSettingKey.app_mapping_location, string.Empty, ref config, noOverwrite);
            Update(AppSettingKey.app_clippy_random_chance, 0, ref config, noOverwrite);
            Update(AppSettingKey.app_clippy_shortcut_keycode, 190, ref config, noOverwrite);
            Update(AppSettingKey.app_clippy_shortcut_keycount, 3, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_clippy_button, true, ref config, noOverwrite);
            Update(AppSettingKey.app_exclude_clippy_shortcut, true, ref config, noOverwrite);
            Update(AppSettingKey.app_clippy_quote_mode, false, ref config, noOverwrite);
        }

        public static AppSettingType GetType(AppSettingKey key)
        {
            AppSettingType retvalue;
            switch (key)
            {
                case AppSettingKey.app_exclude_resume:
                case AppSettingKey.app_exclude_theme:
                case AppSettingKey.app_exclude_leet:
                case AppSettingKey.app_exclude_quotes:
                case AppSettingKey.app_exclude_search:
                case AppSettingKey.app_exclude_forum:
                case AppSettingKey.app_exclude_rss:
                case AppSettingKey.app_exclude_print:
                case AppSettingKey.app_notoggle_quote:
                case AppSettingKey.app_exclude_clippy_shortcut:
                case AppSettingKey.app_exclude_clippy_button:
                case AppSettingKey.app_clippy_quote_mode:
                    retvalue = AppSettingType.type_bool;
                    break;
                case AppSettingKey.app_recpage_news_summary:
                case AppSettingKey.app_recpage_news:
                case AppSettingKey.app_recpage_search_results:
                case AppSettingKey.app_recpage_forum_posts:
                case AppSettingKey.app_recpage_rss:
                case AppSettingKey.app_timelimit_forum_edit:
                case AppSettingKey.app_timelimit_admin_login:
                case AppSettingKey.app_timelimit_forum_login:
                case AppSettingKey.app_clippy_random_chance:
                case AppSettingKey.app_clippy_shortcut_keycode:
                case AppSettingKey.app_clippy_shortcut_keycount:
                    retvalue = AppSettingType.type_int;
                    break;
                case AppSettingKey.none:
                    retvalue = AppSettingType.none;
                    break;
                default:
                    retvalue = AppSettingType.type_string;
                    break;
            }
            return retvalue;
        }

        public static object Query(AppSettingKey key)
        {
            System.Collections.Specialized.NameValueCollection config = Snapshot();
            return Query(key, ref config);
        }

        public static object Query(AppSettingKey key, ref System.Collections.Specialized.NameValueCollection config)
        {
            object retvalue = null;
            string name = key.ToString();
            string value = Query(name, ref config);
            switch (GetType(key))
            {
                case AppSettingType.type_bool:
                    if ((value == "true") || (value == "1"))
                    {
                        retvalue = true;
                    }
                    else
                    {
                        retvalue = false;
                    }
                    break;
                case AppSettingType.type_int:
                    if (Helpers.IsNumeric(value))
                    {
                        retvalue = Convert.ToInt32(value);
                    }
                    else
                    {
                        retvalue = (int)0;
                    }
                    break;
                case AppSettingType.type_string:
                    retvalue = value;
                    break;
                case AppSettingType.none:
                    retvalue = null;
                    break;
            }
            return retvalue;
        }

        private static string Query(string name)
        {
            System.Collections.Specialized.NameValueCollection config = Snapshot();
            return Query(name, ref config);
        }

        private static string Query(string name, ref System.Collections.Specialized.NameValueCollection config)
        {
            if (config[name] != null)
            {
                return config[name];
            }
            else
            {
                return string.Empty;
            }
        }

        public static void Update(AppSettingKey key, object value, ref System.Collections.Specialized.NameValueCollection config, bool noOverwrite)
        {
            string strvalue = string.Empty;
            string name = key.ToString();
            bool skipflag = false;
            switch (GetType(key))
            {
                case AppSettingType.type_bool:
                    if (value is bool)
                    {
                        if (((bool)value) == true)
                        {
                            strvalue = "true";
                        }
                        else
                        {
                            strvalue = "false";
                        }
                    }
                    else if (value is string)
                    {
                        strvalue = ((string)value).ToLower();
                        if ((strvalue == "true") || (strvalue == "1"))
                        {
                            strvalue = "true";
                        }
                        else
                        {
                            strvalue = "false";
                        }
                    }
                    break;
                case AppSettingType.type_int:
                    if (value is int)
                    {
                        strvalue = ((int)value).ToString();
                    }
                    else if (value is string)
                    {
                        if (Helpers.IsNumeric((string)value))
                        {
                            strvalue = (string)value;
                        }
                        else
                        {
                            strvalue = "0";
                        }
                    }
                    break;
                case AppSettingType.type_string:
                    strvalue = (string)value;
                    break;
                case AppSettingType.none:
                    skipflag = true;
                    break;
            }
            if (skipflag == false)
            {
                if (config[name] != null)
                {
                    if (!noOverwrite)
                    {
                        config[name] = strvalue;
                    }
                }
                else
                {
                    config.Add(name, strvalue);
                }
            }
        }

        public static void Update(string name, object value, ref System.Collections.Specialized.NameValueCollection config, bool noOverwrite)
        {
            AppSettingKey key = Translate(name);
            Update(key, value, ref config, noOverwrite);
        }

        public static System.Collections.Specialized.NameValueCollection Snapshot()
        {
            System.Collections.Specialized.NameValueCollection ret =
                (System.Collections.Specialized.NameValueCollection) HttpContext.Current.Cache["PEConfig"];
            if (ret == null)
            {
                HttpContext context = HttpContext.Current;
                ret = new System.Collections.Specialized.NameValueCollection();
                string configData = System.IO.File.ReadAllText(context.Server.MapPath("~/App_Data/runtime.config"));
                configData = "<?xml version=\"1.0\"?>\r\n" + configData;
                XmlDocument configDoc = new XmlDocument();
                configDoc.LoadXml(configData);
                XmlNodeList lines = configDoc.SelectNodes("//appSettings/add");
                foreach (XmlNode line in lines)
                {
                    if (line.Attributes["key"] != null && line.Attributes["value"] != null)
                    {
                        string key = line.Attributes["key"].Value;
                        string value = line.Attributes["value"].Value;
                        ret.Add(key, value);
                    }
                }
                HttpContext.Current.Cache.Insert("PEConfig", ret);
            }
            return ret;
        }

        static private AppSettingKey Translate(string name)
        {
            AppSettingKey retvalue;
            switch (name.ToLower())
            {
                case "ownername":
                    retvalue = AppSettingKey.app_owner_name;
                    break;
                case "owneremail":
                    retvalue = AppSettingKey.app_owner_email;
                    break;
                case "defaultpagetitle":
                    retvalue = AppSettingKey.app_default_title;
                    break;
                case "defaulttheme":
                    retvalue = AppSettingKey.app_default_theme;
                    break;
                case "frontpagelogo":
                    retvalue = AppSettingKey.app_logo_frontpage;
                    break;
                case "newssummaryperpage":
                    retvalue = AppSettingKey.app_recpage_news_summary;
                    break;
                case "newsperpage":
                    retvalue = AppSettingKey.app_recpage_news;
                    break;
                case "searchresultsperpage":
                    retvalue = AppSettingKey.app_recpage_search_results;
                    break;
                case "forumpostsperpage":
                    retvalue = AppSettingKey.app_recpage_forum_posts;
                    break;
                case "forumeditlimit":
                    retvalue = AppSettingKey.app_timelimit_forum_edit;
                    break;
                case "excluderesume":
                    retvalue = AppSettingKey.app_exclude_resume;
                    break;
                case "excludetheme":
                    retvalue = AppSettingKey.app_exclude_theme;
                    break;
                case "excludeleet":
                    retvalue = AppSettingKey.app_exclude_leet;
                    break;
                case "excludequotes":
                    retvalue = AppSettingKey.app_exclude_quotes;
                    break;
                case "excludesearch":
                    retvalue = AppSettingKey.app_exclude_search;
                    break;
                case "excludeprint":
                    retvalue = AppSettingKey.app_exclude_print;
                    break;
                case "homelabel":
                    retvalue = AppSettingKey.app_label_home;
                    break;
                case "themelabel":
                    retvalue = AppSettingKey.app_label_theme;
                    break;
                case "resume-label":
                    retvalue = AppSettingKey.app_label_resume;
                    break;
                case "leetlabel":
                    retvalue = AppSettingKey.app_label_leet;
                    break;
                case "leetlabel2":
                    retvalue = AppSettingKey.app_label_leet2;
                    break;
                case "adminlabel":
                    retvalue = AppSettingKey.app_label_admin;
                    break;
                case "adminlabel2":
                    retvalue = AppSettingKey.app_label_admin2;
                    break;
                case "dbrelativepath":
                    retvalue = AppSettingKey.old_db_path;
                    break;
                case "dbfilename":
                    retvalue = AppSettingKey.app_db_name;
                    break;
                case "timeout":
                    retvalue = AppSettingKey.app_timelimit_admin_login;
                    break;
                case "adminpass":
                    retvalue = AppSettingKey.app_pass_admin;
                    break;
                case "godpass":
                    retvalue = AppSettingKey.app_pass_god;
                    break;
                case "excludeforum":
                    retvalue = AppSettingKey.app_exclude_forum;
                    break;
                default:
                    try
                    {
                        retvalue = (AppSettingKey)Enum.Parse(typeof(AppSettingKey), name, true);
                    }
                    catch
                    {
                        retvalue = AppSettingKey.none;
                    }
                    break;
            }
            return retvalue;
        }

        public static bool Load()
        {
            System.Collections.Specialized.NameValueCollection config = Snapshot();
            return Load(ref config);
        }

        public static bool Load(ref System.Collections.Specialized.NameValueCollection config)
        {
            bool retvalue = true;
            //Check for old pre 3.5 config file and load and convert if required.
            if (System.IO.File.Exists(HttpContext.Current.Server.MapPath("~/settings.asp")))
            {
                Reset(ref config, false);
                string[] records = System.IO.File.ReadAllLines(HttpContext.Current.Server.MapPath("~/settings.asp"));
                for (int rptr = 0; rptr < records.Length; rptr++)
                {
                    if (records[rptr].StartsWith("'"))
                    {
                        records[rptr] = records[rptr].Substring(1, records[rptr].Length - 1);
                        string[] fields = records[rptr].Split(',');
                        Update(fields[0], fields[1], ref config, false);
                    }
                }
                List<string> errors = Save(ref config);
                if (errors.Count <= 0)
                {
                    System.IO.File.Delete(HttpContext.Current.Server.MapPath("~/settings.asp"));
                }
                else
                {
                    retvalue = false;
                    //throw new Exception("Default PEngine Settings do not meet data type requirements and contain errors.");
                }
            }
            else
            {
                Reset(ref config, true);
                List<string> errors = Save(ref config);
                if (errors.Count > 0)
                {
                    retvalue = false;
                }
            }

            return retvalue;
        }

        public static bool IsValid(AppSettingKey key, string value)
        {
            bool retvalue = false;
            switch (GetType(key))
            {
                case AppSettingType.type_bool:
                    switch (value.ToLower())
                    {
                        case "true":
                        case "false":
                        case "1":
                        case "0":
                            retvalue = true;
                            break;
                        default:
                            retvalue = false;
                            break;
                    }
                    break;
                case AppSettingType.type_int:
                    retvalue = Helpers.IsNumeric(value);
                    break;
                case AppSettingType.type_string:
                    retvalue = true;
                    break;
                case AppSettingType.none:
                    retvalue = true;
                    break;
            }
            return retvalue;
        }

        public static List<string> Save(ref System.Collections.Specialized.NameValueCollection config)
        {
            List<string> Errors = new List<string>();
            int[] keyvals = (int[])Enum.GetValues(typeof(AppSettingKey));
            for (int keyptr = 0; keyptr < keyvals.Length; keyptr++)
            {
                AppSettingKey key = (AppSettingKey)Enum.ToObject(typeof(AppSettingKey), keyvals[keyptr]);
                AppSettingType type = GetType(key);
                string name = key.ToString();
                string value = Query(name, ref config);
                if (!IsValid(key, value))
                {
                    Errors.Add("Invalid data type value provided for setting, '" + name + "'");
                }
            }
            if (Errors.Count == 0)
            {
                try
                {
                    System.IO.File.Delete(HttpContext.Current.Server.MapPath("~/App_Data/runtime.config"));
                    System.IO.TextWriter tout = System.IO.File.CreateText(HttpContext.Current.Server.MapPath("~/App_Data/runtime.config"));
                    tout.WriteLine("<appSettings>");
                    foreach (string key in config.Keys)
                    {
                        tout.WriteLine("  <add key=\"" + key + "\" value=\"" + config[key] + "\" />");
                    }
                    tout.WriteLine("</appSettings>");
                    tout.Close();
                    HttpContext.Current.Cache.Remove("PEConfig");
                }
                catch (Exception ex)
                {
                    Errors.Add("Unable to save runtime.config changes: " + ex.Message);
                }
            }
            return Errors;
        }
    }
}
