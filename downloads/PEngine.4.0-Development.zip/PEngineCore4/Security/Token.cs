﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PEngine4.Core.Security
{
    public class Token
    {
        private List<Helpers.AccessLevel> _levels = new List<Helpers.AccessLevel>();
        private List<Guid> _articleGuids = new List<Guid>();
        private DateTime _sessionStart = new DateTime();

        public Token()
        {
            Add(Helpers.AccessLevel.none);
            Rebuild();
            _sessionStart = DateTime.UtcNow;
        }

        public void Rebuild()
        {
            //Rebuild access token using Cookie values
            HttpRequest MyRequest = HttpContext.Current.Request;
            for (int cptr = 0; cptr < MyRequest.Cookies.Count; cptr++)
            {
                Cookie_Check(MyRequest.Cookies[cptr]);
            }
        }

        public List<Helpers.AccessLevel> Get()
        {
            return _levels;
        }

        public void Add(Helpers.AccessLevel alevel, bool cookie, int n_objid)
        {
            if (!_levels.Contains(alevel))
            {
                _levels.Add(alevel);
                if (cookie)
                {
                    switch (alevel)
                    {
                        case Helpers.AccessLevel.admin:
                            Cookie_Add(Helpers.LoginType.system, "admin");
                            break;
                        case Helpers.AccessLevel.god:
                            Cookie_Add(Helpers.LoginType.system, "god");
                            break;
                    }
                }
            }
        }

        public void Add(Helpers.AccessLevel alevel)
        {
            Add(alevel, false);
        }

        public void Add(Helpers.AccessLevel alevel, bool cookie)
        {
            Add(alevel, cookie, 0);
        }

        public bool Has(Helpers.AccessLevel alevel)
        {
            return _levels.Contains(alevel);
        }

        public void Remove(Helpers.AccessLevel alevel)
        {
            if (_levels.Contains(alevel))
            {
                _levels.Remove(alevel);
                switch (alevel)
                {
                    case Helpers.AccessLevel.admin:
                        Cookie_Del(Helpers.LoginType.system, "admin");
                        break;
                    case Helpers.AccessLevel.god:
                        Cookie_Del(Helpers.LoginType.system, "god");
                        break;
                }
            }
        }

        public void Article_Add(Guid guid)
        {
            Article_Add(guid, false);
        }

        public void Article_Add(Guid guid, bool cookie)
        {
            if (!_articleGuids.Contains(guid))
            {
                _articleGuids.Add(guid);
                if (cookie)
                {
                    Cookie_Add(Helpers.LoginType.article, guid.ToString());
                }
            }
        }

        public bool Article_Has(Guid guid)
        {
            return _articleGuids.Contains(guid);
        }

        public void Article_Remove(Guid guid)
        {
            if (_articleGuids.Contains(guid))
            {
                _articleGuids.Remove(guid);
                Cookie_Del(Helpers.LoginType.article, guid.ToString());
            }
        }

        private void Cookie_Add(Helpers.LoginType log_type, string parameter)
        {
            string value = Cookie_Value(log_type, parameter);
            if (!string.IsNullOrEmpty(value))
            {
                HttpCookie mycookie = new HttpCookie("login:" + log_type.ToString() + ":" + parameter, value);
                mycookie.Expires = DateTime.Now.AddDays(30);
                HttpContext.Current.Response.Cookies.Add(mycookie);
            }
        }

        private void Cookie_Del(Helpers.LoginType log_type, string parameter)
        {
            if (HttpContext.Current.Response.Cookies["login:" + log_type.ToString() + ":" + parameter] != null)
            {
                HttpContext.Current.Response.Cookies["login:" + log_type.ToString() + ":" + parameter].Expires = DateTime.Now.AddDays(-1);
            }
        }

        private string Cookie_Value(Helpers.LoginType log_type, string parameter)
        {
            string retvalue = string.Empty;
            switch (log_type)
            {
                case Helpers.LoginType.article:
                    Services.ArticleService articleService = new Services.ArticleService();
                    Model.Article article = articleService.ArticleGet(new Guid(parameter), true);
                    if (article != null)
                    {
                        retvalue = article.AdminPass;
                    }
                    break;
                case Helpers.LoginType.system:
                    if (parameter == "admin")
                    {
                        retvalue = (string)Settings.Query(Settings.AppSettingKey.app_pass_admin);
                    }
                    else if (parameter == "god")
                    {
                        retvalue = (string)Settings.Query(Settings.AppSettingKey.app_pass_god);
                    }
                    break;
            }
            return retvalue;
        }

        private void Cookie_Check(HttpCookie cookie)
        {
            string[] keys = cookie.Name.Split(':');
            if ((keys.Length == 3) && (keys[0] == "login"))
            {
                Helpers.LoginType ltype = Helpers.LoginType.none;
                try
                {
                    ltype = (Helpers.LoginType) Enum.Parse(typeof(Helpers.LoginType), keys[1], true);
                }
                catch
                {
                    ltype = Helpers.LoginType.none;
                }
                if (ltype != Helpers.LoginType.none)
                {
                    string param = keys[2];
                    string value = Cookie_Value(ltype, param);
                    if ((!string.IsNullOrEmpty(value)) && (value == cookie.Value))
                    {
                        //Add appropriate access level for cookie as it has been verified
                        switch (ltype)
                        {
                            case Helpers.LoginType.article:
                                Article_Add(new Guid(param));
                                break;
                            case Helpers.LoginType.system:
                                if (param.ToLower() == "god")
                                {
                                    Add(Helpers.AccessLevel.god);
                                    Add(Helpers.AccessLevel.admin);
                                }
                                else if (param.ToLower() == "admin")
                                {
                                    Add(Helpers.AccessLevel.admin);
                                }
                                break;
                        }
                    }
                    else
                    {
                        //Cookie Value is invalid - delete on response
                        Cookie_Del(ltype, param);
                    }
                }
            }
        }
    }
}
