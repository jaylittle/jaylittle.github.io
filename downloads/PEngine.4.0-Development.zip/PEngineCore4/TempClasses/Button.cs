﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEngine4.Core.TempClasses
{
    public class Button
    {
        public string URL { get; set; }
        public string Text { get; set; }
        public string CSSClass { get; set; }

        public Button(string url, string text, string cssClass)
        {
            this.URL = url;
            this.Text = text;
            this.CSSClass = cssClass;
        }

        public bool IsButton()
        {
            if ((this.URL != string.Empty) || (this.Text != string.Empty) || (this.CSSClass != string.Empty))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
