﻿/* This script will insert all of the default quotes used by the system */

DELETE FROM QUOTE
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The conservation movement is a breeding ground of Communists and other&nbsp;subversives.  We intend to clean them out, even if it means rounding up&nbsp;every bird watcher in the country.<br>&nbsp;-- John Mitchell, Atty. General 1969-1972')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m returning this note to you, instead of your paper, because it<br>your paper) presently occupies the bottom of my bird cage."<br>&nbsp;-- English Professor, Providence College')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any stone in your boot always migrates against the pressure gradient to&nbsp;exactly the point of most pressure.<br>&nbsp;-- Milt Barber')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In a museum in Havana, there are two skulls of Christopher Columbus,<br>"one when he was a boy and one when he was a man."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real World, The n.:<br>1. In programming, those institutions at which programming may&nbsp;be used in the same sentence as FORTRAN, COBOL, RPG, IBM, etc.  2. To&nbsp;programmers, the location of non-programmers and activities not related&nbsp;to programming.  3. A universe in which the standard dress is shirt and&nbsp;tie and in which a person''s working hours are defined as 9 to 5.  4.<br>The location of the status quo.  5. Anywhere outside a university.<br>"Poor fellow, he''s left MIT and gone into the real world."  Used&nbsp;pejoratively by those not in residence there.  In conversation, talking&nbsp;of someone who has entered the real world is not unlike talking about a&nbsp;deceased person.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anything free is worth what you pay for it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'AQUARIUS (Jan 20 - Feb 18)<br>You have an inventive mind and are inclined to be progressive.<br>You lie a great deal.  On the other hand, you are inclined to<br>be careless and impractical, causing you to make the same<br>mistakes over and over again.  People think you are stupid.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #32:<br>&nbsp;Q:  Do you know how far pregnant you are right now?&nbsp;A:  I will be three months November 8th.<br>Q:  Apparently then, the date of conception was August 8th?&nbsp;A:  Yes.<br>Q:  What were you and your husband doing at that time?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real computer scientists admire ADA for its overwhelming aesthetic&nbsp;value but they find it difficult to actually program in it, as it is&nbsp;much too large to implement.  Most computer scientists don''t notice&nbsp;this because they are still arguing over what else to add to ADA.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I think that all good, right thinking people in this country are sick&nbsp;and tired of being told that all good, right thinking people in this&nbsp;country are fed up with being told that all good, right thinking people&nbsp;in this country are fed up with being sick and tired.  I''m certainly&nbsp;not, and I''m sick and tired of being told that I am.<br>&nbsp;-- Monty Python')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Talking much about oneself can also be a means to conceal oneself.<br>&nbsp;-- Friedrich Nietzsche')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Artistic ventures highlighted.  Rob a museum.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lubarsky''s Law of Cybernetic Entomology:<br>There''s always one more bug.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Memphis, Tennessee, it is illegal for a woman to drive a car unless&nbsp;there is a man either running or walking in front of it waving a red&nbsp;flag to warn approaching motorists and pedestrians.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I only touch base with reality on an as-needed basis!"<br>&nbsp;-- Royal Floyd Mengot (Klaus)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Personifiers Unite!  You have nothing to lose but Mr. Dignity!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is very difficult to prophesy, especially when it pertains to the&nbsp;future.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Two percent of zero is almost nothing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For 20 dollars, I''ll give you a good fortune next time ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ken Thompson has an automobile which he helped design.  Unlike most&nbsp;automobiles, it has neither speedometer, nor gas gage, nor any of the&nbsp;numerous idiot lights which plague the modern driver.  Rather, if the&nbsp;driver makes any mistake, a giant "?" lights up in the center of the&nbsp;dashboard.  "The experienced driver", he says, "will usually know&nbsp;what''s wrong."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You know you have a small apartment when Rice Krispies echo.<br>&nbsp;-- S. Rickly Christian')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s no room in the drug world for amateurs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Confidence is the feeling you have before you understand the&nbsp;situation.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Blessed are they who Go Around in Circles, for they Shall be Known as&nbsp;Wheels.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once ... in the wilds of Afghanistan, I lost my corkscrew, and we were&nbsp;forced to live on nothing but food and water for days.<br>&nbsp;-- W. C. Fields, "My Little Chickadee"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A total abstainer is one who abstains from everything but abstention,<br>and especially from inactivity in the affairs of others.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Take everything in stride.  Trample anyone who gets in your way.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pure drivel tends to drive ordinary drivel off the TV screen.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Authors (and perhaps columnists) eventually rise to the top of whatever&nbsp;depths they were once able to plumb.<br>&nbsp;-- Stanley Kaufman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Distress, n.:<br>A disease incurred by exposure to the prosperity of a friend.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is now 10 p.m.  Do you know where Henry Kissinger is?<br>&nbsp;-- Elizabeth Carpenter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Join the march to save individuality!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Heaven, n.:<br>A place where the wicked cease from troubling you with talk of&nbsp;their personal affairs, and the good listen with attention while you&nbsp;expound your own.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Go placidly amid the noise and waste, and remember what value there may&nbsp;be in owning a piece thereof.<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Where there''s a will, there''s an Inheritance Tax.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speaking as someone who has delved into the intricacies of PL/I, I am&nbsp;sure that only Real Men could have written such a machine-hogging,<br>cycle-grabbing, all-encompassing monster.  Allocate an array and free&nbsp;the middle third?  Sure!  Why not?  Multiply a character string times a&nbsp;bit string and assign the result to a float decimal?  Go ahead!  Free a&nbsp;controlled variable procedure parameter and reallocate it before&nbsp;passing it back?  Overlay three different types of variable on the same&nbsp;memory location?  Anything you say!  Write a recursive macro?  Well,<br>no, but Real Men use rescan.  How could a language so obviously&nbsp;designed and written by Real Men not be intended for Real Man use?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real programmers don''t draw flowcharts.  Flowcharts are, after all, the&nbsp;illiterate''s form of documentation.  Cavemen drew flowcharts; look how&nbsp;much good it did them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you''re away, I''m restless, lonely,<br>Wretched, bored, dejected; only&nbsp;Here''s the rub, my darling dear&nbsp;I feel the same when you are near.<br>&nbsp;-- Samuel Hoffenstein, "When You''re Away"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Measure with a micrometer.  Mark with chalk.  Cut with an axe.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Actor:&nbsp;"I''m a smash hit.  Why, yesterday during the last act, I had<br>everyone glued in their seats!"&nbsp;Oliver Herford:&nbsp;"Wonderful!  Wonderful!  Clever of you to think of<br>it!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;Pittsburgh Driver''s Test&nbsp;<br>8) Pedestrians are&nbsp;<br>(a) irrelevant.<br>(b) communists.<br>(c) a nuisance.<br>(d) difficult to clean off the front grille.<br>&nbsp;The correct answer is (a).  Pedestrians are not in cars, so they are&nbsp;totally irrelevant to driving; you should ignore them completely.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nasrudin walked into a shop one day, and the owner came forward to&nbsp;serve him.  Nasrudin said, "First things first.  Did you see me walk&nbsp;into your shop?"  "Of course."  "Have you ever seen me before?"&nbsp;"Never."  "Then how do you know it was me?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"MacDonald has the gift on compressing the largest amount of words into&nbsp;the smallest amount of thoughts."<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Trying to establish voice contact ... please ____^H^H^H^Hyell into keyboard.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No part of this message may reproduce, store itself in a retrieval&nbsp;system, or transmit disease, in any form, without the permissiveness of&nbsp;the author.<br>&nbsp;-- Chris Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chemicals, n.:<br>Noxious substances from which modern foods are made.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whether you can hear it or not&nbsp;The Universe is laughing behind your back<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Quidquid latine dictum sit, altum viditur.<br><br>Whatever is said in Latin sounds profound.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '[Prime Minister Joseph] Chamberlain loves the working man -- he loves&nbsp;to see him work.<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;Get GUMMed<br>&nbsp;&nbsp;--- ------&nbsp;The Gurus of Unix Meeting of Minds (GUMM) takes place Wednesday, April&nbsp;1, 2076 (check THAT in your perpetual calendar program), 14 feet above&nbsp;the ground directly in front of the Milpitas Gumps.  Members will grep&nbsp;each other by the hand (after intro), yacc a lot, smoke filtered&nbsp;chroots in pipes, chown with forks, use the wc (unless uuclean), fseek&nbsp;nice zombie processes, strip, and sleep, but not, we hope, od.  Three&nbsp;days will be devoted to discussion of the ramifications of whodo.  Two&nbsp;seconds have been allotted for a complete rundown of all the user-&nbsp;friendly features of Unix.  Seminars include "Everything You Know is&nbsp;Wrong", led by Tom Kempson, "Batman or Cat:man?" led by Richie Dennis&nbsp;"cc C?  Si!  Si!" led by Kerwin Bernighan, and "Document Unix, Are You&nbsp;Kidding?" led by Jan Yeats.  No Reader Service No. is necessary because&nbsp;all GUGUs (Gurus of Unix Group of Users) already know everything we&nbsp;could tell them.<br>&nbsp;-- Dr. Dobb''s Journal, June ''84')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s easier to fight for one''s principles than to live up to them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Over the years, I''ve developed my sense of deja vu so acutely that now&nbsp;I can remember things that *have* happened before ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The verdict of a jury is the a priori opinion of that juror who smokes&nbsp;the worst cigars.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The study of non-linear physics is like the study of non-elephant&nbsp;biology.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #3:<br>&nbsp;Q:  When he went, had you gone and had she, if she wanted to and were&nbsp;    able, for the time being excluding all the restraints on her not to&nbsp;    go, gone also, would he have brought you, meaning you and she, with&nbsp;    him to the station?&nbsp;MR. BROOKS:  Objection.  That question should be taken out and shot.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For a good time, call (415) 642-9483')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When the Universe was not so out of whack as it is today, and all the&nbsp;stars were lined up in their proper places, you could easily count them&nbsp;from left to right, or top to bottom, and the larger and bluer ones&nbsp;were set apart, and the smaller yellowing types pushed off to the&nbsp;corners as bodies of a lower grade ...<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love your enemies: they''ll go crazy trying to figure out what you''re up&nbsp;to.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"They told me I was gullible ... and I believed them!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Greener''s Law:<br>Never argue with a man who buys ink by the barrel.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man is the only animal that blushes -- or needs to.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Checkuary, n.:<br>The thirteenth month of the year.  Begins New Year''s Day and&nbsp;ends when a person stops absentmindedly writing the old year on his&nbsp;checks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Truly great madness can not be achieved without significant&nbsp;intelligence.<br>&nbsp;-- Henrik Tikkanen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Logic is a little bird, sitting in a tree; that smells *_____^H^H^H^H^Hawful*.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One learns to itch where one can scratch.<br>&nbsp;-- Ernest Bramah')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am, in point of fact, a particularly haughty and exclusive person,<br>of pre-Adamite ancestral descent.  You will understand this when I tell&nbsp;you that I can trace my ancestry back to a protoplasmal primordial&nbsp;atomic globule.  Consequently, my family pride is something&nbsp;inconceivable.  I can''t help it.  I was born sneering."<br>&nbsp;-- Pooh-Bah, "The Mikado", Gilbert & Sullivan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mohandas K. Gandhi often changed his mind publicly.  An aide once asked&nbsp;him how he could so freely contradict this week what he had said just&nbsp;last week.  The great man replied that it was because this week he knew&nbsp;better.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Fifth Rule:<br>You have taken yourself too seriously.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;     JACK AND THE BEANSTACK<br>&nbsp;&nbsp;  by Mark Isaak&nbsp;<br>Long ago, in a finite state far away, there lived a JOVIAL&nbsp;character named Jack.  Jack and his relations were poor.  Often their&nbsp;hash table was bare.  One day Jack''s parent said to him, "Our matrices&nbsp;are sparse.  You must go to the market to exchange our RAM for some&nbsp;BASICs."  She compiled a linked list of items to retrieve and passed it&nbsp;to him.<br>So Jack set out.  But as he was walking along a Hamilton path,<br>he met the traveling salesman.<br>"Whither dost thy flow chart take thou?" prompted the salesman&nbsp;in high-level language.<br>"I''m going to the market to exchange this RAM for some chips&nbsp;and Apples," commented Jack.<br>"I have a much better algorithm.  You needn''t join a queue&nbsp;there; I will swap your RAM for these magic kernels now."<br>Jack made the trade, then backtracked to his house.  But when&nbsp;he told his busy-waiting parent of the deal, she became so angry she&nbsp;started thrashing.<br>"Don''t you even have any artificial intelligence?  All these&nbsp;kernels together hardly make up one byte," and she popped them out the&nbsp;window ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Marriage is the only adventure open to the cowardly.<br>&nbsp;-- Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'cursor address, n:<br>"Hello, cursor!"<br>&nbsp;-- Stan Kelly-Bootle, "The Devil''s DP Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Computers are useless.  They can only give you answers.<br>&nbsp;-- Pablo Picasso')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is your fortune.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You are the only person to ever get this message.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We may hope that machines will eventually compete with men in all&nbsp;purely intellectual fields.  But which are the best ones to start&nbsp;with?  Many people think that a very abstract activity, like the&nbsp;playing of chess, would be best.  It can also be maintained that it is&nbsp;best to provide the machine with the best sense organs that money can&nbsp;buy, and then teach it to understand and speak English.<br>&nbsp;-- Alan M. Turing')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How long a minute is depends on which side of the bathroom door you''re&nbsp;on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hartley''s First Law:<br>You can lead a horse to water, but if you can get him to float&nbsp;on his back, you''ve got something.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'X-rated movies are all alike ... the only thing they leave to the&nbsp;imagination is the plot.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ambidextrous, adj.:<br>Able to pick with equal skill a right-hand pocket or a left.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Philosophy will clip an angel''s wings.<br>&nbsp;-- John Keats')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I hate quotations."<br>&nbsp;-- Ralph Waldo Emerson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is National Non-Dairy Creamer Week.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Festivity Level 1: Your guests are chatting amiably with each&nbsp;other, admiring your Christmas-tree ornaments, singing carols around&nbsp;the upright piano, sipping at their drinks and nibbling hors&nbsp;d''oeuvres.<br>Festivity Level 2: Your guests are talking loudly -- sometimes&nbsp;to each other, and sometimes to nobody at all, rearranging your&nbsp;Christmas-tree ornaments, singing "I Gotta Be Me" around the upright&nbsp;piano, gulping their drinks and wolfing down hors d''oeuvres.<br>Festivity Level 3: Your guests are arguing violently with&nbsp;inanimate objects, singing "I can''t get no satisfaction," gulping down&nbsp;other peoples'' drinks, wolfing down Christmas tree ornaments and&nbsp;placing hors d''oeuvres in the upright piano to see what happens when&nbsp;the little hammers strike.<br>Festivity Level 4: Your guests, hors d''oeuvres smeared all over&nbsp;their naked bodies are performing a ritual dance around the burning&nbsp;Christmas tree.  The piano is missing.<br><br>You want to keep your party somewhere around level 3, unless&nbsp;you rent your home and own Firearms, in which case you can go to level&nbsp;4.  The best way to get to level 3 is egg-nog.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this country needs is a good five cent ANYTHING!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;AMAZING BUT TRUE ...<br>&nbsp;There is so much sand in Northern Africa that if it were spread out it&nbsp;would completely cover the Sahara Desert.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This fortune cookie program out of order.  For those in desperate need,<br>please use the program "________^H^H^H^H^H^H^H^Hrandchar".  This program generates random&nbsp;characters, and, given enough time, will undoubtedly come up with&nbsp;something profound.  It will, however, take it no time at all to be&nbsp;more profound than THIS program has ever been.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The older I grow the more I distrust the familiar doctrine that age&nbsp;brings wisdom.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Corruption is not the #1 priority of the Police Commissioner.  His job&nbsp;is to enforce the law and fight crime.<br>&nbsp;-- P.B.A. President E. J. Kiernan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing is more admirable than the fortitude with which millionaires&nbsp;tolerate the disadvantages of their wealth.<br>&nbsp;-- Nero Wolfe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The sheep that fly over your head are soon to land.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The moon is a planet just like the Earth, only it is even deader.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Seventh Commandments for Technicians<br>Work thou not on energized equipment, for if thou dost, thy&nbsp;fellow workers will surely buy beers for thy widow and console her in&nbsp;other ways.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To iterate is human, to recurse, divine.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... Had this been an actual emergency, we would have fled in terror,<br>and you would not have been informed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We are confronted with insurmountable opportunities.<br>&nbsp;-- Walt Kelly, "Pogo"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s odd, and a little unsettling, to reflect upon the fact that&nbsp;English is the only major language in which "I" is capitalized; in many&nbsp;other languages "You" is capitalized and the "i" is lower case.<br>&nbsp;-- Sydney J. Harris')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'VYARZERZOMANIMORORSEZASSEZANSERAREORSES?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'By trying, we can easily learn to endure adversity -- another man''s, I&nbsp;mean.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is the recurrent suspicion that more than half of the people&nbsp;are right more than half of the time.<br>&nbsp;-- E. B. White')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t tell any big lies today.  Small ones can be just as effective.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As you know, birds do not have sexual organs because they would&nbsp;interfere with flight.  [In fact, this was the big breakthrough for the&nbsp;Wright Brothers.  They were watching birds one day, trying to figure&nbsp;out how to get their crude machine to fly, when suddenly it dawned on&nbsp;Wilbur.  "Orville," he said, "all we have to do is remove the sexual&nbsp;organs!"  You should have seen their original design.]  As a result,<br>birds are very, very difficult to arouse sexually.  You almost never&nbsp;see an aroused bird.  So when they want to reproduce, birds fly up and&nbsp;stand on telephone lines, where they monitor telephone conversations&nbsp;with their feet.  When they find a conversation in which people are&nbsp;talking dirty, they grip the line very tightly until they are both&nbsp;highly aroused, at which point the female gets pregnant.<br>&nbsp;-- Dave Barry, "Sex and the Single Amoeba: What Every<br>&nbsp;   Teen Should Know"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  Why did the tachyon cross the road?&nbsp;A:  Because it was on the other side.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What garlic is to food, insanity is to art.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Pascal is not a high-level language."<br>&nbsp;-- Steven Feiner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cinemuck, n.:<br>The combination of popcorn, soda, and melted chocolate which&nbsp;covers the floors of movie theaters.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who express random thoughts to legislative committees are often&nbsp;surprised and appalled to find themselves the instigators of law.<br>&nbsp;-- Mark B. Cohen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"That must be wonderful!  I don''t understand it at all."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We can defeat gravity.  The problem is the paperwork involved.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reader, suppose you were an idiot.  And suppose you were a member of&nbsp;Congress.  But I repeat myself.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have to convince you, or at least snow you ..."<br>&nbsp;-- Prof. Romas Aleliunas, CS 435')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are three ways to get something done:<br>(1) Do it yourself.<br>(2) Hire someone to do it for you.<br>(3) Forbid your kids to do it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Adult, n.:<br>One old enough to know better.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kiss me twice.  I''m schizophrenic.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A "No" uttered from deepest conviction is better and greater than a&nbsp;"Yes" merely uttered to please, or what is worse, to avoid trouble.<br>&nbsp;-- Mahatma Ghandi')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An artist should be fit for the best society and keep out of it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Troubled day for virgins over 16 who are beautiful and wealthy and live&nbsp;in eucalyptus trees.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The USA is so enormous, and so numerous are its schools, colleges and&nbsp;religious seminaries, many devoted to special religious beliefs ranging&nbsp;from the unorthodox to the dotty, that we can hardly wonder at its&nbsp;yielding a more bounteous harvest of gobbledygook than the rest of the&nbsp;world put together.<br>&nbsp;-- Sir Peter Medawar')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dave Mack:&nbsp;"Your stupidity, Allen, is simply not up to par."&nbsp;Allen Gwinn:&nbsp;"Yours is."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Death is Nature''s way of recycling human beings.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How much does it cost to entice a dope-smoking UNIX system guru to&nbsp;Dayton?<br>&nbsp;-- Brian Boyle, UNIX/WORLD''s First Annual Salary Survey')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The penalty for laughing in a courtroom is six months in jail; if it&nbsp;were not for this penalty, the jury would never hear the evidence.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Apathy is not the problem, it''s the solution"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'THE GOLDEN RULE OF ARTS AND SCIENCES<br>The one who has the gold makes the rules.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Line Printer paper is strongest at the perforations.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Have you lived here all your life?"&nbsp;"Oh, twice that long."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I have to floss my cat."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Common sense and a sense of humor are the same thing, moving at&nbsp;different speeds.  A sense of humor is just common sense, dancing.<br>&nbsp;-- Clive James')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Jacquin''s Postulate on Democratic Government:<br>No man''s life, liberty, or property are safe while the&nbsp;legislature is in session.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mother is the invention of necessity.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A fanatic is one who can''t change his mind and won''t change the&nbsp;subject.<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You don''t sew with a fork, so I see no reason to eat with knitting&nbsp;needles.<br>&nbsp;-- Miss Piggy, on eating Chinese Food')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We ARE as gods and might as well get good at it.<br>&nbsp;-- Whole Earth Catalog')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Binary, adj.:<br>Possessing the ability to have friends of both sexes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is a device that insures we shall be governed no better than&nbsp;we deserve.<br>&nbsp;-- George Bernard Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The Lord gave us farmers two strong hands so we could grab as much as&nbsp;we could with both of them."<br>&nbsp;-- Joseph Heller, "Catch-22"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Irrationality is the square root of all evil"<br>&nbsp;-- Douglas Hofstadter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Immigration is the sincerest form of flattery.<br>&nbsp;-- Jack Paar')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Reality is that which, when you stop believing in it, doesn''t go&nbsp;away".<br>&nbsp;-- Philip K. Dick')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I used to be an agnostic, but now I''m not so sure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Actor:&nbsp;So what do you do for a living?&nbsp;Doris:&nbsp;I work for a company that makes deceptively shallow serving<br>dishes for Chinese restaurants.<br>&nbsp;-- Woody Allen, "Without Feathers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'methionylglutaminylarginyltyrosylglutamylserylleucylphenylalanylalanylglutamin-&nbsp;ylleucyllysylglutamylarginyllysylglutamylglycylalanylphenylalanylvalylprolyl-&nbsp;phenylalanylvalylthreonylleucylglycylaspartylprolylglycylisoleucylglutamylglu-&nbsp;taminylserylleucyllysylisoleucylaspartylthreonylleucylisoleucylglutamylalanyl-&nbsp;glycylalanylaspartylalanylleucylglutamylleucylglycylisoleucylprolylphenylala-&nbsp;nylserylaspartylprolylleucylalanylaspartylglycylprolylthreonylisoleucylgluta-&nbsp;minylasparaginylalanylthreonylleucylarginylalanylphenylalanylalanylalanylgly-&nbsp;cylvalylthreonylprolylalanylglutaminylcysteinylphenylalanylglutamylmethionyl-&nbsp;leucylalanylleucylisoleucylarginylglutaminyllysylhistidylprolylthreonylisoleu-&nbsp;cylprolylisoleucylglycylleucylleucylmethionyltyrosylalanylasparaginylleucylva-&nbsp;lylphenylalanylasparaginyllysylglycylisoleucylaspartylglutamylphenylalanyltyro-&nbsp;sylalanylglutaminylcysteinylglutamyllysylvalylglycylvalylaspartylserylvalylleu-&nbsp;cylvalylalanylaspartylvalylprolylvalylglutaminylglutamylserylalanylprolylphe-&nbsp;nylalanylarginylglutaminylalanylalanylleucylarginylhistidylasparaginylvalylala-&nbsp;nylprolylisoleucylphenylalanylisoleucylcysteinylprolylprolylaspartylalanylas-&nbsp;partylaspartylaspartylleucylleucylarginylglutaminylisoleucylalanylseryltyrosyl-&nbsp;glycylarginylglycyltyrosylthreonyltyrosylleucylleucylserylarginylalanylglycyl-&nbsp;valylthreonylglycylalanylglutamylasparaginylarginylalanylalanylleucylprolylleu-&nbsp;cylasparaginylhistidylleucylvalylalanyllysylleucyllysylglutamyltyrosylasparagi-&nbsp;nylalanylalanylprolylprolylleucylglutaminylglycylphenylalanylglycylisoleucylse-&nbsp;rylalanylprolylaspartylglutaminylvalyllysylalanylalanylisoleucylaspartylalanyl-&nbsp;glycylalanylalanylglycylalanylisoleucylserylglycylserylalanylisoleucylvalylly-&nbsp;sylisoleucylisoleucylglutamylglutaminylhistidylasparaginylisoleucylglutamylpro-&nbsp;lylglutamyllysylmethionylleucylalanylalanylleucyllysylvalylphenylalanylvalyl-&nbsp;glutaminylprolylmethionyllysylalanylalanylthreonylarginylserine, n.:<br>The chemical name for tryptophan synthetase A protein, a<br>1,913-letter enzyme with 267 amino acids.<br>&nbsp;-- Mrs. Bryne''s Dictionary of Unusual, Obscure, and')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In those days he was wiser than he is now -- he used to frequently take&nbsp;my advice.<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The only thing to do with good advice is pass it on.  It is never any&nbsp;use to oneself.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Only adults have difficulty with childproof caps.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mother told me to be good, but she''s been wrong before.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;The STAR WARS Song<br>Sung to the tune of "Lola", by the Kinks:<br>&nbsp;I met him in a swamp down in Dagobah&nbsp;Where it bubbles all the time like a giant cabinet soda<br>S-O-D-A soda&nbsp;I saw the little runt sitting there on a log&nbsp;I asked him his name and in a raspy voice he said Yoda<br>Y-O-D-A Yoda, Yo-Yo-Yo-Yo Yoda&nbsp;&nbsp;Well I''ve been around but I ain''t never seen&nbsp;A guy who looks like a Muppet but he''s wrinkled and green<br>Oh my Yoda, Yo-Yo-Yo-Yo Yoda&nbsp;Well I''m not dumb but I can''t understand&nbsp;How he can raise me in the air just by raising his hand<br>Oh my Yoda, Yo-Yo-Yo-Yo Yoda, Yo-Yo-Yo-Yo Yoda')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I cannot and will not cut my conscience to fit this year''s fashions."<br>&nbsp;-- Lillian Hellman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will be a winner today.  Pick a fight with a four-year-old.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Connector Conspiracy, n:<br>[probably came into prominence with the appearance of the&nbsp;KL-10, none of whose connectors match anything else] The tendency of&nbsp;manufacturers (or, by extension, programmers or purveyors of anything)<br>to come up with new products which don''t fit together with the old&nbsp;stuff, thereby making you buy either all new stuff or expensive&nbsp;interface devices.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fights between cats and dogs are prohibited by statute in Barber, North&nbsp;Carolina.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'CANCER (June 21 - July 22)<br>You are sympathetic and understanding to other people''s&nbsp;problems.  They think you are a sucker.  You are always putting things&nbsp;off.  That''s why you''ll never make anything of yourself.  Most welfare&nbsp;recipients are Cancer people.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He was a modest, good-humored boy.  It was Oxford that made him&nbsp;insufferable."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It has just been discovered that research causes cancer in rats.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why I Can''t Go Out With You:<br>&nbsp;I''d LOVE to, but ...<br>-- I have to floss my cat.<br>-- I''ve dedicated my life to linguini.<br>-- I need to spend more time with my blender.<br>-- it wouldn''t be fair to the other Beautiful People.<br>-- it''s my night to pet the dog/ferret/goldfish.<br>-- I''m going downtown to try on some gloves.<br>-- I have to check the freshness dates on my dairy products.<br>-- I''m going down to the bakery to watch the buns rise.<br>-- I have an appointment with a cuticle specialist.<br>-- I have some really hard words to look up.<br>-- I''ve got a Friends of the Lowly Rutabaga meeting.<br>-- I promised to help a friend fold road maps.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All progress is based upon a universal innate desire on the part of&nbsp;every organism to live beyond its income.<br>&nbsp;-- Samuel Butler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stop searching.  Happiness is right next to you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '''Twas midnight, and the UNIX hacks&nbsp;Did gyre and gimble in their cave&nbsp;All mimsy was the CS-VAX&nbsp;And Cory raths outgrabe.<br>&nbsp;"Beware the software rot, my son!&nbsp;The faults that bite, the jobs that thrash!&nbsp;Beware the broken pipe, and shun&nbsp;The frumious system crash!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Now, you might ask, "How do I get one of those complete home&nbsp;tool sets for under $4?"  An excellent question.<br>Go to one of those really cheap discount stores where they sell&nbsp;plastic furniture in colors visible from the planet Neptune and where&nbsp;they have a food section specializing in cardboard cartons full of&nbsp;Raisinets and malted milk balls manufactured during the Nixon&nbsp;administration.  In either the hardware or housewares department,<br>you''ll find an item imported from an obscure Oriental country and&nbsp;described as "Nine Tools in One", consisting of a little handle with&nbsp;interchangeable ends representing inscrutable Oriental notions of tools&nbsp;that Americans might use around the home.  Buy it.<br>This is the kind of tool set professionals use.  Not only is it&nbsp;inexpensive, but it also has a great safety feature not found in the&nbsp;so-called quality tools sets: The handle will actually break right off&nbsp;if you accidentally hit yourself or anything else, or expose it to&nbsp;direct sunlight.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Atlanta makes it against the law to tie a giraffe to a telephone pole&nbsp;or street lamp.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My God, I''m depressed!  Here I am, a computer with a mind a thousand&nbsp;times as powerful as yours, doing nothing but cranking out fortunes and&nbsp;sending mail about softball games.  And I''ve got this pain right&nbsp;through my ALU.  I''ve asked for it to be replaced, but nobody ever&nbsp;listens.  I think it would be better for us both if you were to just&nbsp;log out again.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Although the moon is smaller than the earth, it is farther away.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There was a young poet named Dan,<br>Whose poetry never would scan.<br>When told this was so,<br>He said, "Yes, I know.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If the code and the comments disagree, then both are probably wrong.<br>&nbsp;-- Norm Schryer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be careful of reading health books, you might die of a misprint.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Please try to limit the amount of "this room doesn''t have any bazingas"&nbsp;until you are told that those rooms are "punched out".  Once punched&nbsp;out, we have a right to complain about atrocities, missing bazingas,<br>and such.<br>&nbsp;-- N. Meyrowitz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Would you tell me, please, which way I ought to go from here?"&nbsp;&nbsp;"That depends a good deal on where you want to get to," said the Cat<br>&nbsp;-- Lewis Carrol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can''t start worrying about what''s going to happen.  You get spastic&nbsp;enough worrying about what''s happening now.<br>&nbsp;-- Lauren Bacall')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Signs of crime: screaming or cries for help.<br>&nbsp;-- from the Brown Security Crime Prevention Pamphlet')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'That secret you''ve been guarding, isn''t.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Humor is a drug which it''s the fashion to abuse."<br>&nbsp;-- William Gilbert')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The mosquito is the state bird of New Jersey.<br>&nbsp;-- Andy Warhol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Machines certainly can solve problems, store information, correlate,<br>and play games -- but not with pleasure.<br>&nbsp;-- Leo Rosten')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Consultant''s Curse:<br>When the customer has beaten upon you long enough, give him&nbsp;what he asks for, instead of what he needs.  This is very strong&nbsp;medicine, and is normally only required once.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cleveland still lives.  God ____^H^H^H^Hmust be dead.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Who needs friends when you can sit alone in your room and drink?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no distinctly native American criminal class except Congress.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"They make a desert and call it peace."<br>&nbsp;-- Tacitus (55?-120?)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Graduate life -- it''s not just a job, it''s an indenture.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Put no trust in cryptic comments.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dentist, n.:<br>A Prestidigitator who, putting metal in one''s mouth, pulls&nbsp;coins out of one''s pockets.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Africa some of the native tribes have a custom of beating the ground&nbsp;with clubs and uttering spine chilling cries.  Anthropologists call&nbsp;this a form of primitive self-expression.  In America we call it golf.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finagle''s fourth Law:<br>Once a job is fouled up, anything done to improve it only makes&nbsp;it worse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A bachelor is a selfish, undeserving guy who has cheated some woman out&nbsp;of a divorce.<br>&nbsp;-- Don Quinn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any fool can paint a picture, but it takes a wise person to be able to&nbsp;sell it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every program is a part of some other program, and rarely fits.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Somewhere", said Father Vittorini, "did Blake not speak of the&nbsp;Machineries of Joy?  That is, did not God promote environments, then&nbsp;intimidate these Natures by provoking the existence of flesh, toy men&nbsp;and women, such as are we all?  And thus happily sent forth, at our&nbsp;best, with good grace and fine wit, on calm noons, in fair climes, are&nbsp;we not God''s Machineries of Joy?"&nbsp;&nbsp;"If Blake said that", said Father Brian, "he never lived in Dublin."<br>&nbsp;-- R. Bradbury, "The Machineries of Joy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How doth the VAX''s C-compiler&nbsp;Improve its object code.<br>And even as we speak does it&nbsp;Increase the system load.<br>&nbsp;How patiently it seems to run&nbsp;And spit out error flags,<br>While users, with frustration, all&nbsp;Tear all their clothes to rags.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On the road, ZIPPY is a pinhead without a purpose, but never without a&nbsp;POINT ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Since I hurt my pendulum&nbsp;My life is all erratic.<br>My parrot, who was cordial,<br>Is now transmitting static.<br>The carpet died, a palm collapsed,<br>The cat keeps doing poo.<br>The only thing that keeps me sane&nbsp;Is talking to my shoe.<br>&nbsp;-- My Shoe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is easier to be a "humanitarian" than to render your own country its&nbsp;proper due; it is easier to be a "patriot" than to make your community&nbsp;a better place to live in; it is easier to be a "civic leader" than to&nbsp;treat your own family with loving understanding; for the smaller the&nbsp;focus of attention, the harder the task.<br>&nbsp;-- Sydney J. Harris')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'REPORTER: Senator, are you for or against the MX missile system?&nbsp; &nbsp;SENATOR: Bob, the MX missile system reminds me of an old saying that&nbsp;the country folk in my state like to say.  It goes like this: "You can&nbsp;carry a pig for six miles, but if you set it down it might run away."&nbsp;I have no idea why the country folk say this.  Maybe there''s some kind&nbsp;of chemical pollutant in their drinking water.  That is why I pledge to&nbsp;do all that I can to protect the environment of this great nation of&nbsp;ours, and put prayer back in the schools, where it belongs.  What we&nbsp;need is jobs, not empty promises.  I realize I''m risking my political&nbsp;career be being so outspoken on a sensitive issue such as the MX, but&nbsp;that''s just the kind of straight-talking honest person I am, and I&nbsp;can''t help it.<br>&nbsp;-- Dave Barry, "On Presidential Politics"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;The seven eyes of Ningauble the Wizard floated back to his hood&nbsp;as he reported to Fafhrd: "I have seen much, yet cannot explain all.<br>The Gray Mouser is exactly twenty-five feet below the deepest cellar in&nbsp;the palace of Gilpkerio Kistomerces.  Even though twenty-four parts in&nbsp;twenty-five of him are dead, he is alive.<br><br>"Now about Lankhmar.  She''s been invaded, her walls breached&nbsp;everywhere and desperate fighting is going on in the streets, by a&nbsp;fierce host which out-numbers Lankhmar''s inhabitants by fifty to one --&nbsp;and equipped with all modern weapons.  Yet you can save the city."&nbsp;<br>"How?" demanded Fafhrd.<br><br>Ningauble shrugged.  "You''re a hero.  You should know."<br>&nbsp;-- Fritz Leiber, from "The Swords of Lankhmar"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The primary requisite for any new tax law is for it to exempt enough&nbsp;voters to win the next election.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dessert is probably the most important stage of the meal, since it will&nbsp;be the last thing your guests remember before they pass out all over&nbsp;the table.<br>&nbsp;-- The Anarchist Cookbook')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Dr. Johnson''s famous dictionary patriotism is defined as the last&nbsp;resort of the scoundrel.  With all due respect to an enlightened but&nbsp;inferior lexicographer I beg to submit that it is the first.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If they can make penicillin out of moldy bread, they can sure make&nbsp;something out of you.<br>&nbsp;-- Muhammad Ali')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You might have mail')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He''s the kind of guy, that, well, if you were ever in a jam he''d be&nbsp;there ... with two slices of bread and some chunky peanut butter.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The plot was designed in a light vein that somehow became varicose.<br>&nbsp;-- David Lardner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If Patrick Henry thought that taxation without representation was bad,<br>he should see how bad it is with representation.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Xerox does it again and again and again and ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Let''s talk about how to fill out your 1984 tax return.  Here''s an often&nbsp;overlooked accounting technique that can save you thousands of&nbsp;dollars:  For several days before you put it in the mail, carry your&nbsp;tax return around under your armpit.  No IRS agent is going to want to&nbsp;spend hours poring over a sweat-stained document.  So even if you owe&nbsp;money, you can put in for an enormous refund and the agent will&nbsp;probably give it to you, just to avoid an audit.  What does he care?&nbsp;It''s not his money.<br>&nbsp;-- Dave Barry, "Sweating Out Taxes"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lockwood''s Long Shot:<br>The chances of getting eaten up by a lion on Main Street aren''t&nbsp;one in a million, but once would be enough.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The new Congressmen say they''re going to turn the government around.  I&nbsp;hope I don''t get run over again.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Laetrile is the pits')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cigarette, n.:<br>A fire at one end, a fool at the other, and a bit of tobacco in&nbsp;between.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Users never use the Help key.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Stealing a rhinoceros should not be attempted lightly."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It is easier for a camel to pass through the eye of a needle if it is&nbsp;lightly greased."<br>&nbsp;-- Kehlog Albran, "The Profit"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Murray and Esther, a middle-aged Jewish couple, are touring&nbsp;Chile.  Murray just got a new camera and is constantly snapping&nbsp;pictures.  One day, without knowing it, he photographs a top-secret&nbsp;military installation.  In an instant, armed troops surround Murray and&nbsp;Esther and hustle them off to prison.<br>They can''t prove who they are because they''ve left their&nbsp;passports in their hotel room.  For three weeks they''re tortured day&nbsp;and night to get them to name their contacts in the liberation&nbsp;movement..  Finally they''re hauled in front of a military court,<br>charged with espionage, and sentenced to death.<br>The next morning they''re lined up in front of the wall where&nbsp;they''ll be shot.  The sergeant in charge of the firing squad asks them&nbsp;if they have any lasts requests.  Esther wants to know if she can call&nbsp;her daughter in Chicago.  The sergeant says he''s sorry, that''s not&nbsp;possible, and turns to Murray.<br>"This is crazy!"  Murray shouts.  "We''re not spies!"  And he&nbsp;spits in the sergeants face.<br>"Murray!"  Esther cries.  "Please!  Don''t make trouble."<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I may not be totally perfect, but parts of me are excellent."<br>&nbsp;-- Ashleigh Brilliant')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A mathematician is a machine for converting coffee into theorems.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Spouse, n.:<br>Someone who''ll stand by you through all the trouble you&nbsp;wouldn''t have had if you''d stayed single.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One advantage of talking to yourself is that you know at least&nbsp;somebody''s listening.<br>&nbsp;-- Franklin P. Jones')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whenever you find that you are on the side of the majority, it is time&nbsp;to reform.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As Will Rogers would have said, "There is no such things as a free&nbsp;variable."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any philosophy that can be put in a nutshell belongs there.<br>&nbsp;-- Sydney J. Harris')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man usually avoids attributing cleverness to somebody else -- unless it&nbsp;is an enemy.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kinkler''s First Law:<br>Responsibility always exceeds authority.<br>&nbsp;Kinkler''s Second Law:<br>All the easy problems have been solved.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Termiter''s argument that God is His own grandmother generated a&nbsp;surprising amount of controversy among Church leaders, who on the one&nbsp;hand considered the argument unsupported by scripture but on the other&nbsp;hand were unwilling to risk offending God''s grandmother."<br>&nbsp;-- Len Cool, "American Pie"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Genius may have its limitations, but stupidity is not thus&nbsp;handicapped.<br>&nbsp;-- Elbert Hubbard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There are three principal ways to lose money: wine, women, and&nbsp;engineers.  While the first two are more pleasant, the third is by far&nbsp;the more certain."<br>&nbsp;-- Baron Rothschild, ca. 1800')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You must realize that the computer has it in for you.  The irrefutable&nbsp;proof of this is that the computer always does what you tell it to do."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '[In the 60''s] there was madness in any direction, at any hour ...  You&nbsp;could strike sparks anywhere.  There was a fantastic universal sense&nbsp;that whatever we were doing was `right'', that we were winning ...<br>&nbsp;And that, I think, was the handle -- the sense of inevitable victory&nbsp;over the forces of Old and Evil.  Not in any mean or military sense; we&nbsp;didn''t need that.  Our energy would simply `prevail''.  There was no&nbsp;point in fighting -- on our side or theirs.  We had all the momentum:<br>we were riding the crest of a high and beautiful wave ....<br>&nbsp;So now, less than five years later, you can go up on a steep hill in&nbsp;Las Vegas and look West, and with the right kind of eyes you can almost&nbsp;___^H^H^Hsee the high-water mark -- the place where the wave finally broke and&nbsp;rolled back.<br>&nbsp;-- Hunter S. Thompson, "Fear and Loathing in Las Vegas"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If entropy is increasing, where is it coming from?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'USER, n.:<br>The word computer professionals use when they mean "idiot."<br>&nbsp;-- Dave Barry, "Claw Your Way to the Top"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nasrudin walked into a teahouse and declaimed, "The moon is more useful&nbsp;than the sun."  "Why?", he was asked.  "Because at night we need the&nbsp;light more."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You may have heard that a dean is to faculty as a hydrant is to a dog.<br>&nbsp;-- Alfred Kahn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a President doesn''t do it to his wife, he''ll do it to his country.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never settle with words what you can accomplish with a flame thrower.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Power corrupts.  And atomic power corrupts atomically.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Command, n.:<br>Statement presented by a human and accepted by a computer in&nbsp;such a manner as to make the human feel as if he is in control.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Hey!  Who took the cork off my lunch??!"<br>&nbsp;-- W. C. Fields')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t have any solution but I certainly admire the problem."<br>&nbsp;-- Ashleigh Brilliant')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Incumbent, n.:<br>Person of liveliest interest to the outcumbents.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As far as the laws of mathematics refer to reality, they are not&nbsp;certain, and as far as they are certain, they do not refer to reality.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kin, n.:<br>An affliction of the blood')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A day for firm decisions!!!!!  Or is it?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Trying to define yourself is like trying to bite your own teeth.<br>&nbsp;-- Alan Watts')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The trouble with being punctual is that people think you have nothing&nbsp;more important to do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All syllogisms have three parts, therefore this is not a syllogism.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Niklaus Wirth has lamented that, whereas Europeans pronounce his name&nbsp;correctly (Ni-klows Virt), Americans invariably mangle it into<br>Nick-les Worth).  Which is to say that Europeans call him by name, but&nbsp;Americans call him by value.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be security conscious -- National defense is at stake.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lobster:<br>Everyone loves these delectable crustaceans, but many cooks are&nbsp;squeamish about placing them into boiling water alive, which is the&nbsp;only proper method of preparing them.  Frankly, the easiest way to&nbsp;eliminate your guilt is to establish theirs by putting them on trial&nbsp;before they''re cooked.  The fact is, lobsters are among the most&nbsp;ferocious predators on the sea floor, and you''re helping reduce crime&nbsp;in the reefs.  Grasp the lobster behind the head, look it right in its&nbsp;unmistakably guilty eyestalks and say, "Where were you on the night of&nbsp;the 21st?", then flourish a picture of a scallop or a sole and shout,<br>"Perhaps this will refresh that crude neural apparatus you call a&nbsp;memory!"  The lobster will squirm noticeably.  It may even take a swipe&nbsp;at you with one of its claws.  Incorrigible.  Pop it into the pot.<br>Justice has been served, and shortly you and your friends will be,<br>too.<br>&nbsp;-- "Cooking: The Art of Using Appliances and Utensils<br>&nbsp;   into Excuses and Apologies"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On Monday mornings I am dedicated to the proposition that all men are&nbsp;created jerks.<br>&nbsp;-- H. Allen Smith, "Let the Crabgrass Grow"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nobody wants constructive criticism.  It''s all we can do to put up with&nbsp;constructive praise.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'ARCHDUKE FERDINAND FOUND ALIVE --&nbsp;    FIRST WORLD WAR A MISTAKE')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You know the great thing about TV?  If something important happens&nbsp;anywhere at all in the world, no matter what time of the day or night,<br>you can always change the channel.<br>&nbsp;-- Jim Ignatowski')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If there are epigrams, there must be meta-epigrams.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you sit down at a poker game and don''t see a sucker, get up.  You''re&nbsp;the sucker.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maturity is only a short break in adolescence.<br>&nbsp;-- Jules Feiffer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vote anarchist')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once the realization is accepted that even between the closest human&nbsp;beings infinite distances continue to exist, a wonderful living side by&nbsp;side can grow up, if they succeed in loving the distance between them&nbsp;which makes it possible for each to see each other whole against the&nbsp;sky.<br>&nbsp;-- Rainer Rilke')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anybody who doesn''t cut his speed at the sight of a police car is&nbsp;probably parked.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You cannot propel yourself forward by patting yourself on the back.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Plato, by the way, wanted to banish all poets from his proposed Utopia&nbsp;because they were liars.  The truth was that Plato knew philosophers&nbsp;couldn''t compete successfully with poets.<br>&nbsp;-- Kilgore Trout (Philip J. Farmer) "Venus on the Half<br>&nbsp;   Shell"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Injustice anywhere is a threat to justice everywhere.<br>&nbsp;-- Martin Luther King, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s kind of fun to do the impossible."<br>&nbsp;-- Walt Disney')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gerrold''s Laws of Infernal Dynamics:<br>(1) An object in motion will always be headed in the wrong<br>    direction.<br>(2) An object at rest will always be in the wrong place.<br>(3) The energy required to change either one of these states<br>    will always be more than you wish to expend, but never so<br>    much as to make the task totally impossible.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any great truth can -- and eventually will -- be expressed as a cliche&nbsp;-- a cliche is a sure and certain way to dilute an idea.  For instance,<br>my grandmother used to say, "The black cat is always the last one off&nbsp;the fence."  I have no idea what she meant, but at one time, it was&nbsp;undoubtedly true.<br>&nbsp;-- Solomon Short')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Corning, Iowa, it''s a misdemeanor for a man to ask his wife to ride&nbsp;in any motor vehicle.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bore, n.:<br>A person who talks when you wish him to listen.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One difference between a man and a machine is that a machine is quiet&nbsp;when well oiled.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Coincidences are spiritual puns.<br>&nbsp;-- G. K. Chesterton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"But don''t you worry, its for a cause -- feeding global corporations&nbsp;paws."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pig, n.:<br>An animal (Porcus omnivorous) closely allied to the human race&nbsp;by the splendor and vivacity of its appetite, which, however, is&nbsp;inferior in scope, for it balks at pig.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... This striving for excellence extends into people''s personal lives&nbsp;as well.  When ''80s people buy something, they buy the best one, as&nbsp;determined by (1) price and (2) lack of availability.  Eighties people&nbsp;buy imported dental floss.  They buy gourmet baking soda.  If an ''80s&nbsp;couple goes to a restaurant where they have made a reservation three&nbsp;weeks in advance, and they are informed that their table is available,<br>they stalk out immediately, because they know it is not an excellent&nbsp;restaurant.  If it were, it would have an enormous crowd of&nbsp;excellence-oriented people like themselves waiting, their beepers going&nbsp;off like crickets in the night.  An excellent restaurant wouldn''t have&nbsp;a table ready immediately for anybody below the rank of Liza Minnelli.<br>&nbsp;-- Dave Barry, "In Search of Excellence"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Predestination was doomed from the start.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The cry has been that when war is declared, all opposition should&nbsp;therefore be hushed.  A sentiment more unworthy of a free country could&nbsp;hardly be propagated.  If the doctrine be admitted, rulers have only to&nbsp;declare war and they are screened at once from scrutiny ...  In war,<br>then, as in peace, assert the freedom of speech and of the press.<br>Cling to this as the bulwark of all our rights and privileges.<br>&nbsp;-- William Ellery Channing')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Living on Earth may be expensive, but it includes an annual free trip&nbsp;around the Sun.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '//GO.SYSIN DD *, DOODAH, DOODAH')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Liberty is always dangerous, but it is the safest thing we have.<br>&nbsp;-- Harry Emerson Fosdick')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pardo''s First Postulate:<br>Anything good in life is either illegal, immoral, or&nbsp;fattening.<br>&nbsp;Arnold''s Addendum:<br>Everything else causes cancer in rats.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Clairvoyant, n.:<br>A person, commonly a woman, who has the power of seeing that&nbsp;which is invisible to her patron -- namely, that he is a blockhead.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The optimum committee has no members.<br>&nbsp;-- Norman Augustine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A physicist is an atom''s way of knowing about atoms.<br>&nbsp;-- George Wald')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ask five economists and you''ll get five different explanations (six if&nbsp;one went to Harvard).<br>&nbsp;-- Edgar R. Fiedler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The District of Columbia has a law forbidding you to exert pressure on&nbsp;a balloon and thereby cause a whistling sound on the streets.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Millihelen, adj:<br>The amount of beauty required to launch one ship.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hatred, n.:<br>A sentiment appropriate to the occasion of another''s&nbsp;superiority.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Iles''s Law:<br>There is always an easier way to do it.  When looking directly&nbsp;at the easy way, especially for long periods, you will not see it.<br>Neither will Iles.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I haven''t lost my mind; I know exactly where I left it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  Do you know what the death rate around here is?&nbsp;A:  One per person.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #52:<br>&nbsp;Q:  What is your name?&nbsp;A:  Ernestine McDowell.<br>Q:  And what is your marital status?&nbsp;A:  Fair.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'American business long ago gave up on demanding that prospective&nbsp;employees be honest and hardworking.  It has even stopped hoping for&nbsp;employees who are educated enough that they can tell the difference&nbsp;between the men''s room and the women''s room without having little&nbsp;pictures on the doors.<br>&nbsp;-- Dave Barry, "Urine Trouble, Mister"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I went on to test the program in every way I could devise.  I strained&nbsp;it to expose its weaknesses.  I ran it for high-mass stars and low-mass&nbsp;stars, for stars born exceedingly hot and those born relatively cold.<br>I ran it assuming the superfluid currents beneath the crust to be&nbsp;absent -- not because I wanted to know the answer, but because I had&nbsp;developed an intuitive feel for the answer in this particular case.<br>Finally I got a run in which the computer showed the pulsar''s&nbsp;temperature to be less than absolute zero.  I had found an error.  I&nbsp;chased down the error and fixed it.  Now I had improved the program to&nbsp;the point where it would not run at all.<br>&nbsp;-- George Greenstein, "Frozen Star: Of Pulsars, Black<br>&nbsp;   Holes and the Fate of Stars"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'better !pout !cry&nbsp;better watchout&nbsp;lpr why&nbsp;santa claus <north pole >town&nbsp;&nbsp;cat /etc/passwd >list&nbsp;ncheck list &nbsp;ncheck list&nbsp;cat list | grep naughty >nogiftlist&nbsp;cat list | grep nice >giftlist&nbsp;santa claus <north pole > town&nbsp;&nbsp;who | grep sleeping&nbsp;who | grep awake&nbsp;who | egrep ''bad|good''&nbsp;for (goodness sake) {<br>be good&nbsp;}')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Two men came before Nasrudin when he was magistrate.  The first man&nbsp;said, "This man has bitten my ear -- I demand compensation."  The&nbsp;second man said, "He bit it himself."  Nasrudin withdrew to his&nbsp;chambers, and spent an hour trying to bite his own ear.  He succeeded&nbsp;only in falling over and bruising his forehead.  Returning to the&nbsp;courtroom, Nasrudin pronounced, "Examine the man whose ear was bitten.<br>If his forehead is bruised, he did it himself and the case is&nbsp;dismissed.  If his forehead is not bruised, the other man did it and&nbsp;must pay three silver pieces."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Egotist, n.:<br>A person of low taste, more interested in himself than me.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicago Transit Authority Rider''s Rule #36:<br>Never ever ask the tough looking gentleman wearing El Rukn&nbsp;headgear where he got his "pyramid powered pizza warmer".<br>&nbsp;-- Chicago Reader 3/27/81')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Polymer physicists are into chains.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Of all the words of witch''s doom&nbsp;There''s none so bad as which and whom.<br>The man who kills both which and whom&nbsp;Will be enshrined in our Who''s Whom.<br>&nbsp;-- Fletcher Knebel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Plaese porrf raed."<br>&nbsp;-- Prof. Michael O''Longhlin, S.U.N.Y. Purchase')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '$100 invested at 7% interest for 100 years will become $100,000, at&nbsp;which time it will be worth absolutely nothing.<br>&nbsp;-- Lazarus Long, "Time Enough for Love"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Klein bottle for rent -- inquire within.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You are a very redundant person, that''s what kind of person you are.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Before Xerox, five carbons were the maximum extension of anybody''s&nbsp;ego.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"My weight is perfect for my height -- which varies"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All Finagle Laws may be bypassed by learning the simple art of doing&nbsp;without thinking.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rule 46, Oxford Union Society, London:<br>Any member introducing a dog into the Society''s premises shall&nbsp;be liable to a fine of one pound.  Any animal leading a blind person&nbsp;shall be deemed to be a cat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Got Mole problems?&nbsp;Call Avogardo 6.02 x 10^23')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Census Taker to Housewife: Did you ever have the measles, and, if so,<br>how many?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s a small world, but I wouldn''t want to have to paint it."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The best way to make a fire with two sticks is to make sure one of them&nbsp;is a match.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;On his first day as a bus driver, Maxey Eckstein handed in&nbsp;receipts of $65.  The next day his take was $67.  The third day''s&nbsp;income was $62.  But on the fourth day, Eckstein emptied no less than&nbsp;$283 on the desk before the cashier.<br>"Eckstein!" exclaimed the cashier.  "This is fantastic.  That&nbsp;route never brought in money like this!  What happened?"<br>"Well, after three days on that cockamamie route, I figured&nbsp;business would never improve, so I drove over to Fourteenth Street and&nbsp;worked there.  I tell you, that street is a gold mine!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man 1:&nbsp;Ask me the what the most important thing about telling a good<br>joke is.<br>&nbsp;Man 2:&nbsp;OK, what is the most impo --&nbsp;&nbsp;Man 1:&nbsp;______^H^H^H^H^H^HTIMING!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"On two occasions I have been asked [by members of Parliament!], `Pray,<br>Mr.  Babbage, if you put into the machine wrong figures, will the right&nbsp;answers come out?''  I am not able rightly to apprehend the kind of&nbsp;confusion of ideas that could provoke such a question."<br>&nbsp;-- Charles Babbage')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Top scientists agree that with the present rate of consumption, the&nbsp;earth''s supply of gravity will be exhausted before the 24th century.<br>As man struggles to discover cheaper alternatives, we need your help.<br>Please...<br><br>&nbsp;&nbsp;CONSERVE GRAVITY&nbsp;&nbsp;Follow these simple suggestions:<br><br>1)  Walk with a light step.  Carry helium balloons if possible.<br>(2)  Use tape, magnets, or glue instead of paperweights.<br>(3)  Give up skiing and skydiving for more horizontal sports like&nbsp;     curling.<br>(4)  Avoid showers .. take baths instead.<br>(5)  Don''t hang all your clothes in the closet ... Keep them in one big&nbsp;     pile.<br>(6)  Stop flipping pancakes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When God endowed human beings with brains, He did not intend to&nbsp;guarantee them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Star Wars is adolescent nonsense; Close Encounters is obscurantist&nbsp;drivel; Star Trek can turn your brains to pur''^Hee of bat guano; and the&nbsp;greatest science fiction series of all time is Doctor Who!  And I''ll&nbsp;take you all on, one-by-one or all in a bunch to back it up!"<br>&nbsp;-- Harlan Ellison')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Monday is an awful way to spend one seventh of your life.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Scientists are people who build the Brooklyn Bridge and then buy it.<br>&nbsp;-- William Buckley&nbsp;')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No animal should ever jump on the dining room furniture unless&nbsp;absolutely certain he can hold his own in conversation.<br>&nbsp;-- Fran Lebowitz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Thompson, if he is to be believed, has sampled the entire&nbsp;rainbow of legal and illegal drugs in heroic efforts to feel better&nbsp;than he does.<br>As for the truth about his health: I have asked around about&nbsp;it.  I am told that he appears to be strong and rosy, and steadily&nbsp;sane.  But we will be doing what he wants us to do, I think, if we&nbsp;consider his exterior a sort of Dorian Gray facade.  Inwardly, he is&nbsp;being eaten alive by tinhorn politicians.<br>The disease is fatal.  There is no known cure.  The most we can&nbsp;do for the poor devil, it seems to me, is to name his disease in his&nbsp;honor.  From this moment on, let all those who feel that Americans can&nbsp;be as easily led to beauty as to ugliness, to truth as to public&nbsp;relations, to joy as to bitterness, be said to be suffering from Hunter&nbsp;Thompson''s disease.  I don''t have it this morning.  It comes and goes.<br>This morning I don''t have Hunter Thompson''s disease.<br>&nbsp;-- Kurt Vonnegut Jr. on Dr. Hunter S. Thompson: Excerpt<br>&nbsp;   from "A Political Disease", Vonnegut''s review of "Fear<br>&nbsp;   and Loathing: On the Campaign Trail ''72"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fuch''s Warning:<br>If you actually look like your passport photo, you aren''t well&nbsp;enough to travel.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The climate of Bombay is such that its inhabitants have to live&nbsp;elsewhere."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The most difficult thing in the world is to know how to do a thing and&nbsp;to watch someone else do it wrong without comment."<br>&nbsp;-- Theodore H. White')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every four seconds a woman has a baby.  Our problem is to find this&nbsp;woman and stop her.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Broad-mindedness, n.:<br>The result of flattening high-mindedness out.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Schwine-Kitzenger Institute study of 47 men over the age of 100&nbsp;showed that all had these things in common:<br><br>(1) They all had moderate appetites.<br>(2) They all came from middle class homes<br>(3) All but two of them were dead.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I must have a prodigious quantity of mind; it takes me as much as a&nbsp;week sometimes to make it up."<br>&nbsp;-- Mark Twain, "The Innocents Abroad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This land is made of mountains,<br>This land is made of mud,<br>This land has lots of everything,<br>For me and Elmer Fudd.<br>&nbsp;This land has lots of trousers,<br>This land has lots of mousers,<br>And pussycats to eat them&nbsp;When the sun goes down.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mandrell: "You know what I think?"&nbsp;Doctor:   "Ah, ah that''s a catch question. With a brain your size you<br>  don''t think, right?"<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Different all twisty a of in maze are you, passages little.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A LISP programmer knows the value of everything, but the cost of&nbsp;nothing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be a better psychiatrist and the world will beat a psychopath to your&nbsp;door.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bug, n.:<br>An aspect of a computer program which exists because the&nbsp;programmer was thinking about Jumbo Jacks or stock options when s/he&nbsp;wrote the program.<br>&nbsp;Fortunately, the second-to-last bug has just been fixed.<br>&nbsp;-- Ray Simard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Once there lived a village of creatures along the bottom of a&nbsp;great crystal river.  Each creature in its own manner clung tightly to&nbsp;the twigs and rocks of the river bottom, for clinging was their way of&nbsp;life, and resisting the current what each had learned from birth.  But&nbsp;one creature said at last, "I trust that the current knows where it is&nbsp;going.  I shall let go, and let it take me where it will.  Clinging, I&nbsp;shall die of boredom."<br>The other creatures laughed and said, "Fool!  Let go, and that&nbsp;current you worship will throw you tumbled and smashed across the&nbsp;rocks, and you will die quicker than boredom!"<br>But the one heeded them not, and taking a breath did let go,<br>and at once was tumbled and smashed by the current across the rocks.<br>Yet, in time, as the creature refused to cling again, the current&nbsp;lifted him free from the bottom, and he was bruised and hurt no more.<br>And the creatures downstream, to whom he was a stranger, cried,<br>"See a miracle!  A creature like ourselves, yet he flies!  See the&nbsp;Messiah, come to save us all!"  And the one carried in the current&nbsp;said, "I am no more Messiah than you.  The river delight to lift us&nbsp;free, if only we dare let go.  Our true work is this voyage, this&nbsp;adventure.<br>But they cried the more, "Saviour!" all the while clinging to&nbsp;the rocks, making legends of a Saviour.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is practically impossible to teach good programming style to&nbsp;students that have had prior exposure to BASIC: as potential&nbsp;programmers they are mentally mutilated beyond hope of&nbsp;regeneration.<br>&nbsp;-- Dijkstra')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Baruch''s Observation:<br>If all you have is a hammer, everything looks like a nail.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I want to spend more time with my&nbsp;blender."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Washington [D.C.] is a city of Southern efficiency and Northern charm.<br>&nbsp;-- John F. Kennedy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;Gimmie That Old Time Religion&nbsp;We will follow Zarathustra,&nbsp;&nbsp;We will worship like the Druids,<br>Zarathustra like we use to,&nbsp;&nbsp;Dancing naked in the woods,<br>I''m a Zarathustra booster,&nbsp;&nbsp;Drinking strange fermented fluids,<br>And he''s good enough for me!&nbsp;&nbsp;And it''s good enough for me!<br>(chorus)&nbsp;&nbsp;&nbsp;&nbsp;(chorus)<br>&nbsp;In the church of Aphrodite,<br>The priestess wears a see-through nightie,<br>She''s a mighty righteous sightie,<br>And she''s good enough for me!<br>(chorus)<br>&nbsp;CHORUS:&nbsp;Give me that old time religion,<br>Give me that old time religion,<br>Give me that old time religion,<br>''Cause it''s good enough for me!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every journalist has a novel in him, which is an excellent place for it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real software engineers work from 9 to 5, because that is the way the&nbsp;job is described in the formal spec.  Working late would feel like&nbsp;using an undocumented external procedure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As far as we know, our computer has never had an undetected error.<br>&nbsp;-- Weisert')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dealing with failure is easy: work hard to improve.  Success is also&nbsp;easy to handle: you''ve solved the wrong problem.  Work hard to&nbsp;improve.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The right to revolt has sources deep in our history.<br>&nbsp;-- Supreme Court Justice William O. Douglas')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Celebrate Hannibal Day this year.  Take an elephant to lunch.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Santa Claus wears a Red Suit,<br>He must be a communist.<br>And a beard and long hair,<br>Must be a pacifist.<br><br>What''s in that pipe that he''s smoking?<br>&nbsp;-- Arlo Guthrie')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old," said the youth, "as I mentioned before,<br>And have grown most uncommonly fat:<br>Yet you turned a back-somersault in at the door --<br>Pray what is the reason of that?"&nbsp;&nbsp;"In my youth," said the sage, as he shook his grey locks,<br>"I kept all my limbs very supple&nbsp;By the use of this ointment -- one shilling the box --<br>Allow me to sell you a couple?"<br>&nbsp;-- Lewis Carrol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Her locks an ancient lady gave&nbsp;Her loving husband''s life to save:<br>And men -- they honored so the dame --&nbsp;Upon some stars bestowed her name.<br>&nbsp;But to our modern married fair,<br>Who''d give their lords to save their hair,<br>No stellar recognition''s given.<br>There are not stars enough in heaven.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is the ____^H^H^H^HLAST time I take travel suggestions from Ray Bradbury!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many Zen masters does it take to screw in a light bulb?&nbsp;A:  None.  The Universe spins the bulb, and the Zen master stays out&nbsp;    of the way.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cocaine -- the thinking man''s Dristan.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Green light in a.m. for new projects.  Red light in P.M. for traffic&nbsp;tickets.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The truth is what is; what should be is a dirty lie.<br>&nbsp;-- Lenny Bruce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Newton''s Fourth Law:  Every action has an equal and opposite satisfaction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A fool''s brain digests philosophy into folly, science into&nbsp;superstition, and art into pedantry.  Hence University education.<br>&nbsp;-- G. B. Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Remember, even if you win the rat race -- you''re still a rat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For a man to truly understand rejection, he must first be ignored by a&nbsp;cat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s a damn poor mind that can only think of one way to spell a word.<br>&nbsp;-- Andrew Jackson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... [concerning quotation marks] even if we *___^H^H^Hdid* quote anybody in this&nbsp;business, it probably would be gibberish.<br>&nbsp;-- Thom McLeod')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #41:<br>&nbsp;Q:  Now, Mrs. Johnson, how was your first marriage terminated?&nbsp;A:  By death.<br>Q:  And by whose death was it terminated?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The government [is] extremely fond of amassing great quantities of&nbsp;statistics.  These are raised to the _^Hnth degree, the cube roots are&nbsp;extracted, and the results are arranged into elaborate and impressive&nbsp;displays.  What must be kept ever in mind, however, is that in every&nbsp;case, the figures are first put down by a village watchman, and he puts&nbsp;down anything he damn well pleases.<br>&nbsp;-- Sir Josiah Stamp')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some people live life in the fast lane.  You''re in oncoming traffic.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dear Mister Language Person: I am curious about the expression, "Part&nbsp;of this complete breakfast".  The way it comes up is, my 5-year-old&nbsp;will be watching TV cartoon shows in the morning, and they''ll show a&nbsp;commercial for a children''s compressed breakfast compound such as&nbsp;"Froot Loops" or "Lucky Charms", and they always show it sitting on a&nbsp;table next to some actual food such as eggs, and the announcer always&nbsp;says: "Part of this complete breakfast".  Don''t that really mean,<br>"Adjacent to this complete breakfast", or "On the same table as this&nbsp;complete breakfast"?  And couldn''t they make essentially the same claim&nbsp;if, instead of Froot Loops, they put a can of shaving cream there, or a&nbsp;dead bat?&nbsp;&nbsp;Answer: Yes.<br>&nbsp;-- Dave Barry, "Tips for Writer''s"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A dozen, a gross, and a score,<br>Plus three times the square root of four,<br>Divided by seven,<br>Plus five times eleven,<br>Equals nine squared plus zero, no more.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The human race has been fascinated by sharks for as long as I can&nbsp;remember.  Just like the bluebird feeding its young, or the spider&nbsp;struggling to weave its perfect web, or the buttercup blooming in&nbsp;spring, the shark reveals to us yet another of the infinite and&nbsp;wonderful facets of nature, namely the facet that it can bite your head&nbsp;off.  This causes us humans to feel a certain degree of awe.<br>&nbsp;-- Dave Barry, "The Wonders of Sharks on TV"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Begathon, n.:<br>A multi-day event on public television, used to raise money so&nbsp;you won''t have to watch commercials.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s is not, it isn''t ain''t, and it''s it''s, not its, if you mean it&nbsp;is.  If you don''t, it''s its.  Then too, it''s hers.  It isn''t her''s.  It&nbsp;isn''t our''s either.  It''s ours, and likewise yours and theirs.<br>&nbsp;-- Oxford University Press, Edpress News')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '''I generally avoid temptation unless I can''t resist it."<br>&nbsp;-- Mae West')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"What do you give a man who has everything?" the pretty&nbsp;teenager asked her mother.<br>"Encouragement, dear," she replied.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicago, n.:<br>Where the dead still vote ... early and often!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ask not for whom the telephone bell tolls ... if thou art in the&nbsp;bathtub, it tolls for thee.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'From too much love of living,<br>From hope and fear set free,<br>We thank with brief thanksgiving,<br>Whatever gods may be,<br>That no life lives forever,<br>That dead men rise up never,<br>That even the weariest river winds somewhere safe to sea.<br>&nbsp;-- Swinburne')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Adore, v.:<br>To venerate expectantly.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chivalry, Schmivalry!<br>Roger the thief has a<br>method he uses for<br>sneaky attacks:<br>Folks who are reading are<br>Characteristically<br>Always Forgetting to<br>Guard their own bac ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love cannot be much younger than the lust for murder.<br>&nbsp;-- Sigmund Freud')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is the story of the bee&nbsp;Whose sex is very hard to see&nbsp;&nbsp;You cannot tell the he from the she&nbsp;But she can tell, and so can he&nbsp;&nbsp;The little bee is never still&nbsp;She has no time to take the pill&nbsp;&nbsp;And that is why, in times like these&nbsp;There are so many sons of bees.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We must remember the First Amendment which protects any shrill jackass&nbsp;no matter how self-seeking.<br>&nbsp;-- F. G. Withington')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One reason why George Washington&nbsp;Is held in such veneration:<br>He never blamed his problems&nbsp;On the former Administration.<br>&nbsp;-- George O. Ludcke')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"Seven years and six months!"  Humpty Dumpty repeated&nbsp;thoughtfully.  "An uncomfortable sort of age.  Now if you''d asked MY&nbsp;advice, I''d have said `Leave off at seven'' -- but it''s too late now."<br>"I never ask advice about growing,"  Alice said indignantly.<br>"Too proud?" the other enquired.<br>Alice felt even more indignant at this suggestion.  "I mean,"&nbsp;she said, "that one can''t help growing older."<br>"ONE can''t, perhaps," said Humpty Dumpty; "but TWO can.  With&nbsp;proper assistance, you might have left off at seven."<br>&nbsp;-- Lewis Carroll')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Age, n.:<br>That period of life in which we compound for the vices that we&nbsp;still cherish by reviling those that we no longer have the enterprise&nbsp;to commit.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He''s just a politician trying to save both his faces ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pereant, inquit, qui ante nos nostra dixerunt.<br>"Confound those who have said our remarks before us."<br>&nbsp;-- Aelius Donatus')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The difference between a misfortune and a calamity?  If Gladstone fell&nbsp;into the Thames, it would be a misfortune.  But if someone dragged him&nbsp;out again, it would be a calamity."<br>&nbsp;-- Benjamin Disraeli')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'She is not refined.  She is not unrefined.  She keeps a parrot.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I went to a job interview the other day, the guy asked me if I had any&nbsp;questions , I said yes, just one, if you''re in a car traveling at the&nbsp;speed of light and you turn your headlights on, does anything happen?&nbsp;&nbsp;He said he couldn''t answer that, I told him sorry, but I couldn''t work&nbsp;for him then.<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One day the King decided that he would force all his subjects to tell&nbsp;the truth.  A gallows was erected in front of the city gates.  A herald&nbsp;announced, "Whoever would enter the city must first answer the truth to&nbsp;a question which will be put to him."  Nasrudin was first in line.  The&nbsp;captain of the guard asked him, "Where are you going?  Tell the truth&nbsp;-- the alternative is death by hanging."  "I am going," said Nasrudin,<br>"to be hanged on that gallows."  "I don''t believe you."  "Very well, if&nbsp;I have told a lie, then hang me!" "But that would make it the truth!"&nbsp;"Exactly," said Nasrudin, "your truth."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp; A Plan for the Improvement of English Spelling<br>&nbsp;&nbsp;  by Mark Twain&nbsp;<br>For example, in Year 1 that useless letter "c" would be dropped&nbsp;to be replased either by "k" or "s", and likewise "x" would no longer&nbsp;be part of the alphabet.  The only kase in which "c" would be retained&nbsp;would be the "ch" formation, which will be dealt with later.  Year 2&nbsp;might reform "w" spelling, so that "which" and "one" would take the&nbsp;same konsonant, wile Year 3 might well abolish "y" replasing it with&nbsp;"i" and Iear 4 might fiks the "g/j" anomali wonse and for all.<br>Jenerally, then, the improvement would kontinue iear bai iear&nbsp;with Iear 5 doing awai with useless double konsonants, and Iears 6-12&nbsp;or so modifaiing vowlz and the rimeining voist and unvoist konsonants.<br>Bai Iear 15 or sou, it wud fainali bi posibl tu meik ius ov thi&nbsp;ridandant letez "c", "y" and "x" -- bai now jast a memori in the maindz&nbsp;ov ould doderez -- tu riplais "ch", "sh", and "th" rispektivli.<br>Fainali, xen, aafte sam 20 iers ov orxogrefkl riform, wi wud&nbsp;hev a lojikl, kohirnt speling in ius xrewawt xe Ingliy-spiking werld.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Aphorism, n.:<br>A concise, clever statement.<br>Afterism, n.:<br>A concise, clever statement you don''t think of until too late.<br>&nbsp;-- James Alexander Thom')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE WOMBAT&nbsp;&nbsp;The wombat lives across the seas,<br>Among the far Antipodes.<br>He may exist on nuts and berries,<br>Or then again, on missionaries:<br>His distant habitat precludes&nbsp;Conclusive knowledge of his moods.<br>But I would not engage the wombat&nbsp;In any form of mortal combat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'First Corollary of Taber''s Second Law:<br>Machines that piss people off get murdered.<br>&nbsp;-- Pat Taber')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Deck Us All With Boston Charlie&nbsp;&nbsp;Deck us all with Boston Charlie,<br>Walla Walla, Wash., an'' Kalamazoo!&nbsp;Nora''s freezin'' on the trolley,<br>Swaller dollar cauliflower, alleygaroo!&nbsp;&nbsp;Don''t we know archaic barrel,<br>Lullaby Lilla Boy, Louisville Lou.<br>Trolley Molly don''t love Harold,<br>Boola boola Pensacoola hullabaloo!<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Grandpa Charnock''s Law:<br>You never really learn to swear until you learn to drive.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sorry.  I forget what I was going to say.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Madam, there''s no such thing as a tough child -- if you parboil them&nbsp;first for seven hours, they always come out tender.<br>&nbsp;-- W. C. Fields')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Right now I''m having amnesia and deja vu at the same time."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I like your game but we have to change the rules."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Men''s skin is different from women''s skin.  It is usually bigger, and&nbsp;it has more snakes tattooed on it.  Also, if you examine a woman''s skin&nbsp;very closely, inch by inch, starting at her shapely ankles, then gently&nbsp;tracing the slender curve of her calves, then moving up to her ...<br>[EDITOR''S NOTE: To make room for news articles about important<br> world events such as agriculture, we''re going to delete the<br> next few square feet of the woman''s skin.  Thank you.]&nbsp;... until finally the two of you are lying there, spent, smoking your&nbsp;cigarettes, and suddenly it hits you: Human skin is actually made up of&nbsp;billions of tiny units of protoplasm, called "cells"!  And what is even&nbsp;more interesting, the ones on the outside are all dying!  This is a&nbsp;fact.  Your skin is like an aggressive modern corporation, where the&nbsp;older veteran cells, who have finally worked their way to the top and&nbsp;obtained offices with nice views, are constantly being shoved out the&nbsp;window head first, without so much as a pension plan, by younger&nbsp;hotshot cells moving up from below.<br>&nbsp;-- Dave Barry, "Saving Face"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'May a Misguided Platypus lay its Eggs in your Jockey Shorts')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Computers are not intelligent.  They only think they are.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Today is National Existential Ennui Awareness Day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'HOW YOU CAN TELL THAT IT''S GOING TO BE A ROTTEN DAY:<br><br>#32: You call your answering service and they''ve never heard of<br>     you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A novice was trying to fix a broken Lisp machine by turning the power&nbsp;off and on.  Knight, seeing what the student was doing spoke sternly:<br>"You can not fix a machine by just power-cycling it with no&nbsp;understanding of what is going wrong."  Knight turned the machine off&nbsp;and on.  The machine worked.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ignisecond, n.:<br>The overlapping moment of time when the hand is locking the car&nbsp;door even as the brain is saying, "my keys are in there!"<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Too often I find that the volume of paper expands to fill the available&nbsp;briefcases.<br>&nbsp;-- Governor Jerry Brown')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There once was an old man from Esser,<br>Who''s knowledge grew lesser and lesser.<br>It at last grew so small,<br>He knew nothing at all,<br>And now he''s a College Professor.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cloning is the sincerest form of flattery.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Three Laws of Thermodynamics:<br>&nbsp;The First Law:&nbsp;You can''t get anything without working for it.<br>The Second Law:&nbsp;The most you can accomplish by working is to break<br>&nbsp;even.<br>The Third Law:&nbsp;You can only break even at absolute zero.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Here in my heart, I am Helen;<br>I''m Aspasia and Hero, at least.<br>I''m Judith, and Jael, and Madame de Sta"^Hel;<br>I''m Salome, moon of the East.<br>&nbsp;Here in my soul I am Sappho;<br>Lady Hamilton am I, as well.<br>In me R''^Hecamier vies with Kitty O''Shea,<br>With Dido, and Eve, and poor nell.<br>&nbsp;I''m all of the glamorous ladies<br>At whose beckoning history shook.<br>But you are a man, and see only my pan,<br>So I stay at home with a book.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Man invented language to satisfy his deep need to complain."<br>&nbsp;-- Lily Tomlin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Why be a man when you can be a success?"<br>&nbsp;-- Bertold Brecht')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Love''s Drug&nbsp;&nbsp;My love is like an iron wand <br>That conks me on the head,<br>My love is like the valium <br>That I take before my bed,<br>My love is like the pint of scotch <br>That I drink when I be dry:<br>And I shall love thee still, my dear,<br>Until my wife is wise.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I was born because it was a habit in those days, people didn''t know&nbsp;anything else ... I was not a Child Prodigy, because a Child Prodigy is&nbsp;a child who knows as much when it is a child as it does when it grows&nbsp;up.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I love to eat them Smurfies&nbsp; Smurfies what I love to eat&nbsp; Bite they ugly heads off,<br> Nibble on they bluish feet."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Houston, Tranquillity Base here.  The Eagle has landed."<br>&nbsp;-- Neil Armstrong')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There was a plane crash over mid-ocean, and only three survivors were&nbsp;left in the life-raft: the Pope, the President, and Mayor Daley.<br>Unfortunately, it was a one-man life-raft, and quickly sinking, so they&nbsp;started debating who should be allowed to stay.<br>&nbsp;The Pope pointed out that he was the spiritual leader of millions all&nbsp;over the world, the President explained that if he died then America&nbsp;would be stuck with the Vice-President, and so forth.  Then Mayor Daley&nbsp;said, "Look!  We''re not solving anything like this!  The only fair&nbsp;thing to do is to vote on it."  So they did, and Mayor Daley won by 97&nbsp;votes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man is the only animal that can remain on friendly terms with the&nbsp;victims he intends to eat until he eats them.<br>&nbsp;-- Samuel Butler (1835-1902)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ingrate, n.:<br>A man who bites the hand that feeds him, and then complains of&nbsp;indigestion.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Canonical, adj.:<br>The usual or standard state or manner of something.  A true&nbsp;story:  One Bob Sjoberg, new at the MIT AI Lab, expressed some&nbsp;annoyance at the use of jargon.  Over his loud objections, we made a&nbsp;point of using jargon as much as possible in his presence, and&nbsp;eventually it began to sink in.  Finally, in one conversation, he used&nbsp;the word "canonical" in jargon-like fashion without thinking.<br>Steele: "Aha!  We''ve finally got you talking jargon too!"<br>Stallman: "What did he say?"<br>Steele: "He just used `canonical'' in the canonical way."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What sane person could live in this world and not be crazy?<br>&nbsp;-- Ursula K. LeGuin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The sum of the Universe is zero.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If an S and an I and an O and a U&nbsp;With an X at the end spell Su:<br>And an E and a Y and an E spell I,<br>Pray what is a speller to do?&nbsp;Then, if also an S and an I and a G&nbsp;And an HED spell side,<br>There''s nothing much left for a speller to do&nbsp;But to go commit siouxeyesighed.<br>&nbsp;-- Charles Follen Adams, "An Orthographic Lament"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sooner or later you must pay for your sins.  (Those who have already&nbsp;paid may disregard this fortune).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you throw a New Year''s Party, the worst thing that you can do would&nbsp;be to throw the kind of party where your guests wake up today, and call&nbsp;you to say they had a nice time.  Now you''ll be be expected to throw&nbsp;another party next year.<br>&nbsp;What you should do is throw the kind of party where your guest wake up&nbsp;several days from now and call their lawyers to find out if they''ve&nbsp;been indicted for anything.  You want your guests to be so anxious to&nbsp;avoid a recurrence of your party that they immediately start planning&nbsp;parties of their own, a year in advance, just to prevent you from&nbsp;having another one ...<br>&nbsp;If your party is successful, the police will knock on your door, unless&nbsp;your party is very successful in which case they will lob tear gas&nbsp;through your living room window.  As host, your job is to make sure&nbsp;that they don''t arrest anybody.  Or if they''re dead set on arresting&nbsp;someone, your job is to make sure it isn''t you ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Too much of a good thing is WONDERFUL.<br>&nbsp;-- Mae West')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Consultants are mystical people who ask a company for a number and then&nbsp;give it back to them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... Our second completely true news item was sent to me by Mr. H. Boyce&nbsp;Connell Jr. of Atlanta, Ga., where he is involved in a law firm.  One&nbsp;thing I like about the South is, folks there care about tradition.  If&nbsp;somebody gets handed a name like "H. Boyce," he hangs on to it, puts it&nbsp;on his legal stationery, even passes it to his son, rather than do what&nbsp;a lesser person would do, such as get it changed or kill himself.<br>&nbsp;-- Dave Barry, "This Column is Nothing but the Truth!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The price of seeking to force our beliefs on others is that someday&nbsp;they might force their beliefs on us.<br>&nbsp;-- Mario Cuomo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Support wildlife -- vote for an orgy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t object to sex before marriage, but two minutes before?!?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"OK, now let''s look at four dimensions on the blackboard."<br>&nbsp;-- Dr. Joy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How come wrong numbers are never busy?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is a government where you can say what you think even if you&nbsp;don''t think.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An excellence-oriented ''80s male does not wear a regular watch.  He&nbsp;wears a Rolex watch, because it weighs nearly six pounds and is&nbsp;advertised only in excellence-oriented publications such as Fortune and&nbsp;Rich Protestant Golfer Magazine.  The advertisements are written in&nbsp;incomplete sentences, which is how advertising copywriters denote&nbsp;excellence:<br>&nbsp;"The Rolex Hyperion.  An elegant new standard in quality excellence and&nbsp;discriminating handcraftsmanship.  For the individual who is truly able&nbsp;to discriminate with regard to excellent quality standards of crafting&nbsp;things by hand.  Fabricated of 100 percent 24-karat gold.  No watch&nbsp;parts or anything.  Just a great big chunk on your wrist.  Truly a&nbsp;timeless statement.  For the individual who is very secure.  Who&nbsp;doesn''t need to be reminded all the time that he is very successful.<br>Much more successful than the people who laughed at him in high&nbsp;school.  Because of his acne.  People who are probably nowhere near as&nbsp;successful as he is now.  Maybe he''ll go to his 20th reunion, and&nbsp;they''ll see his Rolex Hyperion.  Hahahahahahahahaha."<br>&nbsp;-- Dave Barry, "In Search of Excellence"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Philogyny recapitulates erogeny; erogeny recapitulates philogyny.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The trouble with doing something right the first time is that nobody&nbsp;appreciates how difficult it was.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s just a jump to the left<br>And then a step to the right.<br>Put your hands on your hips<br>And pull your knees in tight.<br>It''s the pelvic thrust<br>That really gets you insa-a-a-a-ane&nbsp;<br>LET''S DO THE TIME WARP AGAIN!&nbsp;<br>&nbsp;-- Rocky Horror Picture Show')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conscience is what hurts when everything else feels so good.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;To A Quick Young Fox:<br>Why jog exquisite bulk, fond crazy vamp,<br>Daft buxom jonquil, zephyr''s gawky vice?&nbsp;Guy fed by work, quiz Jove''s xanthic lamp --&nbsp;Zow!  Qualms by deja vu gyp fox-kin thrice.<br>&nbsp;-- Lazy Dog')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'ADA, n.:<br>Something you need only know the name of to be an Expert in&nbsp;Computing.  Useful in sentences like, "We had better develop an ADA&nbsp;awareness."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Proof techniques #2: Proof by Oddity.<br>SAMPLE: To prove that horses have an infinite number of legs.<br>(1) Horses have an even number of legs.<br>(2) They have two legs in back and fore legs in front.<br>(3) This makes a total of six legs, which certainly is an odd number of&nbsp;    legs for a horse.<br>(4) But the only number that is both odd and even is infinity. <br>5) Therefore, horses must have an infinite number of legs.<br>&nbsp;Topics is be covered in future issues include proof by:<br>Intimidation<br>Gesticulation (handwaving)<br>"Try it; it works"<br>Constipation (I was just sitting there and ...)<br>Blatant assertion<br>Changing all the 2''s to _^Hn''s<br>Mutual consent<br>Lack of a counterexample, and<br>"It stands to reason"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are no data that cannot be plotted on a straight line if the axis&nbsp;are chosen correctly.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Give me enough medals, and I''ll win any war."<br>&nbsp;-- Napolean')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Idaho state law makes it illegal for a man to give his sweetheart a box&nbsp;of candy weighing less than fifty pounds.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Speed is subsittute fo accurancy."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paul''s Law:<br>In America, it''s not how much an item costs, it''s how much you&nbsp;save.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We gave you an atomic bomb, what do you want, mermaids?<br>&nbsp;-- I. I. Rabi to the Atomic Energy Commission')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hummingbirds never remember the words to songs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Lowes Crossroads, Delaware, it is a violation of local law for any&nbsp;pilot or passenger to carry an ice cream cone in their pocket while&nbsp;either flying or waiting to board a plane.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"How many hors d''oeuvres you are allowed to take off a tray being&nbsp;carried by a waiter at a nice party?"&nbsp;&nbsp;Two, but there are ways around it, depending on the style of the hors&nbsp;d''oeuvre.  If they''re those little pastry things where you can''t tell&nbsp;what''s inside, you take one, bite off about two-thirds of it, then&nbsp;say:  "This is cheese!  I hate cheese!"  Then you put the rest of it&nbsp;back on the tray and bite another one and go, "Darn it!  Another&nbsp;cheese!" and so on.<br>&nbsp;-- Dave Barry, "The Stuff of Etiquette"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All science is either physics or stamp collecting.<br>&nbsp;-- E. Rutherford')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Then a man said: Speak to us of Expectations.<br>&nbsp;He then said: If a man does not see or hear the waters of the Jordan,<br>then he should not taste the pomegranate or ply his wares in an open&nbsp;market.<br>&nbsp;If a man would not labour in the salt and rock quarries then he should&nbsp;not accept of the Earth that which he refuses to give of himself.<br>&nbsp;Such a man would expect a pear of a peach tree.<br>Such a man would expect a stone to lay an egg.<br>Such a man would expect Sears to assemble a lawnmower.<br>&nbsp;-- Kehlog Albran, "The Profit"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lost interest?  It''s so bad I''ve lost apathy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whatever became of Strange de Jim?  Well, he found a substitute for&nbsp;cocaine: "You cover Q-tips with sandpaper and ram them up your nostrils&nbsp;as far as they will go.  Then you sniff talcum powder while shredding&nbsp;hundred dollar bills."<br>&nbsp;-- Herb Caen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God did not create the world in seven days; he screwed around for six&nbsp;days and then pulled an all-nighter.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The day after tomorrow is the third day of the rest of your life.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A continuing flow of paper is sufficient to continue the flow of paper.<br>&nbsp;-- Dyer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Although we modern persons tend to take our electric lights, radios,<br>mixers, etc., for granted, hundreds of years ago people did not have&nbsp;any of these things, which is just as well because there was no place&nbsp;to plug them in.  Then along came the first Electrical Pioneer,<br>Benjamin Franklin, who flew a kite in a lighting storm and received a&nbsp;serious electrical shock.  This proved that lighting was powered by the&nbsp;same force as carpets, but it also damaged Franklin''s brain so severely&nbsp;that he started speaking only in incomprehensible maxims, such as "A&nbsp;penny saved is a penny earned."  Eventually he had to be given a job&nbsp;running the post office.<br>&nbsp;-- Dave Barry, "What is Electricity?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The subspace _^HW inherits the other 8 properties of _^HV. And there aren''t&nbsp;even any property taxes."<br>&nbsp;-- J. MacKay, Mathematics 134b')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Using TSO is like kicking a dead whale down the beach.<br>&nbsp;-- S. C. Johnson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Try to be the best of whatever you are, even if what you are is no&nbsp;good.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'f u cn rd ths, u cn gt a gd jb n cmptr prgrmmng.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Justice is incidental to law and order.<br>&nbsp;-- J. Edgar Hoover')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '101 USES FOR A DEAD MICROPROCESSOR<br>(1)  Scarecrow for centipedes<br>(2)  Dead cat brush<br>(3)  Hair barrettes<br>(4)  Cleats<br>(5)  Self-piercing earrings<br>(6)  Fungus trellis<br>(7)  False eyelashes<br>(8)  Prosthetic dog claws&nbsp;        .<br>        .<br>        .<br>(99)  Window garden harrow (pulled behind Tonka tractors)<br>(100) Killer velcro<br>(101) Currency')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I never fail to convince an audience that the best thing they could do&nbsp;was to go away."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When a place gets crowded enough to require ID''s, social collapse is&nbsp;not far away.  It is time to go elsewhere.  The best thing about space&nbsp;travel is that it made it possible to go elsewhere.<br>&nbsp;-- Robert Heinlein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Calling J-Man Kink.  Calling J-Man Kink.  Hash missile sighted, target&nbsp;Los Angeles.  Disregard personal feelings about city and intercept."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'And on the seventh day, He exited from append mode.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"One basic notion underlying Usenet is that it is a cooperative."&nbsp;&nbsp;Having been on USENET for going on ten years, I disagree with this.<br>The basic notion underlying USENET is the flame.<br>&nbsp;-- Chuq Von Rospach')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What use is magic if it can''t save a unicorn?<br>&nbsp;-- Peter S. Beagle, "The Last Unicorn"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I predict that today will be remembered until tomorrow!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"In any world menu, Canada must be considered the vichyssoise of&nbsp;nations -- it''s cold, half-French, and difficult to stir."<br>&nbsp;-- Stuart Keate')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this country needs is a good five dollar plasma weapon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The very ink with which all history is written is merely fluid&nbsp;prejudice.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The sooner you fall behind, the more time you''ll have to catch up!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '''I believe in getting into hot water; it keeps you clean."<br>&nbsp;-- G. K. Chesterton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '[From an announcement of a congress of the International Ontopsychology&nbsp;Association, in Rome]:<br>&nbsp;The Ontopsychological school, availing itself of new research criteria&nbsp;and of a new telematic epistemology, maintains that social modes do not&nbsp;spring from dialectics of territory or of class, or of consumer goods,<br>or of means of power, but rather from dynamic latencies capillarized in&nbsp;millions of individuals in system functions which, once they have&nbsp;reached the event maturation, burst forth in catastrophic phenomenology&nbsp;engaging a suitable stereotype protagonist or duty marionette (general,<br>president, political party, etc.) to consummate the act of social&nbsp;schizophrenia in mass genocide.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love and scandal are the best sweeteners of tea.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ehrman''s Commentary:<br>(1) Things will get worse before they get better.<br>(2) Who said things would get better?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A consultant is a person who borrows your watch, tells you what time it&nbsp;is, pockets the watch, and sends you a bill for it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Despising machines to a man,<br>The Luddites joined up with the Klan,<br>And ride out by night<br>In a sheeting of white&nbsp;To lynch all the robots they can.<br>&nbsp;-- C. M. and G. A. Maxson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is only one thing in the world worse than being talked about, and&nbsp;that is not being talked about.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ducharme''s Axiom:<br>If you view your problem closely enough you will recognize&nbsp;yourself as part of the problem.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There can be no twisted thought without a twisted molecule.<br>&nbsp;-- R. W. Gerard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What makes the universe so hard to comprehend is that there''s nothing&nbsp;to compare it with.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The end of the world will occur at 3:00 p.m., this Friday, with&nbsp;symposium to follow.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cauliflower is nothing but Cabbage with a College Education.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the land of the dark, the Ship of the Sun is driven by the Grateful&nbsp;Dead.<br>&nbsp;-- Egyptian Book of the Dead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love means having to say you''re sorry every five minutes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Give me a Plumber''s friend the size of the Pittsburgh dome, and a place&nbsp;to stand, and I will drain the world.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When the speaker and he to whom he is speaks do not understand, that is&nbsp;metaphysics.<br>&nbsp;-- Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Heisenberg may have slept here"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"As part of the conversion, computer specialists rewrote 1,500&nbsp;programs; a process that traditionally requires some debugging."<br>&nbsp;-- USA Today, referring to the IRS switchover to a new<br>&nbsp;   computer system.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What you don''t know can hurt you, only you won''t know it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tact, n.:<br>The unsaid part of what you''re thinking.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reporter, n.:<br>A writer who guesses his way to the truth and dispels it with a&nbsp;tempest of words.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No good deed goes unpunished.<br>&nbsp;-- Clare Boothe Luce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Important letters which contain no errors will develop errors in the&nbsp;mail.  Corresponding errors will show up in the duplicate while the&nbsp;Boss is reading it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you had any brains, you''d be dangerous.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A baby is an alimentary canal with a loud voice at one end and no&nbsp;responsibility at the other.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Living in LA is like not having a date on Saturday night.<br>&nbsp;-- Candice Bergen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hollywood is where if you don''t have happiness you send out for it.<br>&nbsp;-- Rex Reed')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One of the lessons of history is that nothing is often a good thing to&nbsp;do and always a clever thing to say.<br>&nbsp;-- Will Durant')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A door is what a dog is perpetually on the wrong side of.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but the man on television told me to say&nbsp;tuned."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #10: SIMPLE&nbsp;&nbsp;SIMPLE is an acronym for Sheer Idiot''s Monopurpose Programming Language&nbsp;Environment.  This language, developed at the Hanover College for&nbsp;Technological Misfits, was designed to make it impossible to write code&nbsp;with errors in it.  The statements are, therefore, confined to BEGIN,<br>END and STOP.  No matter how you arrange the statements, you can''t make&nbsp;a syntax error.  Programs written in SIMPLE do nothing useful.  Thus&nbsp;they achieve the results of programs written in other languages without&nbsp;the tedious, frustrating process of testing and debugging.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is also a form of worship.  It is the worship of Jackals by&nbsp;Jackasses.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are no physicists in the hottest parts of hell, because the&nbsp;existence of a "hottest part" implies a temperature difference, and any&nbsp;marginally competent physicist would immediately use this to run a heat&nbsp;engine and make some other part of hell comfortably cool.  This is&nbsp;obviously impossible.<br>&nbsp;&nbsp;&nbsp;-- Richard Davisson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Microwave oven?  Whaddya mean, it''s a microwave oven?  I''ve been&nbsp;watching Channel 4 on the thing for two weeks."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"But I don''t like Spam!!!!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I have great faith in fools -- self confidence my friends call it.<br>&nbsp;-- Edgar Allan Poe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Beware of the man who works hard to learn something, learns it, and&nbsp;finds himself no wiser than before," Bokonon tells us.  "He is full of&nbsp;murderous resentment of people who are ignorant without having come by&nbsp;their ignorance the hard way."<br>&nbsp;-- Kurt Vonnegut, "Cat''s Cradle"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s only one way to have a happy marriage and as soon as I learn&nbsp;what it is I''ll get married again.<br>&nbsp;-- Clint Eastwood')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Information Center, n.:<br>A room staffed by professional computer people whose job it is&nbsp;to tell you why you cannot have the information you require.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'LIBRA (Sep. 23 to Oct. 22)<br>Your desire for justice and truth will be overshadowed by your<br>desire for filthy lucre and a decent meal.  Be gracious and<br>polite.  Someone is watching you, so stop staring like that.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can''t make a program without broken egos."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have just read your lousy review buried in the back pages.  You&nbsp;sound like a frustrated old man who never made a success, an&nbsp;eight-ulcer man on a four-ulcer job, and all four ulcers working.  I&nbsp;have never met you, but if I do you''ll need a new nose and plenty of&nbsp;beefsteak and perhaps a supporter below.  Westbrook Pegler, a&nbsp;guttersnipe, is a gentleman compared to you.  You can take that as more&nbsp;of an insult than as a reflection on your ancestry."<br>&nbsp;-- President Harry S Truman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Here at the Phone Company, we serve all kinds of people; from&nbsp;Presidents and Kings to the scum of the earth ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Meader''s Law:<br>Whatever happens to you, it will previously have happened to&nbsp;everyone you know, only more so.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hark, Hark, the dogs do bark&nbsp;The Duke is fond of kittens&nbsp;He likes to take their insides out&nbsp;And use them for his mittens<br>From "The Thirteen Clocks"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The older I grow, the less important the comma becomes.  Let the reader&nbsp;catch his own breath.<br>&nbsp;-- Elizabeth Clarkson Zwart')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you have to hate, hate gently"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anybody can win, unless there happens to be a second entry.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Es brilig war.  Die schlichte Toven<br>Wirrten und wimmelten in Waben:<br>Und aller-m"^Humsige Burggoven<br>Dir mohmen R"^Hath ausgraben.<br>&nbsp;-- Lewis Carrol, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The man who follows the crowd will usually get no further than the&nbsp;crowd.  The man who walks alone is likely to find himself in places no&nbsp;one has ever been.<br>&nbsp;-- Alan Ashley-Pitt')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will think of something funnier than this to add to the fortunes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If all the world''s a stage, I want to operate the trap door.<br>&nbsp;-- Paul Beatty')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I bet the human brain is a kludge."<br>&nbsp;-- Marvin Minsky')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Political T.V. commercials prove one thing: some candidates can tell&nbsp;all their good points and qualifications in just 30 seconds.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The gods gave man fire and he invented fire engines.  They gave him&nbsp;love and he invented marriage.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It wasn''t that she had a rose in her teeth, exactly.  It was more like&nbsp;the rose and the teeth were in the same glass.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... and furthermore ... I don''t like your trousers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reality is for people who lack imagination.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Millions of sensible people are too high-minded to concede that&nbsp;politics is almost always the choice of the lesser evil.  "Tweedledum&nbsp;and Tweedledee," they say, "I will not vote."  Having abstained, they&nbsp;are presented with a President who appoints the people who are going to&nbsp;rummage around in their lives for the next four years.  Consider all&nbsp;the people who sat home in a stew in 1968 rather than vote for Hubert&nbsp;Humphrey.  They showed Humphrey.  Those people who taught Hubert&nbsp;Humphrey a lesson will still be enjoying the Nixon Supreme Court when&nbsp;Tricia and Julie begin to find silver threads among the gold and the&nbsp;black.<br>&nbsp;-- Russel Baker, "Ford without Flummery"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Saw a sign on a restaurant that said Breakfast, any time -- so I&nbsp;ordered French Toast in the Renaissance.<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How wonderful opera would be if there were no singers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Try to find the real tense of the report you are reading:  Was it done,<br>is it being done, or is something to be done?  Reports are now written&nbsp;in four tenses:  past tense, present tense, future tense, and&nbsp;pretense.  Watch for novel uses of CONGRAM (CONtractor GRAMmer),<br>defined by the imperfect past, the insufficient present, and the&nbsp;absolutely perfect future.<br>&nbsp;-- Amrom Katz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... at least I thought I was dancing, ''til somebody stepped on my hand.<br>&nbsp;-- J. B. White')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Harris''s Lament:<br>All the good ones are taken.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The one good thing about repeating your mistakes is that you know when&nbsp;to cringe.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Associate with well-mannered persons and your manners will improve.<br>Run with decent folk and your own decent instincts will be&nbsp;strengthened.  Keep the company of bums and you will become a bum.<br>Hang around with rich people and you will end by picking up the check&nbsp;and dying broke.<br>&nbsp;-- Stanley Walker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A child of five could understand this!  Fetch me a child of five.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Home centers are designed for the do-it-yourselfer who''s&nbsp;willing to pay higher prices for the convenience of being able to shop&nbsp;for lumber, hardware, and toasters all in one location.  Notice I say&nbsp;"shop for", as opposed to "obtain".  This is the major drawback of home&nbsp;centers: they are always out of everything except artificial Christmas&nbsp;trees.  The home center employees have no time to reorder merchandise&nbsp;because they are too busy applying little price stickers to every&nbsp;object -- every board, washer, nail and screw -- in the entire store ...<br>Let''s say a piece in your toilet tank breaks, so you remove the&nbsp;broken part, take it to the home center, and ask an employee if he has&nbsp;a replacement.  The employee, who has never is his life even seen the&nbsp;inside of a toilet tank, will peer at the broken part in very much the&nbsp;same way that a member of a primitive Amazon jungle tribe would look at&nbsp;an electronic calculator, and then say, "We''re expecting a shipment of&nbsp;these sometime around the middle of next week".<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He is now rising from affluence to poverty."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Sixth Commandment of Frisbee:<br>The greatest single aid to distance is for the disc to be going&nbsp;in a direction you did not want.   (Goes the wrong way = Goes a long&nbsp;way.)<br>&nbsp;-- Dan Roddick')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"At least they''re ___________^H^H^H^H^H^H^H^H^H^H^HEXPERIENCED incompetents"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have people realized that the purpose of the fortune cookie program is&nbsp;to defuse project tensions?  When did you ever see a cheerful cookie, a&nbsp;non-cynical, or even an informative cookie?&nbsp;&nbsp;Perhaps inadvertently, we have a channel for our aggressions.  This&nbsp;still begs the question of whether the cookie releases the pressure or&nbsp;only serves to blunt the warning signs.<br><br>&nbsp;Long live the revolution!<br>&nbsp;Have a nice day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Grub first, then ethics."<br>&nbsp;-- Bertolt Brecht')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The lawgiver, of all beings, most owes the law allegiance.  He of all&nbsp;men should behave as though the law compelled him.  But it is the&nbsp;universal weakness of mankind that what we are given to administer we&nbsp;presently imagine we own."<br>&nbsp;-- H.G. Wells')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The best thing about growing older is that it takes such a long time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Peanut Blossoms&nbsp;&nbsp;4 cups sugar           16 tbsp. milk&nbsp;4 cups brown sugar     4 tsp. vanilla&nbsp;4 cups shortening      14 cups flour&nbsp;8 eggs                 4 tsp. soda&nbsp;4 cups peanut butter   4 tsp. salt&nbsp;&nbsp;Shape dough into balls.  Roll in sugar and bake on ungreased cookie&nbsp;sheet at 375 F. for 10-12 minutes.  Immediately top each cookie with a&nbsp;Hershey''s kiss or star pressing down firmly to crack cookie.  Makes a&nbsp;hell of a lot.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whenever the literary German dives into a sentence, that is the last&nbsp;you are going to see of him until he emerges on the other side of his&nbsp;Atlantic with his verb in his mouth.<br>&nbsp;-- Mark Twain<br>&nbsp;   "Connecticut Yankee in King Arthur''s Court"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you''re not looking at it, this fortune is written in FORTRAN.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;You will remember, Watson, how the dreadful business of the&nbsp;Abernetty family was first brought to my notice by the depth which the&nbsp;parsley had sunk into the butter upon a hot day.<br>&nbsp;-- Sherlock Holmes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bagdikian''s Observation:<br>Trying to be a first-rate reporter on the average American&nbsp;newspaper is like trying to play Bach''s "St. Matthew Passion" on a&nbsp;ukelele.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The optimum committee has no members.<br>&nbsp;-- Norman Augustine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Condense soup, not books!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The meta-Turing test counts a thing as intelligent if it seeks to&nbsp;devise and apply Turing tests to objects of its own creation.<br>&nbsp;-- Lew Mammel, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A [golf] ball hitting a tree shall be deemed not to have hit the tree.<br>Hitting a tree is simply bad luck and has no place in a scientific&nbsp;game.  The player should estimate the distance the ball would have&nbsp;traveled if it had not hit the tree and play the ball from there,<br>preferably atop a nice firm tuft of grass.<br>&nbsp;-- Donald A. Metz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We have met the enemy, and he is us.<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I love Saturday morning cartoons, what classic humour!  This is what&nbsp;entertainment is all about ... Idiots, explosives and falling anvils."<br>&nbsp;-- Calvin and Hobbes, Bill Watterson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never drink coke in a moving elevator.  The elevator''s motion coupled&nbsp;with the chemicals in coke produce hallucinations.  People tend to&nbsp;change into lizards and attack without warning, and large bats usually&nbsp;fly in the window.  Additionally, you begin to believe that elevators&nbsp;have windows.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #18:<br>&nbsp;Q:  Are you married?&nbsp;A:  No, I''m divorced.<br>Q:  And what did your husband do before you divorced him?&nbsp;A:  A lot of things I didn''t know about.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A journey of a thousand miles begins with a cash advance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don:    I didn''t know you had a cousin Penelope, Bill!  Was she<br>pretty?&nbsp;W. C.:  Well, her face was so wrinkled it looked like seven miles of<br>bad road.  She had so many gold teeth, Don, she use to have to<br>sleep with her head in a safe.  She died in Bolivia.<br>Don:&nbsp;Oh Bill, it must be hard to lose a relative.<br>W. C.:&nbsp;It''s almost impossible.<br>&nbsp;-- W. C. Fields, from "The Further Adventures of Larson<br>&nbsp;   E. Whipsnade and other Tarradiddles"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As long as war is regarded as wicked, it will always have its&nbsp;fascination.  When it is looked upon as vulgar, it will cease to be&nbsp;popular.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Money is the root of all wealth.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Interpreter, n.:<br>One who enables two persons of different languages to&nbsp;understand each other by repeating to each what it would have been to&nbsp;the interpreter''s advantage for the other to have said.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"His great aim was to escape from civilization, and, as soon as he had&nbsp;money, he went to Southern California."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are three schools of magic.  One:  State a tautology, then ring&nbsp;the changes on its corollaries; that''s philosophy.  Two:  Record many&nbsp;facts.  Try to find a pattern.  Then make a wrong guess at the next&nbsp;fact; that''s science.  Three:  Be aware that you live in a malevolent&nbsp;Universe controlled by Murphy''s Law, sometimes offset by Brewster''s&nbsp;Factor; that''s engineering.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What''s the use of a good quotation if you can''t change it?"<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The best book on programming for the layman is "Alice in Wonderland":<br>but that''s because it''s the best book on anything for the layman.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If the aborigine drafted an IQ test, all of Western civilization would&nbsp;presumably flunk it.<br>&nbsp;-- Stanley Garn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Test-tube babies shouldn''t throw stones.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pascal Users:<br>To show respect for the 313th anniversary (tomorrow) of the&nbsp;death of Blaise Pascal, your programs will be run at half speed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had meant for us to be in the Army, we would have been born with&nbsp;green, baggy skin.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I was in school, I cheated on my metaphysics exam: I looked into&nbsp;the soul of the boy sitting next to me.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t hit a man when he''s down -- kick him; it''s easier.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rhode''s Law:<br>When any principle, law, tenet, probability, happening,<br>circumstance, or result can in no way be directly, indirectly,<br>empirically, or circuitously proven, derived, implied, inferred,<br>induced, deducted, estimated, or scientifically guessed, it will always&nbsp;for the purpose of convenience, expediency, political advantage,<br>material gain, or personal comfort, or any combination of the above, or&nbsp;none of the above, be unilaterally and unequivocally assumed,<br>proclaimed, and adhered to as absolute truth to be undeniably,<br>universally, immutably, and infinitely so, until such time as it&nbsp;becomes advantageous to assume otherwise, maybe.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve built a better model than the one at Data General&nbsp;For data bases vegetable, animal, and mineral&nbsp;My OS handles CPUs with multiplexed duality:<br>My PL/1 compiler shows impressive functionality.<br>My storage system''s better than magnetic core polarity,<br>You never have to bother checking out a bit for parity:<br>There isn''t any reason to install non-static floor matting:<br>My disk drive has capacity for variable formatting.<br>&nbsp;I feel compelled to mention what I know to be a gloating point:<br>There''s lots of room in memory for variables floating-point,<br>Which shows for input vegetable, animal, and mineral&nbsp;I''ve built a better model than the one at Data General.<br><br>&nbsp;-- Steve Levine, "A Computer Song" (To the tune of<br>&nbsp;   "Modern Major General", from "Pirates of Penzance",<br>&nbsp;   by Gilbert & Sullivan)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '(1) Everything depends.<br>(2) Nothing is always.<br>(3) Everything is sometimes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hark, the Herald Tribune sings,<br>Advertising wondrous things.<br>&nbsp;-- Tom Lehrer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An apple every eight hours will keep three doctors away.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When we are planning for posterity, we ought to remember that virtue is&nbsp;not hereditary.<br>&nbsp;-- Thomas Paine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Hello," he lied.<br>&nbsp;-- Don Carpenter quoting a Hollywood agent')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'From the moment I picked your book up until I put it down I was&nbsp;convulsed with laughter.  Some day I intend reading it.<br>&nbsp;-- Groucho Marx, from "The Book of Insults"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The cost of living hasn''t affected its popularity.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s more than magnificent -- it''s mediocre.<br>&nbsp;-- Sam Goldwyn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Due to a shortage of devoted followers, the production of great leaders&nbsp;has been discontinued.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #13: SLOBOL&nbsp;&nbsp;SLOBOL is best known for the speed, or lack of it, of its compiler.<br>Although many compilers allow you to take a coffee break while they&nbsp;compile, SLOBOL compilers allow you to travel to Bolivia to pick the&nbsp;coffee.  Forty-three programmers are known to have died of boredom&nbsp;sitting at their terminals while waiting for a SLOBOL program to&nbsp;compile.  Weary SLOBOL programmers often turn to a related (but&nbsp;infinitely faster) language, COCAINE.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you ever want to get anywhere in politics, my boy, you''re going to&nbsp;have to get a toehold in the public eye."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Think big.  Pollute the Mississippi.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '2180, U.S. History question:<br>What 20th Century U.S. President was almost impeached and what&nbsp;office did he later hold?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dawn, n.:<br>The time when men of reason go to bed.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'flowchart, n. & v.:<br>[From flow "to ripple down in rich profusion, as hair" + chart&nbsp;"a cryptic hidden-treasure map designed to mislead the uninitiated."]&nbsp;1. n. The solution, if any, to a class of Mascheroni construction&nbsp;problems in which given algorithms require geometrical representation&nbsp;using only the 35 basic ideograms of the ANSI template.  2. n. Neronic&nbsp;doodling while the system burns.  3. n. A low-cost substitute for&nbsp;wallpaper.  4. n.  The innumerate misleading the illiterate.  "A&nbsp;thousand pictures is worth ten lines of code." -- The Programmer''s&nbsp;Little Red Vade Mecum, Mao Tse T''umps.  5. v.intrans. To produce&nbsp;flowcharts with no particular object in mind.  6. v.trans. To obfuscate<br>a problem) with esoteric cartoons.<br>&nbsp;-- Stan Kelly-Bootle, "The Devil''s DP Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"The Good Ship Enterprise" (to the tune of "The Good Ship Lollipop")<br>&nbsp;On the good ship Enterprise&nbsp;Every week there''s a new surprise&nbsp;Where the Romulans lurk&nbsp;And the Klingons often go berserk.<br>&nbsp;Yes, the good ship Enterprise&nbsp;There''s excitement anywhere it flies&nbsp;Where Tribbles play&nbsp;And Nurse Chapel never gets her way.<br><br>See Captain Kirk standing on the bridge,<br>Mr. Spock is at his side.<br>The weekly menace, ooh-ooh<br>It gets fried, scattered far and wide.<br>&nbsp;It''s the good ship Enterprise&nbsp;Heading out where danger lies&nbsp;And you live in dread&nbsp;If you''re wearing a shirt that''s red.<br>-- Doris Robin and Karen Trimble of The L.A. Filkharmonics')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Executive ability is deciding quickly and getting somebody else to do&nbsp;the work.<br>&nbsp;-- John G. Pollard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Outside of a dog, a book is a man''s best friend: and inside a dog,<br>it''s too dark to read."<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Take the folks at Coca-Cola.  For many years, they were content to sit&nbsp;back and make the same old carbonated beverage.  It was a good&nbsp;beverage, no question about it; generations of people had grown up&nbsp;drinking it and doing the experiment in sixth grade where you put a&nbsp;nail into a glass of Coke and after a couple of days the nail dissolves&nbsp;and the teacher says: "Imagine what it does to your TEETH!"  So&nbsp;Coca-Cola was solidly entrenched in the market, and the management saw&nbsp;no need to improve ...<br>&nbsp;-- Dave Barry, "In Search of Excellence"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once Law was sitting on the bench<br>And Mercy knelt a-weeping.<br>"Clear out!" he cried, "disordered wench!<br>Nor come before me creeping.<br>Upon you knees if you appear,<br>''Tis plain you have no standing here."&nbsp;&nbsp;Then Justice came.  His Honor cried:<br>"YOUR states? -- Devil seize you!"&nbsp;"Amica curiae," she replied --<br>"Friend of the court, so please you."&nbsp;"Begone!" he shouted -- "There''s the door --&nbsp;I never saw your face before!"<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This fortune is inoperative.  Please try another.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ask your boss to reconsider -- it''s so difficult to take "Go to hell"&nbsp;for an answer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do not sleep in a eucalyptus tree tonight.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God is perfect, why did He create discontinuous functions?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Users never know what they want, but they always know when your&nbsp;program doesn''t deliver it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Board the windows, up your car insurance, and don''t leave any booze in&nbsp;plain sight.  It''s St. Patrick''s day in Chicago again.  The legend has&nbsp;it that St. Patrick drove the snakes out of Ireland.  In fact, he was&nbsp;arrested for drunk driving.  The snakes left because people kept&nbsp;throwing up on them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Join in the new game that''s sweeping the country.  It''s called&nbsp;"Bureaucracy".  Everybody stands in a circle.  The first person to do&nbsp;anything loses.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Now this is a totally brain damaged algorithm.  Gag me with a&nbsp;smurfette."<br>&nbsp;-- P. Buhr, Computer Science 354')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What''s another word for Thesaurus?"<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If time heals all wounds, how come the belly button stays the same?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you live to the age of a hundred you have it made because very few&nbsp;people die past the age of a hundred.<br>&nbsp;-- George Burns')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I cannot overemphasize the importance of good grammar.<br>&nbsp;What a crock.  I could easily overemphasize the importance of good&nbsp;grammar.  For example, I could say: "Bad grammar is the leading cause&nbsp;of slow, painful death in North America," or "Without good grammar, the&nbsp;United States would have lost World War II."<br>&nbsp;-- Dave Barry, "An Utterly Absurd Look at Grammar"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s so much plastic in this culture that vinyl leopard skin is&nbsp;becoming an endangered synthetic.<br>&nbsp;-- Lily Tomlin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Court, n.:<br>A place where they dispense with justice.<br>&nbsp;-- Arthur Train')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dare to be naive.<br>&nbsp;-- R. Buckminster Fuller')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pope Goestheveezl was the shortest reigning pope in the history of the&nbsp;Church, reigning for two hours and six minutes on 1 April 1866.  The&nbsp;white smoke had hardly faded into the blue of the Vatican skies before&nbsp;it dawned on the assembled multitudes in St. Peter''s Square that his&nbsp;name had hilarious possibilities.  The crowds fell about, helpless with&nbsp;laughter, singing<br>Half a pound of tuppenny rice<br>Half a pound of treacle<br>That''s the way the chimney smokes<br>Pope Goestheveezl&nbsp;The square was finally cleared by armed carabineri with tears of&nbsp;laughter streaming down their faces.  The event set a record for&nbsp;hilarious civic functions, smashing the previous record set when Baron&nbsp;Hans Neizant B"^Hompzidaize was elected Landburgher of K"^Holn in 1653.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I like work ... I can sit and watch it for hours."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'May the Fleas of a Thousand Camels infest one of your Erogenous Zones.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I can remember when a good politician had to be 75 percent ability and&nbsp;25 percent actor, but I can well see the day when the reverse could be&nbsp;true."<br>&nbsp;-- Harry Truman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;INVENTORY&nbsp;Four be the things I am wiser to know:<br>Idleness, sorrow, a friend, and a foe.<br>&nbsp;Four be the things I''d been better without:<br>Love, curiosity, freckles, and doubt.<br>&nbsp;Three be the things I shall never attain:<br>Envy, content, and sufficient champagne.<br>&nbsp;Three be the things I shall have till I die:<br>Laughter and hope and a sock in the eye.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A day without sunshine is like night.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Miksch''s Law:<br>If a string has one end, then it has another end.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am the mother of all things, and all things should wear a sweater."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"This is a test of the Emergency Broadcast System.  If this had been an&nbsp;actual emergency, do you really think we''d stick around to tell you?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rocky''s Lemma of Innovation Prevention<br>Unless the results are known in advance, funding agencies will<br>reject the proposal.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everyone can be taught to sculpt: Michelangelo would have had to be&nbsp;taught how ___^H^H^Hnot to.  So it is with the great programmers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My theology, briefly, is that the universe was dictated but not&nbsp;signed.<br>&nbsp;-- Christopher Morley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The human animal differs from the lesser primates in his passion for&nbsp;lists of "Ten Best".<br>&nbsp;-- H. Allen Smith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Infancy, n.:<br>The period of our lives when, according to Wordsworth, "Heaven&nbsp;lies about us."  The world begins lying about us pretty soon&nbsp;afterward.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Power, n:<br>The only narcotic regulated by the SEC instead of the FDA.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It would be nice if the Food and Drug Administration stopped issuing&nbsp;warnings about toxic substances and just gave me the names of one or&nbsp;two things still safe to eat.<br>&nbsp;-- Robert Fuoss')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t be humble ... you''re not that great.<br>&nbsp;-- Golda Meir')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The assertion that "all men are created equal" was of no practical use&nbsp;in effecting our separation from Great Britain and it was placed in the&nbsp;Declaration not for that, but for future use.<br>&nbsp;--  Abraham Lincoln')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Insanity is hereditary.  You get it from your kids.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Learning French is trivial: the word for horse is cheval, and&nbsp;everything else follows in the same way.<br>&nbsp;-- Alan J. Perlis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had intended Man to Walk, He would have given him Feet.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Down with categorical imperative!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'And as we stand on the edge of darkness&nbsp;Let our chant fill the void&nbsp;That others may know&nbsp;<br>In the land of the night<br>The ship of the sun<br>Is drawn by<br>The grateful dead.<br><br>&nbsp;-- Tibetan "Book of the Dead," ca. 4000 BC.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never eat more than you can lift.<br>&nbsp;-- Miss Piggy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A disciple of another sect once came to Drescher as he was&nbsp;eating his morning meal.  "I would like to give you this personality&nbsp;test", said the outsider, "because I want you to be happy."<br>Drescher took the paper that was offered him and put it into&nbsp;the toaster -- "I wish the toaster to be happy too".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s not reality or how you perceive things that''s important -- it''s&nbsp;what you''re taking for it...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The question is, why are politicians so eager to be president?  What is&nbsp;it about the job that makes it worth revealing, on national television,<br>that you have the ethical standards of a slime-coated piece of&nbsp;industrial waste?<br>&nbsp;-- Dave Barry, "On Presidential Politics"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Playing an unamplified electric guitar is like strumming on a picnic&nbsp;table.<br>&nbsp;-- Dave Barry, "The Snake"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Virtue is its own punishment.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who make peaceful revolution impossible will make violent&nbsp;revolution inevitable.<br>&nbsp;-- John F. Kennedy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If this is timesharing, give me my share right now.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Williams and Holland''s Law:<br>If enough data is collected, anything may be proven by&nbsp;statistical methods.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sex is the mathematics urge sublimated.<br>&nbsp;-- M. C. Reed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is for all ill-treated fellows<br>Unborn and unbegot,<br>For them to read when they''re in trouble<br>And I am not.<br>&nbsp;-- A. E. Housman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Molecule, n.:<br>The ultimate, indivisible unit of matter.  It is distinguished&nbsp;from the corpuscle, also the ultimate, indivisible unit of matter, by a&nbsp;closer resemblance to the atom, also the ultimate, indivisible unit of&nbsp;matter ... The ion differs from the molecule, the corpuscle and the&nbsp;atom in that it is an ion ...<br>-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Jesus Saves,<br>Moses Invests,<br>But only Buddha pays Dividends.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Feel disillusioned?  I''ve got some great new illusions ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;YOU TOO CAN MAKE BIG MONEY IN THE EXCITING FIELD OF<br>&nbsp;      PAPER SHUFFLING!&nbsp;&nbsp;Mr. TAA of Muddle, Mass. says:  "Before I took this course I used to be&nbsp;a lowly bit twiddler.  Now with what I learned at MIT Tech I feel&nbsp;really important and can obfuscate and confuse with the best."&nbsp;&nbsp;Mr. MARC had this to say:  "Ten short days ago all I could look forward&nbsp;to was a dead-end job as a engineer.  Now I have a promising future and&nbsp;make really big Zorkmids."&nbsp;&nbsp;MIT Tech can''t promise these fantastic results to everyone, but when&nbsp;you earn your MDL degree from MIT Tech your future will be brighter.<br><br>&nbsp;SEND FOR OUR FREE BROCHURE TODAY!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We ought to be very grateful that we have tools.  Millions of years ago&nbsp;people did not have them, and home projects were extremely difficult.<br>For example, when a primitive person wanted to put up paneling, he had&nbsp;to drive the little paneling nails into the cave wall with his bare&nbsp;fist, so generally the paneling wound up getting spattered with&nbsp;primitive blood, which isn''t really all that bad when you consider how&nbsp;ugly paneling is to begin with.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Flon''s Law:<br>There is not now, and never will be, a language in which it is&nbsp;the least bit difficult to write bad programs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'PL/1, "the fatal disease", belongs more to the problem set than to the&nbsp;solution set.<br>&nbsp;-- E. W. Dijkstra')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If little green men land in your back yard, hide any little green women&nbsp;you''ve got in the house.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you can''t learn to do it well, learn to enjoy doing it badly.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do you have lysdexia?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'So as your consumer electronics adviser, I am advising you to donate&nbsp;your current VCR to a grate resident, who will laugh sardonically and&nbsp;hurl it into a dumpster.  Then I want you to go out and purchase a vast&nbsp;array of 8-millimeter video equipment.<br>&nbsp;... OK!  Got everything?  Well, *too bad, sucker*, because while you&nbsp;were gone the electronics industry came up with an even newer format&nbsp;that makes your 8-millimeter VCR look as technologically advanced as&nbsp;toenail dirt.  This format is called "3.5 hectare" and it will not be&nbsp;made available until it is outmoded, sometime early next week, by a&nbsp;format called "Elroy", so *order yours now*.<br>&nbsp;-- Dave Barry, "No Surrender in the Electronics<br>&nbsp;   Revolution"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In 1880 the French captured Detroit but gave it back ... they couldn''t&nbsp;get parts.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brook''s Law:<br>Adding manpower to a late software project makes it later')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ink, n.:<br>A villainous compound of tannogallate of iron, gum-arabic, and&nbsp;water, chiefly used to facilitate the infection of idiocy and promote&nbsp;intellectual crime.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Renning''s Maxim:<br>Man is the highest animal.  Man does the classifying.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Pig, if I am not mistaken,<br>Gives us ham and pork and Bacon.<br>Let others think his heart is big,<br>I think it stupid of the Pig.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fudd''s First Law of Opposition:<br>Push something hard enough and it will fall over.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New members are urgently needed in the Society for Prevention of&nbsp;Cruelty to Yourself.  Apply within.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tussman''s Law:<br>Nothing is as inevitable as a mistake whose time has come.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have an adequate day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You may be sure that when a man begins to call himself a "realist," he&nbsp;is preparing to do something he is secretly ashamed of doing.<br>&nbsp;-- Sydney Harris')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Garter, n.:<br>An elastic band intended to keep a woman from coming out of her&nbsp;stockings and desolating the country.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No man in the world has more courage than the man who can stop after&nbsp;eating one peanut.<br>&nbsp;-- Channing Pollock')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Today is the tomorrow you worried about yesterday')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A [golf] ball sliced or hooked into the rough shall be lifted and&nbsp;placed in the fairway at a point equal to the distance it carried or&nbsp;rolled into the rough.  Such veering right or left frequently results&nbsp;from friction between the face of the club and the cover of the ball&nbsp;and the player should not be penalized for the erratic behavior of the&nbsp;ball resulting from such uncontrollable physical&nbsp;phenomena.<br>&nbsp;-- Donald A. Metz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Has everyone noticed that all the letters of the word "database" are&nbsp;typed with the left hand?  Now the layout of the QWERTYUIOP typewriter&nbsp;keyboard was designed, among other things, to facilitate the even use&nbsp;of both hands.  It follows, therefore, that writing about databases is&nbsp;not only unnatural, but a lot harder than it appears.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Just out of curiosity does this actually mean something or have some&nbsp;of the few remaining bits of your brain just evaporated?"<br>&nbsp;-- Patricia O Tuama, rissa@killer.DALLAS.TX.US')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I traveled to the end of the rainbow&nbsp;As Dame Fortune did intend,<br>Murphy would be there to tell me&nbsp;The pot''s at the other end.<br>&nbsp;-- Bert Whitney')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is really only another artist.  He invented the giraffe, the&nbsp;elephant and the cat.  He has no real style, He just goes on trying&nbsp;other things.<br>&nbsp;-- Pablo Picasso')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It seems like the less a statesman amounts to, the more he loves the&nbsp;flag.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While Europe''s eye is fix''d on mighty things,<br>The fate of empires and the fall of kings:<br>While quacks of State must each produce his plan,<br>And even children lisp the Rights of Man:<br>Amid this mighty fuss just let me mention,<br>The Rights of Woman merit some attention.<br>&nbsp;-- Robert Burns, Address on "The Rights of Woman",<br>&nbsp;   November 26, 1792')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... But we''ve only fondled the surface of that subject.<br>&nbsp;-- Virginia Masters')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you''re not part of the solution, you''re part of the precipitate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'SCCS, the source motel!  Programs check in and never check out!<br>&nbsp;-- Ken Thompson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s no real need to do housework -- after four years it doesn''t get&nbsp;any worse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All bridge hands are equally likely, but some are more equally likely&nbsp;than others.<br>&nbsp;-- Alan Truscott')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pound for pound, the amoeba is the most vicious animal on earth.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Our OS who art in CPU, UNIX be thy name.<br>Thy programs run, thy syscalls done,<br>In kernel as it is in user!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing takes the taste out of peanut butter quite like unrequited&nbsp;love.<br>&nbsp;-- Charlie Brown')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;COMMENT&nbsp;&nbsp;Oh, life is a glorious cycle of song,<br>A medley of extemporanea:<br>And love is thing that can never go wrong:<br>And I am Marie of Roumania.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh, I have slipped the surly bonds of earth,<br>And danced the skies on laughter silvered wings:<br>Sunward I''ve climbed and joined the tumbling mirth&nbsp;Of sun-split clouds and done a hundred things&nbsp;You have not dreamed of --&nbsp;Wheeled and soared and swung&nbsp;High in the sunlit silence.<br>Hovering there&nbsp;I''ve chased the shouting wind along and flung&nbsp;My eager craft through footless halls of air.<br>Up, up along delirious, burning blue&nbsp;I''ve topped the wind-swept heights with easy grace,<br>Where never lark, or even eagle flew:<br>And, while with silent, lifting mind I''ve trod&nbsp;The high untrespassed sanctity of space,<br>Put out my hand, and touched the face of God.<br>&nbsp;-- John Gillespie Magee Jr., "High Flight"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The fortune program is supported, in part, by user contributions and by&nbsp;a major grant from the National Endowment for the Inanities.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;(to "The Caissons Go Rolling Along")<br>Scratch the disks, dump the core,&nbsp;Shut it down, pull the plug&nbsp;Roll the tapes across the floor,&nbsp;Give the core an extra tug&nbsp;And the system is going to crash.&nbsp;And the system is going to crash.<br>Teletypes smashed to bits.&nbsp;&nbsp;Mem''ry cards, one and all,<br>Give the scopes some nasty hits&nbsp;&nbsp;Toss out halfway down the hall&nbsp;And the system is going to crash.&nbsp;And the system is going to crash.<br>And we''ve also found&nbsp;&nbsp;&nbsp;Just flip one switch&nbsp;When you turn the power down,&nbsp;&nbsp;And the lights will cease to twitch&nbsp;You turn the disk readers into trash.&nbsp;And the tape drives will crumble<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;in a flash.<br>Oh, it''s so much fun,&nbsp;&nbsp;&nbsp;When the CPU&nbsp;Now the CPU won''t run&nbsp;&nbsp;&nbsp;Can print nothing out but "foo,"&nbsp;And the system is going to crash.&nbsp;The system is going to crash.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Programmers don''t play tennis, or any other sport that requires&nbsp;you to change clothes.  Mountain climbing is OK, and real programmers&nbsp;wear their climbing boots to work in case a mountain should suddenly&nbsp;spring up in the middle of the machine room.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brace yourselves.  We''re about to try something that borders on the&nbsp;unique: an actually rather serious technical book which is not only<br>gasp) vehemently anti-Solemn, but also (shudder) takes sides.  I tend&nbsp;to think of it as `Constructive Snottiness.''<br>&nbsp;-- Mike Padlipsky, Foreword to "Elements of Networking<br>&nbsp;   Style"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Honk if you love peace and quiet.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Military intelligence is a contradiction in terms.<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lieberman''s Law:<br>Everybody lies, but it doesn''t matter since nobody listens.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Military justice is to justice what military music is to music.<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are three ways to get something done: do it yourself, hire&nbsp;someone, or forbid your kids to do it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As the poet said, "Only God can make a tree" -- probably because it''s&nbsp;so hard to figure out how to get the bark on.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some people have a way about them that seems to say: "If I have only&nbsp;one life to live, let me live it as a jerk."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A radioactive cat has eighteen half-lives."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh Dad!  We''re ALL Devo!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ideas don''t stay in some minds very long because they don''t like&nbsp;solitary confinement.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''m having all my plants neutered."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I don''t want to alarm anybody, but there is an excellent chance that&nbsp;the Earth will be destroyed in the next several days.  Congress is&nbsp;thinking about eliminating a federal program under which scientists&nbsp;broadcast signals to alien beings.  This would be a large mistake.<br>Alien beings have nuclear blaster death cannons.  You cannot cut off&nbsp;their federal programs as if they were merely poor people ...<br>&nbsp;-- Davy Barry, "THE ALIENS ARE COMING, THE ALIENS ARE<br>&nbsp;   COMING!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The more data I punch in this card, the lighter it becomes, and the&nbsp;lower the mailing cost."<br>&nbsp;-- Stan Kelly-Bootle, "The Devil''s DP Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The following quote is from page 4-27 of the MSCP Basic Disk Functions&nbsp;Manual which is part of the UDA50 Programmers Doc Kit manuals:<br>&nbsp;As stated above, the host area of a disk is structured as a vector of&nbsp;logical blocks.  From a performance viewpoint, however, it is more&nbsp;appropriate to view the host area as a four dimensional hyper-cube, the&nbsp;four dimensions being cylinder, group, track, and sector.<br>. . .<br>Referring to our hyper-cube analogy, the set of potentially accessible&nbsp;blocks form a line parallel to the track axis.  This line moves&nbsp;parallel to the sector axis, wrapping around when it reaches the edge&nbsp;of the hyper-cube.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cerebus:&nbsp;I''d love to lick apricot brandy out of your navel.<br>Jaka:&nbsp;&nbsp;Look, Cerebus-- Jaka has to tell you ... something&nbsp;Cerebus:&nbsp;If Cerebus had a navel, would you lick apricot brandy<br>&nbsp;out of it?&nbsp;Jaka:&nbsp;&nbsp;Ugh!&nbsp;Cerebus:&nbsp;You don''t like apricot brandy?<br>&nbsp;-- Cerebus #6, "The Secret"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All extremists should be taken out and shot.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'May Euell Gibbons eat your only copy of the manual!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What does "it" mean in the sentence "What time is it?"?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicken Little only has to be right once.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The wind doth taste so bitter sweet,<br>Like Jaspar wine and sugar,<br>It must have blown through someone''s feet,<br>Like those of Caspar Weinberger.<br>&nbsp;-- P. Opus')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Truth will be out this morning.  (Which may really mess things up.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bumper sticker:<br>&nbsp;"All the parts falling off this car are of the very finest British&nbsp;manufacture"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Parkinson''s Fourth Law:<br>The number of people in any working group tends to increase&nbsp;regardless of the amount of work to be done.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Die, v.:<br>To stop sinning suddenly.<br>&nbsp;-- Elbert Hubbard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The longer I am out of office, the more infallible I appear to myself.<br>&nbsp;-- Henry Kissinger')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Excellent time to become a missing person.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ogden''s Law:<br>The sooner you fall behind, the more time you have to catch&nbsp;up.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Parkinson''s Fifth Law:<br>If there is a way to delay in important decision, the good&nbsp;bureaucracy, public or private, will find it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''ve seen better heads on half a pint of beer."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A countryman between two lawyers is like a fish between two cats.<br>&nbsp;-- Ben Franklin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fairy Tale, n.:<br>A horror story to prepare children for the newspapers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Here is the fact of the week, maybe even the fact of the&nbsp;month.  According to probably reliable sources, the Coca-Cola people&nbsp;are experiencing severe marketing anxiety in China.<br>The words "Coca-Cola" translate into Chinese as either<br>depending on the inflection) "wax-fattened mare" or "bite the wax&nbsp;tadpole".<br>Bite the wax tadpole.<br>There is a sort of rough justice, is there not?<br>The trouble with this fact, as lovely as it is, is that it''s&nbsp;hard to get a whole column out of it. I''d like to teach the world to&nbsp;bite a wax tadpole.  Coke -- it''s the real wax-fattened mare. Not bad,<br>but broad satiric vistas do not open up.<br>&nbsp;-- John Carrol, San Francisco Chronicle')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Taxes, n.:<br>Of life''s two certainties, the only one for which you can get&nbsp;an extension.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A wizard cannot do everything; a fact most magicians are reticent to&nbsp;admit, let alone discuss with prospective clients.  Still, the fact&nbsp;remains that there are certain objects, and people, that are, for one&nbsp;reason or another, completely immune to any direct magical spell.  It&nbsp;is for this group of beings that the magician learns the subtleties of&nbsp;using indirect spells.  It also does no harm, in dealing with these&nbsp;matters, to carry a large club near your person at all times."<br>&nbsp;-- The Teachings of Ebenezum, Volume VIII')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... Once you''re safely in the mall, you should tie your children to you&nbsp;with ropes so the other shoppers won''t try to buy them.  Holiday&nbsp;shoppers have been whipped into a frenzy by months of holiday&nbsp;advertisements, and they will buy anything small enough to stuff into a&nbsp;shopping bag.  If your children object to being tied, threaten to take&nbsp;them to see Santa Claus; that ought to shut them up.<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Not Hercules could have knock''d out his brains, for he had none."<br>&nbsp;-- Shakespeare')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bizoos, n.:<br>The millions of tiny individual bumps that make up a&nbsp;basketball.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You are wise, witty, and wonderful, but you spend too much time reading&nbsp;this sort of trash.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Here I sit, broken-hearted,<br>All logged in, but work unstarted.<br>First net.this and net.that,<br>And a hot buttered bun for net.fat.<br>&nbsp;The boss comes by, and I play the game,<br>Then I turn back to net.flame.<br>Is there a cure (I need your views),<br>For someone trapped in net.news?&nbsp;&nbsp;I need your help, I say ''tween sobs,<br>''Cause I''ll soon be listed in net.jobs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everything should be built top-down, except the first time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;AMAZING BUT TRUE ...<br>&nbsp;If all the salmon caught in Canada in one year were laid end to end&nbsp;across the Sahara Desert, the smell would be absolutely awful.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stupidity got us into this mess -- why can''t it get us out?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When are you BUTTHEADS gonna learn that you can''t oppose Gestapo&nbsp;tactics *with* Gestapo tactics?"<br>&nbsp;-- Reuben Flagg')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Screw up your courage!  You''ve screwed up everything else.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Today is the first day of the rest of the mess')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Making files is easy under the UNIX operating system.  Therefore, users&nbsp;tend to create numerous files using large amounts of file space.  It&nbsp;has been said that the only standard thing about all UNIX systems is&nbsp;the message-of-the-day telling users to clean up their files.<br>&nbsp;-- System V.2 administrator''s guide')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you can count your money, you don''t have a billion dollars."<br>&nbsp;-- J. Paul Getty')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '(1) Alexander the Great was a great general.<br>(2) Great generals are forewarned.<br>(3) Forewarned is forearmed.<br>(4) Four is an even number.<br>(5) Four is certainly an odd number of arms for a man to have.<br>(6) The only number that is both even and odd is infinity.<br>&nbsp;Therefore, Alexander the Great had an infinite number of arms.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A Galileo could no more be elected president of the United States than&nbsp;he could be elected Pope of Rome.  Both high posts are reserved for men&nbsp;favored by God with an extraordinary genius for swathing the bitter&nbsp;facts of life in bandages of self-illusion.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Modern man is the missing link between apes and human beings.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing makes one so vain as being told that one is a sinner.<br>Conscience makes egotists of us all.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Murphy''s Law of Research:<br>Enough research will tend to support your theory.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Age before beauty; and pearls before swine.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real programmers don''t write in BASIC.  Actually, no programmers write&nbsp;in BASIC after reaching puberty.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If at first you don''t succeed, give up, no use being a damn fool.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Of course power tools and alcohol don''t mix.  Everyone knows power&nbsp;tools aren''t soluble in alcohol ..."<br>&nbsp;-- Crazy Nigel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The man who sets out to carry a cat by its tail learns something that&nbsp;will always be useful and which never will grow dim or doubtful.<br>&nbsp;-- Mark Twain.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any time things appear to be going better, you have overlooked&nbsp;something.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People who claim they don''t let little things bother them have never&nbsp;slept in a room with a single mosquito.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh, I am a C programmer and I''m okay<br>I muck with indices and structs all day&nbsp;And when it works, I shout hoo-ray<br>Oh, I am a C programmer and I''m okay')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Boy, life takes a long time to live<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Lexington, Kentucky, it''s illegal to carry an ice cream cone in your&nbsp;pocket.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The trouble with superheros is what to do between phone booths.<br>&nbsp;-- Ken Kesey')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Schlattwhapper, n.:<br>The window shade that allows itself to be pulled down,<br>hesitates for a second, then snaps up in your face.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'From the "Guiness Book of World Records", 1973:<br>&nbsp;Certain passages in several laws have always defied interpretation and&nbsp;the most inexplicable must be a matter of opinion.  A judge of the&nbsp;Court of Session of Scotland has sent the editors of this book his&nbsp;candidate which reads, "In the Nuts (unground), (other than ground&nbsp;nuts) Order, the expression nuts shall have reference to such nuts,<br>other than ground nuts, as would but for this amending Order not&nbsp;qualify as nuts (unground)(other than ground nuts) by reason of their&nbsp;being nuts (unground)."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;An old Jewish man reads about Einstein''s theory of relativity&nbsp;in the newspaper and asks his scientist grandson to explain it to him.<br>"Well, zayda, it''s sort of like this.  Einstein says that if&nbsp;you''re having your teeth drilled without Novocain, a minute seems like&nbsp;an hour.  But if you''re sitting with a beautiful woman on your lap, an&nbsp;hour seems like a minute."<br>The old man considers this profound bit of thinking for a&nbsp;moment and says, "And from this he makes a living?"<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gyroscope, n.:<br>A wheel or disk mounted to spin rapidly about an axis and also&nbsp;free to rotate about one or both of two axes perpendicular to each&nbsp;other and the axis of spin so that a rotation of one of the two&nbsp;mutually perpendicular axes results from application of torque to the&nbsp;other when the wheel is spinning and so that the entire apparatus&nbsp;offers considerable opposition depending on the angular momentum to any&nbsp;torque that would change the direction of the axis of spin.<br>&nbsp;-- Webster''s Seventh New Collegiate Dictionary')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It took me fifteen years to discover that I had no talent for writing,<br>but I couldn''t give up because by that time I was too famous."<br>&nbsp;-- Robert Benchly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Law of Communications:<br>The inevitable result of improved and enlarged communications&nbsp;between different levels in a hierarchy is a vastly increased area of&nbsp;misunderstanding.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Good-bye.  I am leaving because I am bored."<br>&nbsp;-- George Saunders'' dying words')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I doubt, therefore I might be.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No problem is so formidable that you can''t just walk away from it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Message will arrive in the mail.  Destroy, before the FBI sees it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When I was crossing the border into Canada, they asked if I had any&nbsp;firearms with me.  I said, `Well, what do you need?''"<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alexander Graham Bell is alive and well in New York, and still waiting&nbsp;for a dial tone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Being disintegrated makes me ve-ry an-gry!" <huff, huff>')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have come up with a sure-fire concept for a hit television show,<br>which would be called `A Live Celebrity Gets Eaten by a Shark''."<br>&nbsp;-- Dave Barry, "The Wonders of Sharks on TV"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve given up reading books; I find it takes my mind off myself.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A formal parsing algorithm should not always be used.<br>&nbsp;-- D. Gries')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The brain is a wonderful organ; it starts working the moment you get up&nbsp;in the morning, and does not stop until you get to school.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My own dear love, he is strong and bold<br>And he cares not what comes after.<br>His words ring sweet as a chime of gold,<br>And his eyes are lit with laughter.<br>He is jubilant as a flag unfurled --<br>Oh, a girl, she''d not forget him.<br>My own dear love, he is all my world --<br>And I wish I''d never met him.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People need good lies.  There are too many bad ones.<br>&nbsp;-- Bokonon, "Cat''s Cradle" by Kurt Vonnegut, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The opossum is a very sophisticated animal.  It doesn''t even get up&nbsp;until 5 or 6 p.m.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;DETERIORATA&nbsp;&nbsp;Go placidly amid the noise and waste,<br>And remember what comfort there may be in owning a piece thereof.<br>Avoid quiet and passive persons, unless you are in need of sleep.<br>Rotate your tires.<br>Speak glowingly of those greater than yourself,<br>And heed well their advice -- even though they be turkeys.<br>Know what to kiss -- and when.<br>Remember that two wrongs never make a right,<br>But that three do.<br>Wherever possible, put people on "HOLD".<br>Be comforted, that in the face of all aridity and disillusionment,<br>And despite the changing fortunes of time,<br>There is always a big future in computer maintenance.<br><br>You are a fluke of the universe ...<br>You have no right to be here.<br>Whether you can hear it or not, the universe<br>Is laughing behind your back.<br>&nbsp;-- National Lampoon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To err is human, to moo bovine.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bombeck''s Rule of Medicine:<br>Never go to a doctor whose office plants have died.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You never know how many friends you have until you rent a house on the&nbsp;beach.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Horngren''s Observation:<br>Among economists, the real world is often a special case.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The eleventh commandment was `Thou Shalt Compute'' or `Thou Shalt Not&nbsp;Compute'' -- I forget which."<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Winter is the season in which people try to keep the house as warm as&nbsp;it was in the summer, when they complained about the heat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A fool must now and then be right by chance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... So the documentary-makers stick with sharks.  Generally, their&nbsp;procedure is to scatter bleeding fish pieces around their boat, so as&nbsp;to infest the waters.  I would estimate that the primary food source of&nbsp;sharks today is bleeding fish pieces scattered by people making&nbsp;documentaries.  Once the sharks arrive, they are generally fairly&nbsp;listless.  The general shark attitude seems to be: "Oh God, another&nbsp;documentary."  So the divers have to somehow goad them into attacking,<br>under the guise of Scientific Research.  "We know very little about the&nbsp;effect of electricity on sharks," the narrator will say, in a deeply&nbsp;scientific voice.  "That is why Todd is going to jab this Great White&nbsp;in the testicles with a cattle prod."  The divers keep this kind of&nbsp;thing up until the shark finally gets irritated and snaps at them, and&nbsp;then they act as though this was a totally unexpected and very&nbsp;dangerous development, although clearly it is what they wanted all&nbsp;along.<br>&nbsp;-- Dave Barry, "The Wonders of Sharks on TV"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I value kindness to human beings first of all, and kindness to&nbsp;animals.  I don''t respect the law; I have a total irreverence for&nbsp;anything connected with society except that which makes the roads&nbsp;safer, the beer stronger, the food cheaper, and old men and women&nbsp;warmer in the winter, and happier in the summer.<br>&nbsp;-- Brendan Behan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The human mind ordinarily operates at only ten percent of its capacity&nbsp;-- the rest is overhead for the operating system.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The steady state of disks is full.<br>&nbsp;-- Ken Thompson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the force if Yoda''s so strong, construct a sentence with words in&nbsp;the proper order then why can''t he?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just because everything is different doesn''t mean anything has&nbsp;changed.<br>&nbsp;-- Irene Peter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everyone is a genius.  It''s just that some people are too stupid to&nbsp;realize it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just about every computer on the market today runs Unix, except the Mac<br>and nobody cares about it).<br>&nbsp;-- Bill Joy 6/21/85')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you didn''t get caught, did you really do it?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Look, we play the Star Spangled Banner before every game.  You want us&nbsp;to pay income taxes, too?<br>&nbsp;-- Bill Veeck, Chicago White Sox')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just because your doctor has a name for your condition doesn''t mean he&nbsp;knows what it is.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you understand what you''re doing, you''re not learning anything."<br>&nbsp;-- A. L.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"What''s that thing?"<br>"Well, it''s a highly technical, sensitive instrument we use in&nbsp;computer repair.  Being a layman, you probably can''t grasp exactly what&nbsp;it does.  We call it a two-by-four."<br>&nbsp;-- Jeff MacNelley, "Shoe"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some performers on television appear to be horrible people, but when&nbsp;you finally get to know them in person, they turn out to be even&nbsp;worse.<br>&nbsp;-- Avery')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #5: VALGOL&nbsp;From its modest beginnings in Southern California''s San Fernando Valley,<br>VALGOL is enjoying a dramatic surge of popularity across the industry.<br>&nbsp;Here is a sample program:<br>LIKE, Y*KNOW(I MEAN)START<br>IF PIZZA = LIKE BITCHEN AND GUY = LIKE TUBULAR AND<br>   VALLEY GIRL = LIKE GRODY**MAX(FERSURE)**2 THEN<br>&nbsp;FOR I = LIKE 1 TO OH*MAYBE 100<br>&nbsp;&nbsp;DO*WAH - (DITTY**2)<br>&nbsp;&nbsp;BARF(I)=TOTALLY GROSS(OUT)<br>&nbsp;SURE<br>LIKE BAG THIS PROGRAM<br>REALLY<br>LIKE TOTALLY (Y*KNOW)<br>IM*SURE<br>GOTO THE MALL&nbsp;&nbsp;When the user makes a syntax error, the interpreter displays the message:<br><br>GAG ME WITH A SPOON!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You should, without hesitation, pound your typewriter into a&nbsp;plowshare, your paper into fertilizer, and enter agriculture"<br>&nbsp;-- Business Professor, University of Georgia')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A lack of leadership is no substitute for inaction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone who cannot cope with mathematics is not fully human.  At best he&nbsp;is a tolerable subhuman who has learned to wear shoes, bathe and not&nbsp;make messes in the house.<br>&nbsp;-- Lazarus Long, "Time Enough for Love"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New York is real.  The rest is done with mirrors.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'May your Tongue stick to the Roof of your Mouth with the Force of a&nbsp;Thousand Caramels.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My opinions may have changed, but not the fact that I am right.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is a form of government that substitutes election by the&nbsp;incompetent many for appointment by the corrupt few.<br>&nbsp;-- G. B. Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nature and nature''s laws lay hid in night,<br>God said, "Let Newton be," and all was light.<br>&nbsp;It did not last; the devil howling "Ho!&nbsp;Let Einstein be!" restored the status quo.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Wiker''s Law:<br>Government expands to absorb revenue and then some.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yes, but which self do you want to be?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;We were young and our happiness dazzled us with its strength.<br>But there was also a terrible betrayal that lay within me like a Merle&nbsp;Haggard song at a French restaurant. ...<br>I could not tell the girl about the woman of the tollway, of&nbsp;her milk white BMW and her Jordache smile.  There had been a fight.  I&nbsp;had punched her boyfriend, who fought the mechanical bulls.  Everyone&nbsp;told him, "You ride the bull, senor.  You do not fight it."  But he was&nbsp;lean and tough like a bad rib-eye and he fought the bull.  And then he&nbsp;fought me.  And when we finished there were no winners, just men doing&nbsp;what men must do. ...<br>"Stop the car," the girl said.  There was a look of terrible&nbsp;sadness in her eyes.  She knew about the woman of the tollway.  I knew&nbsp;not how.  I started to speak, but she raised an arm and spoke with a&nbsp;quiet and peace I will never forget.<br>"I do not ask for whom''s the tollway belle," she said, "the&nbsp;tollway belle''s for thee."<br>The next morning our youth was a memory, and our happiness was&nbsp;a lie.  Life is like a bad margarita with good tequila, I thought as I&nbsp;poured whiskey onto my granola and faced a new day.<br>&nbsp;-- Peter Applebome, International Imitation Hemingway<br>&nbsp;   Competition')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In America today ... we have Woody Allen, whose humor has become so&nbsp;sophisticated that nobody gets it any more except Mia Farrow.  All&nbsp;those who think Mia Farrow should go back to making movies where the&nbsp;devil gets her pregnant and Woody Allen should go back to dressing up&nbsp;as a human sperm, please raise your hands.  Thank you.<br>&nbsp;-- Dave Barry, "Why Humor is Funny"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cynic, n.:<br>One who looks through rose-colored glasses with a jaundiced&nbsp;eye.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If two wrongs don''t make a right, try three.<br>&nbsp;-- Laurence J. Peter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'K:&nbsp;Cobalt''s metal, hard and shining;<br>Cobol''s wordy and confining;<br>KOBOLDS topple when you strike them;<br>Don''t feel bad, it''s hard to like them.<br>&nbsp;-- The Roguelet''s ABC')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The New York Times is read by the people who run the country.  The&nbsp;Washington Post is read by the people who think they run the country.<br>The National Enquirer is read by the people who think Elvis is alive&nbsp;and running the country ..."<br>&nbsp;-- Robert J Woodhead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'But in our enthusiasm, we could not resist a radical overhaul of the&nbsp;system, in which all of its major weaknesses have been exposed,<br>analyzed, and replaced with new weaknesses.<br>&nbsp;-- Bruce Leverett, "Register Allocation in Optimizing<br>&nbsp;   Compilers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Well, I would -- if they realized that we -- again if -- if we led them&nbsp;back to that stalemate only because our retaliatory power, our seconds,<br>or strike at them after our first strike, would be so destructive they&nbsp;they couldn''t afford it, that would hold them off.<br>&nbsp;-- President Ronald Reagan, on the MX missile')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Acid absorbs 47 times it''s weight in excess Reality.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Critic, n.:<br>A person who boasts himself hard to please because nobody tries&nbsp;to please him.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The bureaucracy is expanding to meet the needs of an expanding&nbsp;bureaucracy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sometimes I worry about being a success in a mediocre world.<br>&nbsp;-- Lily Tomlin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is an unauthorized cybernetic announcement.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While having never invented a sin, I''m trying to perfect several.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Millions long for immortality who do not know what to do with&nbsp;themselves on a rainy Sunday afternoon.<br>&nbsp;-- Susan Ertz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You should never bet against anything in science at odds of more than&nbsp;about 10^12 to 1.<br>&nbsp;-- Ernest Rutherford')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Succumb to natural tendencies.  Be hateful and boring.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Absentee, n.:<br>A person with an income who has had the forethought to remove&nbsp;himself from the sphere of exaction.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never let your sense of morals prevent you from doing what is right.<br>&nbsp;-- Salvor Hardin, "Foundation"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life may have no meaning -- or even worse, it may have a meaning of&nbsp;which I disapprove."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'LETTERS TO THE EDITOR (The Times of London)<br>&nbsp;Dear Sir,<br>&nbsp;I am firmly opposed to the spread of microchips either to the home or&nbsp;to the office.  We have more than enough of them foisted upon us in&nbsp;public places.  They are a disgusting Americanism, and can only result&nbsp;in the farmers being forced to grow smaller potatoes, which in turn&nbsp;will cause massive unemployment in the already severely depressed&nbsp;agricultural industry.<br>&nbsp;Yours faithfully,<br>Capt. Quinton D''Arcy, J. P.<br>Sevenoaks')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Perfection is reached, not when there is no longer anything to add, but&nbsp;when there is no longer anything to take away.<br>&nbsp;-- Antoine de Saint-Exupery')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nature abhors a hero.  For one thing, he violates the law of&nbsp;conservation of energy.  For another, how can it be the survival of the&nbsp;fittest when the fittest keeps putting himself in situations where he&nbsp;is most likely to be creamed?<br>&nbsp;-- Solomon Short')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In America, any boy may become president and I suppose that''s just one&nbsp;of the risks he takes.<br>&nbsp;-- Adlai Stevenson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... the Mayo Clinic, named after its founder, Dr. Ted Clinic ..."<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;        Has your family tried ''em?&nbsp;<br>&nbsp;&nbsp;   POWDERMILK BISCUITS&nbsp;<br>&nbsp; Heavens, they''re tasty and expeditious!&nbsp;<br>   They''re made from whole wheat, to give shy persons the<br>   strength to get up and do what needs to be done.<br><br>&nbsp;&nbsp;   POWDERMILK BISCUITS&nbsp;<br>Buy them ready-made in the big blue box with the picture of the<br>biscuit on the front, or in the brown bag with the dark stains<br>&nbsp;&nbsp; that indicate freshness.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brain, n.:<br>The apparatus with which we think that we think.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'They told me you had proven it&nbsp;&nbsp;When they discovered our results<br>About a month before.&nbsp;&nbsp;&nbsp;Their hair began to curl&nbsp;The proof was valid, more or less&nbsp;Instead of understanding it<br>But rather less than more.&nbsp;&nbsp;We''d run the thing through PRL.<br>&nbsp;He sent them word that we would try&nbsp;Don''t tell a soul about all this<br>To pass where they had failed&nbsp;&nbsp;For it must ever be&nbsp;And after we were done, to them&nbsp;&nbsp;A secret, kept from all the rest<br>The new proof would be mailed.&nbsp;&nbsp;Between yourself and me.<br>&nbsp;My notion was to start again<br>Ignoring all they''d done&nbsp;We quickly turned it into code<br>To see if it would run.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Insanity is the final defense ... It''s hard to get a refund when the&nbsp;salesman is sniffing your crotch and baying at the moon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Yow!  Am I having fun yet?"<br>&nbsp;-- Zippy the Pinhead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Common sense is instinct, and enough of it is genius.<br>&nbsp;-- Josh Billings')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Serenity through viciousness.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Graduate life: It''s not just a job.  It''s an indenture.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Experience is something you don''t get until just after you need it.<br>&nbsp;-- Olivier')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'NOBODY EXPECTS THE SPANISH INQUISITION')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  Why do ducks have flat feet?&nbsp;A:  To stamp out forest fires.<br>&nbsp;Q:  Why do elephants have flat feet?&nbsp;A:  To stamp out flaming ducks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Technological progress has merely provided us with more efficient means&nbsp;for going backwards.<br>&nbsp;-- Aldous Huxley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There are two ways of disliking poetry; one way is to dislike it, the&nbsp;other is to read Pope."<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Give thought to your reputation.  Consider changing name and moving to&nbsp;a new town.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Call on God, but row away from the rocks.<br>&nbsp;-- Indian proverb')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have made mistakes but I have never made the mistake of claiming&nbsp;that I have never made one."<br>&nbsp;-- James Gordon Bennett')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bride, n.:<br>A woman with a fine prospect of happiness behind her.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old, Father William," the young man said,<br>"All your papers these days look the same:<br>Those William''s would be better unread --<br>Do these facts never fill you with shame?"&nbsp;&nbsp;"In my youth," Father William replied to his son,<br>"I wrote wonderful papers galore:<br>But the great reputation I found that I''d won,<br>Made it pointless to think any more."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;Double Bucky<br>(Sung to the tune of "Rubber Duckie")&nbsp;&nbsp;&nbsp;Double bucky, you''re the one!&nbsp;You make my keyboard lots of fun<br>Double bucky, an additional bit or two:<br>(Vo-vo-de-o!)<br>Control and Meta side by side,<br>Augmented ASCII, nine bits wide!<br>Double bucky, a half a thousand glyphs, plus a few!&nbsp;&nbsp;Double bucky, left and right&nbsp;OR''d together, outta sight!<br>Double bucky, I''d like a whole word of<br>Double bucky, I''m happy I heard of<br>Double bucky, I''d like a whole word of you!&nbsp;<br>&nbsp;-- (C) 1978 by Guy L. Steele, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"According to the Rand McNally Places-Rated Almanac, the best place to&nbsp;live in America is the city of Pittsburgh.  The city of New York came&nbsp;in twenty-fifth.  Here in New York we really don''t care too much.<br>Because we know that we could beat up their city anytime."<br>&nbsp;-- David Letterman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To those accustomed to the precise, structured methods of conventional&nbsp;system development, exploratory development techniques may seem messy,<br>inelegant, and unsatisfying.  But it''s a question of congruence:<br>precision and flexibility may be just as disfunctional in novel,<br>uncertain situations as sloppiness and vacillation are in familiar,<br>well-defined ones.  Those who admire the massive, rigid bone structures&nbsp;of dinosaurs should remember that jellyfish still enjoy their very&nbsp;secure ecological niche.<br>&nbsp;-- Beau Sheil, "Power Tools for Programmers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If A = B and B = C, then A = C, except where void or prohibited by law.<br>&nbsp;-- Roy Santoro')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are many intelligent species in the universe.  They all own&nbsp;cats.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eat drink and be merry, for tomorrow they may make it illegal.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Take your dying with some seriousness, however.  Laughing on the way to&nbsp;your execution is not generally understood by less advanced life forms,<br>and they''ll call you crazy.<br>&nbsp;-- "Messiah''s Handbook: Reminders for the Advanced Soul"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I can feel for her because, although I have never been an Alaskan&nbsp;prostitute dancing on the bar in a spangled dress, I still get very&nbsp;bored with washing and ironing and dishwashing and cooking day after&nbsp;relentless day.<br>&nbsp;-- Betty MacDonald')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... If forced to travel on an airplane, try and get in the cabin with&nbsp;the Captain, so you can keep an eye on him and nudge him if he falls&nbsp;asleep or point out any mountains looming up ahead ...<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The problem with engineers is that they tend to cheat in order to get&nbsp;results.<br>&nbsp;The problem with mathematicians is that they tend to work on toy&nbsp;problems in order to get results.<br>&nbsp;The problem with program verifiers is that they tend to cheat at toy&nbsp;problems in order to get results.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If I am elected, the concrete barriers around the WHITE HOUSE will be&nbsp;replaced by tasteful foam replicas of ANN MARGARET!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An American''s a person who isn''t afraid to criticize the President but&nbsp;is always polite to traffic cops.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Familiarity breeds attempt')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whom the gods wish to destroy they first call promising.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You have acquired a scroll entitled ''irk gleknow mizk''(n).--More--&nbsp;&nbsp;This is an IBM Manual scroll.--More--&nbsp;&nbsp;You are permanently confused.<br>&nbsp;-- Dave Decot')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Help stamp out and abolish redundancy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kiss your keyboard goodbye!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Excess on occasion is exhilarating.  It prevents moderation from&nbsp;acquiring the deadening effect of a habit.<br>&nbsp;-- W. Somerset Maugham')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'She missed an invaluable opportunity to give him a look that you could&nbsp;have poured on a waffle ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The two most common things in the universe are hydrogen and&nbsp;stupidity."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once upon a time, when I was training to be a mathematician, a group of&nbsp;us bright young students taking number theory discovered the names of&nbsp;the smaller prime numbers.<br>&nbsp;2:  The Odd Prime --<br>It''s the only even prime, therefore is odd.  QED.<br>3:  The True Prime --<br>Lewis Carroll: "If I tell you three times, it''s true."&nbsp;31: The Arbitrary Prime --<br>Determined by unanimous unvote.  We needed an arbitrary prime<br>in case the prof asked for one, and so had an election.  91<br>received the most votes (well, it *looks* prime) and 3+4i the<br>next most.  However, 31 was the only candidate to receive none<br>at all.<br>&nbsp;Since the composite numbers are formed from primes, their qualities are&nbsp;derived from those primes.  So, for instance, the number 6 is "odd but&nbsp;true", while the powers of 2 are all extremely odd numbers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real software engineers don''t debug programs, they verify correctness.<br>This process doesn''t necessarily involve execution of anything on a&nbsp;computer, except perhaps a Correctness Verification Aid package.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;William Safire''s Rules for Writers:<br>&nbsp;Remember to never split an infinitive.  The passive voice should never&nbsp;be used.  Do not put statements in the negative form.  Verbs have to&nbsp;agree with their subjects.  Proofread carefully to see if you words&nbsp;out.  If you reread your work, you can find on rereading a great deal&nbsp;of repetition can be avoided by rereading and editing.  A writer must&nbsp;not shift your point of view.  And don''t start a sentence with a&nbsp;conjunction.  (Remember, too, a preposition is a terrible word to end a&nbsp;sentence with.)  Don''t overuse exclamation marks!!  Place pronouns as&nbsp;close as possible, especially in long sentences, as of 10 or more&nbsp;words, to their antecedents.  Writing carefully, dangling participles&nbsp;must be avoided.  If any word is improper at the end of a sentence, a&nbsp;linking verb is.  Take the bull by the hand and avoid mixing&nbsp;metaphors.  Avoid trendy locutions that sound flaky.  Everyone should&nbsp;be careful to use a singular pronoun with singular nouns in their&nbsp;writing.  Always pick on the correct idiom.  The adverb always follows&nbsp;the verb.  Last but not least, avoid cliches like the plague; seek&nbsp;viable alternatives.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"God gives burdens; also shoulders"&nbsp;&nbsp;Jimmy Carter cited this Jewish saying in his concession speech at the&nbsp;end of the 1980 election.  At least he said it was a Jewish saying; I&nbsp;can''t find it anywhere.  I''m sure he''s telling the truth though; why&nbsp;would he lie about a thing like that?<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Unquestionably, there is progress.  The average American now pays out&nbsp;twice as much in taxes as he formerly got in wages.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I profoundly believe it takes a lot of practice to become a moral&nbsp;slob."<br>&nbsp;-- William F. Buckley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One of the rules of Busmanship, New York style, is never surrender your&nbsp;seat to another passenger.  This may seem callous, but it is the best&nbsp;way, really.  If one passenger were to give a seat to someone who&nbsp;fainted in the aisle, say, the others on the bus would become&nbsp;disoriented and imagine they were in Topeka, Kansas.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t steal; thou''lt never thus compete successfully in business.<br>Cheat.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"... The name of the song is called ''Haddocks'' Eyes''!"<br>"Oh, that''s the name of the song, is it?" Alice said, trying to&nbsp;feel interested.<br>"No, you don''t understand," the Knight said, looking a little&nbsp;vexed.  "That''s what the name is called.  The name really is, ''The Aged&nbsp;Aged Man.''"<br>"Then I ought to have said "That''s what the song is called''?"&nbsp;Alice corrected herself.<br>"No, you oughtn''t:  that''s quite another thing!  The song is&nbsp;called ''Ways and Means'':  but that''s only what it is called you know!"<br>"Well, what is the song then?" said Alice, who was by this time&nbsp;completely bewildered.<br>"I was coming to that," the Knight said.  "The song really is&nbsp;"A-sitting on a Gate":  and the tune''s my own invention."<br>&nbsp;-- Lewis Carroll, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While most peoples'' opinions change, the conviction of their&nbsp;correctness never does.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When the government bureau''s remedies don''t match your problem, you&nbsp;modify the problem, not the remedy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Half Moon tonight.  (At least it''s better than no Moon at all.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Take my word for it, the silliest woman can manage a clever man, but it&nbsp;needs a very clever woman to manage a fool.<br>&nbsp;-- Kipling')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A classic is something that everybody wants to have read and nobody&nbsp;wants to read.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My love, he''s mad, and my love, he''s fleet,<br>And a wild young wood-thing bore him!&nbsp;The ways are fair to his roaming feet,<br>And the skies are sunlit for him.<br>As sharply sweet to my heart he seems<br>As the fragrance of acacia.<br>My own dear love, he is all my dreams --<br>And I wish he were in Asia.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While you don''t greatly need the outside world, it''s still very&nbsp;reassuring to know that it''s still there.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You have a tendency to feel you are superior to most computers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lewis''s Law of Travel:<br>The first piece of luggage out of the chute doesn''t belong to&nbsp;anyone, ever.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Abandon the search for Truth; settle for a good fantasy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Show respect for age.  Drink good Scotch for a change.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Computers can figure out all kinds of problems, except the things in&nbsp;the world that just don''t add up.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Watson''s Law:<br>The reliability of machinery is inversely proportional to the&nbsp;number and significance of any persons watching it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #19:<br>&nbsp;Q:  Doctor, how many autopsies have you performed on dead people?&nbsp;A:  All my autopsies have been performed on dead people.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Play Rogue, visit exotic locations, meet strange creatures and kill&nbsp;them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''ll carry your books, I''ll carry a tune, I''ll carry on, carry over,<br>carry forward, Cary Grant, cash & carry, Carry Me Back To Old Virginia,<br>I''ll even Hara Kari if you show me how, but I will *not* carry a gun."<br>&nbsp;-- Hawkeye, M*A*S*H')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You could get a new lease on life -- if only you didn''t need the first&nbsp;and last month in advance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Disclaimer: "These opinions are my own, though for a small fee they be&nbsp;yours too."<br>&nbsp;-- Dave Haynie')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s easier said than done."&nbsp;&nbsp;... and if you don''t believe it, try proving that it''s easier done than&nbsp;said, and you''ll see that "it''s easier said that `it''s easier done than&nbsp;said'' than it is done", which really proves that "it''s easier said than&nbsp;done".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A banker is a fellow who lends you his umbrella when the sun is shining&nbsp;and wants it back the minute it begins to rain.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'TV is chewing gum for the eyes.<br>&nbsp;-- Frank Lloyd Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I must have slipped a disk -- my pack hurts')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"I cannot read the fiery letters," said Frito Bugger in a&nbsp;quavering voice.<br>"No," said GoodGulf, "but I can.  The letters are Elvish, of&nbsp;course, of an ancient mode, but the language is that of Mordor, which&nbsp;I will not utter here.  They are lines of a verse long known in&nbsp;Elven-lore:<br><br>"This Ring, no other, is made by the elves,<br>Who''d pawn their own mother to grab it themselves.<br>Ruler of creeper, mortal, and scallop,<br>This is a sleeper that packs quite a wallop.<br>The Power almighty rests in this Lone Ring.<br>The Power, alrighty, for doing your Own Thing.<br>If broken or busted, it cannot be remade.<br>If found, send to Sorhed (with postage prepaid)."<br>&nbsp;-- Harvard Lampoon, "Bored of the Rings"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Justice always prevails ... three times out of seven!<br>&nbsp;-- Michael J. Wagner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Swahili, n.:<br>The language used by the National Enquirer to print their&nbsp;retractions.<br>&nbsp;-- Johnny Hart')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Although written many years ago, Lady Chatterley''s Lover has just been&nbsp;reissued by the Grove Press, and this pictorial account of the&nbsp;day-to-day life of an English gamekeeper is full of considerable&nbsp;interest to outdoor minded readers, as it contains many passages on&nbsp;pheasant-raising, the apprehending of poachers, ways to control vermin,<br>and other chores and duties of the professional gamekeeper.<br>Unfortunately, one is obliged to wade through many pages of extraneous&nbsp;material in order to discover and savour those sidelights on the&nbsp;management of a midland shooting estate, and in this reviewer''s opinion&nbsp;the book cannot take the place of J. R. Miller''s "Practical&nbsp;Gamekeeping."<br>&nbsp;-- Ed Zern, "Field and Stream" (Nov. 1959)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Crime does not pay ... as well as politics.<br>&nbsp;-- A. E. Newman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The world is coming to an end ... SAVE YOUR BUFFERS!!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An idea is an eye given by God for the seeing of God.  Some of these&nbsp;eyes we cannot bear to look out of, we blind them as quickly as&nbsp;possible.<br>&nbsp;-- Russell Hoban, "Pilgermann"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any clod can have the facts, but having opinions is an art.<br>&nbsp;-- Charles McCabe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Worst Month of 1981 for Downhill Skiing:<br>August.  The lines are the shortest, though.<br>&nbsp;-- Steve Rubenstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New York''s got the ways and means:<br>Just won''t let you be.<br>&nbsp;-- The Grateful Dead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One Page Principle:<br>A specification that will not fit on one page of 8.5x11 inch&nbsp;paper cannot be understood.<br>&nbsp;-- Mark Ardis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Power corrupts.  Absolute power is kind of neat"<br>&nbsp;-- John Lehman, Secretary of the Navy 1981-1987')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s bad luck to be superstitious."<br>&nbsp;-- Andrew W. Mathis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An exotic journey in downtown Newark is in your future.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"For I perceive that behind this seemingly unrelated sequence&nbsp;of events, there lurks a singular, sinister attitude of mind."&nbsp;<br>"Whose?"&nbsp;<br>"MINE! HA-HA!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;The men sat sipping their tea in silence.  After a while the&nbsp;klutz said, "Life is like a bowl of sour cream."&nbsp;<br>"Like a bowl of sour cream?" asked the other.  "Why?"&nbsp;<br>"How should I know?  What am I, a philosopher?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Harrisberger''s Fourth Law of the Lab:<br>Experience is directly proportional to the amount of equipment&nbsp;ruined.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A is for Amy who fell down the stairs, B is for Basil assaulted by bears.<br>C is for Clair who wasted away, D is for Desmond thrown out of the sleigh.<br>E is for Ernest who choked on a peach, F is for Fanny, sucked dry by a leech.<br>G is for George, smothered under a rug, H is for Hector, done in by a thug.<br>I is for Ida who drowned in the lake, J is for James who took lye, by mistake.<br>K is for Kate who was struck with an axe, L is for Leo who swallowed some tacks.<br>M is for Maud who was swept out to sea, N is for Nevil who died of enui.<br>O is for Olive, run through with an awl, P is for Prue, trampled flat in a brawl&nbsp;Q is for Quinton who sank in a mire, R is for Rhoda, consumed by a fire.<br>S is for Susan who parished of fits, T is for Titas who flew into bits.<br>U is for Una  who slipped down a drain, V is for Victor, squashed under a train.<br>W is for Winie, embedded in ice, X is for Xercies, devoured by mice.<br>Y is for Yoric whose head was bashed in, Z is for Zilla who drank too much gin.<br>&nbsp;-- Edward Gorey "The Gastly Crumb Tines"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mr. Cole''s Axiom:<br>The sum of the intelligence on the planet is a constant; the&nbsp;population is growing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'War hath no fury like a non-combatant.<br>&nbsp;-- Charles Edward Montague')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I don''t drive around the park,<br>I''m pretty sure to make my mark.<br>If I''m in bed each night by ten,<br>I may get back my looks again.<br>If I abstain from fun and such,<br>I''ll probably amount to much:<br>But I shall stay the way I am,<br>Because I do not give a damn.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Kennedy Constant:<br>Don''t get mad -- get even.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vila: "I think I have just made the biggest mistake of my life."&nbsp;Orac: "It is unlikely.  I would predict there are far greater mistakes&nbsp;      waiting to be made by someone with your obvious talent for it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You need only reflect that one of the best ways to get yourself a&nbsp;reputation as a dangerous citizen these days is to go about repeating&nbsp;the very phrases which our founding fathers used in the struggle for&nbsp;independence.<br>&nbsp;-- Charles A. Beard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You do not have mail.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To be intoxicated is to feel sophisticated but not be able to say it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never tell a lie unless it is absolutely convenient.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One, with God, is always a majority, but many a martyr has been burned&nbsp;at the stake while the votes were being counted.<br>&nbsp;-- Thomas B. Reed')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t worry over what other people are thinking about you.  They''re too&nbsp;busy worrying over what you are thinking about them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When in doubt, do what the President does -- guess.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'i''m living so far beyond my income that we may almost be said to be&nbsp;living apart.<br>&nbsp;-- e. e. cummings')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have you reconsidered a computer career?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Snacktrek, n.:<br>The peculiar habit, when searching for a snack, of constantly&nbsp;returning to the refrigerator in hopes that something new will have&nbsp;materialized.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s not an optical illusion, it just looks like one.<br>&nbsp;-- Phil White')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I can resist anything but temptation."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m very good at integral and differential calculus,<br>I know the scientific names of beings animalculous:<br>In short, in matters vegetable, animal, and mineral,<br>I am the very model of a modern Major-General.<br>&nbsp;-- Gilbert & Sullivan, "Pirates of Penzance"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A new dramatist of the absurd&nbsp;Has a voice that will shortly be heard.<br>I learn from my spies<br>He''s about to devise&nbsp;An unprintable three-letter word.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Underlying Principle of Socio-Genetics:<br>Superiority is recessive.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sauron is alive in Argentina!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Spirtle, n.:<br>The fine stream from a grapefruit that always lands right in&nbsp;your eye.<br>&nbsp;-- Sniglets, "Rich Hall & Friends"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;If you''re like most homeowners, you''re afraid that many repairs&nbsp;around your home are too difficult to tackle.  So, when your furnace&nbsp;explodes, you call in a so-called professional to fix it.  The&nbsp;"professional" arrives in a truck with lettering on the sides and&nbsp;deposits a large quantity of tools and two assistants who spend the&nbsp;better part of the week in your basement whacking objects at random&nbsp;with heavy wrenches, after which the "professional" returns and gives&nbsp;you a bill for slightly more money than it would cost you to run a&nbsp;successful campaign for the U.S. Senate.<br>And that''s why you''ve decided to start doing things yourself.<br>You figure, "If those guys can fix my furnace, then so can I.  How&nbsp;difficult can it be?"<br>Very difficult.  In fact, most home projects are impossible,<br>which is why you should do them yourself.  There is no point in paying&nbsp;other people to screw things up when you can easily screw them up&nbsp;yourself for far less money.  This article can help you.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'FORTUNE''S PARTY TIPS&nbsp;&nbsp;#14&nbsp;&nbsp;Tired of finding that other people are helping themselves to your good&nbsp;liquor at BYOB parties?  Take along a candle, which you insert and&nbsp;light after you''ve opened the bottle.  No one ever expects anything&nbsp;drinkable to be in a bottle which has a candle stuck in its neck.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People who have what they want are very fond of telling people who&nbsp;haven''t what they want that they don''t want it.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A student who changes the course of history is probably taking an&nbsp;exam.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'America may be unique in being a country which has leapt from barbarism&nbsp;to decadence without touching civilization.<br>&nbsp;-- John O''Hara')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Ruffed Pandanga of Borneo and Rotherham spreads out his feathers in&nbsp;his courtship dance and imitates Winston Churchill and Tommy Cooper on&nbsp;one leg.  The padanga is dying out because the female padanga doesn''t&nbsp;take it too seriously.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Most fish live underwater, which is a terrible place to have sex&nbsp;because virtually anywhere you lie down there will be stinging crabs&nbsp;and large quantities of little fish staring at you with buggy little&nbsp;eyes.  So generally when two fish want to have sex, they swim around&nbsp;and around for hours, looking for someplace to go, until finally the&nbsp;female gets really tired and has a terrible headache, and she just&nbsp;dumps her eggs right on the sand and swims away.  Then the male, driven&nbsp;by some timeless, noble instinct for survival, eats the eggs.  So the&nbsp;truth is that fish don''t reproduce at all, but there are so many of&nbsp;them that it doesn''t make any difference.<br>&nbsp;-- Dave Barry, "Sex and the Single Amoeba: What Every<br>&nbsp;   Teen Should Know"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Thank goodness modern convenience is a thing of the remote future.<br>&nbsp;-- Pogo, by Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A vacuum is a hell of a lot better than some of the stuff that nature&nbsp;replaces it with.<br>&nbsp;-- Tennessee Williams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this country needs is a good five cent microcomputer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If only one could get that wonderful feeling of accomplishment without&nbsp;having to accomplish anything.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Happiness, n.:<br>An agreeable sensation arising from contemplating the misery of&nbsp;another.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Steele''s Plagiarism of Somebody''s Philosophy:<br>Everybody should believe in something -- I believe I''ll have&nbsp;another drink.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Smoking is one of the leading causes of statistics.<br>&nbsp;-- Fletcher Knebel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Behold the warranty ... the bold print giveth and the fine print taketh&nbsp;away.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The only way to get rid of a temptation is to yield to it.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Excellent day to have a rotten day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Travel important today; Internal Revenue men arrive tomorrow.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no TRUTH.  There is no REALITY.  There is no CONSISTENCY.<br>There are no ABSOLUTE STATEMENTS   I''m very probably wrong.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'SAGITTARIUS (Nov 22 - Dec 21)<br>You are optimistic and enthusiastic.  You have a reckless<br>tendency to rely on luck since you lack talent.  The majority<br>of Sagittarians are drunks or dope fiends or both.  People<br>laugh at you a great deal.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We are going to give a little something, a few little years more, to&nbsp;socialism, because socialism is defunct.  It dies all by itself.  The&nbsp;bad thing is that socialism, being a victim of its ... Did I say&nbsp;socialism?<br>&nbsp;-- Fidel Castro')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We''re deep into the holiday gift-giving season, as you can tell from&nbsp;the fact that everywhere you look, you see jolly old St. Nick urging&nbsp;you to purchase things, to the point where you want to slug him right&nbsp;in his bowl full of jelly.<br>&nbsp;-- Dave Barry, "Simple, Homespun Gifts"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'PLUNDERER''S THEME<br>to Supercalifragilisticexpialidocius)<br>&nbsp;Pillage, rape, and loot and burn, but all in moderation.<br>If you do the things we say, then you''ll soon rule the nation.<br>Kill your foes and enemies and then kill your relations.<br>Pillage, rape, and loot and burn, but all in moderation.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A good question is never answered.  It is not a bolt to be tightened&nbsp;into place but a seed to be planted and to bear more seed toward the&nbsp;hope of greening the landscape of idea.<br>&nbsp;-- John Ciardi')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The gentlemen looked one another over with microscopic carelessness.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Re graphics: A picture is worth 10K words -- but only those to describe&nbsp;the picture.  Hardly any sets of 10K words can be adequately described&nbsp;with pictures.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"355/113 -- Not the famous irrational number PI, but an incredible&nbsp;simulation!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I used to work in a fire hydrant factory.  You couldn''t park anywhere&nbsp;near the place.<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After I run your program, let''s make love like crazed weasels, OK?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Every group has a couple of experts.  And every group has at least one&nbsp;idiot.  Thus are balance and harmony (and discord) maintained.  It''s&nbsp;sometimes hard to remember this in the bulk of the flamewars that all&nbsp;of the hassle and pain is generally caused by one or two&nbsp;highly-motivated, caustic twits."<br>&nbsp;-- Chuq Von Rospach, about Usenet')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If anything can go wrong, it will.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You don''t have to think too hard when you talk to teachers.<br>&nbsp;-- J. D. Salinger')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A fool-proof method for sculpting an elephant: first, get a huge block&nbsp;of marble; then you chip away everything that doesn''t look like an&nbsp;elephant.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Help a swallow land at Capistrano.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What is the difference between a Turing machine and the modern&nbsp;computer?  It''s the same as that between Hillary''s ascent of Everest&nbsp;and the establishment of a Hilton on its peak.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'From the Pro 350 Pocket Service Guide, p. 49, Step 5 of the&nbsp;instructions on removing an I/O board from the card cage, comes a new&nbsp;experience in sound:<br><br>5.  Turn the handle to the right 90 degrees.  The pin-spreading<br>    sound is normal for this type of connector.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Truthful, adj.:<br>Dumb and illiterate.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fine day to throw a party.  Throw him as far as you can.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #29:<br>&nbsp;THE JUDGE: Now, as we begin, I must ask you to banish all present<br>   information and prejudice from your minds, if you have<br>   any ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Aleph-null bottles of beer on the wall,<br>Aleph-null bottles of beer,<br>You take one down, and pass it around,<br>Aleph-null bottles of beer on the wall.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t believe in astrology.  But then I''m an Aquarius, and Aquarians&nbsp;don''t believe in astrology."<br>&nbsp;-- James R. F. Quirk')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What is wanted is not the will to believe, but the will to find out,<br>which is the exact opposite."<br>&nbsp;-- Bertrand Russell, "Skeptical_Essays", 1928')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One thing the inventors can''t seem to get the bugs out of is fresh&nbsp;paint.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old," said the youth, "and your programs don''t run,<br>And there isn''t one language you like:<br>Yet of useful suggestions for help you have none --<br>Have you thought about taking a hike?"&nbsp;&nbsp;"Since I never write programs," his father replied,<br>"Every language looks equally bad:<br>Yet the people keep paying to read all my books<br>And don''t realize that they''ve been had."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Drink Canada Dry!  You might not succeed, but it *__^H^His* fun trying.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is illegal to drive more than two thousand sheep down Hollywood&nbsp;Boulevard at one time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'TAURUS (Apr 20 - May 20)<br>You are practical and persistent.  You have a dogged<br>determination and work like hell.  Most people think you are<br>stubborn and bull headed.  You are a Communist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If there is a possibility of several things going wrong, the one that&nbsp;will cause the most damage will be the one to go wrong.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In 1914, the first crossword puzzle was printed in a newspaper.  The&nbsp;creator received $4000 down ... and $3000 across.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;GREAT MOMENTS IN AMERICAN HISTORY #21 -- July 30, 1917&nbsp;&nbsp;On this day, New York City hotel detectives burst in and caught then-&nbsp;Senator Warren G. Harding in bed with an underage girl.  He bought them&nbsp;off with a $20 bribe, and later remarked thankfully, "I thought I&nbsp;wouldn''t get out of that under $1000!"  Always one to learn from his&nbsp;mistakes, in later years President Harding carried on his affairs in a&nbsp;tiny closet in the White House Cabinet Room while Secret Service men&nbsp;stood lookout.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You should emulate your heros, but don''t carry it too far.  Especially&nbsp;if they are dead.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Of what you see in books, believe 75%.  Of newspapers, believe 50%.<br>And of TV news, believe 25% -- make that 5% if the anchorman wears a&nbsp;blazer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'They also surf who only stand on waves.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I think we can all agree that there is not enough common courtesy shown&nbsp;... HEY!  PAY ATTENTION WHEN I''M TALKING TO YOU DAMMIT!  I said I think&nbsp;we can all agree that there is not enough common courtesy shown today.<br>When we take the time to be courteous to each other, we find that we&nbsp;are happier and less likely to engage in nuclear war.  This point was&nbsp;driven home by the recent summit talks, where Nancy Reagan and Raisa&nbsp;Gorbachev, each of whose husband thinks the other''s husband is vermin,<br>were able to sit down at a high-level tea and engage in courteous&nbsp;conversation ...<br>&nbsp;-- Dave Barry, "The Stuff of Etiquette"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Schnuffel, n.:<br>A dog''s practice of continuously nuzzling in your crotch in&nbsp;mixed company.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you know absolutely nothing about the topic, make your forecast by&nbsp;asking a carefully selected probability sample of 300 others who don''t&nbsp;know the answer either.<br>&nbsp;-- Edgar R. Fiedler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing is illegal if one hundred businessmen decide to do it.<br>&nbsp;-- Andrew Young')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'O''Toole''s Commentary on Murphy''s Law:<br>Murphy was an optimist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sure he''s sharp as a razor ... he''s a two-dimensional pinhead!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A long-forgotten loved one will appear soon.  Buy the negatives at any&nbsp;price.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing recedes like success.<br>&nbsp;-- Walter Winchell')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''m doing door-to-door collecting for&nbsp;static cling."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It shall be unlawful for any suspicious person to be within the&nbsp;municipality.<br>&nbsp;-- Local ordinance, Euclid Ohio')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can''t survive by sucking the juice from a wet mitten."<br>&nbsp;-- Charles Schulz, "Things I''ve Had to Learn Over and<br>&nbsp;   Over and Over"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Decision maker, n.:<br>The person in your office who was unable to form a task force&nbsp;before the music stopped.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'BULLWINKLE: "You just leave that to my pal.  He''s the brains of the<br>    outfit."&nbsp;GENERAL:    "What does that make YOU?"&nbsp;BULLWINKLE: "What else?  An executive..."<br>&nbsp;-- Jay Ward')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you put garbage in a computer nothing comes out but garbage.  But&nbsp;this garbage, having passed through a very expensive machine, is&nbsp;somehow enobled and none dare criticize it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Did you know that the voice tapes easily identify the Russian pilot&nbsp;that shot down the Korean jet?  At one point he definitely states:<br><br>"Natasha!  First we shoot jet, then we go after moose and<br>squirrel."&nbsp;<br>&nbsp;-- ihuxw!tommyo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A citizen of America will cross the ocean to fight for democracy, but&nbsp;won''t cross the street to vote in a national election.<br>&nbsp;-- Bill Vaughan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Uncle Ed''s Rule of Thumb:<br>Never use your thumb for a rule.  You''ll either hit it with a&nbsp;hammmer or get a splinter in it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can''t hold a man down without staying down with him.<br>&nbsp;-- Booker T. Washington')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Are you a turtle?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ll defend to the death your right to say that, but I never said I''d&nbsp;listen to it!<br>&nbsp;-- Tom Galloway with apologies to Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Abstainer, n.:<br>A weak person who yields to the temptation of denying himself a&nbsp;pleasure.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;I disapprove of the F-word, not because it''s dirty, but because&nbsp;we use it as a substitute for thoughtful insults, and it frequently&nbsp;leads to violence.  What we ought to do, when we anger each other, say,<br>in traffic, is exchange phone numbers, so that later on, when we''ve had&nbsp;time to think of witty and learned insults or look them up in the&nbsp;library, we could call each other up:<br>&nbsp;     You: Hello?  Bob?&nbsp;     Bob: Yes?&nbsp;     You: This is Ed.  Remember?  The person whose parking space you&nbsp;          took last Thursday?  Outside of Sears?&nbsp;     Bob: Oh yes!  Sure!  How are you, Ed?&nbsp;     You: Fine, thanks.  Listen, Bob, the reason I''m calling is:<br>  "Madam, you may be drunk, but I am ugly, and ..."  No, wait.<br>  I mean:  "you may be ugly, but I am Winston Churchill<br>  and ..."  No, wait.  (Sound of reference book thudding onto<br>  the floor.)  S-word.  Excuse me.  Look, Bob, I''m going to<br>  have to get back to you.<br>     Bob: Fine.<br>&nbsp;-- Dave Barry, "$#$%#^%!^%&@%@!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve enjoyed just about as much of this as I can stand.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A witty saying proves nothing."<br>&nbsp;-- Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Magnet, n.: Something acted upon by magnetism&nbsp;&nbsp;Magnetism, n.: Something acting upon a magnet.<br>&nbsp;The two definition immediately foregoing are condensed from the works&nbsp;of one thousand eminent scientists, who have illuminated the subject&nbsp;with a great white light, to the inexpressible advancement of human&nbsp;knowledge.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"For an adequate time call 555-3321"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Love is a snowmobile racing across the tundra and then suddenly it&nbsp;flips over, pinning you underneath.  At night, the ice weasels come."<br>&nbsp;-- Matt Groening')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'America was discovered by Amerigo Vespucci and was named after him,<br>until people got tired of living in a place called "Vespuccia" and&nbsp;changed its name to "America".<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You know you''ve been spending too much time on the computer when your&nbsp;friend misdates a check, and you suggest adding a "++" to fix it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Weinberg''s Principle:<br>An expert is a person who avoids the small errors while&nbsp;sweeping on to the grand fallacy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All other things being equal, a bald man cannot be elected President of&nbsp;the United States.<br>&nbsp;-- Vic Gold')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d rather have a bottle in front of me than a frontal lobotomy."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Human beings were created by water to transport it uphill.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How doth the VAX''s C compiler&nbsp;Improve its object code.<br>And even as we speak does it&nbsp;Increase the system load.<br>&nbsp;How patiently it seems to run&nbsp;And spit out error flags,<br>While users, with frustration, all&nbsp;Tear their clothes to rags.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He did decide, though, that with more time and a great deal of mental&nbsp;effort, he could probably turn the activity into an acceptable&nbsp;perversion."<br>&nbsp;-- Mick Farren, "When Gravity Fails"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The goal of Computer Science is to build something that will last at&nbsp;least until we''ve finished building it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Two can Live as Cheaply as One for Half as Long.<br>&nbsp;-- Howard Kandel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every successful person has had failures but repeated failure is no&nbsp;guarantee of eventual success.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What the large print giveth, the small print taketh away.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I was gratified to be able to answer promptly, and I did.  I said I&nbsp;didn''t know."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What I want is all of the power and none of the responsibility.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"No self-respecting fish would want to be wrapped in that kind of&nbsp;paper."<br>&nbsp;-- Mike Royko on the Chicago Sun-Times after it was<br>&nbsp;   taken over by Rupert Murdoch')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'WHERE CAN THE MATTER BE&nbsp;<br>Oh, dear, where can the matter be<br>When it''s converted to energy?<br>There is a slight loss of parity.<br>Johnny''s so long at the fair.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One of the oldest problems puzzled over in the Talmud is: "Why did God&nbsp;create goyim?"  The generally accepted answer is "________^H^H^H^H^H^H^H^Hsomebody has to buy&nbsp;retail."<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I had any humility I would be perfect.<br>&nbsp;-- Ted Turner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Only through hard work and perseverance can one truly suffer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Famous last words:')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #2: RENE&nbsp;&nbsp;Named after the famous French philosopher and mathematician Rene&nbsp;DesCartes, RENE is a language used for artificial intelligence.  The&nbsp;language is being developed at the Chicago Center of Machine Politics&nbsp;and Programming under a grant from the Jane Byrne Victory Fund.  A&nbsp;spokesman described the language as "Just as great as dis [sic] city of&nbsp;ours."&nbsp;&nbsp;The center is very pleased with progress to date.  They say they have&nbsp;almost succeeded in getting a VAX to think. However, sources inside the&nbsp;organization say that each time the machine fails to think it ceases to&nbsp;exist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Contrariwise," continued Tweedledee, "if it was so, it might be, and&nbsp;if it were so, it would be; but as it isn''t, it ain''t.  That''s logic!"<br>&nbsp;-- Lewis Carroll, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can do this in a number of ways.  IBM chose to do all of them.<br>Why do you find that funny?"<br>&nbsp;-- D. Taylor, Computer Science 350')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whenever people agree with me I always feel I must be wrong.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Get forgiveness now -- tomorrow you may no longer feel guilty.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Minnie Mouse is a slow maze learner.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Law of Selective Gravity:<br>An object will fall so as to do the most damage.<br>&nbsp;Jenning''s Corollary:<br>The chance of the bread falling with the buttered side down is&nbsp;directly proportional to the cost of the carpet.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this country needs is a dime that will buy a good five-cent bagel.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you think the problem is bad now, just wait until we''ve solved it.<br>&nbsp;-- Arthur Kasspe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I cannot conceive that anybody will require multiplications at the rate&nbsp;of 40,000 or even 4,000 per hour ...<br>&nbsp;-- F. H. Wales (1936)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The confusion of a staff member is measured by the length of his&nbsp;memos.<br>&nbsp;-- New York Times, Jan. 20, 1981')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Tennessee, it is illegal to shoot any game other than whales from a&nbsp;moving automobile.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eighty percent of air pollution comes from plants and trees.<br>&nbsp;-- Ronald Reagan, famous movie star')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paradise is exactly like where you are right now ... only much, much&nbsp;better.<br>&nbsp;-- Laurie Anderson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A real person has two reasons for doing anything ... a good reason and&nbsp;the real reason.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What garlic is to salad, insanity is to art.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Education is the process of casting false pearls before real swine.<br>&nbsp;-- Irsin Edman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Is it possible that software is not like anything else, that it is&nbsp;meant to be discarded: that the whole point is to always see it as a&nbsp;soap bubble?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s a good thing we don''t get all the government we pay for.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Get Revenge!  Live long enough to be a problem for your children!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Death is life''s way of telling you you''ve been fired.<br>&nbsp;-- R. Geis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lunatic Asylum, n.:<br>The place where optimism most flourishes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He played the king as if afraid someone else would play the ace.<br>&nbsp;-- John Mason Brown, drama critic')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I think that I shall never see&nbsp;A billboard lovely as a tree.<br>Perhaps, unless the billboards fall&nbsp;I''ll never see a tree at all.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The Schizophrenic: An Unauthorized Autobiography"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Computer Science is merely the post-Turing decline in formal systems&nbsp;theory.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real programmers don''t comment their code.  It was hard to write, it&nbsp;should be hard to understand.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After the last of 16 mounting screws has been removed from an access&nbsp;cover, it will be discovered that the wrong access cover has been&nbsp;removed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Captain Penny''s Law:<br>You can fool all of the people some of the time, and some of&nbsp;the people all of the time, but you Can''t Fool Mom.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You may easily play a joke on a man who likes to argue -- agree with&nbsp;him.<br>&nbsp;-- Ed Howe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In 1750 Issac Newton became discouraged when he fell up a flight of&nbsp;stairs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... I''m IMAGINING a sensuous GIRAFFE, CAVORTING in the BACK ROOM of a&nbsp;KOSHER DELI!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pity the meek, for they shall inherit the earth.<br>&nbsp;-- Don Marquis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m a creationist; I refuse to believe that I could have evolved from&nbsp;man."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The use of COBOL cripples the mind; its teaching should, therefore, be&nbsp;regarded as a criminal offense.<br>&nbsp;-- E. W. Dijkstra')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The trouble with being poor is that it takes up all your time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Arkansas legislature passed a law that states that the Arkansas&nbsp;River can rise no higher than to the Main Street bridge in Little&nbsp;Rock.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This life is a test.  It is only a test.  Had this been an actual life,<br>you would have received further instructions as to what to do and where&nbsp;to go.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t abandon hope: your Tom Mix decoder ring arrives tomorrow.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boob''s Law:<br>You always find something in the last place you look.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I belong to no organized party.  I am a Democrat."<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you are a fatalist, what can you do about it?<br>&nbsp;-- Ann Edwards-Duff')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hardware, n.:<br>The parts of a computer system that can be kicked.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I know it all.  I just can''t remember it all at once.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Wit, n.:<br>The salt with which the American Humorist spoils his cookery&nbsp;... by leaving it out.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Preudhomme''s Law of Window Cleaning:<br>It''s on the other side.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All this wheeling and dealing around, why, it isn''t for money, it''s for&nbsp;fun.  Money''s just the way we keep score.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Optimization hinders evolution.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t think so," said Ren''^He Descartes.  Just then, he vanished.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Breast Feeding should not be attempted by fathers with hairy chests,<br>since they can make the baby sneeze and give it wind.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boys are beyond the range of anybody''s sure understanding, at least&nbsp;when they are between the ages of 18 months and 90 years.<br>&nbsp;-- James Thurber')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If Jesus Christ were to come today, people would not even crucify him.<br>They would ask him to dinner, and hear what he had to say, and make fun&nbsp;of it.<br>&nbsp;-- Thomas Carlyle')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;*** System shutdown message from root ***&nbsp;&nbsp;System going down in 60 seconds&nbsp;&nbsp;')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Murphy''s Discovery:<br>Do you know Presidents talk to the country the way men talk to&nbsp;women?  They say, "Trust me, go all the way with me, and everything&nbsp;will be all right."  And what happens?  Nine months later, you''re in&nbsp;trouble!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Math is like love -- a simple idea but it can get complicated.<br>&nbsp;-- R. Drabek')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any sufficiently advanced technology is indistinguishable from a rigged&nbsp;demo.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Living your life is a task so difficult, it has never been attempted&nbsp;before.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The reason it''s called "Grape Nuts" is that it contains "dextrose",<br>which is also sometimes called "grape sugar", and also because "Grape&nbsp;Nuts" is catchier, in terms of marketing, than "A Cross Between Gerbil&nbsp;Food and Gravel", which is what it tastes like.<br>&nbsp;-- Dave Barry, "Tips for Writer''s"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Art is anything you can get away with.<br>&nbsp;-- Marshall McLuhan.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many Martians does it take to screw in a lightbulb?&nbsp;A:  One and a half.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I hate it when my foot falls asleep during the day cause that means&nbsp;it''s going to be up all night."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fifty flippant frogs&nbsp;Walked by on flippered feet&nbsp;And with their slime they made the time&nbsp;Unnaturally fleet.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are four kinds of homicide: felonious, excusable, justifiable,<br>and praiseworthy ...<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Avoid revolution or expect to get shot.  Mother and I will grieve, but&nbsp;we will gladly buy a dinner for the National Guardsman who shot you."<br>&nbsp;-- Dr. Paul Williamson, father of a Kent State student')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hanson''s Treatment of Time:<br>There are never enough hours in a day, but always too many days&nbsp;before Saturday.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Practical people would be more practical if they would take a little&nbsp;more time for dreaming.<br>&nbsp;-- J. P. McEvoy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Keep you Eye on the Ball,<br>Your Shoulder to the Wheel,<br>Your Nose to the Grindstone,<br>Your Feet on the Ground,<br>Your Head on your Shoulders.<br>Now ... try to get something DONE!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Our policy is, when in doubt, do the right thing.<br>&nbsp;-- Roy L. Ash, ex-president Litton Industries')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'BLISS is ignorance')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many journalists does it take to screw in a lightbulb?&nbsp;A:  Three.  One to report it as an inspired government program to bring&nbsp;    light to the people, one to report it as a diabolical government&nbsp;    plot to deprive the poor of darkness, and one to win a pulitzer&nbsp;    prize for reporting that Electric Company hired a lightbulb&nbsp;    assassin to break the bulb in the first place.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The average income of the modern teenager is about 2 a.m.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Veni, Vidi, Visa.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All programmers are playwrights and all computers are lousy actors.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is impossible to make anything foolproof because fools are so&nbsp;ingenious.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Is your job running?  You''d better go catch it!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Keep emotionally active.  Cater to your favorite neurosis.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Boston, it is illegal to hold frog-jumping contests in nightclubs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Absent, adj.:<br>Exposed to the attacks of friends and acquaintances; defamed:<br>slandered.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How many hardware engineers does it take to change a lightbulb?&nbsp;None: "We''ll fix it in software."&nbsp;&nbsp;How many software engineers does it take to change a lightbulb?&nbsp;None: "We''ll document it in the manual."&nbsp;&nbsp;How many tech writers does it take to change a lightbulb?&nbsp;None: "The user can work it out."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The reason computer chips are so small is computers don''t eat much.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If there is no God, who pops up the next Kleenex?<br>&nbsp;-- Art Hoppe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Song Title of the Week:<br>"They''re putting dimes in the hole in my head to see the change&nbsp;in me."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pascal, n.:<br>A programming language named after a man who would turn over in&nbsp;his grave if he knew about it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A rock pile ceases to be a rock pile the moment a single man&nbsp;contemplates it, bearing within him the image of a cathedral.<br>&nbsp;-- Antoine de Saint-Exupery')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this country needs is a good five cent nickel.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This planet has -- or rather had -- a problem, which was this: most of&nbsp;the people living on it were unhappy for pretty much of the time.  Many&nbsp;solutions were suggested for this problem, but most of these were&nbsp;largely concerned with the movements of small green pieces of paper,<br>which is odd because on the whole it wasn''t the small green pieces of&nbsp;paper that were unhappy.<br>&nbsp;-- Douglas Adams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Legislation proposed in the Illinois State Legislature, May, 1907:<br>"Speed upon county roads will be limited to ten miles an hour&nbsp;unless the motorist sees a bailiff who does not appear to have had a&nbsp;drink in 30 days, when the driver will be permitted to make what he&nbsp;can."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once, adv.:<br>Enough.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A tautology is a thing which is tautological.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be assured that a walk through the ocean of most Souls would scarcely&nbsp;get your Feet wet.  Fall not in Love, therefore: it will stick to your&nbsp;face.<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Old programmers never die.  They just branch to a new address.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The Computer made me do it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fakir, n:<br>A psychologist whose charismatic data have inspired almost&nbsp;religious devotion in his followers, even though the sources seem to&nbsp;have shinnied up a rope and vanished.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There once was a member of Mensa&nbsp;Who was a most excellent fencer.<br>The sword that he used<br>Was his -- (line is refused,<br>And has now been removed by the censor).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hippogriff, n.:<br>An animal (now extinct) which was half horse and half griffin.<br>The griffin was itself a compound creature, half lion and half eagle.<br>The hippogriff was actually, therefore, only one quarter eagle, which&nbsp;is two dollars and fifty cents in gold.  The study of zoology is full&nbsp;of surprises.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the days when Sussman was a novice Minsky once came to him as he sat&nbsp;hacking at the PDP-6.  "What are you doing?", asked Minsky.  "I am&nbsp;training a randomly wired neural net to play Tic-Tac-Toe."  "Why is the&nbsp;net wired randomly?", asked Minsky.  "I do not want it to have any&nbsp;preconceptions of how to play." Minsky shut his eyes.  "Why do you&nbsp;close your eyes?", Sussman asked his teacher.  "So the room will be&nbsp;empty."  At that moment, Sussman was enlightened.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Klein bottle for sale ... inquire within.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In an organization, each person rises to the level of his own&nbsp;incompetency<br>&nbsp;-- The Peter Principle')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is an important and popular fact that things are not always what&nbsp;they seem.  For instance, on the planet Earth, man had always assumed&nbsp;that he was more intelligent than dolphins because he had achieved so&nbsp;much -- the wheel, New York wars and so on -- whilst all the dolphins&nbsp;had ever done was muck about in the water having a good time.  But&nbsp;conversely, the dolphins had always believed that they were far more&nbsp;intelligent than man -- for precisely the same reasons.<br>&nbsp;Curiously enough, the dolphins had long known of the impending&nbsp;destruction of the of the planet Earth and had made many attempts to&nbsp;alert mankind to the danger; but most of their communications were&nbsp;misinterpreted ...<br>&nbsp;-- Douglas Admas "The Hitch-Hikers'' Guide To The<br>&nbsp;   Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Issawi''s Laws of Progress:<br><br>The Course of Progress:<br>&nbsp;Most things get steadily worse.<br><br>The Path of Progress:<br>&nbsp;A shortcut is the longest distance between two points.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There is hopeful symbolism in the fact that flags do not wave in a&nbsp;vacuum."<br>&nbsp;-- Arthur C. Clarke')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A new supply of round tuits has arrived and are available from Mary.<br>Anyone who has been putting off work until they got a round tuit now&nbsp;has no excuse for further procrastination.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '100 buckets of bits on the bus&nbsp;&nbsp;100 buckets of bits&nbsp;Take one down, short it to ground&nbsp;FF buckets of bits on the bus&nbsp;&nbsp;&nbsp;FF buckets of bits on the bus&nbsp;&nbsp;FF buckets of bits&nbsp;Take one down, short it to ground&nbsp;FE buckets of bits on the bus&nbsp;&nbsp;&nbsp;ad infinitum...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Reintegration complete," ZORAC advised.  "We''re back in the universe&nbsp;again ..."  An unusually long pause followed, "... but I don''t know&nbsp;which part.  We seem to have changed our position in space."  A&nbsp;spherical display in the middle of the floor illuminated to show the&nbsp;starfield surrounding the ship.<br>&nbsp;"Several large, artificial constructions are approaching us," ZORAC&nbsp;announced after a short pause.  "The designs are not familiar, but they&nbsp;are obviously the products of intelligence.  Implications: we have been&nbsp;intercepted deliberately by a means unknown, for a purpose unknown, and&nbsp;transferred to a place unknown by a form of intelligence unknown.<br>Apart from the unknowns, everything is obvious."<br>&nbsp;-- James P. Hogan, "Giants Star"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is the business of the future to be dangerous.<br>&nbsp;-- Hawkwind')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hand, n.:<br>A singular instrument worn at the end of a human arm and&nbsp;commonly thrust into somebody''s pocket.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Section 2.4.3.5   AWNS   (Acceptor Wait for New Cycle State).<br>In AWNS the AH function indicates that it has received a&nbsp;multiline message byte.<br>In AWNS the RFD message must be sent false and the DAC message&nbsp;must be sent passive true.<br>The AH function must exit the AWNS and enter:<br>(1)  The ANRS if DAV is false<br>(2)  The AIDS if the ATN message is false and neither:<br>&nbsp;(a)  The LADS is active<br>&nbsp;(b)  Nor LACS is active"&nbsp;<br>&nbsp;-- from the IEEE Standard Digital Interface for<br>&nbsp;   Programmable Instrumentation')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Howe''s Law:<br>Everyone has a scheme that will not work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bell Labs Unix -- Reach out and grep someone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Coward, n.:<br>One who in a perilous emergency thinks with his legs.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The duck hunter trained his retriever to walk on water.  Eager to show&nbsp;off this amazing accomplishment, he asked a friend to go along on his&nbsp;next hunting trip.  Saying nothing, he fired his first shot and, as the&nbsp;duck fell, the dog walked on the surface of the water, retrieved the&nbsp;duck and returned it to his master.<br>"Notice anything?" the owner asked eagerly.<br>"Yes," said his friend, "I see that fool dog of yours can''t&nbsp;swim."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Drugs may be the road to nowhere, but at least they''re the scenic&nbsp;route!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Life would be so much easier if we could just look at the source code.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After living in New York, you trust nobody, but you believe&nbsp;everything.  Just in case.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I think that I shall never see&nbsp;A thing as lovely as a tree.<br>But as you see the trees have gone&nbsp;They went this morning with the dawn.<br>A logging firm from out of town&nbsp;Came and chopped the trees all down.<br>But I will trick those dirty skunks&nbsp;And write a brand new poem called ''Trunks''.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Another possible source of guidance for teenagers is television, but&nbsp;television''s message has always been that the need for truth, wisdom&nbsp;and world peace pales by comparison with the need for a toothpaste that&nbsp;offers whiter teeth *___^H^H^Hand* fresher breath.<br>&nbsp;-- Dave Barry, "Kids Today: They Don''t Know Dum Diddly<br>&nbsp;   Do"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Today is a good day to bribe a high-ranking public official.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Serving coffee on aircraft causes turbulence.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stult''s Report:<br>Our problems are mostly behind us.  What we have to do now is&nbsp;fight the solutions.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old," said the youth, "as I mentioned before,<br>And make errors few people could bear:<br>You complain about everyone''s English but yours --<br>Do you really think this is quite fair?"&nbsp;&nbsp;"I make lots of mistakes," Father William declared,<br>"But my stature these days is so great&nbsp;That no critic can hurt me -- I''ve got them all scared,<br>And to stop me it''s now far too late."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Two sure ways to tell a sexy male; the first is, he has a bad memory.<br>I forget the second."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Don''t worry about people stealing your ideas.  If your ideas are any&nbsp;good, you''ll have to ram them down people''s throats."<br>&nbsp;-- Howard Aiken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicken Soup, n.:<br>An ancient miracle drug containing equal parts of aureomycin,<br>cocaine, interferon, and TLC.  The only ailment chicken soup can''t cure&nbsp;is neurotic dependence on one''s mother.<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You should never wear your best trousers when you go out to fight for&nbsp;freedom and liberty.<br>&nbsp;-- Henrik Ibsen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The only real way to look younger is not to be born so soon."<br>&nbsp;-- Charles Schulz, "Things I''ve Had to Learn Over and<br>&nbsp;   Over and Over"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Micro Credo:<br>Never trust a computer bigger than you can lift.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Keep in mind always the two constant Laws of Frisbee:<br>(1) The most powerful force in the world is that of a disc<br>    straining to land under a car, just out of reach (this<br>    force is technically termed "car suck").<br>(2) Never precede any maneuver by a comment more predictive<br>    than "Watch this!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Arithmetic is being able to count up to twenty without taking off your&nbsp;shoes.<br>&nbsp;-- Mickey Mouse')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hell hath no fury like a bureaucrat scorned.<br>&nbsp;-- Milton Friedman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hire the morally handicapped.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'F u cn rd ths u cnt spl wrth a dm!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A computer, to print out a fact,<br>Will divide, multiply, and subtract.<br>But this output can be<br>No more than debris,<br>If the input was short of exact.<br>&nbsp;-- Gigo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any dramatic series the producers want us to take seriously as a&nbsp;representation of contemporary reality cannot be taken seriously as a&nbsp;representation of anything -- except a show to be ignored by anyone&nbsp;capable of sitting upright in a chair and chewing gum simultaneously.<br>&nbsp;-- Richard Schickel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My pen is at the bottom of a page,<br>Which, being finished, here the story ends:<br>''Tis to be wished it had been sooner done,<br>But stories somehow lengthen when begun.<br>&nbsp;-- Byron')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Law of the Week (this week, from Kentucky):<br>No female shall appear in a bathing suit at any airport in this&nbsp;State unless she is escorted by two officers or unless she is armed&nbsp;with a club.  The provisions of this statute shall not apply to females&nbsp;weighing less than 90 pounds nor exceeding 200 pounds, nor shall it&nbsp;apply to female horses.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'C, n.:<br>A programming language that is sort of like Pascal except more&nbsp;like assembly except that it isn''t very much like either one, or&nbsp;anything else.  It is either the best language available to the art&nbsp;today, or it isn''t.<br>&nbsp;-- Ray Simard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hlade''s Law:<br>If you have a difficult task, give it to a lazy person -- they&nbsp;will find an easier way to do it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t care who does the electing as long as I get to do the&nbsp;nominating"<br>&nbsp;-- Boss Tweed')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many heterosexual males does it take to screw in a light bulb&nbsp;    in San Francisco?&nbsp;A:  Both of them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Let''s say your wedding ring falls into your toaster, and when you stick&nbsp;your hand in to retrieve it, you suffer Pain and Suffering as well as&nbsp;Mental Anguish.  You would sue:<br>&nbsp;* The toaster manufacturer, for failure to include, in the instructions&nbsp;  section that says you should never never never ever stick you hand&nbsp;  into the toaster, the statement "Not even if your wedding ring falls&nbsp;  in there".<br>&nbsp;* The store where you bought the toaster, for selling it to an obvious&nbsp;  cretin like yourself.<br>&nbsp;* Union Carbide Corporation, which is not directly responsible in this&nbsp;  case, but which is feeling so guilty that it would probably send you&nbsp;  a large cash settlement anyway.<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Support your local police force -- steal!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The more we disagree, the more chance there is that at least one of us&nbsp;is right.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The truth of a proposition has nothing to do with its credibility.  And&nbsp;vice versa.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I could drop dead right now, I''d be the happiest man alive!<br>&nbsp;-- Samuel Goldwyn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You know it''s going to be a bad day when you want to put on the clothes&nbsp;you wore home from the party and there aren''t any.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The IQ of the group is the lowest IQ of a member of the group divided&nbsp;by the number of people in the group.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For years a secret shame destroyed my peace --&nbsp;I''d not read Eliot, Auden or MacNiece.<br>But now I think a thought that brings me hope:<br>Neither had Chaucer, Shakespeare, Milton, Pope.<br>&nbsp;-- Justin Richardson.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For every credibility gap, there is a gullibility fill.<br>&nbsp;-- R. Clopton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man is a rational animal who always loses his temper when he is called&nbsp;upon to act in accordance with the dictates of reason.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Disco is to music what Etch-A-Sketch is to art.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'First Rule of History:<br>History doesn''t repeat itself -- historians merely repeat each&nbsp;other.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is better for civilization to be going down the drain than to be&nbsp;coming up it.<br>&nbsp;-- Henry Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Death to all fanatics!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s an old proverb that says just about whatever you want it to.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s nomination for All-Time Champion and Protector of Youthful&nbsp;Morals goes to Representative Clare E. Hoffman of Michigan.  During an&nbsp;impassioned House debate over a proposed bill to "expand oyster and&nbsp;clam research," a sharp-eared informant transcribed the following&nbsp;exchange between our hero and Rep. John D. Dingell, also of Michigan.<br>&nbsp;DINGELL: There are places in the world at the present time where we are<br> having to artificially propagate oysters and clams.<br>HOFFMAN: You mean the oysters I buy are not nature''s oysters?&nbsp;DINGELL: They may or may not be natural.  The simple fact of the matter<br> is that female oysters through their living habits cast out<br> large amounts of seed and the male oysters cast out large<br> amounts of fertilization ...<br>HOFFMAN: Wait a minute!  I do not want to go into that.  There are many<br> teenagers who read The Congressional Record.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Eat, drink, and be merry, for tomorrow you may work."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lowery''s Law:<br>If it jams -- force it.  If it breaks, it needed replacing&nbsp;anyway.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One promising concept that I came up with right away was that you could&nbsp;manufacture personal air bags, then get a law passed requiring that&nbsp;they be installed on congressmen to keep them from taking trips.  Let''s&nbsp;say your congressman was trying to travel to Paris to do a fact-finding&nbsp;study on how the French government handles diseases transmitted by&nbsp;sherbet.  Just when he got to the plane, his mandatory air bag,<br>strapped around his waist, would inflate -- FWWAAAAAAPPPP -- thus&nbsp;rendering him too large to fit through the plane door.  It could also&nbsp;be rigged to inflate whenever the congressman proposed a law.  ("Mr.<br>Speaker, people ask me, why should October be designated as Cuticle&nbsp;Inspection Month?  And I answer that FWWAAAAAAPPPP.") This would save&nbsp;millions of dollars, so I have no doubt that the public would violently&nbsp;support a law requiring airbags on congressmen.  The problem is that&nbsp;your potential market is very small: there are only around 500 members&nbsp;of Congress, and some of them, such as House Speaker "Tip" O''Neil, are&nbsp;already too large to fit on normal aircraft.<br>&nbsp;-- Dave Barry, "''Mister Mediocre'' Restaurants"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Thirty days hath Septober,<br>April, June, and no wonder.<br>all the rest have peanut butter&nbsp;except my father who wears red suspenders."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I was seven years old, I was once reprimanded by my mother for an&nbsp;act of collective brutality in which I had been involved at school.  A&nbsp;group of seven-year-olds had been teasing and tormenting a&nbsp;six-year-old.  "It is always so," my mother said.  "You do things&nbsp;together which not one of you would think of doing alone."  ...<br>Wherever one looks in the world of human organization, collective&nbsp;responsibility brings a lowering of moral standards.  The military&nbsp;establishment is an extreme case, an organization which seems to have&nbsp;been expressly designed to make it possible for people to do things&nbsp;together which nobody in his right mind would do alone.<br>&nbsp;-- Freeman Dyson, "Weapons and Hope"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If all the Chinese simultaneously jumped into the Pacific off a 10 foot&nbsp;platform erected 10 feet off their coast, it would cause a tidal wave&nbsp;that would destroy everything in this country west of Nebraska.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never put off until tomorrow what you can do today.  There might be a&nbsp;law against it by that time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"That boy''s about as sharp as a pound of wet liver"<br>&nbsp;-- Foghorn Leghorn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anything labeled "NEW" and/or "IMPROVED" isn''t.  The label means the&nbsp;price went up.  The label "ALL NEW", "COMPLETELY NEW", or "GREAT NEW"&nbsp;means the price went way up.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He looked at me as if I was a side dish he hadn''t ordered.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eggheads unite!  You have nothing to lose but your yolks.<br>&nbsp;-- Adlai Stevenson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What I''ve done, of course, is total garbage."<br>&nbsp;-- R. Willard, Pure Math 430a')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Colvard''s Logical Premises:<br>All probabilities are 50%.  Either a thing will happen or it<br>won''t.<br>&nbsp;Colvard''s Unconscionable Commentary:<br>This is especially true when dealing with someone you''re<br>attracted to.<br>&nbsp;Grelb''s Commentary<br>Likelihoods, however, are 90% against you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"But what we need to know is, do people want nasally-insertable&nbsp;computers?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The streets are safe in Philadelphia, it''s only the people who make&nbsp;them unsafe.<br>&nbsp;-- Mayor Frank Rizzo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Not only is this incomprehensible, but the ink is ugly and the paper&nbsp;is from the wrong kind of tree."<br>&nbsp;-- Professor W.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m willing to sacrifice anything for this cause, even other people''s&nbsp;lives"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;FIGHTING WORDS&nbsp;&nbsp;Say my love is easy had,<br>Say I''m bitten raw with pride,<br>Say I am too often sad --<br>Still behold me at your side.<br>&nbsp;Say I''m neither brave nor young,<br>Say I woo and coddle care,<br>Say the devil touched my tongue --<br>Still you have my heart to wear.<br>&nbsp;But say my verses do not scan,<br>And I get me another man!<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is not dead!  He''s alive and autographing bibles at Cody''s')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you wish to live wisely, ignore sayings -- including this one.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If A equals success, then the formula is _^HA = _^HX + _^HY + _^HZ.  _^HX is work.  _^HY&nbsp;is play.  _^HZ is keep your mouth shut.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can tell how far we have to go, when FORTRAN is the language of&nbsp;supercomputers.<br>&nbsp;-- Steven Feiner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve had a perfectly wonderful evening.  But this wasn''t it.<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In seeking the unattainable, simplicity only gets in the way.<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... And malt does more than Milton can&nbsp;To justify God''s ways to man<br>&nbsp;-- A. E. Housman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Show me a man who is a good loser and I''ll show you a man who is&nbsp;playing golf with his boss.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ten years of rejection slips is nature''s way of telling you to stop&nbsp;writing.<br>&nbsp;-- R. Geis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d give my right arm to be ambidextrous."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This will be a memorable month -- no matter how hard you try to forget&nbsp;it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fine''s Corollary:<br>Functionality breeds Contempt.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I wouldn''t recommend sex, drugs or insanity for everyone, but they''ve&nbsp;always worked for me."<br>&nbsp;-- Hunter S. Thompson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To err is human, to forgive is Not Company Policy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Liar, n.:<br>A lawyer with a roving commission.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I don''t care for the Sugar Smacks commercial.  I don''t like the idea of&nbsp;a frog jumping on my Breakfast.<br>&nbsp;-- Lowell, Chicago Reader 10/15/82')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"APL is a write-only language.  I can write programs in APL, but I&nbsp;can''t read any of them."<br>&nbsp;-- Roy Keir')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The nice thing about standards is that there are so many of them to&nbsp;choose from.<br>&nbsp;-- Andrew S. Tanenbaum')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Economics, n.:<br>Economics is the study of the value and meaning of J. K.<br>Galbraith ...<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"They''re unfriendly, which is fortunate, really.  They''d be difficult&nbsp;to like."<br>&nbsp;-- Avon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Today is the first day of the rest of your lossage.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I can''t understand why a person will take a year or two to write a&nbsp;novel when he can easily buy one for a few dollars.<br>&nbsp;-- Fred Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A billion here, a couple of billion there -- first thing you know it&nbsp;adds up to be real money.<br>&nbsp;-- Senator Everett McKinley Dirksen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Waiter: "Tea or coffee, gentlemen?"&nbsp;1st customer: "I''ll have tea."&nbsp;2nd customer: "Me, too -- and be sure the glass is clean!"<br>(Waiter exits, returns)<br>Waiter: "Two teas.  Which one asked for the clean glass?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Greene, New York, it is illegal to eat peanuts and walk backwards on&nbsp;the sidewalks when a concert is on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Please take note:')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Army has carried the American ... ideal to its logical conclusion.<br>Not only do they prohibit discrimination on the grounds of race, creed&nbsp;and color, but also on ability.<br>&nbsp;-- T. Lehrer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boy, n.:<br>A noise with dirt on it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The income tax has made more liars out of the American people than golf&nbsp;has.  Even when you make a tax form out on the level, you don''t know&nbsp;when it''s through if you are a crook or a martyr.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Worst Month of the Year:<br>February.  February has only 28 days in it, which means that if&nbsp;you rent an apartment, you are paying for three full days you don''t&nbsp;get.  Try to avoid Februarys whenever possible.<br>&nbsp;-- Steve Rubenstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Scott''s first Law:<br>No matter what goes wrong, it will probably look right.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"This process can check if this value is zero, and if it is, it does&nbsp;something child-like."<br>&nbsp;-- Forbes Burkowski, Computer Science 454')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t knock President Fillmore.  He kept us out of Vietnam.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'World War Three can be averted by adherence to a strictly enforced&nbsp;dress code!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There are some micro-organisms that exhibit characteristics of both&nbsp;plants and animals.  When exposed to light they undergo photosynthesis:<br>and when the lights go out, they turn into animals.  But then again,<br>don''t we all?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fresco''s Discovery:<br>If you knew what you were doing you''d probably be bored.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are people so addicted to exaggeration that they can''t tell the&nbsp;truth without lying.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'San Francisco, n.:<br>Marcel Proust editing an issue of Penthouse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Neckties strangle clear thinking.<br>&nbsp;-- Lin Yutang')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a theory that states: "If anyone finds out what the universe&nbsp;is for it will disappear and be replaced by something more bazaarly&nbsp;inexplicable."&nbsp;&nbsp;There is another theory that states: "This has already happened ...."<br>&nbsp;-- Douglas Adams, "Hitch-Hikers Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The economy depends about as much on economists as the weather does on&nbsp;weather forecasters.<br>&nbsp;-- Jean-Paul Kauffmann')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The reward of a thing well done is to have done it.<br>&nbsp;-- Emerson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Intolerance is the last defense of the insecure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any two philosophers can tell each other all they know in two hours.<br>&nbsp;-- Oliver Wendell Holmes, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"To vacillate or not to vacillate, that is the question ... or is it?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Imagination is the one weapon in the war against reality.<br>&nbsp;-- Jules de Gaultier')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The biggest difference between time and space is that you can''t reuse&nbsp;time.<br>&nbsp;-- Merrick Furst')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'User n.:<br>A programmer who will believe anything you tell him.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''m converting my calendar watch from&nbsp;Julian to Gregorian."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Life is a yo-yo, and mankind ties knots in the string.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What the world *really* needs is a good Automatic Bicycle Sharpener.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Better dead than mellow.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '(null cookie; hope that''s ok)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you wants to get elected president, you''se got to think up some&nbsp;memoraboble homily so''s school kids can be pestered into memorizin'' it,<br>even if they don''t know what it means."<br>&nbsp;-- Walt Kelly, "The Pogo Party"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A great nation is any mob of people which produces at least one honest&nbsp;man a century.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you are about to do an objective and scientific piece of&nbsp;investigation of a topic, it is well to gave the answer firmly in hand,<br>so that you can proceed forthrightly, without being deflected or&nbsp;swayed, directly to the goal.<br>&nbsp;-- Amrom Katz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never hit a man with glasses.  Hit him with a baseball bat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sex is a natural bodily process, like a stroke.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;*** NEWSFLASH ***&nbsp;Russian tanks steamrolling through New Jersey!!!!  Details at eleven!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A large number of installed systems work by fiat.  That is, they work&nbsp;by being declared to work.<br>&nbsp;-- Anatol Holt')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Virtual" means never knowing where your next byte is coming from.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There has been an alarming increase in the number of things you know&nbsp;nothing about.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Error in operator: add beer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God made machine language; all the rest is the work of man.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'With a rubber duck, one''s never alone.<br>&nbsp;-- "The Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... bleakness ... desolation ... plastic forks ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you want your spouse to listen and pay strict attention to every&nbsp;word you say, talk in your sleep.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Last week a cop stopped me in my car.  He asked me if I had a police&nbsp;record.  I said, no, but I have the new DEVO album.  Cops have no sense&nbsp;of humor."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I kiss you, that is a psychological interaction.<br>&nbsp;On the other hand, if I hit you over the head with a brick, that is&nbsp;also a psychological interaction.<br>&nbsp;The difference is that one is friendly and the other is not so&nbsp;friendly.<br>&nbsp;The crucial point is if you can tell which is which.<br>&nbsp;-- Dolph Sharp, "I''m O.K., You''re Not So Hot"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Politician, n.:<br>An eel in the fundamental mud upon which the superstructure of&nbsp;organized society is reared.  When he wriggles, he mistakes the&nbsp;agitation of his tail for the trembling of the edifice.  As compared&nbsp;with the statesman, he suffers the disadvantage of being alive.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am not an Economist.  I am an honest man!"<br>&nbsp;-- Paul McCracken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Congratulations!  You have purchased an extremely fine device that&nbsp;would give you thousands of years of trouble-free service, except that&nbsp;you undoubtably will destroy it via some typical bonehead consumer&nbsp;maneuver.  Which is why we ask you to PLEASE FOR GOD''S SAKE READ THIS&nbsp;OWNER''S MANUAL CAREFULLY BEFORE YOU UNPACK THE DEVICE.  YOU ALREADY&nbsp;UNPACKED IT, DIDN''T YOU?  YOU UNPACKED IT AND PLUGGED IT IN AND TURNED&nbsp;IT ON AND FIDDLED WITH THE KNOBS, AND NOW YOUR CHILD, THE SAME CHILD&nbsp;WHO ONCE SHOVED A POLISH SAUSAGE INTO YOUR VIDEOCASSETTE RECORDER AND&nbsp;SET IT ON "FAST FORWARD", THIS CHILD ALSO IS FIDDLING WITH THE KNOBS,<br>RIGHT?  AND YOU''RE JUST NOW STARTING TO READ THE INSTRUCTIONS,<br>RIGHT???  WE MIGHT AS WELL JUST BREAK THESE DEVICES RIGHT AT THE&nbsp;FACTORY BEFORE WE SHIP THEM OUT, YOU KNOW THAT?<br>&nbsp;-- Dave Barry, "Read This First!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Learned men are the cisterns of knowledge, not the fountainheads.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many IBM types does it take to change a light bulb?&nbsp;A:  100. Ten to do it, and 90 to write document number GC7500439-0001,<br>    Multitasking Incandescent Source System Facility, of which 10% of&nbsp;    the pages state only "This page intentionally left blank", and 20%&nbsp;    of the definitions are of the form "A ...... consists of sequences&nbsp;    of non-blank characters separated by blanks".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Caution: breathing may be hazardous to your health.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He who attacks the fundamentals of the American broadcasting industry&nbsp;attacks democracy itself.<br>&nbsp;-- William S. Paley, chairman of CBS')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"To err is human, to forgive, beyond the scope of the Operating System"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A bird in the bush usually has a friend in there with him.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any excuse will serve a tyrant.<br>&nbsp;-- Aesop')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The basic menu item, in fact the ONLY menu item, would be a food unit&nbsp;called the "patty," consisting of -- this would be guaranteed in&nbsp;writing -- "100 percent animal matter of some kind."  All patties would&nbsp;be heated up and then cooled back down in electronic devices&nbsp;immediately before serving.  The Breakfast Patty would be a patty on a&nbsp;bun with lettuce, tomato, onion, egg, Ba-Ko-Bits, Cheez Whiz, a Special&nbsp;Sauce made by pouring ketchup out of a bottle and a little slip of&nbsp;paper stating: "Inspected by Number 12".  The Lunch or Dinner Patty&nbsp;would be any Breakfast Patties that didn''t get sold in the morning.<br>The Seafood Lover''s Patty would be any patties that were starting to&nbsp;emit a serious aroma.  Patties that were too rank even to be Seafood&nbsp;Lover''s Patties would be compressed into wads and sold as "Nuggets."<br>&nbsp;-- Dave Barry, "''Mister Mediocre'' Restaurants"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Death is only a state of mind.<br>&nbsp;Only it doesn''t leave you much time to think about anything else.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gay shlafen: Yiddish for "go to sleep".<br><br>Now doesn''t "gay shlafen" have a softer, more soothing sound&nbsp;than the harsh, staccato "go to sleep"?  Listen to the difference:<br>"Go to sleep, you little wretch!" ... "Gay shlafen, darling."&nbsp;Obvious, isn''t it?<br>Clearly the best thing you can do for you children is to start&nbsp;speaking Yiddish right now and never speak another word of English as&nbsp;long as you live.  This will, of course, entail teaching Yiddish to all&nbsp;your friends, business associates, the people at the supermarket, and&nbsp;so on, but that''s just the point.  It has to start with committed&nbsp;individuals and then grow ...<br>Some minor adjustments will have to be made, of course: those&nbsp;signs written in what look like Yiddish letters won''t be funny when&nbsp;everything is written in Yiddish.  And we''ll have to start driving on&nbsp;the left side of the road so we won''t be reading the street signs&nbsp;backwards.  But is that too high a price to pay for world peace?  I&nbsp;think not, my friend, I think not.<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There''s nothing in the middle of the road but a yellow stripe and dead&nbsp;armadillos."<br>&nbsp;-- Jim Hightower, Texas Agricultural Commissioner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You should not use your fireplace, because scientists now believe that,<br>contrary to popular opinion, fireplaces actually remove heat from&nbsp;houses.  Really, that''s what scientists believe.  In fact many&nbsp;scientists actually use their fireplaces to cool their houses in the&nbsp;summer.  If you visit a scientist''s house on a sultry August day,<br>you''ll find a cheerful fire roaring on the hearth and the scientist&nbsp;sitting nearby, remarking on how cool he is and drinking heavily.<br>&nbsp;-- Dave Barry, "Postpetroleum Guzzler"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'However, never daunted, I will cope with adversity in my traditional&nbsp;manner ... sulking and nausea.<br>&nbsp;-- Tom K. Ryan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s the opinion of some that crops could be grown on the moon.  Which&nbsp;raises the fear that it may not be long before we''re paying somebody&nbsp;not to.<br>&nbsp;-- Franklin P. Jones')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'HE:  Let''s end it all, bequeathin'' our brains to science.<br>SHE: What?!?  Science got enough trouble with their ___^H^H^HOWN brains.<br>&nbsp;-- Walt Kelley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Malek''s Law:<br>Any simple idea will be worded in the most complicated way.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It was a virgin forest, a place where the Hand of Man had never set&nbsp;foot."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicago Transit Authority Rider''s Rule #84:<br>The CTA has complimentary pop-up timers available on request&nbsp;for overheated passengers.  When your timer pops up, the driver will&nbsp;cheerfully baste you.<br>&nbsp;-- Chicago Reader 5/28/82')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Advertising Agency Song:<br> <br>When your client''s hopping mad,<br>Put his picture in the ad.<br>If he still should prove refractory,<br>Add a picture of his factory.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sturgeon''s Law:<br>90% of everything is crud.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Too clever is dumb.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We demand rigidly defined areas of doubt and uncertainty!"<br>&nbsp;-- Vroomfondel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Psychotherapy is the theory that the patient will probably get well&nbsp;anyhow and is certainly a damn fool.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speak softly and carry a +6 two-handed sword.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real programmers don''t write in FORTRAN.  FORTRAN is for pipe stress&nbsp;freaks and crystallography weenies.  FORTRAN is for wimp engineers who&nbsp;wear white socks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Beware of computerized fortune-tellers!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Think of your family tonight.  Try to crawl home after the computer&nbsp;crashes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a camel is a horse designed by a committee, then a consensus&nbsp;forecast is a camel''s behind.<br>&nbsp;-- Edgar R. Fiedler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you go on with this nuclear arms race, all you are going to do is&nbsp;make the rubble bounce"<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Don''t tell me I''m burning the candle at both ends -- tell me where to&nbsp;get more wax!!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For large values of one, one equals two, for small values of two.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'First Law of Socio-Genetics:<br>Celibacy is not hereditary.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Meeting, n.:<br>An assembly of people coming together to decide what person or&nbsp;department not represented in the room must solve a problem.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Disc space -- the final frontier!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'F:&nbsp;When into a room I plunge, I<br>Sometimes find some VIOLET FUNGI.<br>Then I linger, darkly brooding<br>On the poison they''re exuding.<br>&nbsp;-- The Roguelet''s ABC')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Come, let us hasten to a higher plane,<br>Where dyads tread the fairy fields of Venn,<br>Their indices bedecked from one to _^Hn,<br>Commingled in an endless Markov chain!<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I have to stay home and see if I&nbsp;snore."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be braver -- you can''t cross a chasm in two small jumps.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '" ... I told my doctor I got all the exercise I needed being a&nbsp;pallbearer for all my friends who run and do exercises!"<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Newlan''s Truism:<br>An "acceptable" level of unemployment means that the government&nbsp;economist to whom it is acceptable still has a job.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everyone knows that dragons don''t exist.  But while this simplistic&nbsp;formulation may satisfy the layman, it does not suffice for the&nbsp;scientific mind.  The School of Higher Neantical Nillity is in fact&nbsp;wholly unconcerned with what ____^H^H^H^Hdoes exist.  Indeed, the banality of&nbsp;existence has been so amply demonstrated, there is no need for us to&nbsp;discuss it any further here.  The brilliant Cerebron, attacking the&nbsp;problem analytically, discovered three distinct kinds of dragon: the&nbsp;mythical, the chimerical, and the purely hypothetical.  They were all,<br>one might say, nonexistent, but each nonexisted in an entirely&nbsp;different way ...<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A UNIX saleslady, Lenore,<br>Enjoys work, but she likes the beach more.<br>She found a good way<br>To combine work and play:<br>She sells C shells by the seashore.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Unfair animal names:<br>&nbsp;-- tsetse fly&nbsp;&nbsp;&nbsp;-- bullhead&nbsp;-- booby&nbsp;&nbsp;&nbsp;-- duck-billed platypus&nbsp;-- sapsucker&nbsp;&nbsp;&nbsp;-- Clarence<br>&nbsp;-- Gary Larson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When more and more people are thrown out of work, unemployment&nbsp;results.<br>&nbsp;-- Calvin Coolidge')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Psblurtex is an 18-inch long anaconda that hides in the gentlemen''s&nbsp;outfitting departments of Amazonian stores and is often bought by&nbsp;mistake since its colors are those of the London Reform Club.  Once&nbsp;tied around its victim''s neck, it strangles him gently and then claims&nbsp;the insurance before running off to Germany where it lives in hiding.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Putt''s Law:<br>Technology is dominated by two types of people:<br>&nbsp;Those who understand what they do not manage.<br>&nbsp;Those who manage what they do not understand.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh, well, I guess this is just going to be one of those lifetimes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There is nothing which cannot be answered by means of my doctrine,"&nbsp;said a monk, coming into a teahouse where Nasrudin sat.  "And yet just&nbsp;a short time ago, I was challenged by a scholar with an unanswerable&nbsp;question," said Nasrudin.  "I could have answered it if I had been&nbsp;there." "Very well.  He asked, ''Why are you breaking into my house in&nbsp;the middle of the night?''"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When the going gets tough, the tough get empirical"<br>&nbsp;-- Jon Carroll')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Labor, n.:<br>One of the processes by which A acquires property for B.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '7:30, Channel 5: The Bionic Dog (Action/Adventure)<br>The Bionic Dog gets a hormonal short-circuit and violates the<br>Mann Act with an interstate Greyhound bus.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Acting is an art which consists of keeping the audience from&nbsp;coughing."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Furious activity is no substitute for understanding.<br>&nbsp;-- H. H. Williams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Every man has his price.  Mine is $3.95."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We''re only in it for the volume.<br>&nbsp;-- Black Sabbath')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How come only your friends step on your new white sneakers?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Grelb''s Reminder:<br>Eighty percent of all people consider themselves to be above&nbsp;average drivers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every solution breeds new problems.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Try to get all of your posthumous medals in advance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One way to make your old car run better is to look up the price of a&nbsp;new model.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The idea there was that consumers would bring their broken electronic&nbsp;devices, such as television sets and VCR''s, to the destruction centers,<br>where trained personnel would whack them (the devices) with&nbsp;sledgehammers.  With their devices thus permanently destroyed,<br>consumers would then be free to go out and buy new devices, rather than&nbsp;have to fritter away years of their lives trying to have the old ones&nbsp;repaired at so-called "factory service centers," which in fact consist&nbsp;of two men named Lester poking at the insides of broken electronic&nbsp;devices with cheap cigars and going, "Lookit all them WIRES in there!"<br>&nbsp;-- Dave Barry, "''Mister Mediocre'' Restaurants"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Illinois isn''t exactly the land that God forgot -- it''s more like the&nbsp;land He''s trying to ignore.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Perfect day for scrubbing the floor and other exciting things.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'According to my best recollection, I don''t remember.<br>&nbsp;-- Vincent "Jimmy Blue Eyes" Alo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am ready to meet my Maker.  Whether my Maker is prepared for the&nbsp;great ordeal of meeting me is another matter."<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a certain impertinence in allowing oneself to be burned for an&nbsp;opinion.<br>&nbsp;-- Anatole France')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real programmers disdain structured programming.  Structured&nbsp;programming is for compulsive neurotics who were prematurely toilet-&nbsp;trained.  They wear neckties and carefully line up pencils on otherwise&nbsp;clear desks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Friends, Romans, Hipsters,<br>Let me clue you in:<br>I come to put down Caesar, not to groove him.<br>The square kicks some cats are on stay with them:<br>The hip bits, like, go down under; so let it lay with Caesar.  The cool Brutus&nbsp;Gave you the message: Caesar had big eyes:<br>If that''s the sound, someone''s copping a plea,<br>And, like, old Caesar really set them straight.<br>Here, copacetic with Brutus and the studs, -- for Brutus is a real cool cat:<br>So are they all, all cool cats, --&nbsp;Come I to make this gig at Caesar''s laying down.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Who''s on first?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just because you''re paranoid doesn''t mean they AREN''T after you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some people in this department wouldn''t recognize subtlety if it hit&nbsp;them on the head.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had not given us sticky tape, it would have been necessary to&nbsp;invent it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cahn''s Axiom:<br>When all else fails, read the instructions.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... one of the main causes of the fall of the Roman Empire was that,<br>lacking zero, they had no way to indicate successful termination of&nbsp;their C programs."<br>&nbsp;-- Robert Firth')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alas, I am dying beyond my means.<br>&nbsp;-- Oscar Wilde, as he sipped champagne on his deathbed')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Committee, n.:<br>A group of men who individually can do nothing but as a group&nbsp;decide that nothing can be done.<br>&nbsp;-- Fred Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gordon''s first law:<br>If a research project is not worth doing, it is not worth doing&nbsp;well.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"My advice to you, my violent friend, is to seek out gold and sit on&nbsp;it."<br>&nbsp;-- "Grendel", by John Gardner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A truly wise man never plays leapfrog with a unicorn.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All I can think of is a platter of organic PRUNE CRISPS being trampled&nbsp;by an army of swarthy, Italian LOUNGE SINGERS ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The hardest thing in the world to understand is the income tax.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s no trick to being a humorist when you have the whole government&nbsp;working for you.<br>&nbsp;-- Will Rodgers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... A solemn, unsmiling, sanctimonious old iceberg who looked like he&nbsp;was waiting for a vacancy in the Trinity.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Virginia law forbids bathtubs in the house; tubs must be kept in the&nbsp;yard.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bureaucrat, n.:<br>A politician who has tenure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There were in this country two very large monopolies.  The larger of&nbsp;the two had the following record: the Vietnam War, Watergate, double-&nbsp;digit inflation, fuel and energy shortages, bankrupt airlines, and the&nbsp;8-cent postcard.  The second was responsible for such things as the&nbsp;transistor, the solar cell, lasers, synthetic crystals, high fidelity&nbsp;stereo recording, sound motion pictures, radio astronomy, negative&nbsp;feedback, magnetic tape, magnetic "bubbles", electronic switching&nbsp;systems, microwave radio and TV relay systems, information theory, the&nbsp;first electrical digital computer, and the first communications&nbsp;satellite.  Guess which one got to tell the other how to run the&nbsp;telephone business?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many IBM CPU''s does it take to execute a job?&nbsp;A:  Four; three to hold it down, and one to rip its head off.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If only I could be respected without having to be respectable.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We really don''t have any enemies.  It''s just that some of our best&nbsp;friends are trying to kill us.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We wish you a Hare Krishna&nbsp;We wish you a Hare Krishna&nbsp;We wish you a Hare Krishna&nbsp;And a Sun Myung Moon!<br>&nbsp;-- Maxwell Smart')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mitchell''s Law of Committees:<br>Any simple problem can be made insoluble if enough meetings are&nbsp;held to discuss it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A psychiatrist is a person who will give you expensive answers that&nbsp;your wife will give you for free.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The bland leadeth the bland and they both shall fall into the kitsch."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A Law of Computer Programming:<br>Make it possible for programmers to write in English and you&nbsp;will find the programmers cannot write in English.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Please, won''t somebody tell me what diddie-wa-diddie means?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gold, n.:<br>A soft malleable metal relatively scarce in distribution.  It&nbsp;is mined deep in the earth by poor men who then give it to rich men who&nbsp;immediately bury it back in the earth in great prisons, although gold&nbsp;hasn''t done anything to them.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Nuclear war can ruin your whole compile."<br>&nbsp;-- Karl Lehenbauer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Johnson''s First Law:<br>When any mechanical contrivance fails, it will do so at the&nbsp;most inconvenient possible time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''re not my type.  For that matter, you''re not even my species!!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Talk sense to a fool and he calls you foolish.<br>&nbsp;-- Euripides')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why can''t you be a non-conformist like everyone else?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I didn''t know it was impossible when I did it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Remember that whatever misfortune may be your lot, it could only be&nbsp;worse in Cleveland.<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One way to stop a runaway horse is to bet on him.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Decisions of the judges will be final unless shouted down by a really&nbsp;overwhelming majority of the crowd present.  Abusive and obscene&nbsp;language may not be used by contestants when addressing members of the&nbsp;judging panel, or, conversely, by members of the judging panel when&nbsp;addressing contestants (unless struck by a boomerang).<br>&nbsp;-- Mudgeeraba Creek Emu-Riding and Boomerang-Throwing<br>&nbsp;   Assoc.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'At Group L, Stoffel oversees six first-rate programmers, a managerial&nbsp;challenge roughly comparable to herding cats.<br>&nbsp;-- The Washington Post Magazine, 9 June, 1985')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New crypt.  See /usr/news/crypt.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Gosh that takes me back ... or forward.  That''s the trouble with time&nbsp;travel, you never can tell."<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ambition is a poor excuse for not having sense enough to be lazy.<br>&nbsp;-- Charlie McCarthy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nature is by and large to be found out of doors, a location where, it&nbsp;cannot be argued, there are never enough comfortable chairs.<br>&nbsp;-- Fran Leibowitz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The National Short-Sleeved Shirt Association says:<br>Support your right to bare arms!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''ll rob that rich person and give it to some poor deserving slob.<br>That will *prove* I''m Robin Hood."<br>&nbsp;-- Daffy Duck, "Robin Hood Daffy", [1958, Chuck Jones]')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Year, n.:<br>A period of three hundred and sixty-five disappointments.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People usually get what''s coming to them ... unless it''s been mailed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I dread success.  To have succeeded is to have finished one''s business&nbsp;on earth, like the male spider, who is killed by the female the moment&nbsp;he has succeeded in his courtship.  I like a state of continual&nbsp;becoming, with a goal in front and not behind."<br>&nbsp;-- George Bernard Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone who uses the phrase "easy as taking candy from a baby" has never&nbsp;tried taking candy from a baby.<br>&nbsp;-- Robin Hood')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If I had only known, I would have been a locksmith."<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have you ever wondered what makes Californians so calm?  Besides drugs,<br>I mean.  The answer is hot tubs.  A hot tub is a redwood container&nbsp;filled with water that you sit in naked with members of the opposite&nbsp;sex, none of whom is necessarily your spouse.  After a few hours in&nbsp;their hot tubs, Californians don''t give a damn about earthquakes or&nbsp;mass murderers.  They don''t give a damn about anything , which is why&nbsp;they are able to produce "Laverne and Shirley" week after week.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you stand on your head, you will get footprints in your hair.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It looks like blind screaming hedonism won out.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'WARNING:<br>Reading this fortune can affect the dimensionality of your&nbsp;mind, change the curvature of your spine, cause the growth of hair on&nbsp;your palms, and make a difference in the outcome of your favorite war.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You know you''ve landed gear-up when it takes full power to taxi.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Where humor is concerned there are no standards -- no one can say what&nbsp;is good or bad, although you can be sure that everyone will.<br>&nbsp;-- John Kenneth Galbraith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m fed up to the ears with old men dreaming up wars for young men to&nbsp;die in."<br>&nbsp;-- George McGovern')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"She said, `I know you ... you cannot sing''.  I said, `That''s nothing,<br>you should hear me play piano.''"<br>&nbsp;-- Morrisey')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Our documentation manager was showing her two year old son around the&nbsp;office.  He was introduced to me, at which time he pointed out that we&nbsp;were both holding bags of popcorn.  We were both holding bottles of&nbsp;juice.  But only *_^H_^Hhe* had a lollipop.<br>&nbsp;He asked his mother, "Why doesn''t HE have a lollipop?"&nbsp;&nbsp;Her reply:<br><br>"He can have a lollipop any time he wants to.  That''s what it<br>means to be a programmer."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Overflow on /dev/null, please empty the bit bucket.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Blood flows down one leg and up the other.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many existentialists does it take to screw in a lightbulb?&nbsp;A:  Two.  One to screw it in and one to observe how the lightbulb&nbsp;    itself symbolizes a single incandescent beacon of subjective&nbsp;    reality in a netherworld of endless absurdity reaching out toward a&nbsp;    maudlin cosmos of nothingness.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some primal termite knocked on wood.<br>And tasted it, and found it good.<br>And that is why your Cousin May&nbsp;Fell through the parlor floor today.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is not true that life is one damn thing after another -- it''s one&nbsp;damn thing over and over.<br>&nbsp;-- Edna St. Vincent Millay')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The earth is like a tiny grain of sand, only much, much heavier.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your true value depends entirely on what you are compared with.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"My doctor told me to stop having intimate dinners for four.  Unless&nbsp;there are three other people."<br>&nbsp;-- Orson Welles')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"All snakes who wish to remain in Ireland will please raise their right&nbsp;hands."<br>&nbsp;-- Saint Patrick')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Harry is heavily into camping, and every year in the late fall, he&nbsp;makes us all go to Assateague, which is an island on the Atlantic Ocean&nbsp;famous for its wild horses.  I realize that the concept of wild horses&nbsp;probably stirs romantic notions in many of you, but this is because you&nbsp;have never met any wild horses in person.  In person, they are like&nbsp;enormous hooved rats.  They amble up to your camp site, and their&nbsp;attitude is: "We''re wild horses.  We''re going to eat your food, knock&nbsp;down your tent and poop on your shoes.  We''re protected by federal law,<br>just like Richard Nixon."<br>&nbsp;-- Dave Barry, "Tenting Grandpa Bob"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finding out what goes on in the C.I.A. is like performing acupuncture&nbsp;on a rock.<br>&nbsp;-- New York Times, Jan. 20, 1981')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love is a word that is constantly heard,<br>Hate is a word that is not.<br>Love, I am told, is more precious than gold.<br>Love, I have read, is hot.<br>But hate is the verb that to me is superb,<br>And Love but a drug on the mart.<br>Any kiddie in school can love like a fool,<br>But Hating, my boy, is an Art.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Expect the worst, it''s the least you can do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are times when truth is stranger than fiction and lunch time is&nbsp;one of them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Advice to young men: Be ascetic, and if you can''t be ascetic,<br>then at least be asceptic.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m in Pittsburgh.  Why am I here?"<br>&nbsp;-- Harold Urey, Nobel Laureate')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If that makes any sense to you, you have a big problem."<br>&nbsp;-- C. Durance, Computer Science 234')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"My life is a soap opera, but who has the rights?"<br>-- MadameX')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ray''s Rule of Precision:<br>Measure with a micrometer.  Mark with chalk.  Cut with an axe.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maier''s Law:<br>If the facts don''t conform to the theory, they must be disposed<br>of.<br>&nbsp;Corollaries:<br>(1) The bigger the theory, the better.<br>(2) The experiment may be considered a success if no more than<br>    50% of the observed measurements must be discarded to<br>    obtain a correspondence with the theory.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Easiest Color to Solve on a Rubik''s Cube:<br>Black.  Simply remove all the little colored stickers on the&nbsp;cube, and each of side of the cube will now be the original color of&nbsp;the plastic underneath -- black.  According to the instructions, this&nbsp;means the puzzle is solved.<br>&nbsp;-- Steve Rubenstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Beware of low-flying butterflies.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kirkland, Illinois, law forbids bees to fly over the village or through&nbsp;any of its streets.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Things will be bright in P.M.  A cop will shine a light in your face.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If money can''t buy happiness, I guess you''ll just have to rent it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is something fascinating about science.  One gets such wholesale&nbsp;returns of conjecture out of such a trifling investment of fact.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I had to hit him -- he was starting to make sense."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A cynic is a person searching for an honest man, with a stolen&nbsp;lantern.<br>&nbsp;-- Edgar A. Shoaff')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yes, but every time I try to see things your way, I get a headache.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Honk if you hate bumper stickers that say "Honk if ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chism''s Law of Completion:<br>The amount of time required to complete a government project is&nbsp;precisely equal to the length of time already spent on it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He who Laughs, Lasts.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The good die young -- because they see it''s no use living if you''ve got&nbsp;to be good.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A power so great, it can only be used for Good or Evil!"<br>&nbsp;-- Firesign Theatre, "The Giant Rat of Summatra"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I don''t know anything about music.  In my line you don''t have to.<br>&nbsp;-- Elvis Presley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"How do I love thee?  My accumulator overflows."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t get even -- get odd!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Now the Lord God planted a garden East of Whittier in a place called&nbsp;Yorba Linda, and out of the ground he made to grow orange trees that&nbsp;were good for food and the fruits thereof he labeled SUNKIST ..."<br>&nbsp;-- "The Begatting of a President"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Faith, n:<br>That quality which enables us to believe what we know to be&nbsp;untrue.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The warning message we sent the Russians was a calculated ambiguity&nbsp;that would be clearly understood."<br>&nbsp;-- Alexander Haig')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'James Joyce -- an essentially private man who wished his total&nbsp;indifference to public notice to be universally recognized.<br>&nbsp;-- Tom Stoppard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eleanor Rigby<br>Sits at the keyboard<br>And waits for a line on the screen&nbsp;Lives in a dream&nbsp;Waits for a signal<br>Finding some code<br>That will make the machine do some more.<br>What is it for?&nbsp;&nbsp;All the lonely users, where do they all come from?&nbsp;All the lonely users, why does it take so long?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If the odds are a million to one against something occurring, chances&nbsp;are 50-50 it will.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"They that can give up essential liberty to obtain a little temporary&nbsp;safety deserve neither liberty nor safety."<br>&nbsp;-- Benjamin Franklin, 1759')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Committee Rules:<br>(1) Never arrive on time, or you will be stamped a beginner.<br>(2) Don''t say anything until the meeting is half over; this<br>    stamps you as being wise.<br>(3) Be as vague as possible; this prevents irritating the<br>    others.<br>(4) When in doubt, suggest that a subcommittee be appointed.<br>(5) Be the first to move for adjournment; this will make you<br>    popular -- it''s what everyone is waiting for.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'According to Kentucky state law, every person must take a bath at least&nbsp;once a year.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We have reason to believe that man first walked upright to free his&nbsp;hands for masturbation."<br>&nbsp;-- Lily Tomlin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;A Severe Strain on the Credulity&nbsp;&nbsp;As a method of sending a missile to the higher, and even to the highest&nbsp;parts of the earth''s atmospheric envelope, Professor Goddard''s rocket&nbsp;is a practicable and therefore promising device.  It is when one&nbsp;considers the multiple-charge rocket as a traveler to the moon that one&nbsp;begins to doubt ... for after the rocket quits our air and really&nbsp;starts on its journey, its flight would be neither accelerated nor&nbsp;maintained by the explosion of the charges it then might have left.<br>Professor Goddard, with his "chair" in Clark College and countenancing&nbsp;of the Smithsonian Institution, does not know the relation of action to&nbsp;re-action, and of the need to have something better than a vacuum&nbsp;against which to react ... Of course he only seems to lack the&nbsp;knowledge ladled out daily in high schools.<br>&nbsp;-- New York Times Editorial, 1920')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never worry about theory as long as the machinery does what it''s&nbsp;supposed to do.<br>&nbsp;-- R. A. Heinlein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Justice, n.:<br>A decision in your favor.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bank error in your favor.  Collect $200.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Here is a simple experiment that will teach you an important electrical&nbsp;lesson: On a cool, dry day, scuff your feet along a carpet, then reach&nbsp;your hand into a friend''s mouth and touch one of his dental fillings.<br>Did you notice how your friend twitched violently and cried out in&nbsp;pain?  This teaches us that electricity can be a very powerful force,<br>but we must never use it to hurt others unless we need to learn an&nbsp;important electrical lesson.<br>&nbsp;It also teaches us how an electrical circuit works.  When you scuffed&nbsp;your feet, you picked up batches of "electrons", which are very small&nbsp;objects that carpet manufacturers weave into carpets so they will&nbsp;attract dirt.  The electrons travel through your bloodstream and&nbsp;collect in your finger, where they form a spark that leaps to your&nbsp;friend''s filling, then travels down to his feet and back into the&nbsp;carpet, thus completing the circuit.<br>&nbsp;Amazing Electronic Fact: If you scuffed your feet long enough without&nbsp;touching anything, you would build up so many electrons that your&nbsp;finger would explode!  But this is nothing to worry about unless you&nbsp;have carpeting.<br>&nbsp;-- Dave Barry, "What is Electricity?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Money is better than poverty, if only for financial reasons.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you don''t have a nasty obituary you probably didn''t matter.<br>&nbsp;-- Freeman Dyson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Before he became a hermit, Zarathud was a young Priest, and&nbsp;took great delight in making fools of his opponents in front of his&nbsp;followers.<br>One day Zarathud took his students to a pleasant pasture and&nbsp;there he confronted The Sacred Chao while She was contentedly grazing.<br>"Tell me, you dumb beast," demanded the Priest in his&nbsp;commanding voice, "why don''t you do something worthwhile?  What is your&nbsp;Purpose in Life, anyway?"<br>Munching the tasty grass, The Sacred Chao replied "MU".  (The&nbsp;Chinese ideogram for NO-THING.)<br>Upon hearing this, absolutely nobody was enlightened.<br>Primarily because nobody understood Chinese.<br>&nbsp;-- Camden Benares, "Zen Without Zen Masters"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fifth Law of Procrastination:<br>Procrastination avoids boredom; one never has the feeling that&nbsp;there is nothing important to do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Flappity, floppity, flip&nbsp;The mouse on the m"^Hobius strip;<br>The strip revolved,<br>The mouse dissolved&nbsp;In a chronodimensional skip.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can write a small letter to Grandma in the filename."<br>&nbsp;-- Forbes Burkowski, Computer Science 454')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is only the great men who are truly obscene.  If they had not dared&nbsp;to be obscene, they could never have dared to be great.<br>&nbsp;-- Havelock Ellis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reality is just a convenient measure of complexity.<br>&nbsp;-- Alvy Ray Smith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Horse sense is the thing a horse has which keeps it from betting on&nbsp;people.<br>&nbsp;-- W. C. Fields')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m defending her honor, which is more than she ever did."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As long as the answer is right, who cares if the question is wrong?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What good is having someone who can walk on water if you don''t follow&nbsp;in his footsteps?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I gave up Smoking, Drinking and Sex.  It was the most *__________^H^H^H^H^H^H^H^H^H^Hhorrifying* 20&nbsp;minutes of my life!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m changing my name to Chrysler&nbsp;I''m going down to Washington, D.C.<br>I''ll tell some power broker<br>What they did for Iacocca&nbsp;Will be perfectly acceptable to me!&nbsp;I''m changing my name to Chrysler,<br>I''m heading for that great receiving line.<br>When they hand a million grand out,<br>I''ll be standing with my hand out,<br>Yessir, I''ll get mine!<br>&nbsp;-- Tom Paxton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Telephone, n.:<br>An invention of the devil which abrogates some of the&nbsp;advantages of making a disagreeable person keep his distance.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some don''t prefer the pursuit of happiness to the happiness of pursuit.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bees are very busy souls&nbsp;They have no time for birth controls&nbsp;And that is why in times like these&nbsp;There are so many Sons of Bees.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have you noticed that all you need to grow healthy, vigorous grass is a&nbsp;crack in your sidewalk?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Arguments with furniture are rarely productive."<br>&nbsp;-- Kehlog Albran, "The Profit"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The good Christian should beware of mathematicians and all those who&nbsp;make empty prophecies.  The danger already exists that mathematicians&nbsp;have made a covenant with the devil to darken the spirit and confine&nbsp;man in the bonds of Hell."<br>&nbsp;-- St. Augustine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Men were real men, women were real women, and small, furry creatures&nbsp;from Alpha Centauri were REAL small, furry creatures from Alpha&nbsp;Centauri.  Spirits were brave, men boldly split infinitives that no man&nbsp;had split before.  Thus was the Empire forged.<br>&nbsp;-- "The Hitchhiker''s Guide to the Galaxy", Douglas Adams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Canada Bill Jone''s Motto:<br>It''s morally wrong to allow suckers to keep their money.<br>&nbsp;Supplement:<br>A .44 magnum beats four aces.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s the thought, if any, that counts!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vitamin C deficiency is apauling')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Non-Reciprocal Laws of Expectations:<br>Negative expectations yield negative results.<br>Positive expectations yield negative results.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is easier to change the specification to fit the program than vice&nbsp;versa.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;During a grouse hunt in North Carolina two intrepid sportsmen&nbsp;were blasting away at a clump of trees near a stone wall.  Suddenly a&nbsp;red-faced country squire popped his head over the wall and shouted,<br>"Hey, you almost hit my wife."<br>"Did I?"  cried the hunter, aghast.  "Terribly sorry.  Have a&nbsp;shot at mine, over there."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Hug O'' War&nbsp;&nbsp;I will not play at tug o'' war.<br>I''d rather play at hug o'' war,<br>Where everyone hugs&nbsp;Instead of tugs,<br>Where everyone giggles&nbsp;And rolls on the rug,<br>Where everyone kisses,<br>And everyone grins,<br>And everyone cuddles,<br>And everyone wins.<br>&nbsp;-- Shel Silverstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Deep" is a word like "theory" or "semantic" -- it implies all sorts of&nbsp;marvelous things.  It''s one thing to be able to say "I''ve got a&nbsp;theory", quite another to say "I''ve got a semantic theory", but, ah,<br>those who can claim "I''ve got a deep semantic theory", they are truly&nbsp;blessed.<br>&nbsp;-- Randy Davis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do not read this fortune under penalty of law.<br>Violators will be prosecuted.<br>(Penal Code sec. 2.3.2 (II.a.))')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"This is a country where people are free to practice their religion,<br>regardless of race, creed, color, obesity, or number of dangling&nbsp;keys ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Killer Ducks are coming!!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Around computers it is difficult to find the correct unit of time to&nbsp;measure progress.  Some cathedrals took a century to complete.  Can you&nbsp;imagine the grandeur and scope of a program that would take as long?<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Harvard Law:<br>Under the most rigorously controlled conditions of pressure,<br>temperature, volume, humidity, and other variables, the organism will&nbsp;do as it damn well pleases.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Cutting the space budget really restores my faith in humanity.  It&nbsp;eliminates dreams, goals, and ideals and lets us get straight to the&nbsp;business of hate, debauchery, and self-annihilation."<br>&nbsp;-- Johnny Hart')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A reading from the Book of Armaments, Chapter 4, Verses 16 to 20:<br>&nbsp;Then did he raise on high the Holy Hand Grenade of Antioch, saying,<br>"Bless this, O Lord, that with it thou mayst blow thine enemies to tiny&nbsp;bits, in thy mercy."  And the people did rejoice and did feast upon the&nbsp;lambs and toads and tree-sloths and fruit-bats and orangutans and&nbsp;breakfast cereals ... Now did the Lord say, "First thou pullest the&nbsp;Holy Pin.  Then thou must count to three.  Three shall be the number of&nbsp;the counting and the number of the counting shall be three.  Four shalt&nbsp;thou not count, neither shalt thou count two, excepting that thou then&nbsp;proceedeth to three.  Five is right out.  Once the number three, being&nbsp;the number of the counting, be reached, then lobbest thou the Holy Hand&nbsp;Grenade in the direction of thine foe, who, being naughty in my sight,<br>shall snuff it."<br>&nbsp;-- Monty Python, "Monty Python and the Holy Grail"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just when you thought you were winning the rat race, along comes a&nbsp;faster rat!!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No plain fanfold paper could hold that fractal Puff --&nbsp;He grew so fast no plotting pack could shrink him far enough.<br>Compiles and simulations grew so quickly tame&nbsp;And swapped out all their data space when Puff pushed his stack frame.<br>CHORUS:<br>Puff the fractal dragon was written in C,<br>And frolicked while processes switched in mainframe memory.<br>Puff the fractal dragon was written in C,<br>And frolicked while processes switched in mainframe memory.<br>Puff, he grew so quickly, while others moved like snails&nbsp;And mini-Puffs would perch themselves on his gigantic tail.<br>All the student hackers loved that fractal Puff&nbsp;But DCS did not like Puff, and finally said, "Enough!"<br>&nbsp;(chorus)<br>Puff used more resources than DCS could spare.<br>The operator killed Puff''s job -- he didn''t seem to care.<br>A gloom fell on the hackers; it seemed to be the end,<br>But Puff trapped the exception, and grew from naught again!<br>&nbsp;(chorus)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Honesty is the best policy, but insanity is a better defense"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Law, in its majestic equality, forbids the rich, as well as the&nbsp;poor, to sleep under the bridges, to beg in the streets, and to steal&nbsp;bread.<br>&nbsp;-- Anatole France')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why You Can''t Run When There''s Trouble in the Office:<br>No matter where you stand, no matter how far or fast you flee,<br>when it hits the fan, as much as possible will be propelled in your&nbsp;direction, and almost none will be returned to the source.<br>&nbsp;-- John L.  Shelton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'XIIdigitation, n.:<br>The practice of trying to determine the year a movie was made&nbsp;by deciphering the Roman numerals at the end of the credits.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many surrealists does it take to change a light bulb?&nbsp;A:  Two.  One to hold the giraffe and the other to fill the bathtub&nbsp;    with brightly colored machine tools.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It will be advantageous to cross the great stream ... the Dragon is on&nbsp;the wing in the Sky ... the Great Man rouses himself to his Work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"She is descended from a long line that her mother listened to."<br>&nbsp;-- Gypsy Rose Lee')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m all for computer dating, but I wouldn''t want one to marry my&nbsp;sister."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Weiler''s Law:<br>Nothing is impossible for the man who doesn''t have to do it&nbsp;himself.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can tune a piano, but you can''t tuna fish.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Even if you do learn to speak correct English, whom are you going to&nbsp;speak it to?<br>&nbsp;-- Clarence Darrow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Many years ago in a period commonly know as Next Friday Afternoon,<br>there lived a King who was very Gloomy on Tuesday mornings because he&nbsp;was so Sad thinking about how Unhappy he had been on Monday and how&nbsp;completely Mournful he would be on Wednesday ...<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love and scandal are the best sweeteners of tea.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s really quite a simple choice: Life, Death, or Los Angeles.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A programmer is a person who passes as an exacting expert on the basis&nbsp;of being able to turn out, after innumerable punching, an infinite&nbsp;series of incomprehensive answers calculated with micrometric&nbsp;precisions from vague assumptions based on debatable figures taken from&nbsp;inconclusive documents and carried out on instruments of problematical&nbsp;accuracy by persons of dubious reliability and questionable mentality&nbsp;for the avowed purpose of annoying and confounding a hopelessly&nbsp;defenseless department that was unfortunate enough to ask for the&nbsp;information in the first place."<br>&nbsp;-- IEEE Grid news magazine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you took all the students that felt asleep in class and laid them&nbsp;end to end, they''d be a lot more comfortable.<br>&nbsp;-- "Graffiti in the Big Ten"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why does New Jersey have more toxic waste dumps and California have&nbsp;more lawyers?&nbsp;&nbsp;New Jersey had first choice.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Well, here it is, 1983, so it won''t be long before you start reading a&nbsp;lot of boring stories about people like Vance Hartke.  Hartke is a&nbsp;governor or mayor or something from one of the flatter states, and the&nbsp;reason you''ll be reading about him is that he''s one of the 50 top&nbsp;contenders for the 1984 Democratic presidential nomination.  These men&nbsp;will spend the next 18 months going around the country engaging in the&nbsp;most degrading activities imaginable, such as wearing idiot hats and&nbsp;appearing on "Meet the Press".  "Meet the Press" is one of those Sunday&nbsp;morning public interest shows that the public is not the least bit&nbsp;interested in.  It features a panel of reporters who ask questions of a&nbsp;guest politician, who wins an Amana home freezer if he can get through&nbsp;the entire show without answering a single question ...<br>&nbsp;-- Dave Barry, "On Presidential Politics"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I think the sky is blue because it''s a shift from black through purple&nbsp;to blue, and it has to do with where the light is.  You know, the&nbsp;farther we get into darkness, and there''s a shifting of color of light&nbsp;into the blueness, and I think as you go farther and farther away from&nbsp;the reflected light we have from the sun or the light that''s bouncing&nbsp;off this earth, uh, the darker it gets ... I think if you look at the&nbsp;color scale, you start at black, move it through purple, move it on&nbsp;out, it''s the shifting of color.  We mentioned before about the stars&nbsp;singing, and that''s one of the effects of the shifting of colors."<br>&nbsp;-- Pat Robertson, The 700 Club')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Laugh at your problems; everybody else does.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Experience varies directly with equipment ruined.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The temperature of Heaven can be rather accurately computed.  Our&nbsp;authority is Isaiah 30:26, "Moreover, the light of the Moon shall be as&nbsp;the light of the Sun and the light of the Sun shall be sevenfold, as&nbsp;the light of seven days."  Thus Heaven receives from the Moon as much&nbsp;radiation as we do from the Sun, and in addition 7*7 (49) times as much&nbsp;as the Earth does from the Sun, or 50 times in all.  The light we&nbsp;receive from the Moon is one 1/10,000 of the light we receive from the&nbsp;Sun, so we can ignore that ... The radiation falling on Heaven will&nbsp;heat it to the point where the heat lost by radiation is just equal to&nbsp;the heat received by radiation, i.e., Heaven loses 50 times as much&nbsp;heat as the Earth by radiation.  Using the Stefan-Boltzmann law for&nbsp;radiation, (_^HH/_^HE)^4 = 50, where _^HE is the absolute temperature of the&nbsp;earth (-300K), gives _^HH as 798K (525C).  The exact temperature of Hell&nbsp;cannot be computed ... [However] Revelations 21:8 says "But the&nbsp;fearful, and unbelieving ... shall have their part in the lake which&nbsp;burneth with fire and brimstone."  A lake of molten brimstone means&nbsp;that its temperature must be at or below the boiling point, 444.6C.  We&nbsp;have, then, that Heaven, at 525C is hotter than Hell at 445C.<br>&nbsp;-- From "Applied Optics" vol. 11, A14, 1972')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those of you who think you know everything are very annoying to those&nbsp;of us who do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had intended Men to Smoke, He would have put Chimneys in their&nbsp;Heads.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The best defense against logic is ignorance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What we need in this country, instead of Daylight Savings Time, which&nbsp;nobody really understands anyway, is a new concept called Weekday&nbsp;Morning Time, whereby at 7 a.m. every weekday we go into a space-&nbsp;launch-style "hold" for two to three hours, during which it just&nbsp;remains 7 a.m.  This way we could all wake up via a civilized gradual&nbsp;process of stretching and belching and scratching, and it would still&nbsp;be only 7 a.m. when we were ready to actually emerge from bed.<br>&nbsp;-- Dave Barry, "$#$%#^%!^%&@%@!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Health nuts are going to feel stupid someday, lying in hospitals dying&nbsp;of nothing.<br>&nbsp;-- Redd Foxx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'YOW!!  Everybody out of the GENETIC POOL!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Serocki''s Stricture:<br>Marriage is always a bachelor''s last option.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''m taking punk totem pole carving."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A lot of people I know believe in positive thinking, and so do I.  I&nbsp;believe everything positively stinks.<br>&nbsp;-- Lew Col')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Beware of Programmers who carry screwdrivers.<br>&nbsp;-- Leonard Brandwein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The human race is a race of cowards; and I am not only marching in that&nbsp;procession but carrying a banner.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No man is an island, but some of us are long peninsulas.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Always borrow money from a pessimist; he doesn''t expect to be paid&nbsp;back.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Skinner''s Constant (or Flannagan''s Finagling Factor):<br>That quantity which, when multiplied by, divided by, added to,<br>or subtracted from the answer you get, gives you the answer you should&nbsp;have gotten.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;Chapter 1&nbsp;&nbsp;The story so far:<br><br>In the beginning the Universe was created.  This has made a lot&nbsp;of people very angry and been widely regarded as a bad move.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We are on the verge: Today our program proved Fermat''s next-to-last&nbsp;theorem."<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'fortune''s Contribution of the Month to the Animal Rights Debate:<br><br>I''ll stay out of animals'' way if they''ll stay out of mine.<br>"Hey you, get off my plate"<br>&nbsp;-- Roger Midnight')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"In defeat, unbeatable; in victory, unbearable."<br>&nbsp;-- Winston Curchill, of Montgomery')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Contrary to popular belief, penguins are not the salvation of modern&nbsp;technology.  Neither do they throw parties for the urban proletariat."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God isn''t dead, he just couldn''t find a parking place.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hacker''s Law:<br>The belief that enhanced understanding will necessarily stir a&nbsp;nation to action is one of mankind''s oldest illusions.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Barach''s Rule:<br>An alcoholic is a person who drinks more than his own&nbsp;physician.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An age is called Dark not because the light fails to shine, but because&nbsp;people refuse to see it.<br>&nbsp;-- James Michener, "Space"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A city is a large community where people are lonesome together<br>&nbsp;-- Herbert Prochnow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Clothes make the man.  Naked people have little or no influence on&nbsp;society.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The objective of all dedicated employees should be to thoroughly&nbsp;analyze all situations, anticipate all problems prior to their&nbsp;occurrence, have answers for these problems, and move swiftly to solve&nbsp;these problems when called upon.<br>&nbsp;However, When you are up to your ass in alligators it is difficult to&nbsp;remind yourself your initial objective was to drain the swamp.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bubble Memory, n.:<br>A derogatory term, usually referring to a person''s&nbsp;intelligence.  See also "vacuum tube".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Second Law of Business Meetings:<br>If there are two possible ways to spell a person''s name, you&nbsp;will pick the wrong one.<br>&nbsp;Corollary:<br>If there is only one way to spell a name, you will spell it&nbsp;wrong, anyway.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sattinger''s Law:<br>It works better if you plug it in.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the Top 40, half the songs are secret messages to the teen world to&nbsp;drop out, turn on, and groove with the chemicals and light shows at&nbsp;discotheques.<br>&nbsp;-- Art Linkletter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The debate rages on: Is PL/I Bachtrian or Dromedary?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boston, n.:<br>Ludwig van Beethoven being jeered by 50,000 sports fans for&nbsp;finishing second in the Irish jig competition.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My band career ended late in my senior year when John Cooper and I&nbsp;threw my amplifier out the dormitory window.  We did not act in haste.<br>First we checked to make sure the amplifier would fit through the&nbsp;frame, using the belt from my bathrobe to measure, then we picked up&nbsp;the amplifier and backed up to my bedroom door.  Then we rushed&nbsp;forward, shouting "The WHO!  The WHO!" and we launched my amplifier&nbsp;perfectly, as though we had been doing it all our lives, clean through&nbsp;the window and down onto the sidewalk, where a small but appreciative&nbsp;crowd had gathered.  I would like to be able to say that this was a&nbsp;symbolic act, an effort on my part to break cleanly away from one state&nbsp;in my life and move on to another, but the truth is, Cooper and I&nbsp;really just wanted to find out what it would sound like.  It sounded&nbsp;OK.<br>&nbsp;-- Dave Barry, "The Snake"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love at first sight is one of the greatest labor-saving devices the&nbsp;world has ever seen.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The notion that the church, the press, and the universities should&nbsp;serve the state is essentially a Communist notion ... In a free society&nbsp;these institutions must be wholly free -- which is to say that their&nbsp;function is to serve as checks upon the state.<br>&nbsp;-- Alan Barth')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A copy of the universe is not what is required of art; one of the&nbsp;damned things is ample.<br>&nbsp;-- Rebecca West')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are three kinds of lies: Lies, Damn Lies, and Statistics.<br>&nbsp;-- Disraeli')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'UFO''s are for real: the Air Force doesn''t exist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '[From the operation manual for the CI-300 Dot Matrix Line Printer, made&nbsp;in Japan]:<br>&nbsp;The excellent output machine of MODEL CI-300 as extraordinary DOT&nbsp;MATRIX LINE PRINTER, built in two MICRO-PROCESSORs as well as EAROM, is&nbsp;featured by permitting wonderful co-existence such as; "high quality&nbsp;against low cost", "diversified functions with compact design",<br>"flexibility in accessibleness and durability of approx. 2000,000,00&nbsp;Dot/Head", "being sophisticated in mechanism but possibly agile&nbsp;operating under noises being extremely suppressed" etc.<br>&nbsp;And as a matter of course, the final goal is just simply to help&nbsp;achieve "super shuttle diplomacy" between cool data, perhaps earned by&nbsp;HOST COMPUTER, and warm heart of human being.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All the world''s a stage and most of us are desperately unrehearsed.<br>&nbsp;-- Sean O''Casey')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As I was going up Punch Card Hill,<br>Feeling worse and worser,<br>There I met a C.R.T.<br>And it drop''t me a cursor.<br>&nbsp;C.R.T., C.R.T.,<br>Phosphors light on you!&nbsp;If I had fifty hours a day<br>I''d spend them all at you.<br><br>&nbsp;-- Uncle Colonel''s Cursory Rhymes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I never met a piece of chocolate I didn''t like."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Seminars, n.:<br>From "semi" and "arse", hence, any half-assed discussion.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The day-to-day travails of the IBM programmer are so amusing to most of&nbsp;us who are fortunate enough never to have been one -- like watching&nbsp;Charlie Chaplin trying to cook a shoe.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A great many people think they are thinking when they are merely&nbsp;rearranging their prejudices.<br>&nbsp;-- William James')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ducharme''s Precept:<br>Opportunity always knocks at the least opportune moment.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rule of Creative Research:<br>(1) Never draw what you can copy.<br>(2) Never copy what you can trace.<br>(3) Never trace what you can cut out and paste down.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Probable-Possible, my black hen,<br>She lays eggs in the Relative When.<br>She doesn''t lay eggs in the Positive Now&nbsp;Because she''s unable to postulate how.<br>&nbsp;-- Frederick Winsor')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Krogt, n. (chemical symbol: Kr):<br>The metallic silver coating found on fast-food game cards.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An idea is not responsible for the people who believe in it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Katz'' Law:<br>Man and nations will act rationally when all other&nbsp;possibilities have been exhausted.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'California is a fine place to live -- if you happen to be an orange.<br>&nbsp;-- Fred Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We''ve sent a man to the moon, and that''s 29,000 miles away.  The center&nbsp;of the Earth is only 4,000 miles away.  You could drive that in a week,<br>but for some reason nobody''s ever done it.<br>&nbsp;-- Andy Rooney')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One seldom sees a monument to a committee.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m going to live forever, or die trying!<br>&nbsp;-- Spider Robinson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t get suckered in by the comments -- they can be terribly&nbsp;misleading.  Debug only code.<br>&nbsp;-- Dave Storer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One of my less pleasant chores when I was young was to read the Bible&nbsp;from one end to the other.  Reading the Bible straight through is at&nbsp;least 70 percent discipline, like learning Latin.  But the good parts&nbsp;are, of course, simply amazing.  God is an extremely uneven writer, but&nbsp;when He''s good, nobody can touch Him.<br>&nbsp;-- John Gardner, NYT Book Review, Jan 1983')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Trying to be happy is like trying to build a machine for which the only&nbsp;specification is that it should run noiselessly.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Workers of the world, arise!  You have nothing to lose but your&nbsp;chairs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s no future in time travel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have the simplest tastes.  I am always satisfied with the best."<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'History repeats itself.  That''s one thing wrong with history.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can measure a programmer''s perspective by noting his attitude on&nbsp;the continuing viability of FORTRAN.<br>&nbsp;-- Alan Perlis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There''s nothing wrong with teenagers that reasoning with them won''t&nbsp;aggravate."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'LIBRA (Sept 23 - Oct 22)<br>You are the artistic type and have a difficult time with<br>reality.  If you are a man, you are more than likely gay.<br>Chances for employment and monetary gains are excellent.  Most<br>Libra women are prostitutes.  All Libra people die of venereal<br>disease.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Loan-department manager:  "There isn''t any fine print.  At these&nbsp;interest rates, we don''t need it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... I should explain that I was wearing a black velvet cape that was&nbsp;supposed to make me look like the dashing, romantic Zorro but which&nbsp;actually made me look like a gigantic bat wearing glasses ..."<br>&nbsp;-- Dave Barry, "The Wet Zorro Suit and Other Turning<br>&nbsp;   Points in l''Amour"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Giving up on assembly language was the apple in our Garden of Eden:<br>Languages whose use squanders machine cycles are sinful.  The LISP&nbsp;machine now permits LISP programmers to abandon bra and fig-leaf.<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Epperson''s law:<br>When a man says it''s a silly, childish game, it''s probably&nbsp;something his wife can beat him at.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Egotism is the anesthetic given by a kindly nature to relieve the pain&nbsp;of being a damned fool.<br>&nbsp;-- Bellamy Brooks')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New Year''s Eve is the time of year when a man most feels his age, and&nbsp;his wife most often reminds him to act it.<br>&nbsp;-- Webster''s Unafraid Dictionary')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '`Just the place for a Snark!'' the Bellman cried,<br>As he landed his crew with care:<br>Supporting each man on the top of the tide<br>By a finger entwined in his hair.<br>&nbsp;''Just the place for a Snark!  I have said it twice:<br>That alone should encourage the crew.<br>Just the place for a Snark!  I have said it thrice:<br>What I tell you three times is true.''')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Might as well be frank, monsieur.  It would take a miracle to get you&nbsp;out of Casablanca and the Germans have outlawed miracles."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but the last time I went out, I never&nbsp;came back."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Am I ranting?  I hope so.  My ranting gets raves.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nasrudin called at a large house to collect for charity.  The servant&nbsp;said "My master is out."  Nasrudin replied, "Tell your master that next&nbsp;time he goes out, he should not leave his face at the window.  Someone&nbsp;might steal it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If all be true that I do think,<br>There be Five Reasons why one should Drink:<br>Good friends, good wine, or being dry,<br>Or lest we should be by-and-by,<br>Or any other reason why.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Talkers are no good doers.<br>&nbsp;-- William Shakespeare, "Henry VI"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life is too important to take seriously."<br>&nbsp;-- Corky Siegel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Now is the time for all good men to come to."<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Grabel''s Law:<br>2 is not equal to 3 -- not even for large values of 2.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s not enough to be Hungarian; you must have talent too.<br>&nbsp;-- Alexander Korda')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The hearing ear is always found close to the speaking tongue, a custom&nbsp;whereof the memory of man runneth not howsomever to the contrary,<br>nohow.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In a five year period we can get one superb programming language.  Only&nbsp;we can''t control when the five year period will begin.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Garbage In -- Gospel Out.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Amnesia used to be my favorite word, but then I forgot it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'President Reagan has noted that there are too many economic pundits and&nbsp;forecasters and has decided on an excess prophets tax.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is always preferable to visit home with a friend.  Your parents will&nbsp;not be pleased with this plan, because they want you all to themselves&nbsp;and because in the presence of your friend, they will have to act like&nbsp;mature human beings ...<br>&nbsp;-- Playboy, January 1983')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Computer programmers do it byte by byte')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"About the time we think we can make ends meet, somebody moves the&nbsp;ends."<br>&nbsp;-- Herbert Hoover')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mencken and Nathan''s Fifteenth Law of The Average American:<br>The worst actress in the company is always the manager''s wife.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Overload -- core meltdown sequence initiated.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are three things I always forget.  Names, faces -- the third I&nbsp;can''t remember.<br>&nbsp;-- Italo Svevo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In West Union, Ohio, No married man can go flying without his spouse&nbsp;along at any time, unless he has been married for more than 12 months.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Here''s something to think about:  How come you never see a headline like&nbsp;`Psychic Wins Lottery''?"<br>&nbsp;-- Jay Leno')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'LEO (July 23 - Aug 22)<br>You consider yourself a born leader.  Others think you are<br>pushy.  Most Leo people are bullies.  You are vain and dislike<br>honest criticism.  Your arrogance is disgusting.  Leo people<br>are thieves.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Biology is the only science in which multiplication means the same&nbsp;thing as division."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I can''t complain, but sometimes I still do."<br>&nbsp;-- Joe Walsh')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rule of the Great:<br>When people you greatly admire appear to be thinking deep&nbsp;thoughts, they probably are thinking about lunch.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bathquake, n.:<br>The violent quake that rattles the entire house when the water&nbsp;faucet is turned on to a certain point.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I said "we", officer, I was referring to myself, the four young&nbsp;ladies, and, of course, the goat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I know not with what weapons World War III will be fought, but World&nbsp;War IV will be fought with sticks and stones."<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Security check: INTRUDER ALERT!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Logicians have but ill defined&nbsp;As rational the human kind.<br>Logic, they say, belongs to man,<br>But let them prove it if they can.<br>&nbsp;-- Oliver Goldsmith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The idea is to die young as late as possible.<br>&nbsp;-- Ashley Montagu')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Without ice cream life and fame are meaningless.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Proposed Additions to the PDP-11 Instruction Set:<br>&nbsp;PI&nbsp;Punch Invalid&nbsp;POPI&nbsp;Punch Operator Immediately&nbsp;PVLC&nbsp;Punch Variable Length Card&nbsp;RASC&nbsp;Read And Shred Card&nbsp;RPM&nbsp;Read Programmers Mind&nbsp;RSSC&nbsp;reduce speed, step carefully  (for improved accuracy)<br>RTAB&nbsp;Rewind tape and break&nbsp;RWDSK&nbsp;rewind disk&nbsp;RWOC&nbsp;Read Writing On Card&nbsp;SCRBL&nbsp;scribble to disk  - faster than a write&nbsp;SLC&nbsp;Search for Lost Chord&nbsp;SPSW&nbsp;Scramble Program Status Word&nbsp;SRSD&nbsp;Seek Record and Scar Disk&nbsp;STROM&nbsp;Store in Read Only Memory&nbsp;TDB&nbsp;Transfer and Drop Bit&nbsp;WBT&nbsp;Water Binary Tree')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The modern child will answer you back before you''ve said anything.<br>&nbsp;-- Laurence J. Peter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"I don''t know what you mean by `glory,''" Alice said<br>Humpty Dumpty smiled contemptuously.  "Of course you don''t --&nbsp;till I tell you.  I meant `there''s a nice knock-down argument for&nbsp;you!''"<br>"But glory doesn''t mean `a nice knock-down argument,''" Alice&nbsp;objected.<br>"When I use a word," Humpty Dumpty said, in a rather scornful&nbsp;tone, "it means just what I choose it to mean -- neither more nor&nbsp;less."<br>"The question is," said Alice, "whether you can make words mean&nbsp;so many different things."<br>"The question is," said Humpty Dumpty, "which is to be master--&nbsp;that''s all."<br>&nbsp;-- Lewis Carrol, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every Horse has an Infinite Number of Legs (proof by intimidation):<br>&nbsp;Horses have an even number of legs.  Behind they have two legs, and in&nbsp;front they have fore-legs.  This makes six legs, which is certainly an&nbsp;odd number of legs for a horse.  But the only number that is both even&nbsp;and odd is infinity.  Therefore, horses have an infinite number of&nbsp;legs.  Now to show this for the general case, suppose that somewhere,<br>there is a horse that has a finite number of legs.  But that is a horse&nbsp;of another color, and by the [above] lemma ["All horses are the same&nbsp;color"], that does not exist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'At any given moment, an arrow must be either where it is or where it is&nbsp;not.  But obviously it cannot be where it is not.  And if it is where&nbsp;it is, that is equivalent to saying that it is at rest.<br>&nbsp;-- Zeno''s paradox of the moving (still?) arrow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Goto, n.:<br>A programming tool that exists to allow structured programmers&nbsp;to complain about unstructured programmers.<br>&nbsp;-- Ray Simard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Come, every frustum longs to be a cone,<br>And every vector dreams of matrices.<br>Hark to the gentle gradient of the breeze:<br>It whispers of a more ergodic zone.<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Spark''s Sixth Rule for Managers:<br>If a subordinate asks you a pertinent question, look at him as&nbsp;if he had lost his senses.  When he looks down, paraphrase the question&nbsp;back at him.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t cook tonight -- starve a rat today!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Il brilgue: les t^^Hoves libricilleux<br>Se gyrent et frillant dans le guave,<br>Enm^^Him''^Hes sont les gougebosquex,<br>Et le m^^Homerade horgrave.<br>&nbsp;-- Lewis Carrol, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For perfect happiness, remember two things:<br>(1) Be content with what you''ve got.<br>(2) Be sure you''ve got plenty.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The end of the human race will be that it will eventually die of&nbsp;civilization.<br>&nbsp;-- Ralph Waldo Emerson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ask not for whom the <CONTROL-G> tolls.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Suddenly, Professor Liebowitz realizes he has come to the seminar&nbsp;without his duck ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Arbitrary systems, pl.n.:<br>Systems about which nothing general can be said, save "nothing&nbsp;general can be said."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speaking of Godzilla and other things that convey horror:<br><br>With a purposeful grimace and a Mongo-like flair<br>He throws the spinning disk drives in the air!<br>And he picks up a Vax and he throws it back down<br>As he wades through the lab making terrible sounds!<br>Helpless users with projects due<br>Scream "My God!" as he stomps on the tape drives, too!&nbsp;<br>Oh, no!  He says Unix runs too slow!  Go, go, DECzilla!<br>Oh, yes!  He''s gonna bring up VMS!  Go, go, DECzilla!"&nbsp;&nbsp;* VMS is a trademark of Digital Equipment Corporation&nbsp;* DECzilla is a trademark of Hollow Chocolate Bunnies of Death, Inc.<br>&nbsp;-- Curtis Jackson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Necessity is a mother.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hofstadter''s Law:<br>It always takes longer than you expect, even when you take&nbsp;Hofstadter''s Law into account.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Even though they raised the rate for first class mail in the United&nbsp;States we really shouldn''t complain -- it''s still only two cents a&nbsp;day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Like so many Americans, she was trying to construct a life that made&nbsp;sense from things she found in gift shops.<br>&nbsp;-- Kurt Vonnegut, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone can do any amount of work provided it isn''t the work he is&nbsp;supposed to be doing at the moment.<br>&nbsp;-- Robert Benchley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"People think love is an emotion.  Love is good sense."<br>&nbsp;-- Ken Kesey')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'She''s genuinely bogus.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Overdrawn?  But I still have checks left!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Calvin Coolidge looks as if he had been weaned on a pickle."<br>&nbsp;-- Alice Roosevelt Longworth')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'And yet, seasons must be taken with a grain of salt, for they too have&nbsp;a sense of humor, as does history.  Corn stalks comedy, comedy stalks&nbsp;tragedy, and this too is historic.  And yet, still, when corn meets&nbsp;tragedy face to face, we have politics.<br>&nbsp;-- Dalglish, Larsen and Sutherland, "Root Crops and<br>&nbsp;   Ground Cover"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anything that is good and useful is made of chocolate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'War is peace.  Freedom is slavery.  Ketchup is a vegetable.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Drew''s Law of Highway Biology:<br>The first bug to hit a clean windshield lands directly in front&nbsp;of your eyes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is easier to get forgiveness than permission.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Did you know ...<br>&nbsp;That no-one ever reads these things?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Text processing has made it possible to right-justify any idea, even&nbsp;one which cannot be justified on any other grounds."<br>&nbsp;-- J. Finnegan, USC.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Religion has done love a great service by making it a sin.<br>&nbsp;-- Anatole France')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He hadn''t a single redeeming vice.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '" I changed my headlights the other day. I put in strobe lights&nbsp;instead! Now when I drive at night, it looks like everyone else is&nbsp;standing still ..."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The human mind treats a new idea the way the body treats a strange&nbsp;protein -- it rejects it.<br>&nbsp;-- P. Medawar')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Quigley''s Law:<br>Whoever has any authority over you, no matter how small, will&nbsp;atttempt to use it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You too can wear a nose mitten.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I sent a letter to the fish,<br>I told them, "This is what I wish."&nbsp;The little fishes of the sea,<br>They sent an answer back to me.<br>The little fishes'' answer was&nbsp;"We cannot do it, sir, because ..."&nbsp;I sent a letter back to say&nbsp;It would be better to obey.<br>But someone came to me and said&nbsp;"The little fishes are in bed."&nbsp;I said to him, and I said it plain&nbsp;"Then you must wake them up again."&nbsp;I said it very loud and clear,<br>I went and shouted in his ear.<br>But he was very stiff and proud,<br>He said "You needn''t shout so loud."&nbsp;And he was very proud and stiff,<br>He said "I''ll go and wake them if ..."&nbsp;I took a kettle from the shelf,<br>I went to wake them up myself.<br>But when I found the door was locked&nbsp;I pulled and pushed and kicked and knocked,<br>And when I found the door was shut,<br>I tried to turn the handle, But ...<br><br>"Is that all?" asked Alice.<br>"That is all." said Humpty Dumpty. "Goodbye."<br>&nbsp;-- Lewis Carrol, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh, when I was in love with you,<br>Then I was clean and brave,<br>And miles around the wonder grew<br>How well did I behave.<br>&nbsp;And now the fancy passes by,<br>And nothing will remain,<br>And miles around they''ll say that I<br>Am quite myself again.<br>&nbsp;-- A. E. Housman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Character Density, n.:<br>The number of very weird people in the office.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God has intended the great to be great and the little to be little ...<br>The trade unions, under the European system, destroy liberty ... I do&nbsp;not mean to say that a dollar a day is enough to support a workingman&nbsp;... not enough to support a man and five children if he insists on&nbsp;smoking and drinking beer.  But the man who cannot live on bread and&nbsp;water is not fit to live!  A family may live on good bread and water in&nbsp;the morning, water and bread at midday, and good bread and water at&nbsp;night!<br>&nbsp;-- Rev. Henry Ward Beecher')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When in doubt, use brute force.<br>&nbsp;-- Ken Thompson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no such thing as fortune.  Try again.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Etymology, n.:<br>Some early etymological scholars came up with derivations that&nbsp;were hard for the public to believe.  The term "etymology" was formed&nbsp;from the Latin "etus" ("eaten"), the root "mal" ("bad"), and "logy"<br>"study of").  It meant "the study of things that are hard to swallow."<br>&nbsp;-- Mike Kellen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Entropy isn''t what it used to be.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s a very *__^H^HUN*lucky week in which to be took dead.<br>&nbsp;-- Churchy La Femme')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  Why do mountain climbers rope themselves together?&nbsp;A:  To prevent the sensible ones from going home.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Blythe, California, a city ordinance declares that a person must own&nbsp;at least two cows before he can wear cowboy boots in public.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Demand the establishment of the government&nbsp;in its rightful home at Disneyland.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do not drink coffee in early a.m.  It will keep you awake until noon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cancel me not -- for what then shall remain?&nbsp;Abscissas, some mantissas, modules, modes,<br>A root or two, a torus and a node:<br>The inverse of my verse, a null domain.<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A crusader''s wife slipped from the garrison&nbsp;And had an affair with a Saracen.<br>She was not oversexed,<br>Or jealous or vexed,<br>She just wanted to make a comparison.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Portable, adj.:<br>Survives system reboot.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It was one of those perfect summer days -- the sun was shining, a&nbsp;breeze was blowing, the birds were singing, and the lawn mower was&nbsp;broken ...<br>&nbsp;-- James Dent')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Proposed Additions to the PDP-11 Instruction Set:<br>&nbsp;DC&nbsp;Divide and Conquer&nbsp;DMPK&nbsp;Destroy Memory Protect Key&nbsp;DO&nbsp;Divide and Overflow&nbsp;EMPC&nbsp;Emulate Pocket Calculator&nbsp;EPI&nbsp;Execute Programmer Immediately&nbsp;EROS&nbsp;Erase Read Only Storage&nbsp;EXCE&nbsp;Execute Customer Engineer&nbsp;HCF&nbsp;Halt and Catch Fire&nbsp;IBP&nbsp;Insert Bug and Proceed&nbsp;INSQSW&nbsp;Insert into queue somewhere (for FINO queues [First in never out])<br>PBC&nbsp;Print and Break Chain&nbsp;PDSK&nbsp;Punch Disk')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If only God would give me some clear sign!  Like making a large deposit&nbsp;in my name at a Swiss bank.<br>&nbsp;-- Woody Allen, "Without Feathers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'HELP!  MY TYPEWRITER IS BROKEN!<br>&nbsp;-- E. E. CUMMINGS')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life is like a bowl of soup with hairs floating on it.  You have to&nbsp;eat it nevertheless."<br>&nbsp;-- Flaubert')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many Oregonians does it take to screw in a light bulb?&nbsp;A:  Three.  One to screw in the lightbulb and two to fend off all those&nbsp;    Californians trying to share the experience.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"...and the fully armed nuclear warheads, are, of course, merely a&nbsp;courtesy detail."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I did my own thing and now I''ve got&nbsp;to undo it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good news is just life''s way of keeping you off balance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do what comes naturally now.  Seethe and fume and throw a tantrum.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''re never too old to become younger.<br>&nbsp;-- Mae West')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gravity is a myth, the Earth sucks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cleaning your house while your kids are still growing is like&nbsp;shoveling the walk before it stops snowing.<br>&nbsp;-- Phyllis Diller')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Jones''s First Law:<br>Anyone who makes a significant contribution to any field of&nbsp;endeavor, and stays in that field long enough, becomes an obstruction&nbsp;to its progress -- in direct proportion to the importance of their&nbsp;original contribution.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whenever I hear anyone arguing for slavery, I feel a strong impulse to&nbsp;see it tried on him personally.<br>&nbsp;-- A. Lincoln')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are two types of people in this world, good and bad.  The good&nbsp;sleep better, but the bad seem to enjoy the waking hours much more.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The advertisement is the most truthful part of a newspaper<br>&nbsp;-- Thomas Jefferson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you just try long enough and hard enough, you can always manage to&nbsp;boot yourself in the posterior.<br>&nbsp;-- A. J. Liebling')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"No proper program contains an indication which as an operator-applied&nbsp;occurrence identifies an operator-defining occurrence which as an&nbsp;indication-applied occurrence identifies an indication-defining&nbsp;occurrence different from the one identified by the given indication as&nbsp;an indication-applied occurrence."<br>&nbsp;-- ALGOL 68 Report')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Matrimony isn''t a word, it''s a sentence."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To generalize is to be an idiot.<br>&nbsp;-- William Blake')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The IRS spends God knows how much of your tax money on these toll-free&nbsp;information hot lines staffed by IRS employees, whose idea of a&nbsp;dynamite tax tip is that you should print neatly.  If you ask them a&nbsp;real tax question, such as how you can cheat, they''re useless.<br>&nbsp;So, for guidance, you want to look to big business.  Big business never&nbsp;pays a nickel in taxes, according to Ralph Nader, who represents a big&nbsp;consumer organization that never pays a nickel in taxes...<br>&nbsp;-- Dave Barry, "Sweating Out Taxes"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A University without students is like an ointment without a fly."<br>-- Ed Nather, professor of astronomy at UT Austin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You need no longer worry about the future.  This time tomorrow you''ll&nbsp;be dead.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can bring any calculator you like to the midterm, as long as it &nbsp;doesn''t dim the lights when you turn it on."<br>&nbsp;-- Hepler, Systems Design 182')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conversation, n.:<br>A vocal competition in which the one who is catching his breath&nbsp;is called the listener.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;An architect''s first work is apt to be spare and clean.  He&nbsp;knows he doesn''t know what he''s doing, so he does it carefully and with&nbsp;great restraint.<br>As he designs the first work, frill after frill and&nbsp;embellishment after embellishment occur to him.  These get stored away&nbsp;to be used "next time".  Sooner or later the first system is finished,<br>and the architect, with firm confidence and a demonstrated mastery of&nbsp;that class of systems, is ready to build a second system.<br>This second is the most dangerous system a man ever designs.<br>When he does his third and later ones, his prior experiences will&nbsp;confirm each other as to the general characteristics of such systems,<br>and their differences will identify those parts of his experience that&nbsp;are particular and not generalizable.<br>The general tendency is to over-design the second system, using&nbsp;all the ideas and frills that were cautiously sidetracked on the first&nbsp;one.  The result, as Ovid says, is a "big pile".<br>&nbsp;-- Frederick Brooks, "The Mythical Man Month"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Baseball is a skilled game.  It''s America''s game -- it, and high&nbsp;taxes.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You have the capacity to learn from mistakes.  You''ll learn a lot&nbsp;today.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This novel is not to be tossed lightly aside, but to be hurled with&nbsp;great force.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Velilind''s Laws of Experimentation:<br>(1) If reproducibility may be a problem, conduct the test only<br>    once.<br>(2) If a straight line fit is required, obtain only two data<br>    points.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Given the choice between accomplishing something and just lying&nbsp;around, I''d rather lie around.  No contest."<br>&nbsp;-- Eric Clapton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Shamus, n. [Yiddish]:<br>A shamus is a guy who takes care of handyman tasks around the&nbsp;temple, and makes sure everything is in working order.<br>A shamus is at the bottom of the pecking order of synagog&nbsp;functionaries, and there''s a joke about that:<br>A rabbi, to show his humility before God, cries out in the&nbsp;middle of a service, "Oh, Lord, I am nobody!"  The cantor, not to be&nbsp;bested, also cries out, "Oh, Lord, I am nobody!"<br>The shamus, deeply moved, follows suit and cries, "Oh, Lord, I&nbsp;am nobody!"  The rabbi turns to the cantor and says, "Look who thinks&nbsp;he''s nobody!"<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I am so optimistic about beef prices that I''ve just leased a pot roast&nbsp;with an option to buy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bagbiter:<br>1. n.; Equipment or program that fails, usually&nbsp;intermittently.  2. adj.:  Failing hardware or software.  "This&nbsp;bagbiting system won''t let me get out of spacewar."  Usage:  verges on&nbsp;obscenity.  Grammatically separable; one may speak of "biting the&nbsp;bag".  Synonyms: LOSER, LOSING, CRETINOUS, BLETCHEROUS, BARFUCIOUS,<br>CHOMPER, CHOMPING.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Under a government which imprisons any unjustly, the true place for a&nbsp;just man is also in prison.<br>&nbsp;-- Henry David Thoreau')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Every morning, I get up and look through the ''Forbes'' list of the&nbsp;richest people in America.  If I''m not there, I go to work"<br>&nbsp;-- Robert Orben')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Ubi non accusator, ibi non judex."&nbsp;<br>Where there is no police, there is no speed limit.)<br>&nbsp;-- Roman Law, trans. Petr Beckmann (1971)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Puns are little "plays on words" that a certain breed of person loves&nbsp;to spring on you and then look at you in a certain self-satisfied way&nbsp;to indicate that he thinks that you must think that he is by far the&nbsp;cleverest person on Earth now that Benjamin Franklin is dead, when in&nbsp;fact what you are thinking is that if this person ever ends up in a&nbsp;lifeboat, the other passengers will hurl him overboard by the end of&nbsp;the first day even if they have plenty of food and water.<br>&nbsp;-- Dave Barry, "Why Humor is Funny"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"For that matter, compare your pocket computer with the massive jobs of&nbsp;a thousand years ago.  Why not, then, the last step of doing away with&nbsp;computers altogether?"<br>&nbsp;-- Jehan Shuman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I was drunk last night, crawled home across the lawn.  By accident I&nbsp;put the car key in the door lock.  The house started up.  So I figured&nbsp;what the hell, and drove it around the block a few times.  I thought I&nbsp;should go park it in the middle of the freeway and yell at everyone to&nbsp;get off my driveway."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every program has two purposes -- one for which it was written and&nbsp;another for which it wasn''t.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Only God can make random selections.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The law will never make men free; it is men who have got to make the&nbsp;law free.<br>&nbsp;-- Henry David Thoreau')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The scum also rises.<br>&nbsp;-- Dr. Hunter S. Thompson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I like being single.  I''m always there when I need me."<br>&nbsp;-- Art Leo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speer''s 1st Law of Proofreading:<br>The visibility of an error is inversely proportional to the&nbsp;number of times you have looked at it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The light at the end of the tunnel is the headlight of an approaching&nbsp;train.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This fortune is false.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All things are possible, except skiing thru a revolving door.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reality is an obstacle to hallucination.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gosh that takes me back... or is it forward?  That''s the trouble with&nbsp;time travel, you never can tell."<br>&nbsp;-- Doctor Who "Androids of Tara"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never underestimate the bandwidth of a station wagon full of tapes.<br>&nbsp;-- Dr. Warren Jackson, Director, UTCS')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Think honk if you''re a telepath.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is much easier to suggest solutions when you know nothing about the&nbsp;problem.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is impossible to travel faster than light, and certainly not&nbsp;desirable, as one''s hat keeps blowing off.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '$3,000,000 ')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Half-done:<br>This is the best way to eat a kosher dill -- when it''s still&nbsp;crunchy, light green, yet full of garlic flavor.  The difference&nbsp;between this and the typical soggy dark green cucumber corpse is like&nbsp;the difference between life and death.<br>You may find it difficult to find a good half-done kosher dill&nbsp;there in Seattle, so what you should do is take a cab out to the&nbsp;airport, fly to New York, take the JFK Express to Jay Street-Borough&nbsp;Hall, transfer to an uptown F, get off at East Broadway, walk north on&nbsp;Essex (along the park), make your first left onto Hester Street, walk&nbsp;about fifteen steps, turn ninety degrees left, and stop.  Say to the&nbsp;man, "Let me have a nice half-done."<br>Worth the trouble, wasn''t it?<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Langsam''s Laws:<br>(1) Everything depends.<br>(2) Nothing is always.<br>(3) Everything is sometimes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ginsberg''s Theorem:<br>(1) You can''t win.<br>(2) You can''t break even.<br>(3) You can''t even quit the game.<br>&nbsp;Freeman''s Commentary on Ginsberg''s theorem:<br>Every major philosophy that attempts to make life seem<br>meaningful is based on the negation of one part of Ginsberg''s<br>Theorem.  To wit:<br><br>(1) Capitalism is based on the assumption that you can win.<br>(2) Socialism is based on the assumption that you can break<br>    even.<br>(3) Mysticism is based on the assumption that you can quit the<br>    game.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Best of all is never to have been born.  Second best is to die soon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The correct way to punctuate a sentence that starts: "Of course it is&nbsp;none of my business, but --" is to place a period after the word "but."&nbsp;Don''t use excessive force in supplying such a moron with a period.<br>Cutting his throat is only a momentary pleasure and is bound to get you&nbsp;talked about.<br>&nbsp;-- Lazarus Long, "Time Enough for Love"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had intended Man to Watch TV, He would have given him Rabbit&nbsp;Ears.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Barth''s Distinction:<br>There are two types of people: those who divide people into two&nbsp;types, and those who don''t.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'HOW YOU CAN TELL THAT IT''S GOING TO BE A ROTTEN DAY:<br>#15 Your pet rock snaps at you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many DEC repairman does it take to fix a flat?&nbsp;A:  Five; four to hold the car up and one to swap tires.<br>&nbsp;Q:  How long does it take?&nbsp;A:  It''s indeterminate.  It will depend upon how many flats they''ve&nbsp;    brought with them.<br>&nbsp;Q:  What happens if you''ve got TWO flats?&nbsp;A:  They replace your generator.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Most people wouldn''t know music if it came up and bit them on the ass.<br>&nbsp;-- Frank Zappa')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A budget is just a method of worrying before you spend money, as well&nbsp;as afterward.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THEORY&nbsp;Into love and out again,<br>Thus I went and thus I go.<br>Spare your voice, and hold your pen:<br>Well and bitterly I know&nbsp;All the songs were ever sung,<br>All the words were ever said:<br>Could it be, when I was young,<br>Someone dropped me on my head?<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why does man kill?  He kills for food.  And not only food: frequently&nbsp;there must be a beverage.<br>&nbsp;-- Woody Allen, "Without Feathers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... an experienced, industrious, ambitious, and often quite often&nbsp;picturesque liar."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One monk said to the other, "The fish has flopped out of the net! How&nbsp;will it live?"  The other said, "When you have gotten out of the net,<br>I''ll tell you."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had wanted you to go around nude, He would have given you bigger&nbsp;hands.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Acid -- better living through chemistry.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The computing field is always in need of new cliches.<br>&nbsp;-- Alan Perlis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t take life too seriously -- you''ll never get out of it alive.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If value corrupts then absolute value corrupts absolutely"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a great discovery still to be made in Literature: that of&nbsp;paying literary men by the quantity they do NOT write.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If everything is coming your way then you''re in the wrong lane.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People who are funny and smart and return phone calls get much better&nbsp;press than people who are just funny and smart.<br>&nbsp;-- Howard Simons, "The Washington Post"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A New York City judge ruled that if two women behind you at the movies&nbsp;insist on discussing the probable outcome of the film, you have the&nbsp;right to turn around and blow a Bronx cheer at them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Politician, n.:<br>From the Greek "poly" ("many") and the French "tete" ("head" or&nbsp;"face," as in "tete-a-tete": head to head or face to face).  Hence&nbsp;"polytetien", a person of two or more faces.<br>&nbsp;-- Martin Pitt')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every word is like an unnecessary stain on silence and nothingness.<br>&nbsp;-- Beckett')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t suspect your friends -- turn them in!<br>&nbsp;-- "Brazil"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Don''t say yes until I finish talking."<br>&nbsp;-- Darryl F. Zanuck')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The reader this message encounters not failing to understand is&nbsp;cursed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When Marriage is Outlawed,<br>Only Outlaws will have Inlaws.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ever notice that even the busiest people are never too busy to tell you&nbsp;just how busy they are.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I argue very well.  Ask any of my remaining friends.  I can win an&nbsp;argument on any topic, against any opponent.  People know this, and&nbsp;steer clear of me at parties.  Often, as a sign of their great respect,<br>they don''t even invite me."<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I really hate this damned machine&nbsp;I wish that they would sell it.<br>It never does quite what I want&nbsp;But only what I tell it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Genetics explains why you look like your father, and if you don''t, why&nbsp;you should.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'fortune: cpu time/usefulness ratio too high -- core dumped.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never offend people with style when you can offend them with&nbsp;substance.<br>&nbsp;-- Sam Brown, "The Washington Post", January 26, 1977')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'GEMINI (May 21 - June 20)<br>You are a quick and intelligent thinker.  People like you&nbsp;because you are bisexual.  However, you are inclined to expect too much&nbsp;for too little.  This means you are cheap.  Geminis are known for&nbsp;committing incest.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I shot an arrow into the air, and it stuck."<br>&nbsp;-- Graffito in Los Angeles')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Murphy''s Law is recursive.  Washing your car to make it rain doesn''t&nbsp;work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The fact that boys are allowed to exist at all is evidence of a&nbsp;remarkable Christian forbearance among men.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My mother loved children -- she would have given anything if I had been&nbsp;one.<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A successful [software] tool is one that was used to do something&nbsp;undreamed of by its author.<br>&nbsp;-- S. C. Johnson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Menu, n.:<br>A list of dishes which the restaurant has just run out of.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sixtus V, Pope from 1585 to 1590 authorized a printing of the Vulgate&nbsp;Bible.  Taking no chances, the pope issued a papal bull automatically&nbsp;excommunicating any printer who might make an alteration in the text.<br>This he ordered printed at the beginning of the Bible.  He personally&nbsp;examined every sheet as it came off the press.  Yet the published&nbsp;Vulgate Bible contained so many errors that corrected scraps had to be&nbsp;printed and pasted over them in every copy.  The result provoked wry&nbsp;comments on the rather patchy papal infallibility, and Pope Sixtus had&nbsp;no recourse but to order the return and destruction of every copy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boss, n.:<br>According to the Oxford English Dictionary, in the Middle Ages&nbsp;the words "boss" and "botch" were largely synonymous, except that boss,<br>in addition to meaning "a supervisor of workers" also meant "an&nbsp;ornamental stud."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Abrams'' Principle:<br>The shortest distance between two points is off the wall.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Things are more like they used to be than they are now.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'They''re only trying to make me LOOK paranoid!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Being disintegrated makes me ve-ry an-gry!"  <huff, huff>')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had intended Man to Smoke, He would have set him on Fire.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Under deadline pressure for the next week.  If you want something, it&nbsp;can wait.  Unless it''s blind screaming paroxysmally hedonistic ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... And remember: if you don''t like the news, go out and make some of&nbsp;your own."&nbsp;        &nbsp;-- "Scoop" Nisker, KFOG radio reporter<br>&nbsp;   Preposterous Words')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The giraffe you thought you offended last week is willing to be nuzzled&nbsp;today.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'unix soit qui mal y pense')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Death is God''s way of telling you not to be such a wise guy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Riemann, Hilbert or in Banach space&nbsp;Let superscripts and subscripts go their ways.<br>Our asymptotes no longer out of phase,<br>We shall encounter, counting, face to face.<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but my favorite commercial is on TV."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I refuse to have a battle of wits with an unarmed person."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Help fight continental drift.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'ARIES (Mar 21 - Apr 19)<br>You are the pioneer type and hold most people in contempt.  You<br>are quick tempered, impatient, and scornful of advice.  You are<br>not very nice.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After [Benjamin] Franklin came a herd of Electrical Pioneers whose&nbsp;names have become part of our electrical terminology: Myron Volt, Mary&nbsp;Louise Amp, James Watt, Bob Transformer, etc.  These pioneers conducted&nbsp;many important electrical experiments.  For example, in 1780 Luigi&nbsp;Galvani discovered (this is the truth) that when he attached two&nbsp;different kinds of metal to the leg of a frog, an electrical current&nbsp;developed and the frog''s leg kicked, even though it was no longer&nbsp;attached to the frog, which was dead anyway.  Galvani''s discovery led&nbsp;to enormous advances in the field of amphibian medicine.  Today,<br>skilled veterinary surgeons can take a frog that has been seriously&nbsp;injured or killed, implant pieces of metal in its muscles, and watch it&nbsp;hop back into the pond just like a normal frog, except for the fact&nbsp;that it sinks like a stone.<br>&nbsp;-- Dave Barry, "What is Electricity?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will be Told about it Tomorrow.  Go Home and Prepare Thyself.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your lucky number has been disconnected.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh, wow!  Look at the moon!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Users know your home telephone number.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The human brain is like an enormous fish -- it is flat and slimy and&nbsp;has gills through which it can see."<br>&nbsp;-- Monty Python')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'U:&nbsp;There''s a U -- a Unicorn!<br>Run right up and rub its horn.<br>Look at all those points you''re losing!<br>UMBER HULKS are so confusing.<br>&nbsp;-- The Roguelet''s ABC')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Faith is the quality that enables you to eat blackberry jam on a picnic&nbsp;without looking to see whether the seeds move.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Legalize free-enterprise murder: why should governments have all the&nbsp;fun?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I do not feel obliged to believe that the same God who has endowed us&nbsp;with sense, reason, and intellect has intended us to forego their use."<br>&nbsp;-- Galileo Galilei')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Committees have become so important nowadays that subcommittees have to&nbsp;be appointed to do the work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All I want is a warm bed and a kind word and unlimited power<br>&nbsp;-- Ashleigh Brilliant')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'BOO!  We changed Coke again!  BLEAH!  BLEAH!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love is the triumph of imagination over intelligence.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lazlo''s Chinese Relativity Axiom:<br>No matter how great your triumphs or how tragic your defeats --&nbsp;approximately one billion Chinese couldn''t care less.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What if nothing exists and we''re all in somebody''s dream?  Or what''s&nbsp;worse, what if only that fat guy in the third row exists?<br>&nbsp;-- Woody Allen, "Without Feathers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mathematicians often resort to something called Hilbert space, which is&nbsp;described as being n-dimensional.  Like modern sex, any number can&nbsp;play.<br>&nbsp;-- Dr. Thor Wald, in "Beep/The Quincunx of Time", by<br>&nbsp;   James Blish')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The human race has one really effective weapon, and that is laughter.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A doctor, an architect, and a computer scientist were arguing&nbsp;about whose profession was the oldest.  In the course of their&nbsp;arguments, they got all the way back to the Garden of Eden, whereupon&nbsp;the doctor said, "The medical profession is clearly the oldest, because&nbsp;Eve was made from Adam''s rib, as the story goes, and that was a simply&nbsp;incredible surgical feat."<br>The architect did not agree.  He said, "But if you look at the&nbsp;Garden itself, in the beginning there was chaos and void, and out of&nbsp;that, the Garden and the world were created.  So God must have been an&nbsp;architect."<br>The computer scientist, who had listened to all of this said,<br>"Yes, but where do you think the chaos came from?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People will do tomorrow what they did today because that is what they&nbsp;did yesterday.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every man is as God made him, ay, and often worse.<br>&nbsp;-- Miguel de Cervantes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #7:<br>&nbsp;Q:  What happened then?&nbsp;A:  He told me, he says, "I have to kill you because you can identify&nbsp;    me."&nbsp;Q:  Did he kill you?&nbsp;A:  No.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Look out!  Behind you!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Afternoon very favorable for romance.  Try a single person for a&nbsp;change.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t kiss an elephant on the lips today.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Our country has plenty of good five-cent cigars, but the trouble is&nbsp;they charge fifteen cents for them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In specifications, Murphy''s Law supersedes Ohm''s.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Sherry [Thomas Sheridan] is dull, naturally dull; but it must have&nbsp;taken him a great deal of pains to become what we now see him.  Such an&nbsp;excess of stupidity, sir, is not in Nature."<br>&nbsp;-- Samuel Johnson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Andrea: Unhappy the land that has no heroes.<br>Galileo: No, unhappy the land that _____^H^H^H^H^Hneeds heroes.<br>&nbsp;-- Bertolt Brecht, "Life of Galileo"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Parker''s Law:<br>Beauty is only skin deep, but ugly goes clean to the bone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Our vision is to speed up time, eventually eliminating it."<br>&nbsp;-- Alex Schure')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Slaves are generally expected to sing as well as to work ... I did not,<br>when a slave, understand the deep meanings of those rude, and&nbsp;apparently incoherent songs.  I was myself within the circle, so that I&nbsp;neither saw nor heard as those without might see and hear.  They told a&nbsp;tale which was then altogether beyond my feeble comprehension:  they&nbsp;were tones, loud, long and deep, breathing the prayer and complaint of&nbsp;souls boiling over with the bitterest anguish.  Every tone was a&nbsp;testimony against slavery, and a prayer to God for deliverance from&nbsp;chains.<br>&nbsp;-- Frederick Douglass')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... so long as the people do not care to exercise their freedom, those&nbsp;who wish to tyrranize will do so; for tyrants are active and ardent,<br>and will devote themselves in the name of any number of gods, religious&nbsp;and otherwise, to put shackles upon sleeping men.<br>&nbsp;-- Voltarine de Cleyre')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;Another Glitch in the Call<br>&nbsp;------- ------ -- --- ----<br>(Sung to the tune of a recent Pink Floyd song.)<br>&nbsp;We don''t need no indirection&nbsp;We don''t need no flow control&nbsp;No data typing or declarations&nbsp;Did you leave the lists alone?&nbsp;<br>Hey!  Hacker!  Leave those lists alone!&nbsp;&nbsp;Chorus:<br>All in all, it''s just a pure-LISP function call.<br>All in all, it''s just a pure-LISP function call.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There was a young man who said "God,<br>I find it exceedingly odd,<br>That the willow oak tree<br>Continues to be,<br>When there''s no one about in the Quad."&nbsp;&nbsp;"Dear Sir, your astonishment''s odd,<br>For I''m always about in the Quad;<br>And that''s why the tree,<br>Continues to be,"&nbsp;Signed "Yours faithfully, God."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '(Sung to the tune of "The Impossible Dream" from MAN OF LA MANCHA)<br><br>To code the impossible code,<br>To bring up a virgin machine,<br>To pop out of endless recursion,<br>To grok what appears on the screen,<br><br>To right the unrightable bug,<br>To endlessly twiddle and thrash,<br>To mount the unmountable magtape,<br>To stop the unstoppable crash!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Parallel lines never meet, unless you bend one or both of them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nasrudin returned to his village from the imperial capital, and the&nbsp;villagers gathered around to hear what had passed.  "At this time,"&nbsp;said Nasrudin, "I only want to say that the King spoke to me."  All the&nbsp;villagers but the stupidest ran off to spread the wonderful news.  The&nbsp;remaining villager asked, "What did the King say to you?"  "What he&nbsp;said -- and quite distinctly, for everyone to hear -- was ''Get out of&nbsp;my way!''" The simpleton was overjoyed; he had heard words actually&nbsp;spoken by the King, and seen the very man they were spoken to.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Nondeterminism means never having to say you are wrong."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will feel hungry again in another hour.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'f u cn rd ths, itn tyg h myxbl cd.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tact is the ability to tell a man he has an open mind when he has a&nbsp;hole in his head.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cleanliness is next to impossible.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"After I asked him what he meant, he replied that freedom consisted of&nbsp;the unimpeded right to get rich, to use his ability, no matter what the&nbsp;cost to others, to win advancement."<br>&nbsp;-- Norman Thomas')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If all the world''s economists were laid end to end, we wouldn''t reach a&nbsp;conclusion.<br>&nbsp;-- William Baumol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Besides the device, the box should contain:<br>&nbsp;* Eight little rectangular snippets of paper that say "WARNING"&nbsp;&nbsp;* A plastic packet containing four 5/17 inch pilfer grommets and two&nbsp;  club-ended 6/93 inch boxcar prawns.<br>&nbsp;YOU WILL NEED TO SUPPLY: a matrix wrench and 60,000 feet of tram&nbsp;cable.<br>&nbsp;IF ANYTHING IS DAMAGED OR MISSING: You IMMEDIATELY should turn to your&nbsp;spouse and say: "Margaret, you know why this country can''t make a car&nbsp;that can get all the way through the drive-through at Burger King&nbsp;without a major transmission overhaul?  Because nobody cares, that''s&nbsp;why."&nbsp;&nbsp;WARNING: This is assuming your spouse''s name is Margaret.<br>&nbsp;-- Dave Barry, "Read This First!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The last time somebody said, `I find I can write much better with a&nbsp;word processor.'', I replied, `They used to say the same thing about&nbsp;drugs.''<br>&nbsp;-- Roy Blount, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Question:<br>Man Invented Alcohol,<br>God Invented Grass.<br>Who do you trust?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fourth Law of Revision:<br>It is usually impractical to worry beforehand about&nbsp;interferences -- if you have none, someone will make one for you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anything worth doing is worth overdoing')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vail''s Second Axiom:<br>The amount of work to be done increases in proportion to the&nbsp;amount of work already completed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Next Friday will not be your lucky day.  As a matter of fact, you don''t&nbsp;have a lucky day this year.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Wouldn''t the sentence ''I want to put a hyphen between the words Fish&nbsp;and And and And and Chips in my Fish-And-Chips sign'' have been clearer&nbsp;if quotation marks had been placed before Fish, and between Fish and&nbsp;and, and and and And, and And and and, and and and And, and And and&nbsp;and, and and and Chips, as well as after Chips?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;WARNING TO ALL PERSONNEL:<br>&nbsp;Firings will continue until morale improves.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anything is good if it''s made of chocolate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We don''t understand the software, and sometimes we don''t understand the&nbsp;hardware, but we can *___^H^H^Hsee* the blinking lights!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone who goes to a psychiatrist ought to have his head examined.<br>&nbsp;-- Samuel Goldwyn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is against the law for a monster to enter the corporate limits of&nbsp;Urbana, Illinois.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you perceive that there are four possible ways in which a procedure&nbsp;can go wrong, and circumvent these, then a fifth way will promptly&nbsp;develop.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'That woman speaks eight languages and can''t say "no" in any of them.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When a shepherd goes to kill a wolf, and takes his dog along to see the&nbsp;sport, he should take care to avoid mistakes.  The dog has certain&nbsp;relationships to the wolf the shepherd may have forgotten.<br>&nbsp;-- Robert Pirsig, "Zen and the Art of Motorcycle<br>&nbsp;   Maintenance"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t take life so serious, son, it ain''t nohow permanent.<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The primary theme of SoupCon is communication.  The acronym "LEO"&nbsp;represents the secondary theme:<br><br>Law Enforcement Officials&nbsp;&nbsp;The overall theme of SoupCon shall be:<br><br>Avoiding Communication with Law Enforcement Officials')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good advice is something a man gives when he is too old to set a bad&nbsp;example.<br>&nbsp;-- La Rouchefoucauld')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A musician of more ambition than talent composed an elegy at&nbsp;the death of composer Edward MacDowell.  She played the elegy for the&nbsp;pianist Josef Hoffman, then asked his opinion.  "Well, it''s quite&nbsp;nice," he replied, but don''t you think it would be better if ..."<br>"If what?"  asked the composer.<br>"If ... if you had died and MacDowell had written the elegy?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If God lived on Earth, people would knock out all His windows."<br>&nbsp;-- Yiddish saying')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A very intelligent turtle&nbsp;Found programming UNIX a hurdle<br>The system, you see,<br>Ran as slow as did he,<br>And that''s not saying much for the turtle.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is nothing wrong with Southern California that a rise in the&nbsp;ocean level wouldn''t cure.<br>&nbsp;-- Ross MacDonald')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can''t judge a book by the way it wears its hair.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bipolar, adj.:<br>Refers to someone who has homes in Nome, Alaska, and Buffalo,<br>New York')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As you reach for the web, a venomous spider appears.  Unable to pull&nbsp;your hand away in time, the spider promptly, but politely, bites you.<br>The venom takes affect quickly causing your lips to turn plaid along&nbsp;with your complexion.  You become dazed, and in your stupor you fall&nbsp;from the limbs of the tree.  Snap!  Your head falls off and rolls all&nbsp;over the ground.  The instant before you croak, you hear the whoosh of&nbsp;a vacuum being filled by the air surrounding your head.  Worse yet, the&nbsp;spider is suing you for damages.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Substitute "damn" every time you''re inclined to write "very"; your&nbsp;editor will delete it and the writing will be just as it should be.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ever since prehistoric times, wise men have tried to understand what,<br>exactly, make people laugh.  That''s why they were called "wise men."&nbsp;All the other prehistoric people were out puncturing each other with&nbsp;spears, and the wise men were back in the cave saying: "How about:<br>Would you please take my wife?  No.  How about: Here is my wife, please&nbsp;take her right now.  No How about:  Would you like to take something?&nbsp;My wife is available.  No.  How about ..."<br>&nbsp;-- Dave Barry, "Why Humor is Funny"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A priest asked: What is Fate, Master?&nbsp;&nbsp;And he answered:<br>&nbsp;It is that which gives a beast of burden its reason for existence.<br>&nbsp;It is that which men in former times had to bear upon their backs.<br>&nbsp;It is that which has caused nations to build byways from City to City&nbsp;upon which carts and coaches pass, and alongside which inns have come&nbsp;to be built to stave off Hunger, Thirst and Weariness.<br>&nbsp;And that is Fate?  said the priest.<br>&nbsp;Fate ... I thought you said Freight, responded the Master.<br>&nbsp;That''s all right, said the priest.  I wanted to know what Freight was&nbsp;too.<br>&nbsp;-- Kehlog Albran, "The Profit"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The world is coming to an end!  Repent and return those library books!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The notion of a "record" is an obsolete remnant of the days of the&nbsp;80-column card.<br>&nbsp;-- Dennis M. Ritchie')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Proof techniques #1: Proof by Induction.<br>&nbsp;This technique is used on equations with "_^Hn" in them.  Induction&nbsp;techniques are very popular, even the military used them.<br>&nbsp;SAMPLE: Proof of induction without proof of induction.<br><br>We know it''s true for _^Hn equal to 1.  Now assume that it''s true&nbsp;for every natural number less than _^Hn.  _^HN is arbitrary, so we can take _^Hn&nbsp;as large as we want.  If _^Hn is sufficiently large, the case of _^Hn+1 is&nbsp;trivially equivalent, so the only important _^Hn are _^Hn less than _^Hn.  We&nbsp;can take _^Hn = _^Hn (from above), so it''s true for _^Hn+1 because it''s just&nbsp;about _^Hn.<br>QED.&nbsp;(QED translates from the Latin as "So what?")')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A diplomat is someone who can tell you to go to hell in such a way that&nbsp;you will look forward to the trip.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mosher''s Law of Software Engineering:<br>Don''t worry if it doesn''t work right.  If everything did, you''d&nbsp;be out of a job.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Automobile, n.:<br>A four-wheeled vehicle that runs up hills and down&nbsp;pedestrians.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"And what will you do when you grow up to be as big as me?"&nbsp;asked the father of his little son.<br>"Diet."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Laws of Serendipity:<br><br>(1) In order to discover anything, you must be looking for<br>    something.<br>(2) If you wish to make an improved product, you must already<br>    be engaged in making an inferior one.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A hypothetical paradox:<br>What would happen in a battle between an Enterprise security&nbsp;team, who always get killed soon after appearing, and a squad of&nbsp;Imperial Stormtroopers, who can''t hit the broad side of a planet?<br>&nbsp;-- Tom Galloway')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Earn cash in your spare time -- blackmail your friends')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Flugg''s Law:<br>When you need to knock on wood is when you realize that the&nbsp;world is composed of vinyl, naugahyde and aluminum.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New systems generate new problems.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lactomangulation, n.:<br>Manhandling the "open here" spout on a milk carton so badly&nbsp;that one has to resort to using the "illegal" side.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;The Three Major Kind of Tools&nbsp;&nbsp;* Tools for hittings things to make them loose or to tighten them up or&nbsp;  jar their many complex, sophisticated electrical parts in such a&nbsp;  manner that they function perfectly.  (These are your hammers, maces,<br>  bludgeons, and truncheons.)<br>&nbsp;* Tools that, if dropped properly, can penetrate your foot.  (Awls)<br>&nbsp;* Tools that nobody should ever use because the potential danger is far&nbsp;  greater than the value of any project that could possibly result.<br>  (Power saws, power drills, power staplers, any kind of tool that uses&nbsp;  any kind of power more advanced than flashlight batteries.)<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tomorrow will be canceled due to lack of interest.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Joe''s sister puts spaghetti in her shoes!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A neighbor came to Nasrudin, asking to borrow his donkey.  "It is out&nbsp;on loan," the teacher replied.  At that moment, the donkey brayed&nbsp;loudly inside the stable.  "But I can hear it bray, over there."  "Whom&nbsp;do you believe," asked Nasrudin, "me or a donkey?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dear Mister Language Person: What is the purpose of the apostrophe?&nbsp;&nbsp;Answer: The apostrophe is used mainly in hand-lettered small business&nbsp;signs to alert the reader than an "S" is coming up at the end of a&nbsp;word, as in: WE DO NOT EXCEPT PERSONAL CHECK''S, or: NOT RESPONSIBLE FOR&nbsp;ANY ITEM''S.  Another important grammar concept to bear in mind when&nbsp;creating hand- lettered small-business signs is that you should put&nbsp;quotation marks around random words for decoration, as in "TRY" OUR HOT&nbsp;DOG''S, or even TRY "OUR" HOT DOG''S.<br>&nbsp;-- Dave Barry, "Tips for Writer''s"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'QWERT (kwirt), n. [MW < OW qwertyuiop, a thirteenth]:<br>1. a unit of weight equal to 13 poiuyt avoirdupois (or 1.69&nbsp;kiloliks), commonly used in structural engineering; 2.  [colloq.] one&nbsp;thirteenth the load that a fully grown sligo can carry; 3. [anat.] a&nbsp;painful irritation of the dermis in the region of the anus; 4. [slang]&nbsp;person who excites in others the symptoms of a qwert.<br>&nbsp;-- Webster''s Middle World Dictionary, 4th ed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is a comic playing to an audience that''s afraid to laugh.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When you have to kill a man it costs nothing to be polite." <br>&nbsp;-- Winston Curchill, On formal declarations of war')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Your home electrical system is basically a bunch of wires that&nbsp;bring electricity into your home and take if back out before it has a&nbsp;chance to kill you.  This is called a "circuit".  The most common home&nbsp;electrical problem is when the circuit is broken by a "circuit&nbsp;breaker"; this causes the electricity to back up in one of the wires&nbsp;until it bursts out of an outlet in the form of sparks, which can&nbsp;damage your carpet.  The best way to avoid broken circuits is to change&nbsp;your fuses regularly.<br>Another common problem is that the lights flicker.  This&nbsp;sometimes means that your electrical system is inadequate, but more&nbsp;often it means that your home is possessed by demons, in which case&nbsp;you''ll need to get a caulking gun and some caulking.  If you''re not&nbsp;sure whether your house is possessed, see "The Amityville Horror", a&nbsp;fine documentary film based on an actual book.  Or call in a licensed&nbsp;electrician, who is trained to spot the signs of demonic possession,<br>such as blood coming down the stairs, enormous cats on the dinette&nbsp;table, etc.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nostalgia isn''t what it used to be.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We are all agreed that your theory is crazy.  The question which&nbsp;divides us is whether it is crazy enough to have a chance of being&nbsp;correct.  My own feeling is that it is not crazy enough.<br>&nbsp;-- Niels Bohr')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The birds are singing, the flowers are budding, and it is time for Miss&nbsp;Manners to tell young lovers to stop necking in public.<br>&nbsp;It''s not that Miss Manners is immune to romance.  Miss Manners has been&nbsp;known to squeeze a gentleman''s arm while being helped over a curb, and,<br>in her wild youth, even to press a dainty slipper against a foot or two&nbsp;under the dinner table.  Miss Manners also believes that the sight of&nbsp;people strolling hand in hand or arm in arm or arm in hand dresses up a&nbsp;city considerably more than the more familiar sight of people shaking&nbsp;umbrellas at one another.  What Miss Manners objects to is the kind of&nbsp;activity that frightens the horses on the street ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The ladies men admire, I''ve heard,<br>Would shudder at a wicked word.<br>Their candle gives a single light:<br>They''d rather stay at home at night.<br>They do not keep awake till three,<br>Nor read erotic poetry.<br>They never sanction the impure,<br>Nor recognize an overture.<br>They shrink from powders and from paints ...<br>So far, I''ve had no complaints.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Politics is like coaching a football team.  you have to be smart enough&nbsp;to understand the game but not smart enough to lose interest.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is necessary for the welfare of society that genius should be&nbsp;privileged to utter sedition, to blaspheme, to outrage good taste, to&nbsp;corrupt the youthful mind, and generally to scandalize one''s uncles.<br>&nbsp;-- George Bernard Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Ninety percent of the time things turn out worse than you thought they&nbsp;would.  The other ten percent of the time you had no right to expect&nbsp;that much."<br>&nbsp;-- Augustine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nobody can be exactly like me.  Sometimes even I have trouble doing&nbsp;it.<br>&nbsp;-- Tallulah Bankhead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;It was the next morning that the armies of Twodor marched east&nbsp;laden with long lances, sharp swords, and death-dealing hangovers.  The&nbsp;thousands were led by Arrowroot, who sat limply in his sidesaddle,<br>nursing a whopper.  Goodgulf, Gimlet, and the rest rode by him, praying&nbsp;for their fate to be quick, painless, and if possible, someone else''s.<br>Many an hour the armies forged ahead, the war-merinos bleating&nbsp;under their heavy burdens and the soldiers bleating under their melting&nbsp;icepacks.<br>&nbsp;-- The Harvard Lampoon, "Bored of the Rings"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your fault: core dumped')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oregano, n.:<br>The ancient Italian art of pizza folding.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who profess to favor freedom, and yet deprecate agitation, are&nbsp;men who want rain without thunder and lightning.  They want the ocean&nbsp;without the roar of its many waters.<br>&nbsp;-- Frederick Douglass')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Time, adj.:<br>Here and now, as opposed to fake time, which only occurs there&nbsp;and then.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You couldn''t even prove the White House staff sane beyond a reasonable&nbsp;doubt.<br>&nbsp;-- Ed Meese, on the Hinckley verdict')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I fell asleep reading a dull book, and I dreamt that I was reading on,<br>so I woke up from sheer boredom.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The chicken that clucks the loudest is the one most likely to show up&nbsp;at the steam fitters'' picnic.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vote for ME -- I''m well-tapered, half-cocked, ill-conceived and&nbsp;TAX-DEFERRED!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I could dance till the cows come home.  On second thought, I''d rather&nbsp;dance with the cows till you come home.<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'VIRGO (Aug 23 - Sept 22)<br>You are the logical type and hate disorder.  This nitpicking is<br>sickening to your friends.  You are cold and unemotional and<br>sometimes fall asleep while making love.  Virgos make good bus<br>drivers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Certain old men prefer to rise at dawn, taking a cold bath and a long&nbsp;walk with an empty stomach and otherwise mortifying the flesh.  They&nbsp;then point with pride to these practices as the cause of their sturdy&nbsp;health and ripe years; the truth being that they are hearty and old,<br>not because of their habits, but in spite of them.  The reason we find&nbsp;only robust persons doing this thing is that it has killed all the&nbsp;others who have tried it.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Omnibiblious, adj.:<br>Indifferent to type of drink.  "Oh, you can get me anything.<br>I''m omnibiblious."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Honesty pays, but it doesn''t seem to pay enough to suit some people.<br>&nbsp;-- F. M. Hubbard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m prepared for all emergencies but totally unprepared for everyday&nbsp;life."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Economists can certainly disappoint you.  One said that the economy&nbsp;would turn up by the last quarter.  Well, I''m down to mine and it&nbsp;hasn''t.<br>&nbsp;-- Robert Orben')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do not try to solve all life''s problems at once -- learn to dread each&nbsp;day as it comes.<br>&nbsp;-- Donald Kaul')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Real-Life Courtroom Quote #37:<br>&nbsp;Q:  Did he pick the dog up by the ears?&nbsp;A:  No.<br>Q:  What was he doing with the dog''s ears?&nbsp;A:  Picking them up in the air.<br>Q:  Where was the dog at this time?&nbsp;A:  Attached to the ears.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'And so, men, we can see that human skin is an even more complex and&nbsp;fascinating organ than we thought it was, and if we want to keep it&nbsp;looking good, we have to care for it as though it were our own.  One&nbsp;approach is to undergo a painful surgical procedure wherein your skin&nbsp;is turned inside-out, so the young cells are on the outside, but then&nbsp;of course you have the unpleasant side effect that your insides&nbsp;gradually fill up with dead old cells and you explode.  So this&nbsp;procedure is pretty much limited to top Hollywood stars for whom&nbsp;youthful beauty is a career necessity, such as Elizabeth Taylor and&nbsp;Orson Welles.<br>&nbsp;-- Dave Barry, "Saving Face"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Wombat''s Laws of Computer Selection:<br>(1) If it doesn''t run Unix, forget it.<br>(2) Any computer design over 10 years old is obsolete.<br>(3) Anything made by IBM is junk. (See number 2)<br>(4) The minimum acceptable CPU power for a single user is a<br>    VAX/780 with a floating point accelerator.<br>(5) Any computer with a mouse is worthless.<br>&nbsp;-- Rich Kulawiec')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Great Bald Swamp Hedgehog:<br>The Gerat Bald Swamp Hedgehog of Billericay displays, in&nbsp;courtship, his single prickle and does impressions of Holiday Inn desk&nbsp;clerks.  Since this means him standing motionless for enormous periods&nbsp;of time he is often eaten in full display by The Great Bald Swamp&nbsp;Hedgehog Eater.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is now pitch dark.  If you proceed, you will likely fall into a&nbsp;pit.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some of you ... may have decided that, this year, you''re going to&nbsp;celebrate it the old-fashioned way, with your family sitting around&nbsp;stringing cranberries and exchanging humble, handmade gifts, like on&nbsp;"The Waltons".  Well, you can forget it.  If everybody pulled that kind&nbsp;of subversive stunt, the economy would collapse overnight.  The&nbsp;government would have to intervene: it would form a cabinet-level&nbsp;Department of Holiday Gift-Giving, which would spend billions and&nbsp;billions of tax dollars to buy Barbie dolls and electronic games, which&nbsp;it would drop on the populace from Air Force jets, killing and maiming&nbsp;thousands.  So, for the good of the nation, you should go along with&nbsp;the Holiday Program.  This means you should get a large sum of money&nbsp;and go to a mall.<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'NAPOLEON: What shall we do with this soldier, Guiseppe?  Everything he<br>  says is wrong.<br>GUISEPPE: Make him a general, Excellency, and then everything he says<br>  will be right.<br>&nbsp;-- G. B. Shaw, "The Man of Destiny"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Several years ago, some smart businessmen had an idea: Why not build a&nbsp;big store where a do-it-yourselfer could get everything he needed at&nbsp;reasonable prices?  Then they decided, nah, the hell with that, let''s&nbsp;build a home center.  And before long home centers were springing up&nbsp;like crabgrass all over the United States.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dear Miss Manners:<br>Please list some tactful ways of removing a man''s saliva from&nbsp;your face.<br>&nbsp;Gentle Reader:<br>Please list some decent ways of acquiring a man''s saliva on&nbsp;your face ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... After all, all he did was string together a lot of old, well-known&nbsp;quotations."<br>&nbsp;-- H. L. Mencken, on Shakespeare')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What good is a ticket to the good life, if you can''t find the&nbsp;entrance?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boston State House is the hub of the Solar System.  You couldn''t pry&nbsp;that out of a Boston man if you had the tire of all creation&nbsp;straightened out for a crowbar.<br>&nbsp;-- O. W. Holmes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The pitcher wound up and he flang the ball at the batter.  The batter&nbsp;swang and missed.  The pitcher flang the ball again and this time the&nbsp;batter connected.  He hit a high fly right to the center fielder.  The&nbsp;center fielder was all set to catch the ball, but at the last minute&nbsp;his eyes were blound by the sun and he dropped it.<br>&nbsp;-- Dizzy Dean')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As the trials of life continue to take their toll, remember that there&nbsp;is always a future in Computer Maintenance.<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We don''t care.  We don''t have to.  We''re the Phone Company."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There cannot be a crisis next week.  My schedule is already full.<br>&nbsp;-- Henry Kissinger')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fifth Law of Applied Terror:<br>If you are given an open-book exam, you will forget your book.<br>&nbsp;Corollary:<br>If you are given a take-home exam, you will forget where you&nbsp;live.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t look back, the lemmings are gaining on you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Individualists unite!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"Reflections on Ice-Breaking"&nbsp;Candy&nbsp;Is dandy&nbsp;But liquor&nbsp;Is quicker.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Peace, n.:<br>In international affairs, a period of cheating between two&nbsp;periods of fighting.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'DeVries''s Dilemma:<br>If you hit two keys on the typewriter, the one you don''t want&nbsp;hits the paper.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Wagner''s music is better than it sounds."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Quality Control, n.:<br>The process of testing one out of every 1,000 units coming off&nbsp;a production line to make sure that at least one out of 100 works.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It was pleasant to me to get a letter from you the other day.  Perhaps&nbsp;I should have found it pleasanter if I had been able to decipher it.  I&nbsp;don''t think that I mastered anything beyond the date (which I knew) and&nbsp;the signature (which I guessed at).  There''s a singular and a perpetual&nbsp;charm in a letter of yours; it never grows old, it never loses its&nbsp;novelty .... Other letters are read and thrown away and forgotten, but&nbsp;yours are kept forever -- unread.  One of them will last a reasonable&nbsp;man a lifetime."<br>&nbsp;-- Thomas Aldrich')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When does summertime come to Minnesota, you ask?  Well, last year, I&nbsp;think it was a Tuesday.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Misfortune, n.:<br>The kind of fortune that never misses.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Goldenstern''s Rules:<br>(1) Always hire a rich attorney<br>(2) Never buy from a rich salesman.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'APL is a mistake, carried through to perfection.  It is the language of&nbsp;the future for the problems of the past: it creates a new generation of&nbsp;coding bums.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who in quarrels interpose, must often wipe a bloody nose.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Death is nature''s way of saying `Howdy''".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Jenkinson''s Law:<br>It won''t work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To the best of my recollection, Senator, I can''t recall.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Senate, n.:<br>A body of elderly gentlemen charged with high duties and&nbsp;misdemeanors.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Sometimes I simply feel that the whole world is a cigarette and I''m&nbsp;the only ashtray."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A diva who specializes in risqu''^He arias is an off-coloratura soprano ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mad, adj.:<br>Affected with a high degree of intellectual independence ...<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Left to themselves, things tend to go from bad to worse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Wasting time is an important part of living.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A little inaccuracy sometimes saves tons of explanation.<br>&nbsp;-- H. H. Munroe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When I get real bored, I like to drive downtown and get a great&nbsp;parking spot, then sit in my car and count how many people ask me if&nbsp;I''m leaving."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Psychiatrists say that one out of four people are mentally ill.  Check&nbsp;three friends.  If they''re OK, you''re it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are two ways to write error-free programs.  Only the third one&nbsp;works.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Ah, you know the type.  They like to blame it all on the Jews or the&nbsp;Blacks, ''cause if they couldn''t, they''d have to wake up to the fact&nbsp;that life''s one big, scary, glorious, complex and ultimately&nbsp;unfathomable crapshoot -- and the only reason THEY can''t seem to keep&nbsp;up is they''re a bunch of misfits and losers."<br>&nbsp;-- A analysis of Neo-Nazis, from "The Badger" comic')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Know what I hate most?  Rhetorical questions.<br>&nbsp;-- Henry N. Camp')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have the world''s largest collection of seashells.  I keep it&nbsp;scattered around the beaches of the world ... Perhaps you''ve seen it.<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you have an efficient government, you have a dictatorship.<br>&nbsp;-- Harry Truman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A CONS is an object which cares.<br>&nbsp;-- Bernie Greenberg.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Afternoon, n.:<br>That part of the day we spend worrying about how we wasted the&nbsp;morning.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The wages of sin are death; but after they''re done taking out taxes,<br>it''s just a tired feeling:"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He had that rare weird electricity about him -- that extremely wild and&nbsp;heavy presence that you only see in a person who has abandoned all hope&nbsp;of ever behaving "normally."<br>&nbsp;-- Hunter S. Thompson, "Fear and Loathing ''72"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Double-Blind Experiment, n.:<br>An experiment in which the chief researcher believes he is&nbsp;fooling both the subject and the lab assistant.  Often accompanied by a&nbsp;belief in the tooth fairy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ass, n.:<br>The masculine of "lass".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God is dead, who will save the Queen?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cat, n.:<br>Lapwarmer with built-in buzzer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sex is not the answer.  Sex is the question.  "Yes" is the answer.<br>&nbsp;-- Swami X')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Violence is the last refuge of the incompetent.<br>&nbsp;-- Salvor Hardin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The universe is like a safe to which there is a combination -- but the&nbsp;combination is locked up in the safe.<br>&nbsp;-- Peter DeVries')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All the world''s a VAX,<br>And all the coders merely butchers:<br>They have their exits and their entrails:<br>And one int in his time plays many widths,<br>His sizeof being _^HN bytes.  At first the infant,<br>Mewling and puking in the Regent''s arms.<br>And then the whining schoolboy, with his Sun,<br>And shining morning face, creeping like slug&nbsp;Unwillingly to school.<br>&nbsp;-- A Very Annoyed PDP-11')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You men out there probably think you already know how to dress for&nbsp;success.  You know, for example, that you should not wear leisure suits&nbsp;or white plastic belts and shoes, unless you are going to a costume&nbsp;party disguised as a pig farmer vacationing at Disney World.<br>&nbsp;-- Dave Barry, "How to Dress for Real Success"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Why was I born with such contemporaries?"<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'My love runs by like a day in June,<br>And he makes no friends of sorrows.<br>He''ll tread his galloping rigadoon<br>In the pathway or the morrows.<br>He''ll live his days where the sunbeams start<br>Nor could storm or wind uproot him.<br>My own dear love, he is all my heart --<br>And I wish somebody''d shoot him.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Avoid Quiet and Placid persons unless you are in Need of Sleep.<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Rembrandt''s first name was Beauregard, which is why he never used&nbsp;it."<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A lot of people are afraid of heights.  Not me.  I''m afraid of widths.<br>&nbsp;-- Steve Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'BE ALERT!!!!  (The world needs more lerts ...)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;Pittsburgh Driver''s Test&nbsp;<br>7) The car directly in front of you has a flashing right tail light&nbsp;    but a steady left tail light.  This means&nbsp;<br>(a) one of the tail lights is broken; you should blow your horn<br>    to call the problem to the driver''s attention.<br>(b) the driver is signaling a right turn.<br>(c) the driver is signaling a left turn.<br>(d) the driver is from out of town.<br>&nbsp;The correct answer is (d).  Tail lights are used in some foreign&nbsp;countries to signal turns.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conceit causes more conversation than wit.<br>&nbsp;-- LaRouchefoucauld')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nine-track tapes and seven-track tapes<br>And tapes without any tracks:<br>Stretchy tapes and snarley tapes<br>And tapes mixed up on the racks --<br>&nbsp;Take hold of the tape<br>&nbsp;And pull off the strip,<br>&nbsp;And then you''ll be sure<br>&nbsp;Your tape drive will skip.<br><br>&nbsp;-- Uncle Colonel''s Cursory Rhymes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Deliver yesterday, code today, think tomorrow."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Expense Accounts, n.:<br>Corporate food stamps.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Did you know that if you took all the economists in the world and lined&nbsp;them up end to end, they''d still point in the wrong direction?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anthony''s Law of Force:<br>Don''t force it; get a larger hammer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Glib''s Fourth Law of Unreliability:<br>Investment in reliability will increase until it exceeds the&nbsp;probable cost of errors, or until someone insists on getting some&nbsp;useful work done.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As soon as we started programming, we found to our surprise that it&nbsp;wasn''t as easy to get programs right as we had thought.  Debugging had&nbsp;to be discovered.  I can remember the exact instant when I realized&nbsp;that a large part of my life from then on was going to be spent in&nbsp;finding mistakes in my own programs.<br>&nbsp;-- Maurice Wilkes discovers debugging, 1949')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'But the greatest Electrical Pioneer of them all was Thomas Edison, who&nbsp;was a brilliant inventor despite the fact that he had little formal&nbsp;education and lived in New Jersey.  Edison''s first major invention in&nbsp;1877, was the phonograph, which could soon be found in thousands of&nbsp;American homes, where it basically sat until 1923, when the record was&nbsp;invented.  But Edison''s greatest achievement came in 1879, when he&nbsp;invented the electric company.  Edison''s design was a brilliant&nbsp;adaptation of the simple electrical circuit: the electric company sends&nbsp;electricity through a wire to a customer, then immediately gets the&nbsp;electricity back through another wire, then (this is the brilliant&nbsp;part) sends it right back to the customer again.<br>&nbsp;This means that an electric company can sell a customer the same batch&nbsp;of electricity thousands of times a day and never get caught, since&nbsp;very few customers take the time to examine their electricity closely.<br>In fact the last year any new electricity was generated in the United&nbsp;States was 1937; the electric companies have been merely re-selling it&nbsp;ever since, which is why they have so much free time to apply for rate&nbsp;increases.<br>&nbsp;-- Dave Barry, "What is Electricity?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Now and then an innocent person is sent to the legislature.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"All flesh is grass"<br>&nbsp;-- Isiah&nbsp;Smoke a friend today.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'United Nations, New York, December 25.  The peace and joy of the&nbsp;Christmas season was marred by a proclamation of a general strike of&nbsp;all the military forces of the world.  Panic reigns in the hearts of&nbsp;all the patriots of every persuasion.<br>&nbsp;Meanwhile, fears of universal disaster sank to an all-time low over the&nbsp;world.<br>&nbsp;-- Isaac Asimov')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no substitute for good manners, except, perhaps, fast&nbsp;reflexes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The sun was shining on the sea,<br>Shining with all his might:<br>He did his very best to make&nbsp;The billows smooth and bright --&nbsp;And this was very odd, because it was&nbsp;The middle of the night.<br>&nbsp;-- Lewis Carroll, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Satellite Safety Tip #14:<br>If you see a bright streak in the sky coming at you, duck.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Scotty:&nbsp;Captain, we din'' can reference it!&nbsp;Kirk:&nbsp;Analysis, Mr. Spock?&nbsp;Spock:&nbsp;Captain, it doesn''t appear in the symbol table.<br>Kirk:&nbsp;Then it''s of external origin?&nbsp;Spock:&nbsp;Affirmative.<br>Kirk:&nbsp;Mr. Sulu, go to pass two.<br>Sulu:&nbsp;Aye aye, sir, going to pass two.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The English have no respect for their language, and will not teach&nbsp;their children to speak it.<br>&nbsp;-- G. B. Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This fortune intentionally not included.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m proud to be paying taxes in the United States.  The only thing is&nbsp;-- I could be just as proud for half the money.<br>&nbsp;-- Arthur Godfrey')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why is the alphabet in that order?  Is it because of that song?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be different: conform.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One is not superior merely because one sees the world as odious.<br>&nbsp;-- Chateaubriand (1768-1848)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All true wisdom is found on T-shirts.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I also believe that academic freedom should protect the right of a&nbsp;professor or student to advocate Marxism, socialism, communism, or any&nbsp;other minority viewpoint -- no matter how distasteful to the majority.<br>&nbsp;-- Richard M. Nixon&nbsp;&nbsp;What are our schools for if not indoctrination against Communism?<br>&nbsp;-- Richard M. Nixon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m rated PG-34!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'MESSAGE ACKNOWLEDGED -- The Pershing II missiles have been launched.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After an instrument has been assembled, extra components will be found&nbsp;on the bench.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'LSD melts in your mind, not in your hand.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Law of Probable Dispersal:<br>Whatever it is that hits the fan will not be evenly&nbsp;distributed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As of next week, passwords will be entered in Morse code.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everything you know is wrong!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While money can''t buy happiness, it certainly lets you choose your own&nbsp;form of misery.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"By necessity, by proclivity, and by delight, we all quote.  In fact,<br>it is as difficult to appropriate the thoughts of others as it is to&nbsp;invent. (R. Emerson)"<br>&nbsp;-- Quoted from a fortune cookie program<br>&nbsp;   (whose author claims, "Actually, stealing IS easier.")<br>&nbsp;   [to which I reply, "You think it''s easy for me to<br>&nbsp;   misconstrue all these misquotations?!?"]')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mencken and Nathan''s Ninth Law of The Average American:<br>The quality of a champagne is judged by the amount of noise the&nbsp;cork makes when it is popped.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The New Testament offers the basis for modern computer coding theory,<br>in the form of an affirmation of the binary number system.<br><br>But let your communication be Yea, yea; nay, nay: for<br>whatsoever is more than these cometh of evil.<br>&nbsp;-- Matthew 5:37')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The devil finds work for idle circuits to do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A man wrapped up in himself makes a very small package.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Darth Vader sleeps with a Teddywookie.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mickey Mouse wears a Spiro Agnew watch.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I think it is true for all _^Hn. I was just playing it safe with _^Hn >= 3&nbsp;because I couldn''t remember the proof."<br>&nbsp;-- Baker, Pure Math 351a')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We are all in the gutter, but some of us are looking at the stars.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nihilism should commence with oneself.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Ohio, if you ignore an orator on Decoration day to such an extent as&nbsp;to publicly play croquet or pitch horseshoes within one mile of the&nbsp;speaker''s stand, you can be fined $25.00.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''re at the end of the road again.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Linus:&nbsp;I guess it''s wrong always to be worrying about tomorrow.  Maybe<br>we should think only about today.<br>Charlie Brown:<br>No, that''s giving up.  I''m still hoping that yesterday will get<br>better.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yield to Temptation ... it may not pass your way again.<br>&nbsp;-- Lazarus Long, "Time Enough for Love"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"His super power is to turn into a scotch terrier."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;One of the questions that comes up all the time is: How&nbsp;enthusiastic is our support for UNIX?<br>Unix was written on our machines and for our machines many&nbsp;years ago.  Today, much of UNIX being done is done on our machines.<br>Ten percent of our VAXs are going for UNIX use.  UNIX is a simple&nbsp;language, easy to understand, easy to get started with.  It''s great for&nbsp;students, great for somewhat casual users, and it''s great for&nbsp;interchanging programs between different machines.  And so, because of&nbsp;its popularity in these markets, we support it.  We have good UNIX on&nbsp;VAX and good UNIX on PDP-11s.<br>It is our belief, however, that serious professional users will&nbsp;run out of things they can do with UNIX. They''ll want a real system and&nbsp;will end up doing VMS when they get to be serious about programming.<br>With UNIX, if you''re looking for something, you can easily and&nbsp;quickly check that small manual and find out that it''s not there.  With&nbsp;VMS, no matter what you look for -- it''s literally a five-foot shelf of&nbsp;documentation -- if you look long enough it''s there.  That''s the&nbsp;difference -- the beauty of UNIX is it''s simple; and the beauty of VMS&nbsp;is that it''s all there.<br>&nbsp;-- Ken Olsen, President of DEC, 1984')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Carelessly planned projects take three times longer to complete than&nbsp;expected.  Carefully planned projects take four times longer to&nbsp;complete than expected, mostly because the planners expect their&nbsp;planning to reduce the time it takes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dear Miss Manners:<br>My home economics teacher says that one must never place one''s&nbsp;elbows on the table.  However, I have read that one elbow, in between&nbsp;courses, is all right.  Which is correct?&nbsp;&nbsp;Gentle Reader:<br>For the purpose of answering examinations in your home&nbsp;economics class, your teacher is correct.  Catching on to this&nbsp;principle of education may be of even greater importance to you now&nbsp;than learning correct current table manners, vital as Miss Manners&nbsp;believes that is.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;OUTCONERR&nbsp;Twas FORTRAN as the doloop goes<br>Did logzerneg the ifthen block&nbsp;All kludgy were the function flows<br>And subroutines adhoc.<br>&nbsp;Beware the runtime-bug my friend<br>squrooneg, the false goto&nbsp;Beware the infiniteloop<br>And shun the inprectoo.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Death is nature''s way of telling you to slow down')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Due to lack of disk space, this fortune database has been&nbsp;discontinued.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s no surprise that things are so screwed up: everyone that knows how&nbsp;to run a government is either driving taxicabs or cutting hair.<br>&nbsp;-- George Burns')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Save energy: be apathetic.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this world needs is a good five-dollar plasma weapon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What is mind?  No matter.<br>What is matter?  Never mind.<br>&nbsp;-- Thomas Hewitt Key, 1799-1875')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '!07/11 PDP a ni deppart m''I  !pleH')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A chubby man with a white beard and a red suit will approach you soon.<br>Avoid him.  He''s a Commie.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Very few profundities can be expressed in less than 80 characters.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Uncle Cosmo ... why do they call this a word processor?"&nbsp;&nbsp;"It''s simple, Skyler ... you''ve seen what food processors do to food,<br>right?"<br>&nbsp;-- MacNelley, "Shoe"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whom computers would destroy, they must first drive mad.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Just once, I wish we would encounter an alien menace that wasn''t&nbsp;immune to bullets"<br>&nbsp;-- The Brigader, "Dr. Who"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... the MYSTERIANS are in here with my CORDUROY SOAP DISH!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A pig is a jolly companion,<br>Boar, sow, barrow, or gilt --&nbsp;A pig is a pal, who''ll boost your morale, &nbsp;Though mountains may topple and tilt.<br>When they''ve blackballed, bamboozled, and burned you,<br>When they''ve turned on you, Tory and Whig,<br>Though you may be thrown over by Tabby and Rover,<br>You''ll never go wrong with a pig, a pig,<br>You''ll never go wrong with a pig!<br>&nbsp;-- Thomas Pynchon, "Gravity''s Rainbow"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What I think is that the F-word is basically just a convenient nasty-&nbsp;sounding word that we tend to use when we would really like to come up&nbsp;with a terrifically witty insult, the kind Winston Churchill always&nbsp;came up with when enormous women asked him stupid questions at&nbsp;parties.<br>&nbsp;-- Dave Barry, "$#$%#^%!^%&@%@!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the beginning was the word.<br>But by the time the second word was added to it,<br>there was trouble.<br>For with it came syntax ...<br>&nbsp;-- John Simon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Van Roy''s Law:<br>An unbreakable toy is useful for breaking other toys.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Blore''s Razor:<br>Given a choice between two theories, take the one which is&nbsp;funnier.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Time flies like an arrow&nbsp;Fruit flies like a banana')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Soviet pre-eminence in chess can be traced to the average Russian''s&nbsp;readiness to brood obsessively over anything, even the arrangement of&nbsp;some pieces of wood.  Indeed, the Russians'' predisposition for quiet&nbsp;reflection followed by sudden preventive action explains why they led&nbsp;the field for many years in both chess and ax murders.  It is well&nbsp;known that as early as 1970, the U.S.S.R., aware of what a defeat at&nbsp;Reykjavik would do to national prestige, implemented a vigorous program&nbsp;of preparation and incentive.  Every day for an entire year, a team of&nbsp;psychologists, chess analysts and coaches met with the top three&nbsp;Russian grand masters and threatened them with a pointy stick.  That&nbsp;these tactics proved fruitless is now a part of chess history and a&nbsp;further testament to the American way, which provides that if you want&nbsp;something badly enough, you can always go to Iceland and get it from&nbsp;the Russians.<br>&nbsp;-- Marshall Brickman, Playboy, April, 1973')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m not under the alkafluence of inkahol that some thinkle peep I am.<br>It''s just the drunker I sit here the longer I get."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There is no reason for any individual to have a computer in their&nbsp;home."<br>&nbsp;-- Ken Olson, President of DEC, World Future Society<br>&nbsp;   Convention, 1977')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All wars are civil wars, because all men are brothers ... Each one owes&nbsp;infinitely more to the human race than to the particular country in&nbsp;which he was born.<br>&nbsp;-- Francois Fenelon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The typewriting machine, when played with expression, is no more&nbsp;annoying than the piano when played by a sister or near relation.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We have the flu.  I don''t know if this particular strain has an&nbsp;official name, but if it does, it must be something like "Martian Death&nbsp;Flu".  You may have had it yourself.  The main symptom is that you wish&nbsp;you had another setting on your electric blanket, up past "HIGH", that&nbsp;said "ELECTROCUTION".<br>&nbsp;Another symptom is that you cease brushing your teeth, because (a) your&nbsp;teeth hurt, and (b) you lack the strength.  Midway through the brushing&nbsp;process, you''d have to lie down in front of the sink to rest for a&nbsp;couple of hours, and rivulets of toothpaste foam would dribble sideways&nbsp;out of your mouth, eventually hardening into crusty little toothpaste&nbsp;stalagmites that would bond your head permanently to the bathroom&nbsp;floor, which is how the police would find you.<br>&nbsp;You know the kind of flu I''m talking about.<br>&nbsp;-- Dave Barry, "Molecular Homicide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finish the sentence below in 25 words or less:<br><br>"Love is what you feel just before you give someone a good ..."&nbsp;&nbsp;Mail your answer along with the top half of your supervisor to:<br><br>P.O. Box 35<br>Baffled Greek, Michigan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Seattle, Washington, it is illegal to carry a concealed weapon that&nbsp;is over six feet in length.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bureaucrats cut red tape -- lengthwise.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '1.79 x 10^12 furlongs per fortnight -- it''s not just a good idea, it''s&nbsp;the law!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t let your mind wander -- it''s too little to be let out alone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A professor is one who talks in someone else''s sleep.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"But officer, I was only trying to gain enough speed so I could coast&nbsp;to the nearest gas station."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but there are important world issues that&nbsp;need worrying about."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no realizable power that man cannot, in time, fashion the&nbsp;tools to attain, nor any power so secure that the naked ape will not&nbsp;abuse it.  So it is written in the genetic cards -- only physics and&nbsp;war hold him in check.  And also the wife who wants him home by five,<br>of course.<br>&nbsp;-- Encyclopedia Apocryphia, 1990 ed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"One thing they don''t tell you about doing experimental physics is that&nbsp;sometimes you must work under adverse conditions ... like a state of&nbsp;sheer terror."<br>&nbsp;-- W. K. Hartmann')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alimony is a system by which, when two people make a mistake, one of&nbsp;them keeps paying for it.<br>&nbsp;-- Peggy Joyce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oliver''s Law:<br>Experience is something you don''t get until just after you need&nbsp;it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A priest was walking along the cliffs at Dover when he came&nbsp;upon two locals pulling another man ashore on the end of a rope.<br>"That''s what I like to see", said the priest, "A man helping his fellow&nbsp;man".<br>As he was walking away, one local remarked to the other, "Well,<br>he sure doesn''t know the first thing about shark fishing."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '%DCL-MEM-BAD, bad memory&nbsp;VMS-F-PDGERS, pudding between the ears')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... the privileged being which we call human is distinguished from&nbsp;other animals only by certain double-edged manifestations which in&nbsp;charity we can only call "inhuman."<br>&nbsp;-- R. A. Lafferty')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A Mexican newspaper reports that bored Royal Air Force pilots stationed&nbsp;on the Falkland Islands have devised what they consider a marvelous new&nbsp;game.  Noting that the local penguins are fascinated by airplanes, the&nbsp;pilots search out a beach where the birds are gathered and fly slowly&nbsp;along it at the water''s edge.  Perhaps ten thousand penguins turn their&nbsp;heads in unison watching the planes go by, and when the pilots turn&nbsp;around and fly back, the birds turn their heads in the opposite&nbsp;direction, like spectators at a slow-motion tennis match.  Then, the&nbsp;paper reports, "The pilots fly out to sea and directly to the penguin&nbsp;colony and overfly it.  Heads go up, up, up, and ten thousand penguins&nbsp;fall over gently onto their backs.<br>&nbsp;-- Audobon Society Magazine')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Forgetfulness, n.:<br>A gift of God bestowed upon debtors in compensation for their&nbsp;destitution of conscience.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'But soft you, the fair Ophelia:<br>Ope not thy ponderous and marble jaws,<br>But get thee to a nunnery -- go!<br>&nbsp;-- Mark "The Bard" Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;When you have shot and killed a man you have in some measure&nbsp;clarified your attitude toward him.  You have given a definite answer&nbsp;to a definite problem.  For better or worse you have acted decisively.<br>In a way, the next move is up to him.<br>&nbsp;-- R. A. Lafferty')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I used to think I was indecisive, but now I''m not so sure."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I like to believe that people in the long run are going to do more to&nbsp;promote peace than our governments.  Indeed, I think that people want&nbsp;peace so much that one of these days governments had better get out of&nbsp;the way and let them have it.<br>&nbsp;-- Dwight D. Eisenhower')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will lose your present job and have to become a door to door&nbsp;mayonnaise salesman.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Tulsa, Oklahoma, it is against the law to open a soda bottle without&nbsp;the supervision of a licensed engineer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The sooner all the animals are dead, the sooner we''ll find their&nbsp;money."<br>&nbsp;-- Ed Bluestone, "The National Lampoon"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Under a government which imprisons any unjustly, the true place for a&nbsp;just man is also a prison.<br>&nbsp;-- Henry David Thoreau')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I can''t decide whether to commit suicide or go bowling."<br>&nbsp;-- Florence Henderson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The porcupine with the sharpest quills gets stuck on a tree more&nbsp;often."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Briggs/Chase Law of Program Development:<br>To determine how long it will take to write and debug a&nbsp;program, take your best estimate, multiply that by two, add one, and&nbsp;convert to the next higher units.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'First, a few words about tools.<br>&nbsp;Basically, a tool is an object that enables you to take advantage of&nbsp;the laws of physics and mechanics in such a way that you can seriously&nbsp;injure yourself.  Today, people tend to take tools for granted.  If&nbsp;you''re ever walking down the street and you notice some people who look&nbsp;particularly smug, the odds are that they are taking tools for&nbsp;granted.  If I were you, I''d walk right up and smack them in the face.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I don''t mind what Congress does, as long as they don''t do it in the&nbsp;streets and frighten the horses.<br>&nbsp;-- Victor Hugo')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Extract from Official Sweepstakes Rules:<br><br>&nbsp;NO PURCHASE REQUIRED TO CLAIM YOUR PRIZE&nbsp;&nbsp;To claim your prize without purchase, do the following: (a) Carefully&nbsp;cut out your computer-printed name and address from upper right hand&nbsp;corner of the Prize Claim Form. (b) Affix computer-printed name and&nbsp;address -- with glue or cellophane tape (no staples or paper clips) --&nbsp;to a 3x5 inch index card.  (c) Also cut out the "No" paragraph (lower&nbsp;left hand corner of Prize Claim Form) and affix it to the 3x5 card&nbsp;below your address label. (d) Then print on your 3x5 card, above your&nbsp;computer-printed name and address the words "CARTER & VAN PEEL&nbsp;SWEEPSTAKES" (Use all capital letters.)  (e) Finally place 3x5 card<br>without bending) into a plain envelope [NOTE: do NOT use the the&nbsp;Official Prize Claim and CVP Perfume Reply Envelope or you may be&nbsp;disqualified], and mail to: CVP, Box 1320, Westbury, NY 11595.  Print&nbsp;this address correctly.  Comply with above instructions carefully and&nbsp;completely or you may be disqualified from receiving your prize.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alex Haley was adopted!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a natural hootchy-kootchy to a goldfish.<br>&nbsp;-- Walt Disney')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Programmers think better when playing Adventure or Rogue.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The problem with any unwritten law is that you don''t know where to go&nbsp;to erase it.<br>&nbsp;-- Glaser and Way')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Programs don''t use shared text.  Otherwise, how can they use&nbsp;functions for scratch space after they are finished calling them?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everyone talks about apathy, but no one ____^H^H^H^Hdoes anything about it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some programming languages manage to absorb change but withstand&nbsp;progress.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just go with the flow control, roll with the crunches, and, when you&nbsp;get a prompt, type like hell.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brady''s First Law of Problem Solving:<br>When confronted by a difficult problem, you can solve it more&nbsp;easily by reducing it to the question, "How would the Lone Ranger have&nbsp;handled this?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Famous last words:<br>(1) "Don''t worry, I can handle it."<br>(2) "You and what army?"<br>(3) "If you were as smart as you think you are, you wouldn''t be<br>     a cop."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If at first you don''t succeed, redefine success.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pedaeration, n.:<br>The perfect body heat achieved by having one leg under the&nbsp;sheet and one hanging off the edge of the bed.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gray''s Law of Programming:<br>`_^Hn+1'' trivial tasks are expected to be accomplished in the same&nbsp;time as `_^Hn'' tasks.<br>&nbsp;Logg''s Rebuttal to Gray''s Law:<br>`_^Hn+1'' trivial tasks take twice as long as `_^Hn'' trivial tasks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"BASIC is the Computer Science equivalent of `Scientific Creationism''."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Elevators smell different to midgets')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If this fortune didn''t exist, somebody would have invented it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Let me assure you that to us here at First National, you''re not just a&nbsp;number.  You''re two numbers, a dash, three more numbers, another dash&nbsp;and another number."<br>&nbsp;-- James Estes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hartley''s Second Law:<br>Never sleep with anyone crazier than yourself.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Basic, n.:<br>A programming language.  Related to certain social diseases in&nbsp;that those who have it will not admit it in polite company.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bradley''s Bromide:<br>If computers get too powerful, we can organize them into a&nbsp;committee -- that will do them in.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s not that I''m afraid to die.  I just don''t want to be there when it&nbsp;happens.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '/earth is 98% full ... please delete anyone you can.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Flying saucers on occasion<br>Show themselves to human eyes.<br>Aliens fume, put off invasion<br>While they brand these tales as lies.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;In a forest a fox bumps into a little rabbit, and says, "Hi,<br>junior, what are you up to?"<br>"I''m writing a dissertation on how rabbits eat foxes," said the&nbsp;rabbit.<br>"Come now, friend rabbit, you know that''s impossible!"<br>"Well, follow me and I''ll show you."  They both go into the&nbsp;rabbit''s dwelling and after a while the rabbit emerges with a satisfied&nbsp;expression on his face.<br>Comes along a wolf.  "Hello, what are we doing these days?"<br>"I''m writing the second chapter of my thesis, on how rabbits&nbsp;devour wolves."<br>"Are you crazy?  Where is your academic honesty?"<br>"Come with me and I''ll show you."  As before, the rabbit comes&nbsp;out with a satisfied look on his face and a diploma in his paw.<br>Finally, the camera pans into the rabbit''s cave and, as everybody&nbsp;should have guessed by now, we see a mean-looking, huge lion sitting&nbsp;next to some bloody and furry remnants of the wolf and the fox.<br>&nbsp;The moral: It''s not the contents of your thesis that are important --&nbsp;it''s your PhD advisor that really counts.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Matter cannot be created or destroyed, nor can it be returned without a&nbsp;receipt.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;Safety Tips for the Post-Nuclear Existence<br>&nbsp;  Tip #1: How to tell when you are dead.<br><br>1) Little things start bothering you: little things like worms, bugs,<br>    ants.<br>(2) Something is missing in your personal relationships.<br>(3) Your dog becomes overly affectionate.<br>(4) You have a hard time getting a waiter.<br>(5) Exotic birds flock around you.<br>(6) People ignore you at parties.<br>(7) You have a hard time getting up in the morning.<br>(8) You no longer get off on cocaine.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s raisins that make Post Raisin Bran so raisiny ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you''re going to do something tonight that you''ll be sorry for&nbsp;tomorrow morning, sleep late.<br>&nbsp;-- Henny Youngman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Qvid me anxivs svm?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The camel has a single hump:<br>The dromedary two:<br>Or else the other way around.<br>I''m never sure.  Are you?<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'College football is a game which would be much more interesting if the&nbsp;faculty played instead of the students, and even more interesting if&nbsp;the trustees played.  There would be a great increase in broken arms,<br>legs, and necks, and simultaneously an appreciable diminution in the&nbsp;loss to humanity.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hacking''s just another word for nothing left to kludge.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Loose bits sink chips.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Resisting temptation is easier when you think you''ll probably get&nbsp;another chance later on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boling''s postulate:<br>If you''re feeling good, don''t worry.  You''ll get over it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just as most issues are seldom black or white, so are most good&nbsp;solutions seldom black or white.  Beware of the solution that requires&nbsp;one side to be totally the loser and the other side to be totally the&nbsp;winner.  The reason there are two sides to begin with usually is&nbsp;because neither side has all the facts.  Therefore, when the wise&nbsp;mediator effects a compromise, he is not acting from political&nbsp;motivation.  Rather, he is acting from a deep sense of respect for the&nbsp;whole truth.<br>&nbsp;-- Stephen R. Schwambach')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you can read this, you''re too close.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Keep America beautiful.  Swallow your beer cans.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pohl''s law:<br>Nothing is so good that somebody, somewhere, will not hate it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An Englishman never enjoys himself, except for a noble purpose.<br>&nbsp;-- A. P. Herbert')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To be sure of hitting the target, shoot first and, whatever you hit,<br>call it the target.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bolub''s Fourth Law of Computerdom:<br>Project teams detest weekly progress reporting because it so&nbsp;vividly manifests their lack of progress.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Life is like an analogy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'According to the latest official figures, 43% of all statistics are&nbsp;totally worthless.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sharks are as tough as those football fans who take their shirts off&nbsp;during games in Chicago in January, only more intelligent.<br>&nbsp;-- Dave Barry, "Sex and the Single Amoeba: What Every<br>&nbsp;   Teen Should Know"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Enzymes are things invented by biologists that explain things which&nbsp;otherwise require harder thinking.<br>&nbsp;-- Jerome Lettvin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Non-sequiturs make me eat lampshades.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I took a course in speed reading and was able to read War and Peace in&nbsp;twenty minutes.  It''s about Russia.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'System/3!  System/3!&nbsp;See how it runs!  See how it runs!<br>Its monitor loses so totally!<br>It runs all its programs in RPG!<br>It''s made by our favorite monopoly!&nbsp;System/3!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alliance, n.:<br>In international politics, the union of two thieves who have&nbsp;their hands so deeply inserted in each other''s pocket that they cannot&nbsp;separately plunder a third.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many IBM cpu''s does it take to do a logical right shift?&nbsp;A:  33.  1 to hold the bits and 32 to push the register.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stupid, n.:<br>Losing $25 on the game and $25 on the instant replay.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What are you doing?"&nbsp;&nbsp;"Examining the world''s major religions.  I''m looking for something&nbsp;that''s light on morals, has lots of holidays, and with a short&nbsp;initiation period."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Programmers don''t write in PL/I.  PL/I is for programmers who&nbsp;can''t decide whether to write in COBOL or FORTRAN.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What are we going to do?"&nbsp;&nbsp;"Me, I''m examining the major Western religions.  I''m looking for&nbsp;something that''s soft on morality, generous with holidays, and has a&nbsp;short initiation period."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I was a boy I was told that anybody could become President.  Now&nbsp;I''m beginning to believe it.<br>&nbsp;-- Clarence Darrow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The University of California Bears announced the signing of Reggie&nbsp;Philbin to a letter of intent to attend Cal next Fall.  Philbin is said&nbsp;to make up for no talent by cheating well.  Says Philbin of his&nbsp;decision to attend Cal, "I''m in it for the free ride."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If we were meant to fly, we wouldn''t keep losing our luggage."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am not now, and never have been, a girlfriend of Henry Kissinger."<br>&nbsp;-- Gloria Steinem')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The soul would have no rainbow had the eyes no tears.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Pocatello, Idaho, a law passed in 1912 provided that "The carrying&nbsp;of concealed weapons is forbidden, unless same are exhibited to public&nbsp;view."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anything is good and useful if it''s made of chocolate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Worst Vegetable of the Year:<br>The brussels sprout.  This is also the worst vegetable of next&nbsp;year.<br>&nbsp;-- Steve Rubenstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Others will look to you for stability, so hide when you bite your&nbsp;nails.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sen. Danforth:&nbsp;"There is nothing on the face of the album which would<br>&nbsp;notify you if the record has pornographics material or<br>&nbsp;material glorifying violence?"&nbsp;Tipper Gore:&nbsp;"No, there is nothing that would suggest that to me."&nbsp;Frank Zappa:&nbsp;"I would say that a buzz saw blade between the guy''s<br>&nbsp;legs on the album cover is good indication that it''s<br>&nbsp;not for little Johnny."&nbsp;<br>&nbsp;-- The Senate Commerce Committee hearing on rock<br>&nbsp;   lyrics, from The Village Voice, 6 Oct 1985')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s a summons."&nbsp;"What''s a summons?"&nbsp;"It means summon''s in trouble."<br>&nbsp;-- Rocky and Bullwinkle')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The early bird who catches the worm works for someone who comes in late&nbsp;and owns the worm farm.<br>&nbsp;-- Travis McGee')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'RULES OF EATING -- THE BRONX DIETER''S CREED<br>(1)  Never eat on an empty stomach.<br>(2)  Never leave the table hungry.<br>(3)  When traveling, never leave a country hungry.<br>(4)  Enjoy your food.<br>(5)  Enjoy your companion''s food.<br>(6)  Really taste your food.  It may take several portions to<br>     accomplish this, especially if subtly seasoned.<br>(7)  Really feel your food.  Texture is important.  Compare,<br>     for example, the texture of a turnip to that of a<br>     brownie.  Which feels better against your cheeks?<br>(8)  Never eat between snacks, unless it''s a meal.<br>(9)  Don''t feel you must finish everything on your plate.  You<br>     can always eat it later.<br>(10) Avoid any wine with a childproof cap.<br>(11) Avoid blue food.<br>&nbsp;-- Richard Smit, "The Bronx Diet"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finagle''s Creed:<br>Science is true.  Don''t be misled by facts.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Why isn''t there a special name for the tops of your feet?"<br>&nbsp;-- Lily Tomlin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gurmlish, n.:<br>The red warning flag at the top of a club sandwich which&nbsp;prevents the person from biting into it and puncturing the roof of his&nbsp;mouth.<br>&nbsp;-- Rich Hall & Friends, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You probably wouldn''t worry about what people think of you if you could&nbsp;know how seldom they do.<br>&nbsp;-- Olin Miller.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When two people are under the influence of the most violent, most&nbsp;insane, most delusive, and most transient of passions, they are&nbsp;required to swear that they will remain in that excited, abnormal, and&nbsp;exhausting condition continuously until death do them part.<br>&nbsp;-- George Bernard Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m defending her honor, which is more than she ever did.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The Right Honorable Gentleman is indebted to his memory for his jests&nbsp;and to his imagination for his facts."<br>&nbsp;-- Sheridan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why do we have two eyes?  To watch 3-D movies with.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t mind going nowhere as long as it''s an interesting path."<br>&nbsp;-- Ronald Mabbitt')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kerr''s Three Rules for a Successful College:<br>Have plenty of football for the alumni, sex for the students,<br>and parking for the faculty.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ed Sullivan will be around as long as someone else has talent.<br>&nbsp;-- Fred Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The problem ... is that we have run out of dinosaurs to form oil with.<br>Scientists working for the Department of Energy have tried to form oil&nbsp;using other animals; they''ve piled thousands of tons of sand and Middle&nbsp;Eastern countries on top of cows, raccoons, haddock, laboratory rats,<br>etc., but so far all they have managed to do is run up an enormous&nbsp;bulldozer-rental bill and anger a lot of Middle Eastern persons.  None&nbsp;of the animals turned into oil, although most of the laboratory rats&nbsp;developed cancer.<br>&nbsp;-- Dave Barry, "Postpetroleum Guzzler"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Beware of bugs in the above code; I have only proved it correct, not&nbsp;tried it."<br>&nbsp;-- Donald Knuth')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The makers may make&nbsp;and the users may use,<br>but the fixers must fix&nbsp;with but minimal clues')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Peter''s Law of Substitution:<br>Look after the molehills, and the mountains will look after&nbsp;themselves.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Monday, n.:<br>In Christian countries, the day after the baseball game.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Horses are forbidden to eat fire hydrants in Marshalltown, Iowa.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old," said the youth, "and your jaws are too weak<br>For anything tougher than suet:<br>Yet you finished the goose, with the bones and the beak --<br>Pray, how did you manage to do it?"&nbsp;&nbsp;"In my youth," said his father, "I took to the law,<br>And argued each case with my wife:<br>And the muscular strength which it gave to my jaw,<br>Has lasted the rest of my life."<br>&nbsp;-- Lewis Carrol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rules:<br>(1)  The boss is always right.<br>(2)  When the boss is wrong, refer to rule 1.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Christ:<br>A man who was born at least 5,000 years ahead of his time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On-line, adj.:<br>The idea that a human being should always be accessible to a&nbsp;computer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Teach children to be polite and courteous in the home, and, when he&nbsp;grows up, he will never be able to edge his car onto a freeway.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A bird in the hand is worth what it will bring.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Two wrongs don''t make a right, but three lefts do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Misery loves company, but company does not reciprocate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man is the best computer we can put aboard a spacecraft ... and the&nbsp;only one that can be mass produced with unskilled labor.<br>&nbsp;-- Wernher von Braun')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For my son, Robert, this is proving to be the high-point of his entire&nbsp;life to date.  He has had his pajamas on for two, maybe three days&nbsp;now.  He has the sense of joyful independence a 5-year-old child gets&nbsp;when he suddenly realizes that he could be operating an acetylene torch&nbsp;in the coat closet and neither parent [because of the flu] would have&nbsp;the strength to object.  He has been foraging for his own food, which&nbsp;means his diet consists entirely of "food" substances which are&nbsp;advertised only on Saturday-morning cartoon shows; substances that are&nbsp;the color of jukebox lights and that, for legal reasons, have their&nbsp;names spelled wrong, as in New Creemy Chok-''n''-Cheez Lumps o'' Froot<br>"part of this complete breakfast").<br>&nbsp;-- Dave Barry, "Molecular Homicide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"All my friends and I are crazy.  That''s the only thing that keeps us&nbsp;sane."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A closed mouth gathers no foot.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Certainly there are things in life that money can''t buy, but it''s very funny--<br>Did you ever try buying them without money?<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Users are afraid they''ll break the machine -- but they''re never&nbsp;afraid to break your face.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God must love the Common Man; He made so many of them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never put off till tomorrow what you can avoid all together.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On the subject of C program indentation:<br><br>"In My Egotistical Opinion, most people''s C programs should be<br>indented six feet downward and covered with dirt."<br>&nbsp;-- Blair P. Houghton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When a fellow says, "It ain''t the money but the principle of the&nbsp;thing," it''s the money.<br>&nbsp;-- Kim Hubbard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is the first numerical problem I ever did.  It demonstrates the&nbsp;power of computers:<br>&nbsp;Enter lots of data on calorie & nutritive content of foods.  Instruct&nbsp;the thing to maximize a function describing nutritive content, with a&nbsp;minimum level of each component, for fixed caloric content.  The&nbsp;results are that one should eat each day:<br><br>1/2 chicken<br>1 egg<br>1 glass of skim milk<br>27 heads of lettuce.<br>&nbsp;-- Rev. Adrian Melott')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One man''s theology is another man''s belly laugh.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A straw vote only shows which way the hot air blows.<br>&nbsp;-- O''Henry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A Riverside, California, health ordinance states that two persons may&nbsp;not kiss each other without first wiping their lips with carbolized&nbsp;rosewater.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Self Test for Paranoia:<br>You know you have it when you can''t think of anything that''s&nbsp;your own fault.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To invent, you need a good imagination and a pile of junk.<br>&nbsp;-- Thomas Edison')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paranoid schizophrenics outnumber their enemies at least two to one.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Baker''s First Law of Federal Geometry:<br>A block grant is a solid mass of money surrounded on all sides&nbsp;by governors.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Save the Whales -- Harpoon a Honda.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boys will be boys, and so will a lot of middle-aged men.<br>&nbsp;-- Kin Hubbard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Arthur''s Laws of Love:<br>(1) People to whom you are attracted invariably think you<br>    remind them of someone else.<br>(2) The love letter you finally got the courage to send will be<br>    delayed in the mail long enough for you to make a fool of<br>    yourself in person.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paul''s Law:<br>You can''t fall off the floor.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A limerick packs laughs anatomical&nbsp;Into space that is quite economical.<br>But the good ones I''ve seen<br>So seldom are clean,<br>And the clean ones so seldom are comical.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finagle''s Second Law:<br>No matter what the anticipated result, there will always be&nbsp;someone eager to (a) misinterpret it, (b) fake it, or (c) believe it&nbsp;happened according to his own pet theory.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why bother building any more nuclear warheads until we use the ones we&nbsp;have?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real computer scientists only write specs for languages that might run&nbsp;on future hardware.  Nobody trusts them to write specs for anything homo&nbsp;sapiens will ever be able to fit on a single planet.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I get up each morning, gather my wits.<br>Pick up the paper, read the obits.<br>If I''m not there I know I''m not dead.<br>So I eat a good breakfast and go back to bed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Pocataligo, Georgia, it is a violation for a woman over 200 pounds&nbsp;and attired in shorts to pilot or ride in an airplane.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you think the United States has stood still, who built the largest&nbsp;shopping center in the world?<br>&nbsp;-- Richard Nixon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A year spent in artificial intelligence is enough to make one believe&nbsp;in God.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All the big corporations depreciate their possessions, and you can,<br>too, provided you use them for business purposes.  For example, if you&nbsp;subscribe to the Wall Street Journal, a business-related newspaper, you&nbsp;can deduct the cost of your house, because, in the words of U.S.<br>Supreme Court Chief Justice Warren Burger in a landmark 1979 tax&nbsp;decision: "Where else are you going to read the paper?  Outside?  What&nbsp;if it rains?"<br>&nbsp;-- Dave Barry, "Sweating Out Taxes"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you eat a live frog in the morning, nothing worse will happen to&nbsp;either of you for the rest of the day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anybody with money to burn will easily find someone to tend the fire.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While it may be true that a watched pot never boils, the one you don''t&nbsp;keep an eye on can make an awful mess of your stove.<br>&nbsp;-- Edward Stevenson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Excellent day for drinking heavily.  Spike office water cooler.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Disclaimer: Any resemblance between the above views and those of my&nbsp;employer, my terminal, or the view out my window are purely&nbsp;coincidental.  Any resemblance between the above and my own views is&nbsp;non-deterministic.  The question of the existence of views in the&nbsp;absence of anyone to hold them is left as an exercise for the reader.<br>The question of the existence of the reader is left as an exercise for&nbsp;the second god coefficient.  (A discussion of non-orthogonal,<br>non-integral polytheism is beyond the scope of this article.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He thought he saw an albatross&nbsp;That fluttered ''round the lamp.<br>He looked again and saw it was&nbsp;A penny postage stamp.<br>"You''d best be getting home," he said,<br>"The nights are rather damp."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fourth Law of Applied Terror:<br>The night before the English History mid-term, your Biology&nbsp;instructor will assign 200 pages on planaria.<br>&nbsp;Corollary:<br>Every instructor assumes that you have nothing else to do&nbsp;except study for that instructor''s course.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real software engineers don''t like the idea of some inexplicable and&nbsp;greasy hardware several aisles away that may stop working at any&nbsp;moment.  They have a great distrust of hardware people, and wish that&nbsp;systems could be virtual at *___^H^H^Hall* levels.  They would like personal&nbsp;computers (you know no one''s going to trip over something and kill your&nbsp;DFA in mid-transit), except that they need 8 megabytes to run their&nbsp;Correctness Verification Aid packages.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s better to be wanted for murder that not to be wanted at all.<br>&nbsp;-- Marty Winch')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t like spinach, and I''m glad I don''t, because if I liked it I''d&nbsp;eat it, and I just hate it."<br>&nbsp;-- Clarence Darrow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''m attending the opening of my&nbsp;garage door."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Meskimen''s Law:<br>There''s never time to do it right, but there''s always time to&nbsp;do it over.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'November, n.:<br>The eleventh twelfth of a weariness.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What this country needs is a dime that will buy a good five-cent&nbsp;bagel.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mike:&nbsp;"The Fourth Dimension is a shambles?"&nbsp;Bernie:&nbsp;"Nobody ever empties the ashtrays.  People are SO<br>inconsiderate."<br>&nbsp;-- Gary Trudeau, "Doonesbury"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Like the ski resort of girls looking for husbands and husbands looking&nbsp;for girls, the situation is not as symmetrical as it might seem.<br>&nbsp;-- Alan McKay')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Just remember: when you go to court, you are trusting your fate to&nbsp;twelve people that weren''t smart enough to get out of jury duty!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Misery no longer loves company.  Nowadays it insists on it.<br>&nbsp;-- Russell Baker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you''re happy, you''re successful.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Children are natural mimic who act like their parents despite every&nbsp;effort to teach them good manners.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;DELETE A FORTUNE!&nbsp;&nbsp;Don''t some of these fortunes just drive you nuts?!  Wouldn''t you like&nbsp;to see some of them deleted from the system?  You can!  Just mail to&nbsp;"fortune" with the fortune you hate most, and we MIGHT make sure it&nbsp;gets expunged.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The full impact of parenthood doesn''t hit you until you multiply the&nbsp;number of your kids by 32 teeth.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As long as I am mayor of this city [Jersey City, New Jersey] the great&nbsp;industries are secure.  We hear about constitutional rights, free&nbsp;speech and the free press.  Every time I hear these words I say to&nbsp;myself, "That man is a Red, that man is a Communist".  You never hear a&nbsp;real American talk like that.<br>&nbsp;-- Frank Hague (1896-1956)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pure drivel tends to drive ordinary drivel off of the TV screen.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Art is either plagiarism or revolution.<br>&nbsp;-- Paul Gauguin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'G. B. Shaw to William Douglas Home: "Go on writing plays, my boy.  One&nbsp;of these days a London producer will go into his office and say to his&nbsp;secretary, `Is there a play from Shaw this morning?'' and when she says&nbsp;`No,'' he will say, `Well, then we''ll have to start on the rubbish.'' And&nbsp;that''s your chance, my boy."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Zounds!  I was never so bethumped with words&nbsp;since I first called my brother''s father dad.<br>&nbsp;-- William Shakespeare, "King John"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every creature has within him the wild, uncontrollable urge to punt.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fourth Law of Thermodynamics:  If the probability of success is not&nbsp;almost one, it is damn near zero.<br>&nbsp;-- David Ellis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;How many seconds are there in a year?  If I tell you there  are&nbsp;3.155  x  10^7, you won''t even try to remember it.  On the other hand,<br>who could forget that, to within half a percent, pi seconds is a&nbsp;nanocentury.<br>&nbsp;-- Tom Duff, Bell Labs')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Consequences, Schmonsequences, as long as I''m rich."<br>&nbsp;-- "Ali Baba Bunny" [1957, Chuck Jones]')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Human cardiac catheterization was introduced by Werner Forssman in&nbsp;1929.  Ignoring his department chief, and tying his assistant to an&nbsp;operating table to prevent his interference, he placed a uretheral&nbsp;catheter into a vein in his arm, advanced it to the right atrium [of&nbsp;his heart], and walked upstairs to the x-ray department where he took&nbsp;the confirmatory x-ray film.  In 1956, Dr. Forssman was awarded the&nbsp;Nobel Prize.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'George Orwell 1984.  Northwestern 0.<br>&nbsp;-- Chicago Reader 10/15/82')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Life is a whim of several billion cells to be you for a while.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Zero Defects, n.:<br>The result of shutting down a production line.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'panic: kernel trap (ignored)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If ignorance is bliss, why aren''t there more happy people?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'QUOTE OF THE DAY:<br>&nbsp;       `&nbsp;')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A sine curve goes off to infinity or at least the end of the blackboard<br>&nbsp;-- Prof. Steiner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In 1869 the waffle iron was invented for people who had wrinkled&nbsp;waffles.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eagleson''s Law:<br>Any code of your own that you haven''t looked at for six or more&nbsp;months, might as well have been written by someone else.  (Eagleson is&nbsp;an optimist, the real number is more like three weeks.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The National Association of Theater Concessionaires reported that in&nbsp;1986, 60% of all candy sold in movie theaters was sold to Roger Ebert."<br>&nbsp;-- D. Letterman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You are only young once, but you can stay immature indefinitely.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The voters have spoken, the bastards ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do something unusual today.  Pay a bill.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Did you know that clones never use mirrors?<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I am not now, nor have I ever been, a member of the demigodic party.<br>&nbsp;-- Dennis Ritchie')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Our vision is to speed up time, eventually eliminating it."<br>&nbsp;-- Alex Schure')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Banectomy, n.:<br>The removal of bruises on a banana.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The [Ford Foundation] is a large body of money completely surrounded by&nbsp;people who want some.<br>&nbsp;-- Dwight MacDonald')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The only really good place to buy lumber is at a store where the lumber&nbsp;has already been cut and attached together in the form of furniture,<br>finished, and put inside boxes.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is good.  I say this because other systems are worse.<br>&nbsp;-- Jawaharlal Nehru')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A bore is someone who persists in holding his own views after we have&nbsp;enlightened him with ours.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;-- Gifts for Children --&nbsp;&nbsp;This is easy.  You never have to figure out what to get for children,<br>because they will tell you exactly what they want.  They spend months&nbsp;and months researching these kinds of things by watching Saturday-&nbsp;morning cartoon-show advertisements.  Make sure you get your children&nbsp;exactly what they ask for, even if you disapprove of their choices.  If&nbsp;your child thinks he wants Murderous Bob, the Doll with the Face You&nbsp;Can Rip Right Off, you''d better get it.  You may be worried that it&nbsp;might help to encourage your child''s antisocial tendencies, but believe&nbsp;me, you have not seen antisocial tendencies until you''ve seen a child&nbsp;who is convinced that he or she did not get the right gift.<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a listener nods his head when you''re explaining your program, wake&nbsp;him up.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maintainer''s Motto:<br>If we can''t fix it, it ain''t broke.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life to you is a bold and dashing responsibility"<br>&nbsp;-- a Mary Chung''s fortune cookie')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Dying is a very dull, dreary affair.  And my advice to you is to have&nbsp;nothing whatever to do with it."<br>&nbsp;-- W. Somerset Maugham')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While anyone can admit to themselves they were wrong, the true test is&nbsp;admission to someone else.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We will have solar energy as soon as the utility companies solve one&nbsp;technical problem -- how to run a sunbeam through a meter.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Research is what I''m doing when I don''t know what I''m doing.<br>&nbsp;-- Wernher von Braun')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mark''s Dental-Chair Discovery:<br>Dentists are incapable of asking questions that require a&nbsp;simple yes or no answer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lackland''s Laws:<br>(1) Never be first.<br>(2) Never be last.<br>(3) Never volunteer for anything')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hoare''s Law of Large Problems:<br>Inside every large problem is a small problem struggling to get&nbsp;out.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''ve seen, I SAY, I''ve seen better heads on a mug of beer"<br>&nbsp;-- Senator Claghorn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Users hate Real Programmers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mustgo, n.:<br>Any item of food that has been sitting in the refrigerator so&nbsp;long it has become a science project.<br>&nbsp;-- Sniglets, "Rich Hall & Friends"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Between 1950 and 1952, a bored weatherman, stationed north of Hudson&nbsp;Bay, left a monument that neither government nor time can eradicate.<br>Using a bulldozer abandoned by the Air Force, he spent two years and&nbsp;great effort pushing boulders into a single word.<br>&nbsp;It can be seen from 10,000 feet, silhouetted against the snow.<br>Government officials exchanged memos full of circumlocutions (no Latin&nbsp;equivalent exists) but failed to word an appropriation bill for the&nbsp;destruction of this cairn, that wouldn''t alert the press and embarrass&nbsp;both Parliament and Party.<br>&nbsp;It stands today, a monument to human spirit.  If life exists on other&nbsp;planets, this may be the first message received from us.<br>&nbsp;-- The Realist, November, 1964.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The years of peak mental activity are undoubtedly between the ages of&nbsp;four and eighteen.  At four we know all the questions, at eighteen all&nbsp;the answers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Cable is not a luxury, since many areas have poor TV reception."<br>&nbsp;-- The mayor of Tucson, Arizona, 1989')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Last night, I came home and realized that everything in my apartment&nbsp;had been stolen and replaced with an exact duplicate.  I told this to&nbsp;my friend -- he said, `Do I know you?''"<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Somebody ought to cross ball point pens with coat hangers so that the&nbsp;pens will multiply instead of disappear.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Well, that was a piece of cake, eh K-9?"&nbsp;&nbsp;"Piece of cake, Master?  Radial slice of baked confection ...<br>coefficient of relevance to Key of Time: zero."<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every little picofarad has a nanohenry all its own.<br>&nbsp;-- Don Vonada')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy, n.:<br>A government of the masses.  Authority derived through mass&nbsp;meeting or any other form of direct expression.  Results in mobocracy.<br>Attitude toward property is communistic... negating property rights.<br>Attitude toward law is that the will of the majority shall regulate,<br>whether it is based upon deliberation or governed by passion,<br>prejudice, and impulse, without restraint or regard to consequences.<br>Result is demagogism, license, agitation, discontent, anarchy.<br>&nbsp;-- U. S. Army Training Manual No. 2000-25 (1928-1932),<br>&nbsp;   since withdrawn.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When the weight of the paperwork equals the weight of the plane, the&nbsp;plane will fly.<br>&nbsp;-- Donald Douglas')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The very powerful and the very stupid have one thing in common.<br>Instead of altering their views to fit the facts, they alter the facts&nbsp;to fit their views ... which can be very uncomfortable if you happen to&nbsp;be one of the facts that needs altering.<br>&nbsp;-- Doctor Who, "Face of Evil"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t worry about avoiding temptation -- as you grow older, it starts&nbsp;avoiding you.<br>&nbsp;-- The Old Farmer''s Almanac')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When someone says "I want a programming language in which I need only&nbsp;say what I wish done," give him a lollipop.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A free society is one where it is safe to be unpopular.<br>&nbsp;-- Adlai Stevenson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Walk softly and carry a megawatt laser.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sorry, no fortune this time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When love is gone, there''s always justice.<br>And when justice is gone, there''s always force.<br>And when force is gone, there''s always Mom.<br>Hi, Mom!<br>&nbsp;-- Laurie Anderson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A transistor protected by a fast-acting fuse will protect the fuse by&nbsp;blowing first.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There are those who claim that magic is like the tide; that it swells&nbsp;and fades over the surface of the earth, collecting in concentrated&nbsp;pools here and there, almost disappearing from other spots, leaving&nbsp;them parched for wonder.  There are also those who believe that if you&nbsp;stick your fingers up your nose and blow, it will increase your&nbsp;intelligence."<br>&nbsp;-- The Teachings of Ebenezum, Volume VII')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #17: SARTRE&nbsp;&nbsp;Named after the late existential philosopher, SARTRE is an extremely&nbsp;unstructured language.  Statements in SARTRE have no purpose; they just&nbsp;are.  Thus SARTRE programs are left to define their own functions.<br>SARTRE programmers tend to be boring and depressed, and are no fun at&nbsp;parties.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Campus sidewalks never exist as the straightest line between two&nbsp;points.<br>&nbsp;-- M. M. Johnston')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A putt that stops close enough to the cup to inspire such comments as&nbsp;"you could blow it in" may be blown in.  This rule does not apply if&nbsp;the ball is more than three inches from the hole, because no one wants&nbsp;to make a travesty of the game.<br>&nbsp;-- Donald A. Metz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fashion is a form of ugliness so intolerable that we have to alter it&nbsp;every six months.<br>&nbsp;-- Oscar Wilde')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''ve been scheduled for a karma&nbsp;transplant."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A man goes to a tailor to try on a new custom-made suit.  The&nbsp;first thing he notices is that the arms are too long.<br>"No problem," says the tailor.  "Just bend them at the elbow&nbsp;and hold them out in front of you.  See, now it''s fine."<br>"But the collar is up around my ears!"<br>"It''s nothing.  Just hunch your back up a little ... no, a&nbsp;little more ... that''s it."<br>"But I''m stepping on my cuffs!"  the man cries in desperation.<br>"Nu, bend you knees a little to take up the slack.  There you&nbsp;go.  Look in the mirror -- the suit fits perfectly."<br>So, twisted like a pretzel, the man lurches out onto the&nbsp;street.  Reba and Florence see him go by.<br>"Oh, look," says Reba, "that poor man!"<br>"Yes," says Florence, "but what a beautiful suit."<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"By the time they had diminished from 50 to 8, the other dwarves began&nbsp;to suspect ''Hungry'' ..."<br>&nbsp;-- Gary Larson, "The Far Side"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Cutting the space budget really restores my faith in humanity.  It&nbsp;eliminates dreams, goals, and ideals and lets us get straight to the&nbsp;business of hate, debauchery, and self-annihilation."<br>&nbsp;-- Johnny Hart')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Drive defensively.  Buy a tank.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The chief cause of problems is solutions.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In our civilization, and under our republican form of government,<br>intelligence is so highly honored that it is rewarded by exemption from&nbsp;the cares of office.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We''ll cross out that bridge when we come back to it later."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Remember:  Silly is a state of Mind, Stupid is a way of Life.<br>&nbsp;-- Dave Butler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man, n.:<br>An animal so lost in rapturous contemplation of what he thinks&nbsp;e is as to overlook what he indubitably ought to be.  His hief&nbsp;occupation is extermination of other animals and his own pecies, which,<br>however, multiplies with such insistent apidity as to infest the whole&nbsp;habitable earth and Canada.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bare feet magnetize sharp metal objects so they point upward from the&nbsp;floor -- especially in the dark.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Welcome thy neighbor into thy fallout shelter.  He''ll come in handy if&nbsp;you run out of food.<br>&nbsp;-- Dean McLaughlin.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If everybody minded their own business, the world would go&nbsp;around a deal faster.<br>&nbsp;-- The Duchess, "Through the Looking Glass"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An authority is a person who can tell you more about something than you&nbsp;really care to know.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reporter (to Mahatma Gandhi): Mr Gandhi, what do you think of Western<br>Civilization?&nbsp;Gandhi:&nbsp;I think it would be a good idea.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It runs like _^Hx, where _^Hx is something unsavory"<br>&nbsp;-- Prof. Romas Aleliunas, CS 435')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On Monday mornings I am dedicated to the proposition that all men are&nbsp;created jerks.<br>&nbsp;-- Avery')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The moving cursor writes, and having written, blinks on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The more laws and order are made prominent, the more thieves and&nbsp;robbers there will be.<br>&nbsp;-- Lao Tsu')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"Verily and forsooth," replied Goodgulf darkly.  "In the past&nbsp;year strange and fearful wonders I have seen.  Fields sown with barley&nbsp;reap crabgrass and fungus, and even small gardens reject their&nbsp;artichoke hearts.  There has been a hot day in December and a blue&nbsp;moon.  Calendars are made with a month of Sundays and a blue-ribbon&nbsp;Holstein bore alive two insurance salesmen.  The earth splits and the&nbsp;entrails of a goat were found tied in square knots.  The face of the&nbsp;sun blackens and the skies have rained down soggy potato chips."&nbsp;<br>"But what do all these things mean?" gasped Frito.<br><br>"Beats me," said Goodgulf with a shrug, "but I thought it made&nbsp;good copy."<br>&nbsp;-- Harvard Lampoon, "Bored of the Rings"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The basic idea behind malls is that they are more convenient than&nbsp;cities.  Cities contain streets, which are dangerous and crowded and&nbsp;difficult to park in.  Malls, on the other hand, have parking lots,<br>which are also dangerous and crowded and difficult to park in, but --&nbsp;here is the big difference -- in mall parking lots, THERE ARE NO&nbsp;RULES.  You''re allowed to do anything.  You can drive as fast as you&nbsp;want in any direction you want.  I was once driving in a mall parking&nbsp;lot when my car was struck by a pickup truck being driven backward by a&nbsp;squat man with a tattoo that said "Charlie" on his forearm, who got out&nbsp;and explained to me, in great detail, why the accident was my fault,<br>his reasoning being that he was violent and muscular, whereas I was&nbsp;neither.  This kind of reasoning is legally valid in mall parking&nbsp;lots.<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Great minds run in great circles.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Science is facts; just as houses are made of stones, so is science made&nbsp;of facts; but a pile of stones is not a house and a collection of facts&nbsp;is not necessarily science.<br>&nbsp;-- Henri Poincair''^He')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I have more humility in my little finger than you have in your whole&nbsp;____^H^H^H^HBODY!<br>&nbsp;-- from "Cerebus" #82')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can''t have everything.  Where would you put it?"<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No problem is so large it can''t be fit in somewhere.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What color is a chameleon on a mirror?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Xerox never comes up with anything original.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He''s the kind of man for the times that need the kind of man he is ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Adopted kids are such a pain -- you have to teach them how to look&nbsp;like you ..."<br>&nbsp;-- Gilda Radner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After a number of decimal places, nobody gives a damn.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... Logically incoherent, semantically incomprehensible, and&nbsp;legally ... impeccable!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The hieroglyphics are all unreadable except for a notation on the back,<br>which reads "Genuine authentic Egyptian papyrus.  Guaranteed to be at&nbsp;least 5000 years old."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some points to remember [about animals]:<br><br>1) Don''t go to sleep under big animals, e.g., elephants, rhinoceri,<br>    hippopotamuses:<br>(2) Don''t put animals with sharp teeth or poisonous fangs down the&nbsp;    front of your clothes:<br>(3) Don''t pat certain animals, e.g., crocodiles and scorpions or dogs&nbsp;    you have just kicked.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This quote is taken from the Diamondback, the University of Maryland&nbsp;student newspaper, of Tuesday, 3/10/87.<br><br>One disadvantage of the Univac system is that it does not use<br>Unix, a recently developed program which translates from one<br>computer language to another and has a built-in editing system<br>which identifies errors in the original program.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Iron Law of Distribution:<br>Them that has, gets.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It was a book to kill time for those who liked it better dead.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'President Thieu says he''ll quit if he doesn''t get more than 50% of the&nbsp;vote.  In a democracy, that''s not called quitting.<br>&nbsp;-- The Washington Post')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Commitment, n.:<br>Commitment can be illustrated by a breakfast of ham and eggs.<br>The chicken was involved, the pig was committed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Computers will not be perfected until they can compute how much more&nbsp;than the estimate the job will cost.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He was a fiddler, and consequently a rogue.<br>&nbsp;-- Jonathon Swift')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I had to censor everything my sons watched ... even on the Mary Tyler&nbsp;Moore show I heard the word ''damn''!"<br>&nbsp;-- Mary Lou Bax')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Parsley<br> is gharsley.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Main''s Law:<br>For every action there is an equal and opposite government&nbsp;program.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People often find it easier to be a result of the past than a cause of&nbsp;the future.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paranoids are people, too; they have their own problems.  It''s easy to&nbsp;criticize, but if everybody hated you, you''d be paranoid too.<br>&nbsp;-- D. J. Hicks')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never count your chickens before they rip your lips off')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When asked by an anthropologist what the Indians called America before&nbsp;the white men came, an Indian said simply "Ours."<br>&nbsp;-- Vine Deloria, Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tonight''s the night: Sleep in a eucalyptus tree.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'H:&nbsp;If a ''GOBLIN (HOB) waylays you,<br>Slice him up before he slays you.<br>Nothing makes you look a slob<br>Like running from a HOB''LIN (GOB).<br>&nbsp;-- The Roguelet''s ABC')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Penguin Trivia #46:<br>Animals who are not penguins can only wish they were.<br>&nbsp;-- Chicago Reader 10/15/82')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The distinction between Jewish and goyish can be quite subtle, as the&nbsp;following quote from Lenny Bruce illustrates:<br><br>"I''m Jewish.  Count Basie''s Jewish.  Ray Charles is Jewish.<br>Eddie Cantor''s goyish.  The B''nai Brith is goyish.  The Hadassah is&nbsp;Jewish.  Marine Corps -- heavy goyish, dangerous.<br>"Kool-Aid is goyish.  All Drake''s Cakes are goyish.<br>Pumpernickel is Jewish and, as you know, white bread is very goyish.<br>Instant potatoes -- goyish.  Black cherry soda''s very Jewish.<br>Macaroons are ____^H^H^H^Hvery Jewish.  Fruit salad is Jewish.  Lime Jell-O is&nbsp;goyish.  Lime soda is ____^H^H^H^Hvery goyish.  Trailer parks are so goyish that&nbsp;Jews won''t go near them ..."<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Basic is a high level languish.<br>APL is a high level anguish.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It has been said that man is a rational animal.  All my life I have&nbsp;been searching for evidence which could support this.<br>&nbsp;-- Bertrand Russell')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Always remember that you are unique.  Just like everyone else.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When in doubt, tell the truth."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To get something done, a committee should consist of no more than three&nbsp;men, two of them absent.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Optimization hinders evolution.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The C Programming Language -- A language which combines the&nbsp;flexibility of assembly language with the power of assembly language."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Warning: Listening to WXRT on April Fools'' Day is not recommended for&nbsp;those who are slightly disoriented the first few hours after waking&nbsp;up.<br>&nbsp;-- Chicago Reader 4/22/83')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #18a: FIFTH&nbsp;&nbsp;FIFTH is a precision mathematical language in which the data types&nbsp;refer to quantity.  The data types range from CC, OUNCE, SHOT, and&nbsp;JIGGER to FIFTH (hence the name of the language), LITER, MAGNUM and&nbsp;BLOTTO.  Commands refer to ingredients such as CHABLIS, CHARDONNAY,<br>CABERNET, GIN, VERMOUTH, VODKA, SCOTCH, and WHATEVERSAROUND.<br>&nbsp;The many versions of the FIFTH language reflect the sophistication and&nbsp;financial status of its users.  Commands in the ELITE dialect include&nbsp;VSOP and LAFITE, while commands in the GUTTER dialect include HOOTCH&nbsp;and RIPPLE. The latter is a favorite of frustrated FORTH programmers&nbsp;who end up using this language.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every absurdity has a champion who will defend it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The idea is to die young as late as possible.<br>&nbsp;-- Ashley Montague')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There are three possibilities: Pioneer''s solar panel has turned away&nbsp;from the sun; there''s a large meteor blocking transmission; or someone&nbsp;loaded Star Trek 3.2 into our video processor."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Armadillo:<br>To provide weapons to a Spanish pickle')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Minors in Kansas City, Missouri, are not allowed to purchase cap&nbsp;pistols; they may buy shotguns freely, however.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve known him as a man, as an adolescent and as a child -- sometimes&nbsp;on the same day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If bankers can count, how come they have eight windows and only four&nbsp;tellers?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sweater, n.:<br>A garment worn by a child when its mother feels chilly.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Westheimer''s Discovery:<br>A couple of months in the laboratory can frequently save a&nbsp;couple of hours in the library.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All [zoos] actually offer to the public in return for the taxes spent&nbsp;upon them is a form of idle and witless amusement, compared to which a&nbsp;visit to a penitentiary, or even to a State legislature in session, is&nbsp;informing, stimulating and ennobling.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Barometer, n.:<br>An ingenious instrument which indicates what kind of weather we&nbsp;are having.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One nice thing about egotists: they don''t talk about other people.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The trouble with a kitten is that&nbsp;When it grows up, it''s always a cat<br>&nbsp;-- Ogden Nash.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How wonderful opera would be if there were no singers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many DEC repairman does it take to fix a flat ?&nbsp;A:  Five; four to hold the car up and one to swap tires.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reality is a cop-out for people who can''t handle drugs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mythology, n.:<br>The body of a primitive people''s beliefs concerning its&nbsp;origin, early history, heroes, deities and so forth, as distinguished&nbsp;from the true accounts which it invents later.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The buffalo isn''t as dangerous as everyone makes him out to be.<br>Statistics prove that in the United States more Americans are killed in&nbsp;automobile accidents than are killed by buffalo.<br>&nbsp;-- Art Buchwald')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Children are unpredictable.  You never know what inconsistency they''re&nbsp;going to catch you in next.<br>&nbsp;-- Franklin P. Jones')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Seduced, shaggy Samson snored.<br>She scissored short.  Sorely shorn,<br>Soon shackled slave, Samson sighed,<br>Silently scheming,<br>Sightlessly seeking&nbsp;Some savage, spectacular suicide.<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I don''t see you in the future, I''ll see you in the pasture.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'MAFIA, n:<br>[Acronym for Mechanized Applications in Forced Insurance&nbsp;Accounting.] An extensive network with many on-line and offshore&nbsp;subsystems running under OS, DOS, and IOS.  MAFIA documentation is&nbsp;rather scanty, and the MAFIA sales office exhibits that testy&nbsp;reluctance to bona fide inquiries which is the hallmark of so many DP&nbsp;operations.  From the little that has seeped out, it would appear that&nbsp;MAFIA operates under a non-standard protocol, OMERTA, a tight-lipped&nbsp;variant of SNA, in which extended handshakes also perform complex&nbsp;security functions.  The known timesharing aspects of MAFIA point to a&nbsp;more than usually autocratic operating system.  Screen prompts carry an&nbsp;imperative, nonrefusable weighting (most menus offer simple YES/YES&nbsp;options, defaulting to YES) that precludes indifference or delay.<br>Uniquely, all editing under MAFIA is performed centrally, using a&nbsp;powerful rubout feature capable of erasing files, filors, filees, and&nbsp;entire nodal aggravations.<br>&nbsp;-- Stan Kelly-Bootle, "The Devil''s DP Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"In short, _^HN is Richardian if, and only if, _^HN is not Richardian."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Do you think what we''re doing is wrong?"&nbsp;"Of course it''s wrong!  It''s illegal!"&nbsp;"I''ve never done anything illegal before."&nbsp;"I thought you said you were an accountant!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Magnocartic, adj.:<br>Any automobile that, when left unattended, attracts shopping&nbsp;carts.<br>&nbsp;-- Sniglets, "Rich Hall & Friends"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tertullian was born in Carthage somewhere about 160 A.D.  He was a&nbsp;pagan, and he abandoned himself to the lascivious life of his city&nbsp;until about his 35th year, when he became a Christian .... To him is&nbsp;ascribed the sublime confession: Credo quia absurdum est (I believe&nbsp;because it is absurd).  This does not altogether accord with historical&nbsp;fact, for he merely said:<br><br>"And the Son of God died, which is immediately credible because<br>it is absurd.  And buried he rose again, which is certain<br>because it is impossible."&nbsp;&nbsp;Thanks to the acuteness of his mind, he saw through the poverty of&nbsp;philosophical and Gnostic knowledge, and contemptuously rejected it.<br>&nbsp;-- C. G. Jung, in Psychological Types&nbsp;<br>Teruillian was one of the founders of the Catholic Church).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On a paper submitted by a physicist colleague:<br>&nbsp;"This isn''t right.  This isn''t even wrong."<br>&nbsp;-- Wolfgang Pauli')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I have discovered the art of deceiving diplomats. I tell them the truth&nbsp;and they never believe me.<br>&nbsp;-- Camillo Di Cavour')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A well adjusted person is one who makes the same mistake twice without&nbsp;getting nervous.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the space of one hundred and seventy-six years the Mississippi has&nbsp;shortened itself two hundred and forty-two miles.  Therefore ... in the&nbsp;Old Silurian Period the Mississippi River was upward of one million&nbsp;three hundred thousand miles long ... seven hundred and forty-two years&nbsp;from now the Mississippi will be only a mile and three-quarters long.<br>... There is something fascinating about science.  One gets such&nbsp;wholesome returns of conjecture out of such a trifling investment of&nbsp;fact.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a putt passes over the hole without dropping, it is deemed to have&nbsp;dropped.  The law of gravity holds that any object attempting to&nbsp;maintain a position in the atmosphere without something to support it&nbsp;must drop.  The law of gravity supercedes the law of golf.<br>&nbsp;-- Donald A. Metz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Help me, I''m a prisoner in a Fortune cookie file!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A public debt is a kind of anchor in the storm; but if the anchor be&nbsp;too heavy for the vessel, she will be sunk by that very weight which&nbsp;was intended for her preservation.<br>&nbsp;-- Colton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It appears that after his death, Albert Einstein found himself working&nbsp;as the doorkeeper at the Pearly Gates.  One slow day, he found that he&nbsp;had time to chat with the new entrants.  To the first one he asked,<br>"What''s your IQ?"  The new arrival replied, "190".  They discussed&nbsp;Einstein''s theory of relativity for hours.  When the second new arrival&nbsp;came, Einstein once again inquired as to the newcomer''s IQ.  The answer&nbsp;this time came "120".  To which Einstein replied, "Tell me, how did the&nbsp;Cubs do this year?" and they proceeded to talk for half an hour or so.<br>To the final arrival, Einstein once again posed the question, "What''s&nbsp;your IQ?".  Upon receiving the answer "70", Einstein smiled and asked,<br>"Got a minute to tell me about VMS 4.0?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t think they could put him in a mental hospital.  On the other&nbsp;hand, if he were already in, I don''t think they''d let him out."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One can''t proceed from the informal to the formal by formal means.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are two kinds of solar-heat systems: "passive" systems collect&nbsp;the sunlight that hits your home, and "active" systems collect the&nbsp;sunlight that hits your neighbors'' homes, too.<br>&nbsp;-- Dave Barry, "Postpetroleum Guzzler"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you''re not very clever you should be conciliatory.<br>&nbsp;-- Benjamin Disraeli')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The United States is like the guy at the party who gives cocaine to&nbsp;everybody and still nobody likes him.<br>&nbsp;-- Jim Samuels')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When all other means of communication fail, try words.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can''t carve your way to success without cutting remarks.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The first duty of a revolutionary is to get away with it.<br>&nbsp;-- Abbie Hoffman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This Fortue Examined By INSPECTOR NO. 2-14')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If someone had told me I would be Pope one day, I would have studied&nbsp;harder.<br>&nbsp;-- Pope John Paul I')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The identical is equal to itself, since it is different."<br>&nbsp;-- Franco Spisani')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why did the Roman Empire collapse?  What is the Latin for office&nbsp;automation?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pushing 40 is exercise enough.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have seen the future and it is just like the present, only longer."<br>&nbsp;-- Kehlog Albran, "The Profit"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Earth is a beta site.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One cannot make an omelette without breaking eggs -- but it is amazing&nbsp;how many eggs one can break without making a decent omelette.<br>&nbsp;-- Professor Charles P. Issawi')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Drawing on my fine command of language, I said nothing."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'University, n.:<br>Like a software house, except the software''s free, and it''s&nbsp;usable, and it works, and if it breaks they''ll quickly tell you how to&nbsp;fix it, and ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Who messed with my anti-paranoia shot?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '[Nuclear war] ... may not be desirable.<br>&nbsp;-- Edwin Meese III')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Go ''way!  You''re bothering me!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Utility is when you have one telephone, luxury is when you have two,<br>opulence is when you have three -- and paradise is when you have none.<br>&nbsp;-- Doug Larson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Encyclopedia Salesmen:<br>Invite them all in.  Nip out the back door.  Phone the police&nbsp;and tell them your house is being burgled.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The algorithm to do that is extremely nasty.  You might want to mug&nbsp;someone with it."<br>&nbsp;-- M. Devine, Computer Science 340')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Schwiggle, n.:<br>The amusing rotation of one''s bottom while sharpening a&nbsp;pencil.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can learn many things from children.  How much patience you have,<br>for instance.<br>&nbsp;-- Franklin P. Jones')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am not sure what this is, but an `F'' would only dignify it."<br>&nbsp;-- English Professor')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone who is capable of getting themselves made President should on no&nbsp;account be allowed to do the job.<br>&nbsp;-- Douglas Adams, "The Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Really ??  What a coincidence, I''m shallow too!!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rattling around the back of my head is a disturbing image of something&nbsp;I saw at the airport ... Now I''m remembering, those giant piles of&nbsp;computer magazines right next to "People" and "Time" in the airport&nbsp;store.  Does it bother anyone else that half the world is being told&nbsp;all of our hard-won secrets of computer technology?  Remember how all&nbsp;the lawyers cried foul when "How to Avoid Probate" was published?  Are&nbsp;they taking no-fault insurance lying down?  No way!  But at the current&nbsp;rate it won''t be long before there are stacks of the "Transactions on&nbsp;Information Theory" at the A&P checkout counters.  Who''s going to be&nbsp;impressed with us electrical engineers then?  Are we, as the saying&nbsp;goes, giving away the store?<br>&nbsp;-- Robert W. Lucky, IEEE President')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The first rule of magic is simple.  Don''t waste your time waving your&nbsp;hands and hoping when a rock or a club will do."<br>&nbsp;-- McCloctnik the Lucid')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"I quite agree with you," said the Duchess; "and the moral of&nbsp;that is -- `Be what you would seem to be'' -- or, if you''d like it put&nbsp;more simply -- `Never imagine yourself not to be otherwise than what it&nbsp;might appear to others that what you were or might have been was not&nbsp;otherwise than what you had been would have appeared to them to be&nbsp;otherwise.''"<br>&nbsp;-- Lewis Carrol, "Alice in Wonderland"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The light at the end of the tunnel may be an oncoming dragon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While money doesn''t buy love, it puts you in a great bargaining&nbsp;position.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rudin''s Law:<br>If there is a wrong way to do something, most people will do it&nbsp;every time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you cannot convince them, confuse them.<br>&nbsp;-- Harry S Truman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nobody suffers the pain of birth or the anguish of loving a child in&nbsp;order for presidents to make wars, for governments to feed on the&nbsp;substance of their people, for insurance companies to cheat the young&nbsp;and rob the old.<br>&nbsp;-- Lewis Lapham')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Aquadextrous, adj.:<br>Possessing the ability to turn the bathtub faucet on and off&nbsp;with your toes.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Advertising is a valuable economic factor because it is the cheapest&nbsp;way of selling goods, particularly if the goods are worthless.<br>&nbsp;-- Sinclair Lewis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I don''t believe there really IS a GAS SHORTAGE.. I think it''s all just&nbsp;a BIG HOAX on the part of the plastic sign salesmen -- to sell more&nbsp;numbers!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some programming languages manage to absorb change, but withstand&nbsp;progress.<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cold, adj.:<br>When the politicians walk around with their hands in their own&nbsp;pockets.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If the colleges were better, if they really had it, you would need to&nbsp;get the police at the gates to keep order in the inrushing multitude.<br>See in college how we thwart the natural love of learning by leaving&nbsp;the natural method of teaching what each wishes to learn, and insisting&nbsp;that you shall learn what you have no taste or capacity for.  The&nbsp;college, which should be a place of delightful labor, is made odious&nbsp;and unhealthy, and the young men are tempted to frivolous amusements to&nbsp;rally their jaded spirits.  I would have the studies elective.<br>Scholarship is to be created not by compulsion, but by awakening a pure&nbsp;interest in knowledge.  The wise instructor accomplishes this by&nbsp;opening to his pupils precisely the attractions the study has for&nbsp;himself.  The marking is a system for schools, not for the college; for&nbsp;boys, not for men; and it is an ungracious work to put on a professor.<br>&nbsp;-- Ralph Waldo Emerson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If while you are in school, there is a shortage of qualified personnel&nbsp;in a particular field, then by the time you graduate with the necessary&nbsp;qualifications, that field''s employment market is glutted.<br>&nbsp;-- Marguerite Emmons')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dear Lord:<br>I just want *___^H^H^Hone* one-armed manager so I never have to hear "On&nbsp;the other hand", again.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Are you a turtle?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The most exciting phrase to hear in science, the one that heralds new&nbsp;discoveries, is not "Eureka!" (I found it!) but "That''s funny ..."<br>&nbsp;-- Isaac Asimov')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''ve been leading a dog''s life.  Stay off the furniture.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reality is bad enough, why should I tell the truth?<br>&nbsp;-- Patrick Sky')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you only have a hammer, you tend to see every problem as a nail.<br>&nbsp;-- Maslow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '''Twas the nocturnal segment of the diurnal period&nbsp;   preceding the annual Yuletide celebration, And&nbsp;   throughout our place of residence,<br>Kinetic activity was not in evidence among the&nbsp;   possessors of this potential, including that&nbsp;   species of domestic rodent known as Mus musculus.<br>Hosiery was meticulously suspended from the forward&nbsp;   edge of the woodburning caloric apparatus,<br>Pursuant to our anticipatory pleasure regarding an&nbsp;   imminent visitation from an eccentric&nbsp;   philanthropist among whose folkloric appelations&nbsp;   is the honorific title of St. Nicklaus ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You should tip the waiter $10, minus $2 if he tells you his name,<br>another $2 if he claims it will be His Pleasure to serve you and&nbsp;another $2 for each "special" he describes involving confusing terms&nbsp;such as "shallots," and $4 if the menu contains the word "fixin''s."  In&nbsp;many restaurants, this means the waiter will actually owe you money.<br>If you are traveling with a child  aged six months to three years, you&nbsp;should leave an additional amount equal to twice the bill to compensate&nbsp;for the fact that they will have to take the banquette out and burn it&nbsp;because the cracks are wedged solid with gobbets made of partially&nbsp;chewed former restaurant rolls saturated with baby spit.<br>&nbsp;In New York, tip the taxicab driver $40 if he does not mention his&nbsp;hemorrhoids.<br>&nbsp;-- Dave Barry, "The Stuff of Etiquette"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This land is full of trousers!&nbsp;this land is full of mausers!<br>And pussycats to eat them when the sun goes down!<br>&nbsp;-- Firesign Theater')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reality is for those who can''t face Science Fiction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Today''s scientific question is: What in the world is electricity?&nbsp;&nbsp;And where does it go after it leaves the toaster?<br>&nbsp;-- Dave Barry, "What is Electricity?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After all, what is your hosts'' purpose in having a party?  Surely not&nbsp;for you to enjoy yourself; if that were their sole purpose, they''d have&nbsp;simply sent champagne and women over to your place by taxi.<br>&nbsp;-- P. J. O''Rourke')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will be surprised by a loud noise.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hark ye, Clinker, you are a most notorious offender.  You stand&nbsp;convicted of sickness, hunger, wretchedness, and want.<br>&nbsp;-- Tobias Smollet')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A fractal is by definition a set for which the Hausdorff Besicovitch&nbsp;dimension strictly exceeds the topological dimension."<br>&nbsp;-- Mandelbrot, "The Fractal Geometry of Nature"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If two men agree on everything, you may be sure that one of them is&nbsp;doing the thinking.<br>&nbsp;-- Lyndon Baines Johnson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The primary cause of failure in electrical appliances is an expired&nbsp;warranty.  Often, you can get an appliance running again simply by&nbsp;changing the warranty expiration date with a 15/64-inch felt-tipped&nbsp;marker.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some people are born mediocre, some people achieve mediocrity, and some&nbsp;people have mediocrity thrust upon them.<br>&nbsp;-- Joseph Heller, "Catch-22"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Florence Flask was ... dressing for the opera when she turned to her&nbsp;husband and screamed, "Erlenmeyer!  My joules!  Someone has stolen my&nbsp;joules!"&nbsp;&nbsp;"Now, now, my dear," replied her husband, "keep your balance and reflux&nbsp;a moment.  Perhaps they''re mislead."&nbsp;&nbsp;"No, I know they''re stolen," cried Florence.  "I remember putting them&nbsp;in my burette ... We must call a copper."&nbsp;&nbsp;Erlenmeyer did so, and the flatfoot who turned up, one Sherlock Ohms,<br>said the outrage looked like the work of an arch-criminal by the name&nbsp;of Lawrence Ium.<br>&nbsp;"We must be careful -- he''s a free radical, ultraviolet, and&nbsp;dangerous.  His girlfriend is a chlorine at the Palladium.  Maybe I can&nbsp;catch him there."  With that, he jumped on his carbon cycle in an&nbsp;activated state and sped off along the reaction pathway ...<br>&nbsp;-- Daniel B. Murphy, "Precipitations"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;WARNING TO ALL PERSONNEL:<br>&nbsp;Firings will continue until morale improves.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speak roughly to your little boy,<br>And beat him when he sneezes:<br>He only does it to annoy<br>Because he knows it teases.<br><br>Wow!  wow!  wow!&nbsp;&nbsp;I speak severely to my boy,<br>And beat him when he sneezes:<br>For he can thoroughly enjoy<br>The pepper when he pleases!&nbsp;<br>Wow!  wow!  wow!<br>&nbsp;-- Lewis Carrol, "Alice in Wonderland"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The illegal we do immediately. The unconstitutional takes a bit&nbsp;longer."<br>&nbsp;-- Henry Kissinger')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Carperpetuation (kar'' pur pet u a shun), n.:<br>The act, when vacuuming, of running over a string at least a&nbsp;dozen times, reaching over and picking it up, examining it, then&nbsp;putting it back down to give the vacuum one more chance.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A university is what a college becomes when the faculty loses interest&nbsp;in students.<br>&nbsp;-- John Ciardi')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chemistry is applied theology.<br>&nbsp;-- Augustus Stanley Owsley III')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... Now you''re ready for the actual shopping.  Your goal should be to&nbsp;get it over with as quickly as possible, because the longer you stay in&nbsp;the mall, the longer your children will have to listen to holiday songs&nbsp;on the mall public-address system, and many of these songs can damage&nbsp;children emotionally.  For example: "Frosty the Snowman" is about a&nbsp;snowman who befriends some children, plays with them until they learn&nbsp;to love him, then melts.  And "Rudolph the Red-Nosed Reindeer" is about&nbsp;a young reindeer who, because of a physical deformity, is treated as an&nbsp;outcast by the other reindeer.  Then along comes good, old Santa.  Does&nbsp;he ignore the deformity?  Does he look past Rudolph''s nose and respect&nbsp;Rudolph for the sensitive reindeer he is underneath?  No.  Santa asks&nbsp;Rudolph to guide his sleigh, as if Rudolph were nothing more than some&nbsp;kind of headlight with legs and a tail.  So unless you want your&nbsp;children exposed to this kind of insensitivity, you should shop&nbsp;quickly.<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A conclusion is simply the place where someone got tired of thinking.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sanity is the trademark of a weak mind.<br>&nbsp;-- Mark Harrold')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No committee could ever come up with anything as revolutionary as a&nbsp;camel -- anything as practical and as perfectly designed to perform&nbsp;effectively under such difficult conditions.<br>&nbsp;-- Laurence J. Peter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I drink to make other people interesting."<br>&nbsp;-- George Jean Nathan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Work Rule: Leave of Absence (for an Operation):<br>We are no longer allowing this practice.  We wish to discourage&nbsp;any thoughts that you may not need all of whatever you have, and you&nbsp;should not consider having anything removed.  We hired you as you are,<br>and to have anything removed would certainly make you less than we&nbsp;bargained for.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Nirvana?  Thats the place where the powers that be and their friends&nbsp;hang out.<br>&nbsp;-- Zonker Harris')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Atlee is a very modest man.  And with reason.<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Truth is the most valuable thing we have -- so let us economize it.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'E Pluribus Unix')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The First Commandment for Technicians:<br>Beware the lightening that lurketh in the undischarged&nbsp;capacitor, lest it cause thee to bounce upon thy buttocks in a most&nbsp;untechnician-like manner.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pardon this fortune.  Database under reconstruction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"To YOU I''m an atheist; to God, I''m the Loyal Opposition."<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a 6600 used paper tape instead of core memory, it would use up tape&nbsp;at about 30 miles/second.<br>&nbsp;-- Grishman, Assembly Language Programming')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old," said the youth, "one would hardly suppose<br>That your eye was as steady as ever:<br>Yet you balanced an eel on the end of your nose --<br>What made you so awfully clever?"&nbsp;&nbsp;"I have answered three questions, and that is enough,"<br>Said his father.  "Don''t give yourself airs!&nbsp;Do you think I can listen all day to such stuff?<br>Be off, or I''ll kick you down stairs!"<br>&nbsp;-- Lewis Carrol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It has been said [by Anatole France], "it is not by amusing oneself&nbsp;that one learns," and, in reply: "it is *____^H^H^H^Honly* by amusing oneself that&nbsp;one can learn."<br>&nbsp;-- Edward Kasner and James R. Newman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Air is water with holes in it')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Deliberation, n.:<br>The act of examining one''s bread to determine which side it is&nbsp;buttered on.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone can hold the helm when the sea is calm.<br>&nbsp;-- Publius Syrus')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"... all the modern inconveniences ..."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'UNIX was half a billion (500000000) seconds old on&nbsp;Tue Nov  5 00:53:20 1985 GMT (measuring since the time(2) epoch).<br>&nbsp;-- Andy Tannenbaum')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New members urgently required for SUICIDE CLUB, Watford area.<br>&nbsp;-- Monty Python''s Big Red Book')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Silverman''s Law:<br>If Murphy''s Law can go wrong, it will.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"An ounce of prevention is worth a pound of purge."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"First things first -- but not necessarily in that order"<br>&nbsp;-- The Doctor, "Doctor Who"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any father who thinks he''s all important should remind himself that&nbsp;this country honors fathers only one day a year while pickles get a&nbsp;whole week.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Government [is] an illusion the governed should not encourage.<br>&nbsp;-- John Updike, "Couples"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Job Placement, n.:<br>Telling your boss what he can do with your job.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Croll''s Query:<br>If tin whistles are made of tin, what are foghorns made of?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Excellence is THE trend of the ''80s.  Walk into any shopping&nbsp;mall bookstore, go to the rack where they keep the best-sellers such as&nbsp;"Garfield Gets Spayed", and you''ll see a half-dozen books telling you&nbsp;how to be excellent: "In Search of Excellence", "Finding Excellence",<br>"Grasping Hold of Excellence", "Where to Hide Your Excellence at Night&nbsp;So the Cleaning Personnel Don''t Steal It", etc.<br>&nbsp;-- Dave Barry, "In Search of Excellence"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Is not marriage an open question, when it is alleged, from the&nbsp;beginning of the world, that such as are in the institution wish to get&nbsp;out, and such as are out wish to get in?<br>&nbsp;-- Ralph Emerson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The trouble with being punctual is that nobody''s there to appreciate&nbsp;it.<br>&nbsp;-- Franklin P. Jones')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Did I say 2?  I lied.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"No one gets too old to learn a new way of being stupid."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We don''t know who discovered water, but we''re certain it wasn''t a&nbsp;fish.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When in panic, fear and doubt,<br>Drink in barrels, eat, and shout.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Only presidents, editors, and people with tapeworms have the right to&nbsp;use the editorial "we."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hain''t we got all the fools in town on our side?  And hain''t that a big&nbsp;enough majority in any town?<br>&nbsp;-- Mark Twain, "Huckleberry Finn"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mankind''s yearning to engage in sports is older than recorded history,<br>dating back to the time millions of years ago, when the first primitive&nbsp;man picked up a crude club and a round rock, tossed the rock into the&nbsp;air, and whomped the club into the sloping forehead of the first&nbsp;primitive umpire.<br>&nbsp;What inner force drove this first athlete?  Your guess is as good as&nbsp;mine.  Better, probably, because you haven''t had four beers.<br>&nbsp;-- Dave Barry, "Sports is a Drag"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Frobnicate, v.:<br>To manipulate or adjust, to tweak.  Derived from FROBNITZ.<br>Usually abbreviated to FROB.  Thus one has the saying "to frob a&nbsp;frob".  See TWEAK and TWIDDLE.  Usage: FROB, TWIDDLE, and TWEAK&nbsp;sometimes connote points along a continuum.  FROB connotes aimless&nbsp;manipulation; TWIDDLE connotes gross manipulation, often a coarse&nbsp;search for a proper setting; TWEAK connotes fine-tuning.  If someone is&nbsp;turning a knob on an oscilloscope, then if he''s carefully adjusting it&nbsp;he is probably tweaking it; if he is just turning it but looking at the&nbsp;screen he is probably twiddling it; but if he''s just doing it because&nbsp;turning a knob is fun, he''s frobbing it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There once was a girl named Irene&nbsp;Who lived on distilled kerosene<br>But she started absorbin''<br>A new hydrocarbon&nbsp;And since then has never benzene.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Time is an illusion; lunchtime, doubly so.<br>&nbsp;-- Ford Prefect')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The wages of sin are high but you get your money''s worth.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'T:&nbsp;One big monster, he called TROLL.<br>He don''t rock, and he don''t roll;<br>Drink no wine, and smoke no stogies.<br>He just Love To Eat Them Roguies.<br>&nbsp;-- The Roguelet''s ABC')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I was a kid I said to my father one afternoon, "Daddy, will you&nbsp;take me to the zoo?" He answered, "If the zoo wants you let them come&nbsp;and get you."<br>&nbsp;-- Jerry Lewis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Electrical Engineers do it with less resistance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An effective way to deal with predators is to taste terrible.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... But as records of courts and justice are admissible, it can&nbsp;easily be proved that powerful and malevolent magicians once existed&nbsp;and were a scourge to mankind.  The evidence (including confession)<br>upon which certain women were convicted of witchcraft and executed was&nbsp;without a flaw; it is still unimpeachable.  The judges'' decisions based&nbsp;on it were sound in logic and in law.  Nothing in any existing court&nbsp;was ever more thoroughly proved than the charges of witchcraft and&nbsp;sorcery for which so many suffered death.  If there were no witches,<br>human testimony and human reason are alike destitute of value.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What is the Nature of God?"&nbsp;&nbsp;    CLICK...CLICK...WHIRRR...CLICK...=BEEP!=&nbsp;    1 QT. SOUR CREAM&nbsp;    1 TSP. SAUERKRAUT&nbsp;    1/2 CUT CHIVES.<br>    STIR AND SPRINKLE WITH BACON BITS.<br>&nbsp;"I''ve just GOT to start labeling my software..."<br>&nbsp;-- Bloom County')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'CChheecckk yyoouurr dduupplleexx sswwiittcchh..')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I was part of that strange race of people aptly described as spending&nbsp;their lives doing things they detest to make money they don''t want to&nbsp;buy things they don''t need to impress people they dislike.<br>&nbsp;-- Emile Henry Gauvreay')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a group of _^HN persons implements a COBOL compiler, there will be _^HN-1&nbsp;passes.  Someone in the group has to be the manager.<br>&nbsp;-- T. Cheatham')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Economists state their GNP growth projections to the nearest tenth of a&nbsp;percentage point to prove they have a sense of humor.<br>&nbsp;-- Edgar R. Fiedler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'First Law of Bicycling:<br>No matter which way you ride, it''s uphill and against the&nbsp;wind.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Think of it!  With VLSI we can pack 100 ENIACs in 1 sq. cm.!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Painting, n.:<br>The art of protecting flat surfaces from the weather, and&nbsp;exposing them to the critic.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A man said to the Universe: "Sir, I exist!"&nbsp;&nbsp;"However," replied the Universe, "the fact has not created in me a&nbsp;sense of obligation."<br>&nbsp;-- Stephen Crane')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kids have *_____^H^H^H^H^Hnever* taken guidance from their parents.  If you could&nbsp;travel back in time and observe the original primate family in the&nbsp;original tree, you would see the primate parents yelling at the primate&nbsp;teenager for sitting around and sulking all day instead of hunting for&nbsp;grubs and berries like dad primate.  Then you''d see the primate&nbsp;teenager stomp up to his branch and slam the leaves.<br>&nbsp;-- Dave Barry, "Kids Today: They Don''t Know Dum Diddly<br>&nbsp;   Do"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Quick, sing me the BUDAPEST NATIONAL ANTHEM!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'District of Columbia pedestrians who leap over passing autos to escape&nbsp;injury, and then strike the car as they come down, are liable for any&nbsp;damage inflicted on the vehicle.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Leibowitz''s Rule:<br>When hammering a nail, you will never hit your finger if you&nbsp;hold the hammer with both hands.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I found out why my car was humming.  It had forgotten the words."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Science is what happens when preconception meets verification.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s little in taking or giving,<br>There''s little in water or wine:<br>This living, this living, this living,<br>Was never a project of mine.<br>Oh, hard is the struggle, and sparse is<br>The gain of the one at the top,<br>For art is a form of catharsis,<br>And love is a permanent flop,<br>And work is the province of cattle,<br>And rest''s for a clam in a shell,<br>So I''m thinking of throwing the battle --<br>Would you kindly direct me to hell?<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tell me, O Octopus, I begs,<br>Is those things arms, or is they legs?&nbsp;I marvel at thee, Octopus:<br>If I were thou, I''d call me us.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alone, adj.:<br>In bad company.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Smoking is one of the leading causes of statistics.<br>&nbsp;-- Fletcher Knebel')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One man''s brain plus one other will produce one half as many ideas as&nbsp;one man would have produced alone.  These two plus two more will&nbsp;produce half again as many ideas.  These four plus four more begin to&nbsp;represent a creative meeting, and the ratio changes to one quarter as&nbsp;many ...<br>&nbsp;-- Anthony Chevins')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t you feel more like you do now than you did when you came in?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Coronation, n.:<br>The ceremony of investing a sovereign with the outward and&nbsp;visible signs of his divine right to be blown skyhigh with a dynamite&nbsp;bomb.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What''s the use of a good quotation if you can''t change it?"<br>&nbsp;-- The Doctor')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'HOW YOU CAN TELL THAT IT''S GOING TO BE A ROTTEN DAY:<br>#1040 Your income tax refund cheque bounces.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'At Group L, Stoffel oversees six first-rate programmers, a managerial&nbsp;challenge roughly comparable to herding cats.<br>&nbsp;-- The Washington Post Magazine, June 9, 1985')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"This is lemma 1.1.  We start a new chapter so the numbers all go back&nbsp;to one."<br>&nbsp;-- Prof. Seager, C&O 351')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speak softly and own a big, mean Doberman.<br>&nbsp;-- Dave Millman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Write-Protect Tab, n.:<br>A small sticker created to cover the unsightly notch carelessly&nbsp;left by disk manufacturers.  The use of the tab creates an error&nbsp;message once in a while, but its aesthetic value far outweighs the&nbsp;momentary inconvenience.<br>&nbsp;-- Robb Russon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anoint, v.:<br>To grease a king or other great functionary already&nbsp;sufficiently slippery.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The cow is nothing but a machine with makes grass fit for us people to&nbsp;eat.<br>&nbsp;-- John McNulty')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I may appear to be just sitting here like a bucket of tapioca, but&nbsp;don''t let appearances fool you.  I''m approaching old age ... at the&nbsp;speed of light."<br>&nbsp;-- Prof. Cosmo Fishhawk')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Naeser''s Law:<br>You can make it foolproof, but you can''t make it&nbsp;damnfoolproof.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Prof:    So the American government went to IBM to come up with a data<br> encryption standard and they came up with ...<br>Student: EBCDIC!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Why is it that we rejoice at a birth and grieve at a funeral?  It is&nbsp;because we are not the person involved"<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Day of inquiry.  You will be subpoenaed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The way to make a small fortune in the commodities market is to start&nbsp;with a large fortune."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yea, though I walk through the valley of the shadow of APL, I shall&nbsp;fear no evil, for I can string six primitive monadic and dyadic&nbsp;operators together.<br>&nbsp;-- Steve Higgins')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Recession is when your neighbor loses his job.  Depression is when you&nbsp;lose your job.  These economic downturns are very difficult to predict,<br>but sophisticated econometric modeling houses like Data Resources and&nbsp;Chase Econometrics have successfully predicted 14 of the last 3&nbsp;recessions.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Absence makes the heart go wander.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'San Francisco isn''t what it used to be, and it never was.<br>&nbsp;-- Herb Caen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'OMNIVERSAL AWARENESS??  Oh, YEH!!  First you need four GALLONS of&nbsp;JELL-O and a BIG WRENCH!! ... I think you drop th'' WRENCH in the JELL-O&nbsp;as if it was a FLAVOR, or an INGREDIENT ... or ... I ... um ...<br>WHERE''S the WASHING MACHINES?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is against the grain of modern education to teach children to&nbsp;program.  What fun is there in making plans, acquiring discipline in&nbsp;organizing thoughts, devoting attention to detail, and learning to be&nbsp;self-critical?<br>&nbsp;-- Alan Perlis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I am more bored than you could ever possibly be.  Go back to work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'SCORPIO (Oct 23 - Nov 21)<br>You are shrewd in business and cannot be trusted.  You will<br>achieve the pinnacle of success because of your total lack of<br>ethics.  Most Scorpio people are murdered.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have you ever noticed that the people who are always trying to tell&nbsp;you, "There''s a time for work and a time for play," never find the time&nbsp;for play?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Let us live!!!&nbsp;Let us love!!!&nbsp;Let us share the deepest secrets of our souls!!!&nbsp;&nbsp;You first.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Time is nature''s way of making sure that everything doesn''t happen at&nbsp;once.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Weiner''s Law of Libraries:<br>There are no answers, only cross references.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Major Premise: Sixty men can do a piece of work sixty times as quickly<br>as one man.<br>&nbsp;Minor Premise: One man can dig a posthole in sixty seconds.<br>&nbsp;Conclusion: Sixty men can dig a posthole in one second.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Noncombatant, n.:<br>A dead Quaker.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no time like the pleasant.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No matter how subtle the wizard, a knife in the shoulder blades will&nbsp;seriously cramp his style.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whistler''s Law:<br>You never know who is right, but you always know who is in&nbsp;charge.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sodd''s Second Law:<br>Sooner or later, the worst possible set of circumstances is&nbsp;bound to occur.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cabbage, n.:<br>A familiar kitchen-garden vegetable about as large and wise as&nbsp;a man''s head.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing astonishes men so much as common sense and plain dealing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'According to the obituary notices, a mean and unimportant person never&nbsp;dies.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A language that doesn''t affect the way you think about programming is&nbsp;not worth knowing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You have an unusual magnetic personality.  Don''t walk too close to&nbsp;metal objects which are not fastened down.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I see a good deal of talk from Washington about lowering taxes.  I hope&nbsp;they do get ''em lowered enough so people can afford to pay ''em.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A candidate is a person who gets money from the rich and votes from the&nbsp;poor to protect them from each other.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'While your friend holds you affectionately by both your hands you are&nbsp;safe, for you can watch both of his.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Actors will happen even in the best-regulated families.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God didn''t mean for us to juggle, tennis balls wouldn''t come three&nbsp;to a can.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'LEO (July 23 - Aug 22)<br>Your determination and sense of humor will come to the fore.<br>Your ability to laugh at adversity will be a blessing because<br>you''ve got a day coming you wouldn''t believe.  As a matter of<br>fact, if you can laugh at what happens to you today, you''ve got<br>a sick sense of humor.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve touch''d the highest point of all my greatness:<br>And from that full meridian of my glory&nbsp;I haste now to my setting.  I shall fall,<br>Like a bright exhalation in the evening&nbsp;And no man see me more.<br>&nbsp;-- Shakespeare')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t believe everything you hear or anything you say.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I heated my home with oil, I used an average of 800 gallons a&nbsp;year.  I have found that I can keep comfortably warm for an entire&nbsp;winter with slightly over half that quantity of beer.<br>&nbsp;-- Dave Barry, "Postpetroleum Guzzler"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mophobia, n.:<br>Fear of being verbally abused by a Mississippian.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bringing computers into the home won''t change either one, but may&nbsp;revitalize the corner saloon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rule of Feline Frustration:<br>When your cat has fallen asleep on your lap and looks utterly&nbsp;content and adorable, you will suddenly have to go to the bathroom.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We may not return the affection of those who like us, but we always&nbsp;respect their good judgement.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The bogosity meter just pegged.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Absurdity, n.:<br>A statement or belief manifestly inconsistent with one''s own&nbsp;opinion.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mother is far too clever to understand anything she does not like.<br>&nbsp;-- Arnold Bennett')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you make your mark in the world, watch out for guys with erasers.<br>&nbsp;-- The Wall Street Journal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Gee, Toto, I don''t think we are in Kansas anymore."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We are all worms.  But I do believe I am a glowworm.<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I have learned&nbsp;To spell hors d''oeuvres&nbsp;Which still grates on &nbsp;Some people''s n''oeuvres.<br>&nbsp;-- Warren Knox')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good leaders being scarce, following yourself is allowed.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are three possible parts to a date, of which at least two must be&nbsp;offered: entertainment, food, and affection.  It is customary to begin&nbsp;a series of dates with a great deal of entertainment, a moderate amount&nbsp;of food, and the merest suggestion of affection.  As the amount of&nbsp;affection increases, the entertainment can be reduced proportionately.<br>When the affection IS the entertainment, we no longer call it dating.<br>Under no circumstances can the food be omitted.<br>&nbsp;-- Miss Manners'' Guide to Excruciatingly Correct Behavior')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Spend extra time on hobby.  Get plenty of rolling papers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"In order to make an apple pie from scratch, you must first create the&nbsp;universe."<br>&nbsp;-- Carl Sagan, Cosmos')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Idiot, n.:<br>A member of a large and powerful tribe whose influence in human&nbsp;affairs has always been dominant and controlling.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'During the next two hours, the system will be going up and down several&nbsp;times, often with lin~po_~{po       ~poz~ppo\~{ o n~po_~{o[po&nbsp; ~y oodsou>#w4k**n~po_~{ol;lkld;f;g;dd;po\~{o')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Now I lay me down to sleep&nbsp;I pray the double lock will keep:<br>May no brick through the window break,<br>And, no one rob me till I awake.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have made this letter longer than usual because I lack the time to&nbsp;make it shorter."<br>&nbsp;-- Blaise Pascal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"But this has taken us far afield from interface, which is not a bad&nbsp;place to be, since I particularly want to move ahead to the kludge.<br>Why do people have so much trouble understanding the kludge?  What is a&nbsp;kludge, after all, but not enough Ks, not enough ROMs, not enough RAMs,<br>poor quality interface and too few bytes to go around?  Have I&nbsp;explained yet about the bytes?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Somewhere, just out of sight, the unicorns are gathering.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life is like a buffet; it''s not good but there''s plenty of it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All men are mortal.  Socrates was mortal.  Therefore, all men are&nbsp;Socrates.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing is faster than the speed of light ...<br>&nbsp;To prove this to yourself, try opening the refrigerator door before the&nbsp;light comes on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is difficult to produce a television documentary that is both&nbsp;incisive and probing when every twelve minutes one is interrupted by&nbsp;twelve dancing rabbits singing about toilet paper.<br>&nbsp;-- Rod Serling')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you don''t go to other men''s funerals they won''t go to yours.<br>&nbsp;-- Clarence Day')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Schapiro''s Explanation:<br>The grass is always greener on the other side -- but that''s&nbsp;because they use more manure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Who made the world I cannot tell:<br>''Tis made, and here am I in hell.<br>My hand, though now my knuckles bleed,<br>I never soiled with such a deed.<br>&nbsp;-- A. E. Housman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... A booming voice says, "Wrong, cretin!", and you notice that you&nbsp;have turned into a pile of dust.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real computer scientists despise the idea of actual hardware.  Hardware&nbsp;has limitations, software doesn''t.  It''s a real shame that Turing&nbsp;machines are so poor at I/O.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never let your schooling interfere with your education.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '[Sir Stafford Cripps] has all the virtues I dislike and none of the&nbsp;vices I admire.<br>&nbsp;-- Winston Churchill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"No, `Eureka'' is Greek for `This bath is too hot.''"<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'CAPRICORN (Dec 23 - Jan 19)<br>You are conservative and afraid of taking risks.  You don''t do&nbsp;much of anything and are lazy.  There has never been a Capricorn of any&nbsp;importance.  Capricorns should avoid standing still for too long as&nbsp;they take root and become trees.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"An anthropologist at Tulane has just come back from a field trip to&nbsp;New Guinea with reports of a tribe so primitive that they have Tide but&nbsp;not new Tide with lemon-fresh Borax."<br>&nbsp;-- David Letterman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Try not to have a good time ... This is supposed to be educational.<br>&nbsp;-- Charles Schulz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never call a man a fool; borrow from him.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I stopped believing in Santa Claus when I was six.  Mother took me to&nbsp;see him in a department store and he asked for my autograph."<br>&nbsp;-- Shirley Temple')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;No violence, gentlemen -- no violence, I beg of you! Consider&nbsp;the furniture!<br>&nbsp;-- Sherlock Holmes')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Seleznick''s Theory of Holistic Medicine:<br>Ice Cream cures all ills.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rules for Academic Deans:<br>(1)  HIDE!!!!<br>(2)  If they find you, LIE!!!!<br>&nbsp;-- Father Damian C. Fandal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good day to let down old friends who need help.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t change the reason, just change the excuses!<br>&nbsp;-- Joe Cointment')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Forms follow function, and often obliterate it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God doesn''t play dice.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh, I don''t blame Congress.  If I had $600 billion at my disposal, I''d&nbsp;be irresponsible, too.<br>&nbsp;-- Lichty & Wagner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A bird in the hand makes it awfully hard to blow your nose.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There was a young poet named Dan,<br>Whose poetry never would scan.<br>When told this was so,<br>He said, "Yes, I know.<br>It''s because I try to put every possible syllable into that last line that I can."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ask Not for whom the Bell Tolls, and You will Pay only the&nbsp;Station-to-Station rate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ladybug, ladybug,<br>Look to your stern!&nbsp;Your house is on fire,<br>Your children will burn!&nbsp;So jump ye and sing, for&nbsp;The very first time&nbsp;The four lines above&nbsp;Have been put into rhyme.<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How can you be in two places at once when you''re not anywhere at all?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The greatest dangers to liberty lurk in insidious encroachment by men&nbsp;of zeal, well-meaning but without understanding.<br>&nbsp;-- Justice Louis D. Brandeis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;      THE STORY OF CREATION<br>&nbsp;&nbsp;       or<br>&nbsp;&nbsp; THE MYTH OF URK&nbsp;&nbsp;In the beginning there was data.  The data was without form and null,<br>and darkness was upon the face of the console; and the Spirit of IBM&nbsp;was moving over the face of the market.  And DEC said, "Let there be&nbsp;registers"; and there were registers.  And DEC saw that they carried:<br>and DEC separated the data from the instructions.  DEC called the data&nbsp;Stack, and the instructions they called Code.  And there was evening&nbsp;and there was morning, one interrupt ...<br>&nbsp;-- Rico Tudor')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'ROMEO: Courage, man; the hurt cannot be much.<br>MERCUTIO: No, ''tis not so deep as a well, nor so wide as a church-<br>door; but ''tis enough, ''twill serve.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The average woman would rather have beauty than brains, because the&nbsp;average man can see better than he can think.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Not far from here, by a white sun, behind a green star, lived the&nbsp;Steelypips, illustrious, industrious, and they hadn''t a care: no spats&nbsp;in their vats, no rules, no schools, no gloom, no evil influence of the&nbsp;moon, no trouble from matter or antimatter -- for they had a machine, a&nbsp;dream of a machine, with springs and gears and perfect in every&nbsp;respect.  And they lived with it, and on it, and under it, and inside&nbsp;it, for it was all they had -- first they saved up all their atoms,<br>then they put them all together, and if one didn''t fit, why they&nbsp;chipped at it a bit, and everything was just fine ...<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Facts are stubborn, but statistics are more pliable.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Yeah, but you''re taking the universe out of context."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Professor Gorden Newell threw another shutout in last week''s Chem.<br>Eng.  130 midterm.  Once again no student received a single point on&nbsp;his exam.  Newell has now tossed five shutouts this quarter.  Newell''s&nbsp;earned exam average has now dropped to a phenomenal 30%')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A jury consists of 12 persons chosen to decide&nbsp;who has the better lawyer.<br>&nbsp;-- Robert Frost')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A celebrity is a person who is known for his well-knownness.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Too much of everything is just enough.<br>&nbsp;-- Bob Wier')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s a fine line between courage and foolishness.  Too bad it''s not&nbsp;a fence.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I can read your mind, and you should be ashamed of yourself.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The First Rule of Program Optimization:<br>Don''t do it.<br>&nbsp;The Second Rule of Program Optimization (for experts only!):<br>Don''t do it yet.<br>&nbsp;-- Michael Jackson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can always tell the Christmas season is here when you start getting&nbsp;incredibly dense, tinfoil-and-ribbon- wrapped lumps in the mail.<br>Fruitcakes make ideal gifts because the Postal Service has been unable&nbsp;to find a way to damage them.  They last forever, largely because&nbsp;nobody ever eats them.  In fact, many smart people save the fruitcakes&nbsp;they receive and send them back to the original givers the next year:<br>some fruitcakes have been passed back and forth for hundreds of years.<br>&nbsp;The easiest way to make a fruitcake is to buy a darkish cake, then&nbsp;pound some old, hard fruit into it with a mallet.  Be sure to wear&nbsp;safety glasses.<br>&nbsp;-- Dave Barry, "Simple, Homespun Gifts"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Patageometry, n.:<br>The study of those mathematical properties that are invariant&nbsp;under brain transplants.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Organic chemistry is the chemistry of carbon compounds.  Biochemistry&nbsp;is the study of carbon compounds that crawl.<br>&nbsp;-- Mike Adams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Corrupt, adj.:<br>In politics, holding an office of trust or profit.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maternity pay?&nbsp;Now every Tom, Dick and Harry will get pregnant.<br>&nbsp;-- Malcolm Smith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The seven deadly sins ... Food, clothing, firing, rent, taxes,<br>respectability and children.  Nothing can lift those seven milestones&nbsp;from man''s neck but money; and the spirit cannot soar until the&nbsp;milestones are lifted.<br>&nbsp;-- George Bernard Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eggnog is a traditional holiday drink invented by the English.  Many&nbsp;people wonder where the word "eggnog" comes from.  The first syllable&nbsp;comes from the English word "egg", meaning "egg".  I don''t know where&nbsp;the "nog" comes from.<br>&nbsp;To make eggnog, you''ll need rum, whiskey, wine gin and, if they are in&nbsp;season, eggs...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The meek shall inherit the earth -- they are too weak to refuse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Home of Doberman Propulsion Laboratories:<br>The ultimate in watchdog weaponry.<br>&nbsp;-- Chris Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Frisbeetarianism, n.:<br>The belief that when you die, your soul goes up the on roof and&nbsp;gets stuck.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The only possible interpretation of any research whatever in the&nbsp;`social sciences'' is: some do, some don''t.<br>&nbsp;-- Ernest Rutherford')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The intelligence of any discussion diminishes with the square of the&nbsp;number of participants.<br>&nbsp;-- Adam Walinsky')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Help!  I''m trapped in a PDP 11/70!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All I ask is a chance to prove that money can''t make me happy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The rain it raineth on the just<br>And also on the unjust fella,<br>But chiefly on the just, because<br>The unjust steals the just''s umbrella.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Accidents cause History.<br>&nbsp;If Sigismund Unbuckle had taken a walk in 1426 and met Wat Tyler, the&nbsp;Peasant''s Revolt would never have happened and the motor car would not&nbsp;have been invented until 2026, which would have meant that all the oil&nbsp;could have been used for lamps, thus saving the electric light bulb and&nbsp;the whale, and nobody would have caught Moby Dick or Billy Budd.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life would be much simpler and things would get done much faster if it&nbsp;weren''t for other people"<br>&nbsp;-- Blore')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Limericks are art forms complex,<br>Their topics run chiefly to sex.<br>They usually have virgins,<br>And masculine urgin''s,<br>And other erotic effects.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There was a young lady from Hyde&nbsp;Who ate a green apple and died.<br>While her lover lamented<br>The apple fermented&nbsp;And made cider inside her inside.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Of ______^H^H^H^H^H^Hcourse it''s the murder weapon.  Who would frame someone with a&nbsp;fake?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no satisfaction in hanging a man who does not object to it<br>&nbsp;-- G. B. Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never make anything simple and efficient when a way can be found to&nbsp;make it complex and wonderful.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Scott''s second Law:<br>When an error has been detected and corrected, it will be found&nbsp;to have been wrong in the first place.<br>&nbsp;Corollary:<br>After the correction has been found in error, it will be&nbsp;impossible to fit the original quantity back into the equation.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If the weather is extremely bad, church attendance will be down.  If&nbsp;the weather is extremely good, church attendance will be down.  If the&nbsp;bulletin covers are in short supply, however, church attendance will&nbsp;exceed all expectations.<br>&nbsp;-- Reverend Chichester')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stay away from flying saucers today.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have you noticed the way people''s intelligence capabilities decline&nbsp;sharply the minute they start waving guns around?<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicken Little was right.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Don''t come back until you have him", the Tick-Tock Man said quietly,<br>sincerely, extremely dangerously.<br>&nbsp;They used dogs.  They used probes.  They used cardio plate crossoffs.<br>They used teepers.  They used bribery.  They used stick tites.  They&nbsp;used intimidation.  They used torment.  They used torture.  They used&nbsp;finks.  They used cops.  They used search and seizure.  They used&nbsp;fallaron.  They used betterment incentives.  They used finger prints.<br>They used the bertillion system.  They used cunning.  They used guile.<br>They used treachery.  They used Raoul-Mitgong but he wasn''t much help.<br>They used applied physics.  They used techniques of criminology.  And&nbsp;what the hell, they caught him.<br><br>&nbsp;-- Harlan Ellison, "Repent, Harlequin, said the<br>&nbsp;   Tick-Tock Man"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'According to Arkansas law, Section 4761, Pope''s Digest:  "No person&nbsp;shall be permitted under any pretext whatever, to come nearer than&nbsp;fifty feet of any door or window of any polling room, from the opening&nbsp;of the polls until the completion of the count and the certification of&nbsp;the returns."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Avoid reality at all costs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'COBOL programs are an exercise in Artificial Inelegance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Remember, UNIX spelled backwards is XINU.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every improvement in communication makes the bore more terrible.<br>&nbsp;-- Frank Moore Colby')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We have only two things to worry about:  That things will never get&nbsp;back to normal, and that they already have.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reisner''s Rule of Conceptual Inertia:<br>If you think big enough, you''ll never have to do it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real programmers don''t bring brown-bag lunches.  If the vending machine&nbsp;doesn''t sell it, they don''t eat it.  Vending machines don''t sell&nbsp;quiche.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I see the eigenvalue in thine eye,<br>I hear the tender tensor in thy sigh.<br>Bernoulli would have been content to die&nbsp;Had he but known such _^Ha-squared cos 2(phi)!<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The individual choice of garnishment of a burger can be an important&nbsp;point to the consumer in this day when individualism is an increasingly&nbsp;important thing to people.<br>&nbsp;-- Donald N. Smith, president of Burger King')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oregon, n.:<br>Eighty billion gallons of water with no place to go on Saturday&nbsp;night.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you think nobody cares if you''re alive, try missing a couple of car&nbsp;payments.<br>&nbsp;-- Earl Wilson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A famous Lisp Hacker noticed an Undergraduate sitting in front of a&nbsp;Xerox 1108, trying to edit a complex Klone network via a browser.<br>Wanting to help, the Hacker clicked one of the nodes in the network&nbsp;with the mouse, and asked "what do you see?"  Very earnestly, the&nbsp;Undergraduate replied "I see a cursor."  The Hacker then quickly&nbsp;pressed the boot toggle at the back of the keyboard, while&nbsp;simultaneously hitting the Undergraduate over the head with a thick&nbsp;Interlisp Manual.  The Undergraduate was then Enlightened.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conscious is when you are aware of something and conscience is when you&nbsp;wish you weren''t.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Happiness isn''t something you experience; it''s something you remember.<br>&nbsp;-- Oscar Levant')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God rest ye CS students now,<br>Let nothing you dismay.<br>The VAX is down and won''t be up,<br>Until the first of May.<br>The program that was due this morn,<br>Won''t be postponed, they say.<br><br>Oh, tidings of comfort and joy,<br>Comfort and joy,<br>Oh, tidings of comfort and joy.<br>&nbsp;The bearings on the drum are gone,<br>The disk is wobbling, too.<br>We''ve found a bug in Lisp, and Algol&nbsp;Can''t tell false from true.<br>And now we find that we can''t get&nbsp;At Berkeley''s 4.2.<br><br>(chorus)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you live in a country run by committee, be on the committee.<br>&nbsp;-- Graham Summer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mencken and Nathan''s Sixteenth Law of The Average American:<br>Milking a cow is an operation demanding a special talent that&nbsp;is possessed only by yokels, and no person born in a large city can&nbsp;never hope to acquire it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ll grant thee random access to my heart,<br>Thoul''t tell me all the constants of thy love:<br>And so we two shall all love''s lemmas prove&nbsp;And in our bound partition never part.<br>&nbsp;-- Stanislaw Lem, "Cyberiad"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I have seen farther than others, it is because I was standing on the&nbsp;shoulders of giants.<br>&nbsp;-- Isaac Newton&nbsp;&nbsp;In the sciences, we are now uniquely privileged to sit side by side&nbsp;with the giants on whose shoulders we stand.<br>&nbsp;-- Gerald Holton&nbsp;&nbsp;If I have not seen as far as others, it is because giants were standing&nbsp;on my shoulders.<br>&nbsp;-- Hal Abelson&nbsp;&nbsp;In computer science, we stand on each other''s feet.<br>&nbsp;-- Brian K. Reid')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Experience is what causes a person to make new mistakes instead of old&nbsp;ones.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Documentation is the castor oil of programming.  Managers know it must&nbsp;be good because the programmers hate it so much.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I was playing poker the other night ... with Tarot cards. I got a full&nbsp;house and four people died."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It may be that your whole purpose in life is simply to serve as a&nbsp;warning to others.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Give your child mental blocks for Christmas.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Excessive login or logout messages are a sure sign of senility.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anarchy may not be the best form of government, but it''s better than no&nbsp;government at all.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Children seldom misquote you.  In fact, they usually repeat word for&nbsp;word what you shouldn''t have said.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you want to understand your government, don''t begin by reading the&nbsp;Constitution.  It conveys precious little of the flavor of today''s&nbsp;statecraft.  Instead, read selected portions of the Washington&nbsp;telephone directory containing listings for all the organizations with&nbsp;titles beginning with the word "National".<br>&nbsp;-- George Will')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The first Great Steward, Parrafin the Climber, was employed in King&nbsp;Chloroplast''s kitchen as second scullery boy when the old King met a&nbsp;tragic death.  He apparently fell backward by accident on a dozen salad&nbsp;forks.  Simultaneously the true heir, his son Carotene, mysteriously&nbsp;fled the city, complaining of some sort of plot and a lot of&nbsp;threatening notes left on his breakfast tray.  At the time, this looked&nbsp;suspicious what with his father''s death, and Carotene was suspected of&nbsp;foul play.  Then the rest of the King''s relatives began to drop dead&nbsp;one after the other in an odd fashion.  Some were found strangled with&nbsp;dishrags and some succumbed to food poisoning.  A few were found&nbsp;drowned in the soup vats, and one was attacked by assailants unknown&nbsp;and beaten to death with a pot roast.  At least three appear to have&nbsp;thrown themselves backward on salad forks, perhaps in a noble gesture&nbsp;of grief over the King''s untimely end.  Finally there was no one left&nbsp;in Minas Troney who was either eligible or willing to wear the accursed&nbsp;crown, and the rule of Twodor was up for grabs.  The scullery slave&nbsp;Parrafin bravely accepted the Stewardship of Twodor until that day when&nbsp;a lineal descendant of Carotene''s returns to reclaim his rightful&nbsp;throne, conquer Twodor''s enemies, and revamp the postal system.<br>&nbsp;-- Harvard Lampoon, "Bored of the Rings"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you can survive death, you can probably survive anything.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Experience is that marvelous thing that enables you recognize a mistake&nbsp;when you make it again.<br>&nbsp;-- F. P. Jones')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'These days the necessities of life cost you about three times what they&nbsp;used to, and half the time they aren''t even fit to drink.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Numeric stability is probably not all that important when you''re&nbsp;guessing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We cannot put the face of a person on a stamp unless said person is&nbsp;deceased.  My suggestion, therefore, is that you drop dead.<br>&nbsp;-- James E. Day, Postmaster General')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'On account of being a democracy and run by the people, we are the only&nbsp;nation in the world that has to keep a government four years, no matter&nbsp;what it does.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If it''s Tuesday, this must be someone else''s fortune.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To the systems programmer, users and applications serve only to provide&nbsp;a test load.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Office Automation, n.:<br>The use of computers to improve efficiency by removing anyone&nbsp;you would want to talk with over coffee.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your lucky number is 3552664958674928.  Watch for it everywhere.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cold, adj.:<br>When the local flashers are handing out written descriptions.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The first myth of management is that it exists.  The second myth of&nbsp;management is that success equals skill.<br>&nbsp;-- Robert Heller')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It happened that a fire broke out backstage in a theater.  The clown&nbsp;came out to inform the public.  They thought it was just a jest and&nbsp;applauded.  He repeated his warning, they shouted even louder.  So I&nbsp;think the world will come to an end amid general applause from all the&nbsp;wits, who believe that it is a joke.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every gun that is made, every warship launched, every rocket fired&nbsp;signifies in the final sense, a theft from those who hunger and are not&nbsp;fed, those who are cold and are not clothed.  This world in arms is not&nbsp;spending money alone.  It is spending the sweat of its laborers, the&nbsp;genius of its scientists, the hopes of its children.  This is not a way&nbsp;of life at all in any true sense.  Under the clouds of war, it is&nbsp;humanity hanging on a cross of iron.<br>&nbsp;-- Dwight Eisenhower, April 16, 1953')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Life is like a simile.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The bad reputation UNIX has gotten is totally undeserved, laid on by&nbsp;people who don''t understand, who have not gotten in there and tried&nbsp;anything."<br>&nbsp;-- Jim Joyce, owner of Jim Joyce''s UNIX Bookstore')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I didn''t like the play, but I saw it under adverse conditions.  The&nbsp;curtain was up.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everything you''ve learned in school as "obvious" becomes less and less&nbsp;obvious as you begin to study the universe.  For example, there are no&nbsp;solids in the universe.  There''s not even a suggestion of a solid.<br>There are no absolute continuums.  There are no surfaces.  There are no&nbsp;straight lines.<br>&nbsp;-- R. Buckminster Fuller')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"As an adolescent I aspired to lasting fame, I craved factual&nbsp;certainty, and I thirsted for a meaningful vision of human life -- so I&nbsp;became a scientist.  This is like becoming an archbishop so you can&nbsp;meet girls."<br>&nbsp;-- Matt Cartmill')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The problem with the gene pool is that there is no lifeguard.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brontosaurus Principle:<br>Organizations can grow faster than their brains can manage them&nbsp;in relation to their environment and to their own physiology:  when&nbsp;this occurs, they are an endangered species.<br>&nbsp;-- Thomas K. Connellan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Majority, n.:<br>That quality that distinguishes a crime from a law.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Every time I think I know where it''s at, they move it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Nice boy, but about as sharp as a sack of wet mice."<br>&nbsp;-- Foghorn Leghorn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If dolphins are so smart, why did Flipper work for television?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but it''s my parakeet''s bowling night."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;So Richard and I decided to try to catch [the small shark].<br>With a great deal of strategy and effort and shouting, we managed to&nbsp;maneuver the shark, over the course of about a half-hour, to a sort of&nbsp;corner of the lagoon, so that it had no way to escape other than to&nbsp;flop up onto the land and evolve.  Richard and I were inching toward&nbsp;it, sort of crouched over, when all of a sudden it turned around and --&nbsp;I can still remember the sensation I felt at that moment, primarily in&nbsp;the armpit area -- headed right straight toward us.<br>Many people would have panicked at this point.  But Richard and&nbsp;I were not "many people."  We were experienced waders, and we kept our&nbsp;heads.  We did exactly what the textbook says you should do when you''re&nbsp;unarmed and a shark that is nearly two feet long turns on you in water&nbsp;up to your lower calves: We sprinted I would say 600 yards in the&nbsp;opposite direction, using a sprinting style such that the bottoms of&nbsp;our feet never once went below the surface of the water.  We ran all&nbsp;the way to the far shore, and if we had been in a Warner Brothers&nbsp;cartoon we would have run right INTO the beach, and you would have seen&nbsp;these two mounds of sand racing across the island until they bonked&nbsp;into trees and coconuts fell onto their heads.<br>&nbsp;-- Dave Barry, "The Wonders of Sharks on TV"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'AAAAAAAAAaaaaaaaaaaaaaaaccccccccckkkkkk!!!!!!!!!&nbsp;You brute!  Knock before entering a ladies room!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''re being followed.  Cut out the hanky-panky for a few days.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I used to get high on life but lately I''ve built up a resistance."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Equal bytes for women.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s easier to get forgiveness for being wrong than forgiveness for&nbsp;being right.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '  n = ((n >>  1) & 0x55555555) | ((n <<  1) & 0xaaaaaaaa):<br>   n = ((n >>  2) & 0x33333333) | ((n <<  2) & 0xcccccccc):<br>   n = ((n >>  4) & 0x0f0f0f0f) | ((n <<  4) & 0xf0f0f0f0):<br>   n = ((n >>  8) & 0x00ff00ff) | ((n <<  8) & 0xff00ff00):<br>   n = ((n >> 16) & 0x0000ffff) | ((n << 16) & 0xffff0000):<br><br>&nbsp;-- C code which reverses the bits in a word.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you give Congress a chance to vote on both sides of an issue, it&nbsp;will always do it.<br>&nbsp;-- Les Aspin, D., Wisconsin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good day for overcoming obstacles.  Try a steeplechase.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Toilet Toup''^Hee, n.:<br>Any shag carpet that causes the lid to become top-heavy, thus&nbsp;creating endless annoyance to male users.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Plumbing is one of the easier of do-it-yourself activities,<br>requiring only a few simple tools and a willingness to stick your arm&nbsp;into a clogged toilet.  In fact, you can solve many home plumbing&nbsp;problems, such as annoying faucet drip, merely by turning up the&nbsp;radio.  But before we get into specific techniques, let''s look at how&nbsp;plumbing works.<br>A plumbing system is very much like your electrical system,<br>except that instead of electricity, it has water, and instead of wires,<br>it has pipes, and instead of radios and waffle irons, it has faucets&nbsp;and toilets.  So the truth is that your plumbing systems is nothing at&nbsp;all like your electrical system, which is good, because electricity can&nbsp;kill you.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Heuristics are bug ridden by definition.  If they didn''t have bugs,<br>then they''d be algorithms.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is no time like the present for postponing what you ought to be&nbsp;doing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speaking of love, one problem that recurs more and more frequently&nbsp;these days, in books and plays and movies, is the inability of people&nbsp;to communicate with the people they love; Husbands and wives who can''t&nbsp;communicate, children who can''t communicate with their parents, and so&nbsp;on.  And the characters in these books and plays and so on (and in real&nbsp;life, I might add) spend hours bemoaning the fact that they can''t&nbsp;communicate.  I feel that if a person can''t communicate, the very _____^H^H^H^H^Hleast&nbsp;he can do is to Shut Up!<br>&nbsp;-- Tom Lehrer, "That Was the Year that Was"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Devon, Connecticut, it is unlawful to walk backwards after sunset.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real computer scientists don''t program in assembler.  They don''t write&nbsp;in anything less portable than a number two pencil.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The four building blocks of the universe are fire, water, gravel and&nbsp;vinyl."<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'OK, so you''re a Ph.D.  Just don''t touch anything.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fine day to work off excess energy.  Steal something heavy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A long memory is the most subversive idea in America.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The best thing for being sad," replied Merlin, beginning to puff and&nbsp;blow, "is to learn something.  That''s the only thing that never fails.<br>You may grow old and trembling in your anatomies, you may lie awake at&nbsp;night listening to the disorder of your veins, you may miss your only&nbsp;love, you may see the world about you devastated by evil lunatics, or&nbsp;know your honour trampled in the sewers of baser minds.  There is only&nbsp;one thing for it then -- to learn.  Learn why the world wags and what&nbsp;wags it.  That is the only thing which the mind can never exhaust,<br>never alienate, never be tortured by, never fear or distrust, and never&nbsp;dream of regretting.  Learning is the only thing for you.  Look what a&nbsp;lot of things there are to learn."<br>&nbsp;-- T.H. White, "The Once and Future King"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cogito cogito ergo cogito sum --&nbsp;"I think that I think, therefore I think that I am."<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is the business of little minds to shrink.<br>&nbsp;-- Carl Sandburg')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The pyramid is opening!"&nbsp;"Which one?"&nbsp;"The one with the ever-widening hole in it!"<br>&nbsp;-- Firesign Theater, "How Can You Be In Two Places At<br>&nbsp;   Once When You''re Not Anywhere At All"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any small object that is accidentally dropped will hide under a larger&nbsp;object.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You or I must yield up his life to Ahrimanes.  I would rather it were&nbsp;you.  I should have no hesitation in sacrificing my own life to spare&nbsp;yours, but we take stock next week, and it would not be fair on the&nbsp;company.<br>&nbsp;-- J. Wellington Wells')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I do not know myself, and God forbid that I should."<br>&nbsp;-- Johann Wolfgang von Goethe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He flung himself on his horse and rode madly off in all directions"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The only thing we learn from history is that we learn nothing from&nbsp;history."<br>&nbsp;-- Hegel&nbsp;&nbsp;"I know guys can''t learn from yesterday ... Hegel must be taking the&nbsp;long view."<br>&nbsp;-- John Brunner, "Stand on Zanzibar"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Three great scientific theories of the structure of the universe are&nbsp;the molecular, the corpuscular and the atomic.  A fourth affirms, with&nbsp;Haeckel, the condensation or precipitation of matter from ether --&nbsp;whose existence is proved by the condensation or precipitation ... A&nbsp;fifth theory is held by idiots, but it is doubtful if they know any&nbsp;more about the matter than the others.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Duct tape is like the force.  It has a light side, and a dark side, and&nbsp;it holds the universe together ...<br>&nbsp;-- Carl Zwanzig')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Philadelphia is not dull -- it just seems so because it is next to&nbsp;exciting Camden, New Jersey.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '186,282 miles per second:<br>&nbsp;It isn''t just a good idea, it''s the law!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"My pants just went on a wild rampage through a Long Island Bowling&nbsp;Alley!!"<br>&nbsp;-- Zippy the Pinhead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Take heart amid the deepening gloom that your dog is finally getting&nbsp;enough cheese<br>&nbsp;-- National Lampoon, "Deteriorata"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Benson, you are so free of the ravages of intelligence"<br>&nbsp;-- Time Bandits')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You first have to decide whether to use the short or the long form.<br>The short form is what the Internal Revenue Service calls "simplified",<br>which means it is designed for people who need the help of a Sears&nbsp;tax-preparation expert to distinguish between their first and last&nbsp;names.  Here''s the complete text:<br><br>"(1) How much did you make?  (AMOUNT)<br>"(2) How much did we here at the government take out?  (AMOUNT)<br>"(3) Hey!  Sounds like we took too much!  So we''re going to<br>     send an official government check for (ONE-FIFTEENTH OF<br>     THE AMOUNT WE TOOK) directly to the (YOUR LAST NAME)<br>     household at (YOUR ADDRESS), for you to spend in any way<br>     you please! Which just goes to show you, (YOUR FIRST<br>     NAME), that it pays to file the short form!"&nbsp;&nbsp;The IRS wants you to use this form because it gets to keep most of your&nbsp;money.  So unless you have pond silt for brains, you want the long&nbsp;form.<br>&nbsp;-- Dave Barry, "Sweating Out Taxes"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stop searching.  Happiness is right next to you.  Now, if they''d only&nbsp;take a bath ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Spare no expense to save money on this one."<br>&nbsp;-- Samuel Goldwyn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pick another fortune cookie.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You can''t teach people to be lazy - either they have it, or they&nbsp;don''t."<br>&nbsp;-- Dagwood Bumstead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s not just a computer -- it''s your ass."<br>&nbsp;-- Cal Keegan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Heavy, adj.:<br>Seduced by the chocolate side of the force.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I appreciate the fact that this draft was done in haste, but some of&nbsp;the sentences that you are sending out in the world to do your work for&nbsp;you are loitering in taverns or asleep beside the highway."<br>&nbsp;-- Dr. Dwight Van de Vate, Professor of Philosophy,<br>&nbsp;   University of Tennessee at Knoxville')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People will accept your ideas much more readily if you tell them that&nbsp;Benjamin Franklin said it first.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"To be responsive at this time, though I will simply say, and therefore&nbsp;this is a repeat of what I said previously, that which I am unable to&nbsp;offer in response is based on information available to make no such&nbsp;statement."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The herd instinct among economists makes sheep look like independent&nbsp;thinkers.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A penny saved is ridiculous.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I realize that the MX missile is none of our concern.  I realize that&nbsp;the whole point of living in a democracy is that we pay professional&nbsp;congresspersons to concern themselves with things like the MX missile&nbsp;so we can be free to concern ourselves with getting hold of the&nbsp;plumber.<br>&nbsp;But from time to time, I feel I must address major public issues such&nbsp;as this, because in a free and open society, where the very future of&nbsp;the world hinges on decisions made by our elected leaders, you never&nbsp;win large cash journalism awards if you stick to the topics I usually&nbsp;write about, such as nose-picking.<br>&nbsp;-- Dave Barry, "At Last, the Ultimate Deterrent Against<br>&nbsp;   Political Fallout"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The opposite of a profound truth may well be another profound truth.<br>&nbsp;-- Bohr')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I thought you were trying to get into shape."&nbsp;"I am. The shape I''ve selected is a triangle."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s no point in being grown up if you can''t be childish sometimes.<br>&nbsp;-- Dr. Who')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The turtle lives ''twixt plated decks&nbsp;Which practically conceal its sex.<br>I think it clever of the turtle&nbsp;In such a fix to be so fertile.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To be is to do.<br>&nbsp;-- I. Kant&nbsp;To do is to be.<br>&nbsp;-- A. Sartre&nbsp;Yabba-Dabba-Doo!<br>&nbsp;-- F. Flinstone')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In case of atomic attack, the federal ruling against prayer in schools&nbsp;will be temporarily canceled.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'PISCES (Feb. 19 - Mar. 20)<br>You have a vivid imagination and often think you are being&nbsp;followed by the CIA or FBI.  You have minor influence over your&nbsp;associates and people resent your flaunting of your power.  You lack&nbsp;confidence and you are generally a coward.  Pisces people do terrible&nbsp;things to small animals.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mencken and Nathan''s Second Law of The Average American:<br>All the postmasters in small towns read all the postcards.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finagle''s First Law:<br>If an experiment works, something has gone wrong.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Earth is a great, big funhouse without the fun."<br>&nbsp;-- Jeff Berner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The right half of the brain controls the left half of the body.  This&nbsp;means that only left handed people are in their right mind.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Isn''t it strange that the same people that laugh at gypsy fortune&nbsp;tellers take economists seriously?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you explain so clearly that nobody can misunderstand, somebody&nbsp;will.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Demographic polls show that you have lost credibility across the&nbsp;board.  Especially with  those 14 year-old Valley girls.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The President publicly apologized today to all those offended by his&nbsp;brother''s remark, "There''s more Arabs in this country than there is&nbsp;Jews!".  Those offended include Arabs, Jews, and English teachers.<br>&nbsp;-- Baltimore, Channel 11 News, on Jimmy Carter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Blessed are the young for they shall inherit the national debt.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For those who like this sort of thing, this is the sort of thing they&nbsp;like.<br>&nbsp;-- Abraham Lincoln')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"He was so narrow minded he could see through a keyhole with both&nbsp;eyes ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Receiving a million dollars tax free will make you feel better than&nbsp;being flat broke and having a stomach ache.<br>&nbsp;-- Dolph Sharp, "I''m O.K., You''re Not So Hot"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A real patriot is the fellow who gets a parking ticket and rejoices&nbsp;that the system works.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Slurm, n.:<br>The slime that accumulates on the underside of a soap bar when&nbsp;it sits in the dish too long.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The rights you have are the rights given you by this Committee [the&nbsp;House Un-American Activities Committee].  We will determine what rights&nbsp;you have and what rights you have not got."<br>&nbsp;-- J. Parnell Thomas')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The probability of someone watching you is proportional to the&nbsp;stupidity of your action.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'GEMINI (May 21 to Jun. 20)<br>Good news and bad news highlighted.  Enjoy the good news while&nbsp;you can; the bad news will make you forget it.  You will enjoy praise&nbsp;and respect from those around you; everybody loves a sucker.  A short&nbsp;trip is in the stars, possibly to the men''s room.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It has been observed that one''s nose is never so happy as when it is&nbsp;thrust into the affairs of another, from which some physiologists have&nbsp;drawn the inference that the nose is devoid of the sense of smell.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your life would be very empty if you had nothing to regret.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s illegal in Wilbur, Washington, to ride an ugly horse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Most people can''t understand how others can blow their noses differently&nbsp;than they do.<br>&nbsp;-- Turgenev')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Calvin Coolidge was the greatest man who ever came out of Plymouth&nbsp;Corner, Vermont."<br>&nbsp;-- Clarence Darrow')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Academic politics is the most vicious and bitter form of politics,<br>because the stakes are so low.<br>&nbsp;-- Wallace Sayre')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A general leading the State Department resembles  a dragon commanding&nbsp;ducks.<br>&nbsp;-- New York Times, Jan. 20, 1981')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'PISCES (Feb. 19 to Mar. 20)<br>Take the high road, look for the good things, carry the&nbsp;American Express card and a weapon.  The world is yours today, as&nbsp;nobody else wants it.  Your mortgage will be foreclosed.  You will&nbsp;probably get run over by a bus.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Positive, adj.:<br>Mistaken at the top of one''s voice.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Today''s thrilling story has been brought to you by Mushies, the great new&nbsp;cereal that gets soggy even without milk or cream.  Join us soon for more &nbsp;spectacular adventure starring ... Tippy, the Wonder Dog."<br>&nbsp;-- Bob & Ray')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Well, my terminal''s locked up, and I ain''t got any Mail,<br>And I can''t recall the last time that my program didn''t fail:<br>I''ve got stacks in my structs, I''ve got arrays in my queues,<br>I''ve got the : Segmentation violation -- Core dumped blues.<br>&nbsp;If you think that it''s nice that you get what you C,<br>Then go : illogical statement with your whole family,<br>''Cause the Supreme Court ain''t the only place with : Bus error views.<br>I''ve got the : Segmentation violation -- Core dumped blues.<br>&nbsp;On a PDP-11, life should be a breeze,<br>But with VAXen in the house even magnetic tapes would freeze.<br>Now you might think that unlike VAXen I''d know who I abuse,<br>I''ve got the : Segmentation violation -- Core dumped blues.<br>&nbsp;-- Core Dumped Blues')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t feed the bats tonight.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If I had a plantation in Georgia and a home in Hell, I''d sell the&nbsp;plantation and go home.<br>&nbsp;-- Eugene P. Gallagher')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Law of the Perversity of Nature:<br>You cannot successfully determine beforehand which side of the&nbsp;bread to butter.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The more things change, the more they stay insane.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you''ve done six impossible things before breakfast, why not round&nbsp;it off with dinner at Milliway''s, the restaurant at the end of the&nbsp;universe?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m going to Boston to see my doctor.  He''s a very sick man.<br>&nbsp;-- Fred Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nothing cures insomnia like the realization that it''s time to get up.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I do not fear computers.  I fear the lack of them."<br>&nbsp;-- Isaac Asimov')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is the tangential point between zero and infinity.<br>&nbsp;-- Alfred Jarry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '43rd Law of Computing:<br>Anything that can go wr&nbsp;fortune: Segmentation violation -- Core dumped')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lie, n.:<br>A very poor substitute for the truth, but the only one&nbsp;discovered to date.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If mathematically you end up with the wrong answer, try multiplying by&nbsp;the page number.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love thy neighbor as thyself, but choose your neighborhood.<br>&nbsp;-- Louise Beal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who can, do.  Those who can''t, simulate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Picture the sun as the origin of two intersecting 6-dimensional&nbsp;hyperplanes from which we can deduce a certain transformational&nbsp;sequence which gives us the terminal velocity of a rubber duck ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Reclaimer, spare that tree!&nbsp;Take not a single bit!&nbsp;It used to point to me,<br>Now I''m protecting it.<br>It was the reader''s CONS&nbsp;That made it, paired by dot:<br>Now, GC, for the nonce,<br>Thou shalt reclaim it not.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Newton''s Little-Known Seventh Law:<br>A bird in the hand is safer than one overhead.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We are upping our standards ... so up yours."<br>&nbsp;-- Pat Paulsen for President, 1988.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I just forgot my whole philosophy of life!!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The first time, it''s a KLUDGE!&nbsp;The second, a trick.<br>Later, it''s a well-established technique!<br>&nbsp;-- Mike Broido, Intermetrics')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Universe, n.:<br>The problem.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If once a man indulges himself in murder, very soon he comes to think&nbsp;little of robbing; and from robbing he next comes to drinking and&nbsp;Sabbath-breaking, and from that to incivility and procrastination."<br>&nbsp;-- Thomas De Quincey (1785 - 1859)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A sense of humor keen enough to show a man his own absurdities will&nbsp;keep him from the commission of all sins, or nearly all, save those&nbsp;that are worth committing.<br>&nbsp;-- Samuel Butler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you push the "extra ice" button on the soft drink vending machine,<br>you won''t get any ice.  If you push the "no ice" button, you''ll get&nbsp;ice, but no cup.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s not Camelot, but it''s not Cleveland, either."<br>&nbsp;-- Kevin White, mayor of Boston')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Keep grandma off the streets -- legalize bingo.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Have an adequate day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'By doing just a little every day, you can gradually let the task&nbsp;completely overwhelm you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Cleveland?  Yes, I spent a week there one day."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A master was explaining the nature of Tao to one of his&nbsp;novices.  "The Tao is embodied in all software -- regardless of how&nbsp;insignificant," said the master.<br><br>"Is Tao in a hand-held calculator?" asked the novice.<br><br>"It is," came the reply.<br><br>"Is the Tao in a video game?" continued the novice.<br><br>"It is even in a video game," said the master.<br><br>"And is the Tao in the DOS for a personal computer?"&nbsp;<br>The master coughed and shifted his position slightly.  "The&nbsp;lesson is over for today," he said.<br>&nbsp;-- "The Tao of Programming"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is impossible to experience one''s death objectively and still carry&nbsp;a tune.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do molecular biologists wear designer genes?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Comparing information and knowledge is like asking whether the fatness&nbsp;of a pig is more or less green than the designated hitter rule."<br>&nbsp;-- David Guaspari')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a theory which states that if ever anyone discovers exactly&nbsp;what the Universe is for and why it is here, it will instantly&nbsp;disappear and be replaced by something even more bizarre and&nbsp;inexplicable.  There is another theory which states that this has&nbsp;already happened.<br>&nbsp;-- Douglas Adams, "The Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fats Loves Madelyn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For some reason a glaze passes over people''s faces when you say&nbsp;"Canada".  Maybe we should invade South Dakota or something.<br>&nbsp;-- Sandra Gotlieb, wife of the Canadian ambassador to<br>&nbsp;   the U.S.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Slick''s Three Laws of the Universe:<br>(1) Nothing in the known universe travels faster than a bad<br>    check.<br>(2) A quarter-ounce of chocolate = four pounds of fat.<br>(3) There are two types of dirt: the dark kind, which is<br>    attracted to light objects, and the light kind, which is<br>    attracted to dark objects.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do infants have as much fun in infancy as adults do in adultery?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '''Tis the dream of each programmer,<br>Before his life is done,<br>To write three lines of APL,<br>And make the damn things run.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Larkinson''s Law:<br>All laws are basically false.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'McGowan''s Madison Avenue Axiom:<br>If an item is advertised as "under $50", you can bet it''s not&nbsp;$19.95.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are very few personal problems that cannot be solved through a&nbsp;suitable application of high explosives.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good news.  Ten weeks from Friday will be a pretty good day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brain fried -- Core dumped')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Speak roughly to your little VAX,<br>And boot it when it crashes:<br>It knows that one cannot relax<br>Because the paging thrashes!&nbsp;<br>&nbsp;Wow!  Wow!  Wow!&nbsp;&nbsp;I speak severely to my VAX,<br>And boot it when it crashes:<br>In spite of all my favorite hacks<br>My jobs it always thrashes!&nbsp;<br>&nbsp;Wow!  Wow!  Wow!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The problem with people who have no vices is that generally you can be&nbsp;pretty sure they''re going to have some pretty annoying virtues.<br>&nbsp;-- Elizabeth Taylor')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is something to be able to paint a particular picture, or to carve a&nbsp;statue, and so to make a few objects beautiful; but it is far more&nbsp;glorious to carve and paint the very atmosphere and medium through&nbsp;which we look, which morally we can do.  To affect the quality of the&nbsp;day, that is the highest of arts.<br>&nbsp;-- Henry David Thoreau, "Where I Live"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The only problem with being a man of leisure is that you can never stop&nbsp;and take a rest.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old," said the youth, "and I''m told by my peers<br>That your lectures bore people to death.<br>Yet you talk at one hundred conventions per year --<br>Don''t you think that you should save your breath?"&nbsp;&nbsp;"I have answered three questions and that is enough,"<br>Said his father, "Don''t give yourself airs!&nbsp;Do you think I can listen all day to such stuff?<br>Be off, or I''ll kick you downstairs!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What does it mean if there is no fortune for you?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Do not meddle in the affairs of wizards, for you are crunchy and good&nbsp;with ketchup."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I played lead guitar in a band called The Federal Duck, which is the&nbsp;kind of name that was popular in the ''60s as a result of controlled&nbsp;substances being in widespread use.  Back then, there were no&nbsp;restrictions, in terms of talent, on who could make an album, so we&nbsp;made one, and it sounds like a group of people who have been given&nbsp;powerful but unfamiliar instruments as a therapy for a degenerative&nbsp;nerve disease."<br>&nbsp;-- Dave Barry, "The Snake"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Romeo wasn''t bilked in a day.<br>&nbsp;-- Walt Kelly, "Ten Ever-Lovin'' Blue-Eyed Years With<br>&nbsp;   Pogo"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Nuclear war would really set back cable."<br>&nbsp;-- Ted Turner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'H. L. Mencken suffers from the hallucination that he is H. L.<br>Mencken -- there is no cure for a disease of that magnitude.<br>&nbsp;-- Maxwell Bodenheim')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Some men are alive simply because it is against the law to kill them.<br>&nbsp;-- Ed Howe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Collaboration, n.:<br>A literary partnership based on the false assumption that the&nbsp;other fellow can spell.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t let people drive you crazy when you know it''s in walking&nbsp;distance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The superfluous is very necessary.<br>&nbsp;-- Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'THIS IS PLEDGE WEEK FOR THE FORTUNE PROGRAM&nbsp;&nbsp;If you like the fortune program, why not support it now with your&nbsp;contribution of a pithy fortune, clean or obscene?  We cannot continue&nbsp;without your support.  Less than 14% of all fortune users are&nbsp;contributors.  That means that 86% of you are getting a free ride.  We&nbsp;can''t go on like this much longer.  Federal cutbacks mean less money&nbsp;for fortunes, and unless user contributions increase to make up the&nbsp;difference, the fortune program will have to shut down between midnight&nbsp;and 8 a.m.  Don''t let this happen.  Mail your fortunes right now to&nbsp;"fortune".  Just type in your favorite pithy saying.  Do it now before&nbsp;you forget.  Our target is 300 new fortunes by the end of the week.<br>Don''t miss out.  All fortunes will be acknowledged.  If you contribute&nbsp;30 fortunes or more, you will receive a free subscription to "The&nbsp;Fortune Hunter", our monthly program guide.  If you contribute 50 or&nbsp;more, you will receive a free "Fortune Hunter" coffee mug ....')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'People will buy anything that''s one to a customer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Confession is good for the soul only in the sense that a tweed coat is&nbsp;good for dandruff.<br>&nbsp;-- Peter de Vries')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What is the robbing of a bank compared to the FOUNDING of a bank?"<br>&nbsp;-- Bertold Brecht')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The older a man gets, the farther he had to walk to school as a boy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Politicians are the same all over.  They promise to build a bridge even&nbsp;where there is no river.<br>-- Nikita Khrushchev')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Uncle Ed''s Rule of Thumb:<br>Never use your thumb for a rule.  You''ll either hit it with a&nbsp;hammer or get a splinter in it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A New York City ordinance prohibits the shooting of rabbits from the&nbsp;rear of a Third Avenue street car -- if the car is in motion.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Pascal is Pascal is Pascal is dog meat."<br>&nbsp;-- M. Devine and P. Larson, Computer Science 340')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Save the whales.  Collect the whole set.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Nuclear war would mean abolition of most comforts, and disruption of &nbsp;normal routines, for children and adults alike."<br>&nbsp;-- Willard F. Libby, "You *Can* Survive Atomic Attack"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The marvels of today''s modern technology include the development of a&nbsp;soda can, when discarded will last forever ... and a $7,000 car which&nbsp;when properly cared for will rust out in two or three years.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Electrocution, n.:<br>Burning at the stake with all the modern improvements.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vanilla, adj.:<br>Ordinary flavor, standard.  See FLAVOR.  When used of food,<br>very often does not mean that the food is flavored with vanilla&nbsp;extract!  For example, "vanilla-flavored won ton soup" (or simply&nbsp;"vanilla won ton soup") means ordinary won ton soup, as opposed to hot&nbsp;and sour won ton soup.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Buzz off, Banana Nose; Relieve mine eyes&nbsp;Of hateful soreness, purge mine ears of corn:<br>Less dear than army ants in apple pies&nbsp;Art thou, old prune-face, with thy chestnuts worn,<br>Dropt from thy peeling lips like lousy fruit:<br>Like honeybees upon the perfum''d rose&nbsp;They suck, and like the double-breasted suit&nbsp;Are out of date; therefore, Banana Nose,<br>Go fly a kite, thy welcome''s overstayed:<br>And stem the produce of thy waspish wits:<br>Thy logick, like thy locks, is disarrayed:<br>Thy cheer, like thy complexion, is the pits.<br>Be off, I say; go bug somebody new,<br>Scram, beat it, get thee hence, and nuts to you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Waste not, get your budget cut next year.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bennett''s Laws of Horticulture:<br>(1) Houses are for people to live in.<br>(2) Gardens are for plants to live in.<br>(3) There is no such thing as a houseplant.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"You know, it''s at times like this when I''m trapped in a Vogon&nbsp;airlock with a man from Betelgeuse and about to die of asphyxiation in&nbsp;deep space that I really wish I''d listened to what my mother told me&nbsp;when I was young!"<br>"Why, what did she tell you?"<br>"I don''t know, I didn''t listen!"<br>&nbsp;-- Douglas Adams, "Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nearly all men can stand adversity, but if you want to test a man''s&nbsp;character, give him power.<br>&nbsp;-- Abraham Lincoln')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Of all possible committee reactions to any given agenda item, the&nbsp;reaction that will occur is the one which will liberate the greatest&nbsp;amount of hot air.<br>&nbsp;-- Thomas L. Martin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Genderplex, n.:<br>The predicament of a person in a restaurant who is unable to&nbsp;determine his or her designated restroom (e.g., turtles and&nbsp;tortoises).<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An English judge, growing weary of the barrister''s long-winded&nbsp;summation, leaned over the bench and remarked, "I''ve heard your&nbsp;arguments, Sir Geoffrey, and I''m none the wiser!"  Sir Geoffrey&nbsp;responded, "That may be, Milord, but at least you''re better informed!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"One planet is all you get."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '77.  HO HUM -- The Redundant&nbsp;&nbsp;------- (7)&nbsp;This hexagram refers to a situation of extreme&nbsp;--- --- (8)&nbsp;boredom.  Your programs always bomb off.  Your wife&nbsp;------- (7)&nbsp;smells bad.  Your children have hives.  You are working&nbsp;---O--- (6)&nbsp;on an accounting system, when you want to develop the&nbsp;---X--- (9)&nbsp;GREAT AMERICAN COMPILER.  You give up hot dates to&nbsp;--- --- (8)&nbsp;nurse sick computers.  What you need now is sex.<br>&nbsp;Nine in the second place means:<br>The yellow bird approaches the malt shop.  Misfortune.<br>&nbsp;Six in the third place means:<br>In former times men built altars to honor the Internal Revenue<br>Service.  Great Dragons!  Are you in trouble!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Someone will try to honk your nose today.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Finagle''s Third Law:<br>In any collection of data, the figure most obviously correct,<br>beyond all need of checking, is the mistake&nbsp;&nbsp;Corollaries:<br>(1) Nobody whom you ask for help will see it.<br>(2) The first person who stops by, whose advice you really<br>    don''t want to hear, will see it immediately.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In English, every word can be verbed.  Would that it were so in our&nbsp;programming languages.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Accuracy, n.:<br>The vice of being right')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Life is like an onion: you peel off layer after layer, then you find&nbsp;there is nothing in it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s graffito of the week (or maybe even month):<br><br>&nbsp;Don''t Write On Walls!&nbsp;<br>&nbsp;   (and underneath)<br><br>&nbsp;You want I should type?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''d better beat it.  You can leave in a taxi.  If you can''t get a&nbsp;taxi, you can leave in a huff.  If that''s too soon, you can leave in a&nbsp;minute and a huff.<br>&nbsp;-- Groucho Marx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If you don''t want your dog to have bad breath, do what I do:  Pour a little&nbsp;Lavoris in the toilet."<br>&nbsp;-- Jay Leno')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In a medium in which a News Piece takes a minute and an "In-Depth"&nbsp;Piece takes two minutes, the Simple will drive out the Complex.<br>&nbsp;-- Frank Mankiewicz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any sufficiently advanced bug is indistinguishable from a feature.<br>&nbsp;-- Rich Kulawiec')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I went to the race track once and bet on a horse that was so good that&nbsp;it took seven others to beat him!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'History, n.:<br>Papa Hegel he say that all we learn from history is that we&nbsp;learn nothing from history.  I know people who can''t even learn from&nbsp;what happened this morning.  Hegel must have been taking the long&nbsp;view.<br>&nbsp;-- Chad C. Mulligan, "The Hipcrime Vocab"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All the taxes paid over a lifetime by the average American are spent by&nbsp;the government in less than a second.<br>&nbsp;-- Jim Fiebig')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yesterday I was a dog.  Today I''m a dog.  Tomorrow I''ll probably still&nbsp;be a dog. Sigh!  There''s so little hope for advancement.<br>&nbsp;-- Snoopy')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Celestial navigation is based on the premise that the Earth is the&nbsp;center of the universe.  The premise is wrong, but the navigation&nbsp;works.  An incorrect model can be a useful tool.<br>&nbsp;-- Kelvin Throop III')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Stay away from hurricanes for a while.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pecor''s Health-Food Principle:<br>Never eat rutabaga on any day of the week that has a "y" in&nbsp;it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Heller''s Law:<br>The first myth of management is that it exists.<br>&nbsp;Johnson''s Corollary:<br>Nobody really knows what is going on anywhere within the&nbsp;organization.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A new koan:<br><br>If you have some ice cream, I will give it to you.<br><br>If you have no ice cream, I will take it away from you.<br>&nbsp;It is an ice cream koan.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nudists are people who wear one-button suits.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t know anything about music.  In my line you don''t have to."<br>&nbsp;-- Elvis Presley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The chain which can be yanked is not the eternal chain."<br>&nbsp;-- G. Fitch')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Proposed Additions to the PDP-11 Instruction Set:<br>&nbsp;BBW&nbsp;Branch Both Ways&nbsp;BEW&nbsp;Branch Either Way&nbsp;BBBF&nbsp;Branch on Bit Bucket Full&nbsp;BH&nbsp;Branch and Hang&nbsp;BMR&nbsp;Branch Multiple Registers&nbsp;BOB&nbsp;Branch On Bug&nbsp;BPO&nbsp;Branch on Power Off&nbsp;BST&nbsp;Backspace and Stretch Tape&nbsp;CDS&nbsp;Condense and Destroy System&nbsp;CLBR&nbsp;Clobber Register&nbsp;CLBRI&nbsp;Clobber Register Immediately&nbsp;CM&nbsp;Circulate Memory&nbsp;CMFRM&nbsp;Come From -- essential for truly structured programming&nbsp;CPPR&nbsp;Crumple Printer Paper and Rip&nbsp;CRN&nbsp;Convert to Roman Numerals')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Denver it is unlawful to lend your vacuum cleaner to your next-door&nbsp;neighbor.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Jone''s Law:<br>The man who smiles when things go wrong has thought of someone&nbsp;to blame it on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kansas state law requires pedestrians crossing the highways at night to&nbsp;wear tail lights.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Democracy is a form of government in which it is permitted to wonder&nbsp;aloud what the country could do under first-class management.<br>&nbsp;-- Senator Soaper')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I get up each morning, gather my wits.<br>Pick up the paper, read the obits.<br>If I''m not there I know I''m not dead.<br>So I eat a good breakfast and go back to bed.<br>&nbsp;Oh, how do I know my youth is all spent?&nbsp;My get-up-and-go has got-up-and-went.<br>But in spite of it all, I''m able to grin,<br>And think of the places my get-up has been.<br>&nbsp;-- Pete Seeger')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '10.0 times 0.1 is hardly ever 1.0.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How did you get into artificial intelligence?&nbsp;A:  Seemed logical -- I didn''t have any real intelligence.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is real, unless declared integer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lassie looked brilliant, in part because the farm family she lived with&nbsp;was made up of idiots.  Remember?  One of them was always getting&nbsp;pinned under the tractor, and Lassie was always rushing back to the&nbsp;farmhouse to alert the other ones.  She''d whimper and tug at their&nbsp;sleeves, and they''d always waste precious minutes saying things: "Do&nbsp;you think something''s wrong?  Do you think she wants us to follow her?&nbsp;What is it, girl?", etc., as if this had never happened before, instead&nbsp;of every week.  What with all the time these people spent pinned under&nbsp;the tractor, I don''t see how they managed to grow any crops&nbsp;whatsoever.  They probably got by on federal crop supports, which&nbsp;Lassie filed the applications for.<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The shortest distance between two points is under construction.<br>&nbsp;-- Noelie Alito')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the long run, every program becomes rococo, and then rubble.<br>&nbsp;-- Alan Perlis')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Yacc" owes much to a most stimulating collection of users, who have&nbsp;goaded me beyond my inclination, and frequently beyond my ability in&nbsp;their endless search for "one more feature".  Their irritating&nbsp;unwillingness to learn how to do things my way has usually led to my&nbsp;doing things their way; most of the time, they have been right.<br>&nbsp;-- S. C. Johnson, "Yacc guide acknowledgements"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gnagloot, n.:<br>A person who leaves all his ski passes on his jacket just to&nbsp;impress people.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are no games on this system.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Cogito ergo I''m right and you''re wrong."<br>&nbsp;-- Blair Houghton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You will be attacked by a beast who has the body of a wolf, the tail of&nbsp;a lion, and the face of Donald Duck.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I wish there was a knob on the TV to turn up the intelligence.<br>There''s a knob called `brightness'', but it doesn''t work."<br>&nbsp;-- Gallagher')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"We had it tough ... I had to get up at 9 o''clock at night, half an&nbsp;hour before I went to bed, eat a lump of dry poison, work 29 hours down&nbsp;mill, and when we came home our Dad would kill us, and dance about on&nbsp;our grave singing Haleleuia ..."<br>&nbsp;-- Monty Python')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I call them as I see them.  If I can''t see them, I make them up.<br>&nbsp;-- Biff Barf')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If the King''s English was good enough for Jesus, it''s good enough for&nbsp;me!"<br>&nbsp;-- "Ma" Ferguson, Governor of Texas (circa 1920)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Don''t go around saying the world owes you a living.  The world owes&nbsp;you nothing.  It was here first."<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is said that the lonely eagle flies to the mountain peaks while the&nbsp;lowly ant crawls the ground, but cannot the soul of the ant soar as&nbsp;high as the eagle?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good day for a change of scene.  Repaper the bedroom wall.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... But if we laugh with derision, we will never understand.  Human&nbsp;intellectual capacity has not altered for thousands of years so far as&nbsp;we can tell.  If intelligent people invested intense energy in issues&nbsp;that now seem foolish to us, then the failure lies in our understanding&nbsp;of their world, not in their distorted perceptions.  Even the standard&nbsp;example of ancient nonsense -- the debate about angels on pinheads --&nbsp;makes sense once you realize that theologians were not discussing&nbsp;whether five or eighteen would fit, but whether a pin could house a&nbsp;finite or an infinite number.<br>&nbsp;-- S. J. Gould, "Wide Hats and Narrow Minds"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Economics is extremely useful as a form of employment for economists.<br>&nbsp;-- John Kenneth Galbraith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To every Ph.D. there is an equal and opposite Ph.D.<br>&nbsp;-- B. Duggan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s a dog-eat-dog world out there, and I''m wearing Milkbone&nbsp;underwear."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If one studies too zealously, one easily loses his pants.<br>&nbsp;-- A. Einstein.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can make it illegal, but you can''t make it unpopular.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The rule on staying alive as a forcaster is to give ''em a number or&nbsp;give ''em a date, but never give ''em both at once.<br>&nbsp;-- Jane Bryant Quinn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Know thyself.  If you need help, call the C.I.A.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mathematicians are like Frenchmen: whatever you say to them they&nbsp;translate into their own language, and forthwith it is something&nbsp;entirely different.<br>&nbsp;-- Johann Wolfgang von Goethe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Common sense is the collection of prejudices acquired by age eighteen.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A student, in hopes of understanding the Lambda-nature, came to&nbsp;Greenblatt.  As they spoke a Multics system hacker walked by.  "Is it&nbsp;true," asked the student, "that PL-1 has many of the same data types as&nbsp;Lisp?"  Almost before the student had finished his question, Greenblatt&nbsp;shouted, "FOO!", and hit the student with a stick.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The goal of science is to build better mousetraps.  The goal of nature&nbsp;is to build better mice.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Manual, n.:<br>A unit of documentation.  There are always three or more on a&nbsp;given item.  One is on the shelf; someone has the others.  The&nbsp;information you need in in the others.<br>&nbsp;-- Ray Simard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'H. L. Mencken''s Law:<br>Those who can -- do.<br>Those who can''t -- teach.<br>&nbsp;Martin''s Extension:<br>Those who cannot teach -- administrate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s not so hard to lift yourself by your bootstraps once you''re off&nbsp;the ground.<br>&nbsp;-- Daniel B. Luten')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Corrupt, stupid grasping functionaries will make at least as big a&nbsp;muddle of socialism as stupid, selfish and acquisitive employers can&nbsp;make of capitalism.<br>&nbsp;-- Walter Lippmann')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;Electricity is actually made up of extremely tiny particles,<br>called electrons, that you cannot see with the naked eye unless you&nbsp;have been drinking.  Electrons travel at the speed of light, which in&nbsp;most American homes is 110 volts per hour.  This is very fast.  In the&nbsp;time it has taken you to read this sentence so far, an electron could&nbsp;have traveled all the way from San Francisco to Hackensack, New Jersey,<br>although God alone knows why it would want to.<br>The five main kinds of electricity are alternating current,<br>direct current, lightning, static, and European.  Most American homes&nbsp;have alternating current, which means that the electricity goes in one&nbsp;direction for a while, then goes in the other direction.  This prevents&nbsp;harmful electron buildup in the wires.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Impartial, adj.:<br>Unable to perceive any promise of personal advantage from&nbsp;espousing either side of a controversy or adopting either of two&nbsp;conflicting opinions.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Why must you tell me all your secrets when it''s hard enough to love&nbsp;you knowing nothing?"<br>&nbsp;-- Lloyd Cole and the Commotions')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The reasonable man adapts himself to the world; the unreasonable one&nbsp;persists in trying to adapt the world to himself.  Therefore all&nbsp;progress depends on the unreasonable man.<br>&nbsp;-- George Bernard Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ah say, son, you''re about as sharp as a bowlin'' ball.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I haven''t lost my mind -- it''s backed up on tape somewhere."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Third Law of Photography:<br>If you did manage to get any good shots, they will be ruined&nbsp;when someone inadvertently opens the darkroom door and all of the dark&nbsp;leaks out.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The mome rath isn''t born that could outgrabe me.<br>&nbsp;-- Nicol Williamson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I for one cannot protest the recent M.T.A. fare hike and the&nbsp;accompanying promises that this would in no way improve service.  For&nbsp;the transit system, as it now operates, has hidden advantages that&nbsp;can''t be measured in monetary terms.<br>&nbsp;Personally, I feel that it is well worth 75 cents or even $1 to have&nbsp;that unimpeachable excuse whenever I am late to anything: "I came by&nbsp;subway."  Those four words have such magic in them that if Godot should&nbsp;someday show up and mumble them, any audience would instantly&nbsp;understand his long delay.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real computer scientists don''t comment their code.  The identifiers are&nbsp;so long they can''t afford the disk space.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The only really decent thing to do behind a person''s back is pat it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The church is near but the road is icy; the bar is far away but I will&nbsp;walk carefully.<br>&nbsp;-- Russian Proverb')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''ve found my niche.  If you''re wondering why I''m not there, there was&nbsp;this little hole in the bottom ...<br>&nbsp;-- John Croll')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I brake for chezlogs!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'With all the fancy scientists in the world, why can''t they just once&nbsp;build a nuclear balm?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You may be recognized soon.  Hide.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you pick up a starving dog and make him prosperous, he will not bite&nbsp;you.  This is the principal difference between a dog and a man.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"See - the thing is - I''m an absolutist.  I mean, kind of ... in a way ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The primary purpose of the DATA statement is to give names to&nbsp;constants; instead of referring to pi as 3.141592653589793 at every&nbsp;appearance, the variable PI can be given that value with a DATA&nbsp;statement and used instead of the longer form of the constant.  This&nbsp;also simplifies modifying the program, should the value of pi change.<br>&nbsp;-- FORTRAN manual for Xerox Computers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I have a simple philosophy:<br><br>Fill what''s empty.<br>Empty what''s full.<br>Scratch where it itches.<br>&nbsp;-- A. R. Longworth')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'California, n.:<br>From Latin "calor", meaning "heat" (as in English "calorie" or&nbsp;Spanish "caliente"); and "fornia''" for "sexual intercourse" or&nbsp;"fornication."  Hence: Tierra de California, "the land of hot sex."<br>&nbsp;-- Ed Moran')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God made the world in six days, and was arrested on the seventh.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nondeterminism means never having to say you are wrong.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Twenty Percent of Zero is Better than Nothing.<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Of course there''s no reason for it, it''s just our policy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'George Washington was first in war, first in peace -- and the first to&nbsp;have his birthday juggled to make a long weekend.<br>&nbsp;-- Ashley Cooper')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Burn''s Hog Weighing Method:<br>(1) Get a perfectly symmetrical plank and balance it across a<br>    sawhorse.<br>(2) Put the hog on one end of the plank.<br>(3) Pile rocks on the other end until the plank is again<br>    perfectly balanced.<br>(4) Carefully guess the weight of the rocks.<br>&nbsp;-- Robert Burns')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Slowly and surely the unix crept up on the Nintendo user ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Innovation is hard to schedule.<br>&nbsp;-- Dan Fylstra')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For some reason, this fortune reminds everyone of Marvin Zelkowitz.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am convinced that the manufacturers of carpet odor removing powder&nbsp;have included encapsulated time released cat urine in their products.<br>This technology must be what prevented its distribution during my mom''s&nbsp;reign.  My carpet smells like piss, and I don''t have a cat.  Better go&nbsp;by some more."<br>&nbsp;-- timw@zeb.USWest.COM')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I stayed up all night playing poker with tarot cards.  I got a full&nbsp;house and four people died."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You look like a million dollars.  All green and wrinkled.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For every complex problem, there is a solution that is simple, neat,<br>and wrong.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In any formula, constants (especially those obtained from handbooks)<br>are to be treated as variables.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Give me the Luxuries, and the Hell with the Necessities!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This sentence contradicts itself -- no actually it doesn''t.<br>&nbsp;-- Hofstadter')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Surprise!  You are the lucky winner of random I.R.S. Audit!  Just type&nbsp;in your name and social security number.  Please remember that leaving&nbsp;the room is punishable under law:<br>&nbsp;Name&nbsp;#')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t put off for tomorrow what you can do today, because if you enjoy&nbsp;it today you can do it again tomorrow.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can only live once, but if you do it right, once is enough.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Expert, n.:<br>Someone who comes from out of town and shows slides.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Think twice before speaking, but don''t say "think think click click".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The past always looks better than it was.  It''s only pleasant because&nbsp;it isn''t here.<br>&nbsp;-- Finley Peter Dunne (Mr. Dooley)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Kleptomaniac, n.:<br>A rich thief.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Families, when a child is born&nbsp;Want it to be intelligent.<br>I, through intelligence,<br>Having wrecked my whole life,<br>Only hope the baby will prove&nbsp;Ignorant and stupid.<br>Then he will crown a tranquil life&nbsp;By becoming a Cabinet Minister<br>&nbsp;-- Su Tung-p''o')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Higgeldy Piggeldy,<br>Hamlet of Elsinore&nbsp;Ruffled the critics by&nbsp;Dropping this bomb:<br>"Phooey on Freud and his&nbsp;Psychoanalysis --&nbsp;Oedipus, Shmoedipus,<br>I just love Mom."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When one woman was asked how long she had been going to symphony&nbsp;concerts, she paused to calculate and replied, "Forty-seven years --&nbsp;and I find I mind it less and less."<br>&nbsp;-- Louise Andrews Kent')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Love is an ideal thing, marriage a real thing; a confusion of the real with &nbsp;the ideal never goes unpunished."<br>&nbsp;-- Goethe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"All my life I wanted to be someone; I guess I should have been more&nbsp;specific."<br>&nbsp;-- Jane Wagner')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Far out in the uncharted backwaters of the unfashionable end of the&nbsp;Western Spiral arm of the Galaxy lies a small unregarded yellow sun.<br>Orbiting this at a distance of roughly ninety-eight million miles is an&nbsp;utterly insignificant little blue-green planet whose ape-descended life&nbsp;forms are so amazingly primitive that they still think digital watches&nbsp;are a pretty neat idea ...<br>&nbsp;-- Douglas Adams, "The Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There *__^H^His* intelligent life on Earth, but I leave for Texas on Monday.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The world is coming to an end.  Please log off.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If just one piece of mail gets lost, well, they''ll just think they&nbsp;forgot to send it.  But if *two* pieces of mail get lost, hell, they''ll&nbsp;just think the other guy hasn''t gotten around to answering his mail.<br>And if *fifty* pieces of mail get lost, can you imagine it, if *fifty*&nbsp;pieces of mail get lost, why they''ll think someone *else* is broken!&nbsp;And if 1Gb of mail gets lost, they''ll just *know* that Arpa is down and&nbsp;think it''s a conspiracy to keep them from their God given right to&nbsp;receive Net Mail ..."&nbsp; &nbsp;&nbsp;-- Leith (Casey) Leedom')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Machine-Independent, adj.:<br>Does not run on any existing machine.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do you realize how many holes there could be if people would just take&nbsp;the time to take the dirt out of them?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Protozoa are small, and bacteria are small, but viruses are smaller&nbsp;than the both put together."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Life, loathe it or ignore it, you can''t like it."<br>&nbsp;-- Marvin, "Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You''ve got to think about tomorrow!"&nbsp;&nbsp;"TOMORROW!  I haven''t even prepared for *_________^H^H^H^H^H^H^H^H^Hyesterday* yet!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Accident, n.:<br>A condition in which presence of mind is good, but absence of&nbsp;body is better.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Put your Nose to the Grindstone!<br>&nbsp;-- Amalgamated Plastic Surgeons and Toolmakers, Ltd.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Razors pain you:<br>Rivers are damp:<br>Acids stain you:<br>And drugs cause cramp.<br>Guns aren''t lawful:<br>Nooses give:<br>Gas smells awful:<br>You might as well live.<br>&nbsp;-- Dorothy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Famous, adj.:<br>Conspicuously miserable.<br>&nbsp;-- Ambrose Bierce')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Oh don''t the days seem lank and long<br>When all goes right and none goes wrong,<br>And isn''t your life extremely flat<br>With nothing whatever to grumble at!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What the hell, go ahead and put all your eggs in one basket.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'At the source of every error which is blamed on the computer you will&nbsp;find at least two human errors, including the error of blaming it on&nbsp;the computer.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'British Israelites:<br>The British Israelites believe the white Anglo-Saxons of&nbsp;Britain to be descended from the ten lost tribes of Israel deported by&nbsp;Sargon of Assyria on the fall of Sumeria in 721 B.C. ... They further&nbsp;believe that the future can be foretold by the measurements of the&nbsp;Great Pyramid, which probably means it will be big and yellow and in&nbsp;the hand of the Arabs.  They also believe that if you sleep with your&nbsp;head under the pillow a fairy will come and take all your teeth.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There exist tasks which cannot be done by more than 10 men or fewer&nbsp;than 100.<br>&nbsp;-- Steele''s Law')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Health is merely the slowest possible rate at which one can die.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The cost of living is going up, and the chance of living is going&nbsp;down.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You''re not drunk if you can lie on the floor without holding on.<br>&nbsp;-- Dean Martin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a green, multi-legged creature crawling on your shoulder.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Imagine that Cray computer decides to make a personal computer.  It has&nbsp;a 150 MHz processor, 200 megabytes of RAM, 1500 megabytes of disk&nbsp;storage, a screen resolution of 4096 x 4096 pixels, relies entirely on&nbsp;voice recognition for input, fits in your shirt pocket and costs $300.<br>What''s the first question that the computer community asks?&nbsp;&nbsp;"Is it PC compatible?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Then here''s to the City of Boston,<br>The town of the cries and the groans.<br>Where the Cabots can''t see the Kabotschniks,<br>And the Lowells won''t speak to the Cohns.<br>&nbsp;-- Franklin Pierce Adams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I often quote myself; it adds spice to my conversation.<br>&nbsp;-- G. B. Shaw')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Even the best of friends cannot attend each other''s funeral."<br>&nbsp;-- Kehlog Albran, "The Profit"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The 80''s -- when you can''t tell hairstyles from chemotherapy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I went to the museum where they had all the heads and arms from the&nbsp;statues that are in all the other museums."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Beifeld''s Principle:<br>The probability of a young man meeting a desirable and&nbsp;receptive young female increases by pyramidal progression when he is&nbsp;already in the company of: (1) a date, (2) his wife, (3) a better&nbsp;looking and richer male friend.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Well, if you can''t believe what you read in a comic book, what *___^H^H^Hcan*&nbsp;you believe?!"<br>&nbsp;-- Bullwinkle J. Moose [Jay Ward]')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Subtlety is the art of saying what you think and getting out of the way&nbsp;before it is understood.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What is a magician but a practising theorist?<br>&nbsp;-- Obi-Wan Kenobi')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Worst Response To A Crisis, 1985:<br>From a readers'' Q and A column in TV GUIDE: "If we get involved&nbsp;in a nuclear war, would the electromagnetic pulses from exploding bombs&nbsp;damage my videotapes?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Adolescence, n.:<br>The stage between puberty and adultery.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whatever is not nailed down is mine.  What I can pry loose is not&nbsp;nailed down.<br>&nbsp;-- Collis P. Huntingdon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God may be subtle, but He isn''t plain mean.<br>&nbsp;-- Albert Einstein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'With a gentleman I try to be a gentleman and a half, and with a fraud I&nbsp;try to be a fraud and a half.<br>&nbsp;-- Otto von Bismark')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Vital papers will demonstrate their vitality by spontaneously moving&nbsp;from where you left them to where you can''t find them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'So far as I can remember, there is not one word in the Gospels in&nbsp;praise of intelligence.<br>&nbsp;-- Bertrand Russell')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Warp 7 -- It''s a law we can live with.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Gauls!  We have nothing to fear; except perhaps that the sky may fall&nbsp;on our heads tomorrow.  But as we all know, tomorrow never comes!!<br>&nbsp;-- Adventures of Asterix.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you have a procedure with 10 parameters, you probably missed some.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Schizophrenia beats being alone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The doctrine of human equality reposes on this: that there is no man&nbsp;really clever who has not found that he is stupid.<br>&nbsp;-- Gilbert K. Chesterson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why not have an old-fashioned Christmas for your family this year?&nbsp;Just picture the scene in your living room on Christmas morning as your&nbsp;children open their old-fashioned presents.<br>&nbsp;Your 11-year-old son: "What the heck is this?"&nbsp;&nbsp;You:&nbsp;"A spinning top!  You spin it around, and then eventually it<br>falls down.  What fun!  Ha, ha!"&nbsp;&nbsp;Son:&nbsp;"Is this a joke?  Jason Thompson''s parents got him a computer<br>with two disk drives and 128 kilobytes of random-access memory,<br>and I get this cretin TOP?"&nbsp;&nbsp;Your 8-year-old daughter: "You think that''s bad?  Look at this."&nbsp;&nbsp;You:&nbsp;"It''s figgy pudding!  What a treat!"&nbsp;&nbsp;Daughter: "It looks like goat barf."<br>&nbsp;-- Dave Barry, "Simple, Homespun Gifts"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who educate children well are more to be honored than parents,<br>for these only gave life, those the art of living well.<br>&nbsp;-- Aristotle')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why don''t elephants eat penguins ?&nbsp;&nbsp;Because they can''t get the wrappers off ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A.A.A.A.A.:<br>An organization for drunks who drive')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you don''t care where you are, then you ain''t lost.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You''ll never be the man your mother was!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Go climb a gravity well!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Birth, n.:<br>The first and direst of all disasters.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have a very firm grasp on reality!  I can reach out and strangle it&nbsp;any time!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fertility is hereditary.  If your parents didn''t have any children,<br>neither will you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'VMS is like a nightmare about RXS-11M.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You have junk mail.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You cannot kill time without injuring eternity.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Probably the question asked most often is: Do one-celled animals have&nbsp;orgasms?  The answer is yes, they have orgasms almost constantly, which&nbsp;is why they don''t mind living in pools of warm slime.<br>&nbsp;-- Dave Barry, "Sex and the Single Amoeba: What Every<br>&nbsp;   Teen Should Know"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Immortality -- a fate worse than death.<br>&nbsp;-- Edgar A. Shoaff')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''m really enjoying not talking to you ... Let''s not talk again ____^H^H^H^HREAL&nbsp;soon ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Churchill''s Commentary on Man:<br>Man will occasionally stumble over the truth, but most of the&nbsp;time he will pick himself up and continue on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Magpie, n.:<br>A bird whose theivish disposition suggested to someone that it&nbsp;might be taught to talk.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;The people of Halifax invented the trampoline.  During the&nbsp;Victorian period the tripe-dressers of Halifax stretched tripe across a&nbsp;large wooden frame and jumped up and down on it to `tender and dress''&nbsp;it.  The tripoline, as they called it, degenerated into becoming the&nbsp;apparatus for a spectator sport.<br><br>The people of Halifax also invented the harmonium, a device for&nbsp;castrating pigs during Sunday service.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Teamwork is essential -- it allows you to blame someone else.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Health nuts are going to feel stupid someday, lying in hospitals dying&nbsp;of nothing.<br>&nbsp;-- Redd Foxx')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yesterday upon the stair&nbsp;I met a man who wasn''t there.<br>He wasn''t there again today --&nbsp;I think he''s from the CIA.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All power corrupts, but we need electricity.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I don''t have to take this abuse from you -- I''ve got hundreds of&nbsp;people waiting to abuse me."<br>&nbsp;-- Bill Murray, "Ghostbusters"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conscience is a mother-in-law whose visit never ends.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A pedestal is as much a prison as any small, confined space.<br>&nbsp;-- Gloria Steinem')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s Fabulous!  We haven''t seen anything like it in the last half an&nbsp;hour!"<br>&nbsp;-- Macy''s')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If today is the first day of the rest of your life, what the hell was&nbsp;yesterday?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The best cure for insomnia is to get a  lot of sleep.<br>&nbsp;-- W. C. Fields')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chicago law prohibits eating in a place that is on fire.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I have yet to see any problem, however complicated, which, when looked&nbsp;at in the right way, did not become still more complicated.<br>&nbsp;-- Poul Anderson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Systems have sub-systems and sub-systems have sub-systems and so on ad&nbsp;infinitum -- which is why we''re always starting over.<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any clod can have the facts, but having an opinion is an art.<br>&nbsp;-- Charles McCabe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is only people of small moral stature who have to stand on their&nbsp;dignity.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There was an interesting development in the CBS-Westmoreland trial:<br>both sides agreed that after the trial, Andy Rooney would be allowed to&nbsp;talk to the jury for three minutes about little things that annoyed him&nbsp;during the trial."<br>&nbsp;-- David Letterman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Genius, n.:<br>A chemist who discovers a laundry additive that rhymes with&nbsp;"bright".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you try to make an impression, the chances are that is the&nbsp;impression you will make.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conway''s Law:<br>In any organization there will always be one person who knows<br>what is going on.<br><br>This person must be fired.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '#define BITCOUNT(x)&nbsp;(((BX_(x)+(BX_(x)>>4)) & 0x0F0F0F0F) % 255)<br>#define  BX_(x)&nbsp;&nbsp;((x) - (((x)>>1)&0x77777777)&nbsp;&nbsp;&nbsp;\<br>&nbsp;&nbsp;     - (((x)>>2)&0x33333333)&nbsp;&nbsp;&nbsp;\<br>&nbsp;&nbsp;     - (((x)>>3)&0x11111111))<br><br>&nbsp;-- really weird C code to count the number of bits in a word')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q: Somebody just posted that Roman Polanski directed Star Wars.  What&nbsp;   should I do?&nbsp;&nbsp;A: Post the correct answer at once!  We can''t have people go on&nbsp;   believing that!  Very good of you to spot this.  You''ll probably be&nbsp;   the only one to make the correction, so post as soon as you can.  No&nbsp;   time to lose, so certainly don''t wait a day, or check to see if&nbsp;   somebody else has made the correction.<br>&nbsp;   And it''s not good enough to send the message by mail.  Since you''re&nbsp;   the only one who really knows that it was Francis Coppola, you have&nbsp;   to inform the whole net right away!&nbsp;<br>&nbsp;-- Brad Templeton, "Emily Postnews Answers Your Questions<br>&nbsp;   on Netiquette"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Radioactive cats have 18 half-lives.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The society which scorns excellence in plumbing as a humble activity&nbsp;and tolerates shoddiness in philosophy because it is an exalted&nbsp;activity will have neither good plumbing nor good philosophy ...<br>neither its pipes nor its theories will hold water."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s lucky you''re going so slowly, because you''re going in the wrong&nbsp;direction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'But scientists, who ought to know&nbsp;Assure us that it must be so.<br>Oh, let us never, never doubt&nbsp;What nobody is sure about.<br>&nbsp;-- Hilaire Belloc')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is Dead<br>&nbsp;-- Nietzsche&nbsp;Nietzsche is Dead<br>&nbsp;-- God&nbsp;Nietzsche is God<br>&nbsp;-- The Dead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If a camel flies, no one laughs if it doesn''t get very far."<br>&nbsp;-- Paul White')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Blood is thicker than water, and much tastier.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Due to circumstances beyond your control, you are master of your fate&nbsp;and captain of your soul.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"At a recent meeting in Snowmass, Colorado, a participant from Los&nbsp;Angeles fainted from hyperoxygenation, and we had to hold his head&nbsp;under the exhaust of a bus until he revived."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Food for thought is no substitute for the real thing.<br>&nbsp;-- Walt Kelly, "Putluck Pogo"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is generally agreed that "Hello" is an appropriate greeting because&nbsp;if you entered a room and said "Goodbye," it could confuse a lot of&nbsp;people.<br>&nbsp;-- Dolph Sharp, "I''m O.K., You''re Not So Hot"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Isn''t it interesting that the same people who laugh at science fiction&nbsp;listen to weather forecasts and economists?<br>&nbsp;-- Kelvin Throop III')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I went to the hardware store and bought some used paint.  It was in&nbsp;the shape of a house.  I also bought some batteries, but they weren''t&nbsp;included."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'FORTUNE DISCUSSES THE OBSCURE FILMS!&nbsp;#6&nbsp;&nbsp;RAZORBACK:&nbsp;&nbsp;&nbsp;Paul Harbride, 1984, 2 hours 25 min.<br>One of the great Australian films of the early 1980''s, and<br>arguably the best movie ever made about a large, man-eating<br>hog.  Some violence.  With Gregory Harrison.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Spelling is a lossed art.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Albert Einstein, when asked to describe radio, replied: "You see, wire&nbsp;telegraph is a kind of a very, very long cat.  You pull his tail in New&nbsp;York and his head is meowing in Los Angeles.  Do you understand this?&nbsp;And radio operates exactly the same way: you send signals here, they&nbsp;receive them there.  The only difference is that there is no cat."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Man is the only animal that can remain on friendly terms with the&nbsp;victims he intends to eat until he eats them.<br>&nbsp;-- Samuel Butler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'She liked him; he was a man of many qualities, even if most of them&nbsp;were bad.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I''m staying home to work on my&nbsp;cottage cheese sculpture."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nobody said computers were going to be polite.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... My pants just went on a wild rampage through a Long Island Bowling&nbsp;Alley!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is true that if your paperboy throws your paper into the bushes for&nbsp;five straight days it can be explained by Newton''s Law of Gravity.  But&nbsp;it takes Murphy''s law to explain why it is happening to you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One-Shot Case Study, n.:<br>The scientific equivalent of the four-leaf clover, from which&nbsp;it is concluded all clovers possess four leaves and are sometimes&nbsp;green.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Taxes are going up so fast, the government is likely to price itself&nbsp;out of the market.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every nonzero finite dimensional inner product space has an orthonormal basis.<br>&nbsp;It makes sense, when you don''t think about it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fog Lamps, n.:<br>Excessively (often obnoxiously) bright lamps mounted on the&nbsp;fronts of automobiles; used on dry, clear nights to indicate that the&nbsp;driver''s brain is in a fog.<br>&nbsp;See also "Idiot Lights".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'So, what''s with this guy Gideon, anyway?  And why can''t he ever&nbsp;remember his Bible?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rule of Defactualization:<br>Information deteriorates upward through bureaucracies.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The student in question is performing minimally for his peer group and&nbsp;is an emerging underachiever."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;''Twas the Night before Crisis&nbsp;&nbsp;''Twas the night before crisis, and all through the house,<br>Not a program was working not even a browse.<br>The programmers were wrung out too mindless to care,<br>Knowing chances of cutover hadn''t a prayer.<br>The users were nestled all snug in their beds,<br>While visions of inquiries danced in their heads.<br>When out in the lobby there arose such a clatter,<br>I sprang from my tube to see what was the matter.<br>And what to my wondering eyes should appear,<br>But a Super Programmer, oblivious to fear.<br>More rapid than eagles, his programs they came,<br>And he whistled and shouted and called them by name:<br>On Update!  On Add!  On Inquiry!  On Delete!<br>On Batch Jobs!  On Closing!  On Functions Complete!&nbsp;His eyes were glazed over, his fingers were lean,<br>From Weekends and nights in front of a screen.<br>A wink of his eye, and a twist of his head,<br>Soon gave me to know I had nothing to dread...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you make people think they''re thinking, they''ll love you; but if you&nbsp;really make them think they''ll hate you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is Mr. Mellon''s credo that $200,000,000 can do no wrong.  Our&nbsp;offense consists in doubting it.<br>&nbsp;-- Justice Robert H. Jackson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Always try to do things in chronological order; it''s less confusing&nbsp;that way."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Support bacteria -- it''s the only culture some people have!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Wood is highly ecological, since trees are a renewable resource.  If&nbsp;you cut down a tree, another will grow in its place.  And if you cut&nbsp;down the new tree, still another will grow.  And if you cut down that&nbsp;tree, yet another will grow, only this one will be a mutation with&nbsp;long, poisonous tentacles and revenge in its heart, and it will sit&nbsp;there in the forest, cackling and making elaborate plans for when you&nbsp;come back.<br>&nbsp;Wood heat is not new.  It dates back to a day millions of years ago,<br>when a group of cavemen were sitting around, watching dinosaurs rot.<br>Suddenly, lightning struck a nearby log and set it on fire.  One of the&nbsp;cavemen stared at the fire for a few minutes, then said: "Hey!  Wood&nbsp;heat!"  The other cavemen, who did not understand English, immediately&nbsp;beat him to death with stones.  But the key discovery had been made,<br>and from that day forward, the cavemen had all the heat they needed,<br>although their insurance rates went way up.<br>&nbsp;-- Dave Barry, "Postpetroleum Guzzler"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'HR 3128.  Omnibus Budget Reconciliation, Fiscal 1986.  Martin, R-Ill.,<br>motion that the House recede from its disagreement to the Senate&nbsp;amendment making changes in the bill to reduce fiscal 1986 deficits.<br>The Senate amendment was an amendment to the House amendment to the&nbsp;Senate amendment to the House amendment to the Senate amendment to the&nbsp;bill.  The original Senate amendment was the conference agreement on&nbsp;the bill.  Agreed to.<br>&nbsp;-- Albuquerque Journal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Support your local Search and Rescue unit -- get lost.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I gained nothing at all from Supreme Enlightenment, and for that very&nbsp;reason it is called Supreme Enlightenment."<br>&nbsp;-- Gotama Buddha')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Steinbach''s Guideline for Systems Programming:<br>Never test for an error condition you don''t know how to&nbsp;handle.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Distinctive, adj.:<br>A different color or shape than our competitors.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No one can make you feel inferior without your consent.<br>&nbsp;-- Eleanor Roosevelt')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"For three days after death hair and fingernails continue to grow but&nbsp;phone calls taper off."<br>&nbsp;-- Johnny Carson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You are old, father William," the young man said,<br>"And your hair has become very white:<br>And yet you incessantly stand on your head --<br>Do you think, at your age, it is right?"&nbsp;&nbsp;"In my youth," father William replied to his son,<br>"I feared it might injure the brain:<br>But, now that I''m perfectly sure I have none,<br>Why, I do it again and again."<br>&nbsp;-- Lewis Carrol')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Never underestimate the power of a small tactical nuclear weapon."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Scrubbing floors and emptying bedpans has as much dignity as the&nbsp;Presidency.<br>&nbsp;-- Richard Nixon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Has anyone had problems with the computer accounts?"&nbsp;"Yes, I don''t have one."&nbsp;"Okay, you can send mail to one of the tutors ..."<br>&nbsp;-- E. D''Azevedo, Computer Science 372')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paranoia is simply an optimistic outlook on life.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There was a boy called Eustace Clarence Scrubb, and he almost deserved&nbsp;it."<br>&nbsp;-- C. S. Lewis, The Chronicles of Narnia')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You think Oedipus had a problem -- Adam was Eve''s mother.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Office Door Sign of the Week:<br><br>Incorrigible punster -- Do not incorrige.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ban the bomb.  Save the world for conventional warfare.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"You''ve got to have a gimmick if your band sucks."<br>&nbsp;-- Gary Giddens')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is not enough to succeed.  Others must fail.<br>&nbsp;-- Gore Vidal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Jone''s Motto:<br>Friends come and go, but enemies accumulate.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Who cares if it doesn''t do anything?  It was made with our new&nbsp;Triple-Iso-Bifurcated-Krypton-Gate-MOS process ..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Let He who taketh the Plunge Remember to return it by Tuesday.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ninety-Ninety Rule of Project Schedules:<br>The first ninety percent of the task takes ninety percent of&nbsp;the time, and the last ten percent takes the other ninety percent.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"There are two ways of constructing a software design: One way is to&nbsp;make is so simple that there are obviously no deficiencies, and the&nbsp;other way is to make it so complicated that there are no obvious&nbsp;deficiencies."<br>&nbsp;-- C. A. R. Hoare')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"What George Washington did for us was to throw out the British, so&nbsp;that we wouldn''t have a fat, insensitive government running our&nbsp;country. Nice try anyway, George."<br>&nbsp;-- D.J. on KSFO/KYA')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s Like This"&nbsp;&nbsp;Even the samurai&nbsp;have teddy bears,<br>and even the teddy bears&nbsp;get drunk.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How doth the little crocodile<br>Improve his shining tail,<br>And pour the waters of the Nile<br>On every golden scale!&nbsp;&nbsp;How cheerfully he seems to grin,<br>How neatly spreads his claws,<br>And welcomes little fishes in,<br>With gently smiling jaws!<br>&nbsp;-- Lewis Carrol, "Alice in Wonderland"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'And this is a table ma''am.  What in essence it consists of is a&nbsp;horizontal rectilinear plane surface maintained by four vertical&nbsp;columnar supports, which we call legs.  The tables in this laboratory,<br>ma''am, are as advanced in design as one will find anywhere in the&nbsp;world.<br>&nbsp;-- Michael Frayn, "The Tin Men"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Since we''re all here, we must not be all there.<br>&nbsp;-- Bob "Mountain" Beck')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can get more of what you want with a kind word and a gun than you&nbsp;can with just a kind word.<br>&nbsp;-- Bumper Sticker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chef, n.:<br>Any cook who swears in French.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is easier to write an incorrect program than understand a correct&nbsp;one.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The chief danger in life is that you may take too may precautions.<br>&nbsp;-- Alfred Adler')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eternal nothingness is fine if you happen to be dressed for it.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Angels we have heard on High&nbsp;Tell us to go out and Buy.<br>&nbsp;-- Tom Lehrer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Admiration, n.:<br>Our polite recognition of another''s resemblance to ourselves.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mind!  I don''t mean to say that I know, of my own knowledge, what there&nbsp;is particularly dead about a door-nail.  I might have been inclined,<br>myself, to regard a coffin-nail as the deadest piece of ironmongery in&nbsp;the trade.  But the wisdom of our ancestors is in the simile; and my&nbsp;unhallowed hands shall not disturb it, or the Country''s done for.  You&nbsp;will therefore permit me to repeat, emphatically, that Marley was as&nbsp;dead as a door-nail.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Chisolm''s First Corollary to Murphy''s Second Law:<br>When things just can''t possibly get any worse, they will.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '     _&nbsp;  _  / \&nbsp;&nbsp;&nbsp;   o&nbsp; / \ | |&nbsp;&nbsp;       o&nbsp;   o&nbsp;&nbsp; o&nbsp; | | | |   _&nbsp;&nbsp;&nbsp;o    o&nbsp;&nbsp;       o       o&nbsp; | \_| |  / \&nbsp;&nbsp;      o&nbsp;&nbsp;&nbsp;    o&nbsp; o&nbsp;  \__  |  | |&nbsp;&nbsp;  o&nbsp;&nbsp;&nbsp;      o&nbsp;     | |  | |&nbsp;&nbsp; ______&nbsp;  ~~~~&nbsp;&nbsp;    _____&nbsp;     | |__/ |&nbsp;       / ___--\\ ~~~&nbsp;&nbsp; __/_____\__&nbsp;     |&nbsp;___/&nbsp;      / \--\\  \\   \ ___&nbsp;<__  x x  __\&nbsp;     | |&nbsp;     / /\\  \\&nbsp;     ))&nbsp; \&nbsp;   (  "&nbsp; )<br>     | |     -------(---->>(@)--(@)-------\----------< >-----------&nbsp;     | |   //&nbsp;    | | //__________  /&nbsp;   \&nbsp;____)&nbsp;(___&nbsp;  \\&nbsp;     | |  //&nbsp;  __|_|&nbsp; ( --------- )&nbsp;    //// ______ /////\&nbsp;   \\<br> //&nbsp;  |    (  \ ______  /&nbsp;   <<<< <>-----<<<<< /&nbsp;    \\<br>//&nbsp; (     )&nbsp;&nbsp;      / /&nbsp;  \` \__     \\&nbsp;       //-------------------------------------------------------------\\&nbsp;&nbsp;Every now and then when your life gets complicated and the weasels&nbsp;start closing in, the only cure is to load up on heinous chemicals and&nbsp;then drive like a bastard from Hollywood to Las Vegas ... with the&nbsp;music at top volume and at least a pint of ether.<br>&nbsp;-- H.S. Thompson, "Fear and Loathing in Las Vegas"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #18: C-&nbsp;&nbsp;This language was named for the grade received by its creator when he&nbsp;submitted it as a class project in a graduate programming class.  C- is&nbsp;best described as a "low-level" programming language.  In fact, the&nbsp;language generally requires more C- statements than machine-code&nbsp;statements to execute a given task.  In this respect, it is very&nbsp;similar to COBOL.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Make it myself?  But I''m a physical organic chemist!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In case of injury notify your superior immediately.  He''ll kiss it and&nbsp;make it better.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Diplomacy is the art of saying "nice doggy" until you can find a rock.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What I tell you three times is true.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Slang is language that takes off its coat, spits on its hands, and goes&nbsp;to work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If little else, the brain is an educational toy.<br>&nbsp;-- Tom Robbins')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Wethern''s Law:<br>Assumption is the mother of all screw-ups.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you''re right 90% of the time, why quibble about the remaining 3%?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Indifference will be the downfall of mankind, but who cares?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;A novel approach is to remove all power from the system, which&nbsp;removes most system overhead so that resources can be fully devoted to&nbsp;doing nothing.  Benchmarks on this technique are promising; tremendous&nbsp;amounts of nothing can be produced in this manner.  Certain hardware&nbsp;limitations can limit the speed of this method, especially in the&nbsp;larger systems which require a more involved & less efficient&nbsp;power-down sequence.<br>An alternate approach is to pull the main breaker for the&nbsp;building, which seems to provide even more nothing, but in truth has&nbsp;bugs in it, since it usually inhibits the systems which keep the beer&nbsp;cool.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Boren''s Laws:<br>(1) When in charge, ponder.<br>(2) When in trouble, delegate.<br>(3) When in doubt, mumble.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t worry about the world coming to an end today.  It''s already&nbsp;tomorrow in Australia.<br>&nbsp;-- Charles Schultz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I can''t understand it.  I can''t even understand the people who can&nbsp;understand it.<br>&nbsp;-- Queen Juliana of the Netherlands.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lysistrata had a good idea.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The moon may be smaller than Earth, but it''s further away.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you stick a stock of liquor in your locker,<br>It is slick to stick a lock upon your stock. <br>Or some joker who is slicker,<br>Will trick you of your liquor,<br>If you fail to lock your liquor with a lock.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you want divine justice, die.<br>&nbsp;-- Nick Seldon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is Texas law that when two trains meet each other at a railroad&nbsp;crossing, each shall come to a full stop, and neither shall proceed&nbsp;until the other has gone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s not the valleys in life I dread so much as the dips.<br>&nbsp;-- Garfield')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The capacity of human beings to bore one another seems to be vastly&nbsp;greater than that of any other animals.  Some of their most esteemed&nbsp;inventions have no other apparent purpose, for example, the dinner&nbsp;party of more than two, the epic poem, and the science of metaphysics.<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The number of arguments is unimportant unless some of them are&nbsp;correct.<br>&nbsp;-- Ralph Hartley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Whom are you?" said he, for he had been to night school.<br>&nbsp;-- George Ade')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What I do, first thing [in the morning], is I hop into the shower&nbsp;stall.  Then I hop right back out, because when I hopped in I landed&nbsp;barefoot right on top of See Threepio, a little plastic robot character&nbsp;from "Star Wars" whom my son, Robert, likes to pull the legs off of&nbsp;while he showers.  Then I hop right back into the stall because our&nbsp;dog, Earnest, who has been alone in the basement all night building up&nbsp;powerful dog emotions, has come bounding and quivering into the&nbsp;bathroom and wants to greet me with 60 or 70 thousand playful nips, any&nbsp;one of which -- bear in mind that I am naked and, without my contact&nbsp;lenses, essentially blind -- could result in the kind of injury where&nbsp;you have to learn a whole new part if you want to sing the "Messiah",<br>if you get my drift.  Then I hop right back out, because Robert, with&nbsp;that uncanny sixth sense some children have -- you cannot teach it:<br>they either have it or they don''t -- has chosen exactly that moment to&nbsp;flush one of the toilets.  Perhaps several of them.<br>&nbsp;-- Dave Barry, "Saving Face"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For an idea to be fashionable is ominous, since it must afterwards be&nbsp;always old-fashioned.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'FLASH!  Intelligence of mankind decreasing.  Details at ... uh, when&nbsp;the little hand is on the ....')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Concept, n.:<br>Any "idea" for which an outside consultant billed you more than&nbsp;$25,000.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Why did the Lord give us so much quickness of movement unless it was to&nbsp;avoid responsibility with?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you keep anything long enough, you can throw it away.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune: You will be attacked next Wednesday at 3:15 p.m. by six samuri&nbsp;sword wielding purple fish glued to Harley-Davidson motorcycles.<br>&nbsp;Oh, and have a nice day!<br>&nbsp;-- Bryce Nesbitt ''84')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Simon''s Law:<br>Everything put together falls apart sooner or later.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A girl and a boy bump into each other -- surely an accident.<br>A girl and a boy bump and her handkerchief drops -- surely another accident.<br>But when a girl gives a boy a dead squid -- *_^H_^H_^H_^Hthat _^H_^H_^Hhad _^H_^Hto _^H_^H_^H_^Hmean _^H_^H_^H_^H_^H_^H_^H_^H_^Hsomething*.<br>&nbsp;-- S. Morganstern, "The Silent Gondoliers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Happiness is having a scratch for every itch.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pretend to spank me -- I''m a pseudo-masochist!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Notes for a ballet, "The Spell": ... Suddenly Sigmund hears the flutter&nbsp;of wings, and a group of wild swans flies across the moon ... Sigmund&nbsp;is astounded to see that their leader is part swan and part woman --&nbsp;unfortunately, divided lengthwise.  She enchants Sigmund, who is&nbsp;careful not to make any poultry jokes ...<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Hi, I''m Preston A. Mantis, president of Consumers Retail Law Outlet.<br>As you can see by my suit and the fact that I have all these books of&nbsp;equal height on the shelves behind me, I am a trained legal attorney.<br>Do you have a car or a job?  Do you ever walk around?  If so, you&nbsp;probably have the makings of an excellent legal case.  Although of&nbsp;course every case is different, I would definitely say that based on my&nbsp;experience and training, there''s no reason why you shouldn''t come out&nbsp;of this thing with at least a cabin cruiser.<br>&nbsp;"Remember, at the Preston A. Mantis Consumers Retail Law Outlet, our&nbsp;motto is:  ''It is very difficult to disprove certain kinds of pain.''"<br>&nbsp;-- Dave Barry, "Pain and Suffering"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everybody is somebody else''s weirdo.<br>&nbsp;-- Dykstra')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God made the Idiot for practice, and then He made the School Board<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real Users find the one combination of bizarre input values that shuts&nbsp;down the system for days.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'panic: can''t find /')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Emerson''s Law of Contrariness:<br>Our chief want in life is somebody who shall make us do what we&nbsp;can.  Having found them, we shall then hate them for it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"When you are in it up to your ears, keep your mouth shut."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #8: LAIDBACK&nbsp;&nbsp;This language was developed at the Marin County Center for T''ai Chi,<br>Mellowness and Computer Programming (now defunct), as an alternative to&nbsp;the more intense atmosphere in nearby Silicon Valley.<br>&nbsp;The center was ideal for programmers who liked to soak in hot tubs&nbsp;while they worked.  Unfortunately few programmers could survive there&nbsp;because the center outlawed Pizza and Coca-Cola in favor of Tofu and&nbsp;Perrier.<br>&nbsp;Many mourn the demise of LAIDBACK because of its reputation as a gentle&nbsp;and non-threatening language since all error messages are in lower&nbsp;case.  For example, LAIDBACK responded to syntax errors with the&nbsp;message:<br>"i hate to bother you, but i just can''t relate to that.  can<br>you find the time to try it again?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you think education is expensive, try ignorance.<br>&nbsp;-- Derek Bok, president of Harvard')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A gleekzorp without a tornpee is like a quop without a fertsneet (sort&nbsp;of).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mollison''s Bureaucracy Hypothesis:<br>If an idea can survive a bureaucratic review and be implemented&nbsp;it wasn''t worth doing.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good night to spend with family, but avoid arguments with your mate''s&nbsp;new lover.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If all else fails, immortality can always be assured by spectacular&nbsp;error.<br>&nbsp;-- John Kenneth Galbraith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This login session: $13.99, but for you $11.88')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hurewitz''s Memory Principle:<br>The chance of forgetting something is directly proportional&nbsp;to ..... to ........ uh ..............')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When the Ngdanga tribe of West Africa hold their moon love ceremonies,<br>the men of the tribe bang their heads on sacred trees until they get a&nbsp;nose bleed, which usually cures them of ____^H^H^H^Hthat.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The qotc (quote of the con) was Liz''s:<br>"My brain is paged out to my liver"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As a professional humorist, I often get letters from readers who are&nbsp;interested in the basic nature of humor.  "What kind of a sick&nbsp;perverted disgusting person are you," these letters typically ask,<br>"that you make jokes about setting fire to a goat?" ...<br>&nbsp;-- Dave Barry, "Why Humor is Funny"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'We can predict everything, except the future.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Shaw''s Principle:<br>Build a system that even a fool can use, and only a fool will&nbsp;want to use it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I''d love to go out with you, but I never go out on days that end in&nbsp;`Y.''"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When I was younger, I could remember anything, whether it had happened&nbsp;or not; but my faculties are decaying now and soon I shall be so I&nbsp;cannot remember any but the things that never happened.  It is sad to&nbsp;go to pieces like this but we all have to do it.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ozman''s Laws:<br>(1) If someone says he will do something "without fail," he<br>    won''t.<br>(2) The more people talk on the phone, the less money they<br>    make.<br>(3) People who go to conferences are the ones who shouldn''t.<br>(4) Pizza always burns the roof of your mouth.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Quick!!  Act as if nothing has happened!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anthony''s Law of the Workshop:<br>Any tool when dropped, will roll into the least accessible<br>corner of the workshop.<br>&nbsp;Corollary:<br>On the way to the corner, any dropped tool will first strike<br>your toes.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I used to think that the brain was the most wonderful organ in my&nbsp;body.  Then I realized who was telling me this."<br>&nbsp;-- Emo Phillips')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everybody wants to go to heaven, but nobody wants to die.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Space is big.  You just won''t believe how vastly, hugely, mind-&nbsp;bogglingly big it is.  I mean, you may think it''s a long way down the&nbsp;road to the drug store, but that''s just peanuts to space.<br>&nbsp;-- "The Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Arnold''s Laws of Documentation:<br>(1) If it should exist, it doesn''t.<br>(2) If it does exist, it''s out of date.<br>(3) Only documentation for useless programs transcends the<br>    first two laws.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you want to know what god thinks of money, just look at the people&nbsp;he gave it to.<br>&nbsp;-- Dorthy Parker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Any sufficiently advanced technology is indistinguishable from magic.<br>&nbsp;-- Arthur C. Clarke')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Remember, drive defensively!  And of course, the best defense is a good&nbsp;offense!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Famous last words:<br>(1) Don''t unplug it, it will just take a moment to fix.<br>(2) Let''s take the shortcut, he can''t see us from there.<br>(3) What happens if you touch these two wires tog--<br>(4) We won''t need reservations.<br>(5) It''s always sunny there this time of the year.<br>(6) Don''t worry, it''s not loaded.<br>(7) They''d never (be stupid enough to) make him a manager.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is amusing that a virtue is made of the vice of chastity; and it''s a&nbsp;pretty odd sort of chastity at that, which leads men straight into the&nbsp;sin of Onan, and girls to the waning of their color.<br>&nbsp;-- Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is better to kiss an avocado than to get in a fight with an aardvark')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ankh if you love Isis.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Today, of course, it is considered very poor taste to use the F-word&nbsp;except in major motion pictures."<br>&nbsp;-- Dave Barry, "$#$%#^%!^%&@%@!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Terence, this is stupid stuff:<br>You eat your victuals fast enough:<br>There can''t be much amiss, ''tis clear,<br>To see the rate you drink your beer.<br>But oh, good Lord, the verse you make,<br>It gives a chap the belly-ache.<br>The cow, the old cow, she is dead:<br>It sleeps well the horned head:<br>We poor lads, ''tis our turn now&nbsp;To hear such tunes as killed the cow.<br>Pretty friendship ''tis to rhyme&nbsp;Your friends to death before their time.<br>Moping, melancholy mad:<br>Come, pipe a tune to dance to, lad."<br>&nbsp;-- A. E. Housman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Future looks spotty.  You will spill soup in late evening.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hall''s Laws of Politics:<br>(1) The voters want fewer taxes and more spending.<br>(2) Citizens want honest politicians until they want something<br>    fixed.<br>(3) Constituency drives out consistency (i.e., liberals defend<br>    military spending, and conservatives social spending in<br>    their own districts).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Which is worse: ignorance or apathy?  Who knows?  Who cares?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The net of law is spread so wide,<br>No sinner from its sweep may hide.<br>Its meshes are so fine and strong,<br>They take in every child of wrong.<br>O wondrous web of mystery!&nbsp;Big fish alone escape from thee!<br>&nbsp;-- James Jeffrey Roche')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Old age is the most unexpected of things that can happen to a man.<br>&nbsp;-- Trotsky')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'VIRGO (Aug 23 - Sept 22)<br>Learn something new today, like how to spell or how to count to<br>ten without using your fingers.  Be careful dressing this<br>morning.  You may be hit by a car later in the day and you<br>wouldn''t want to be taken to the doctor''s office in some of<br>that old underwear you own.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Syntactic sugar causes cancer of the semicolon.<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Kirk to Enterprise -- beam down yeoman Rand and a six-pack."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Conscience is the inner voice that warns us somebody is looking<br>&nbsp;-- H. L. Mencken')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The difference between science and the fuzzy subjects is that science&nbsp;requires reasoning while those other subjects merely require&nbsp;scholarship.<br>&nbsp;-- Robert Heinlein')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s always darkest just before it gets pitch black.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whatever became of eternal truth?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Surprise due today.  Also the rent.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Real computer scientists don''t write code.  They occasionally tinker&nbsp;with `programming systems'', but those are so high level that they&nbsp;hardly count (and rarely count accurately; precision is for&nbsp;applications.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Parts that positively cannot be assembled in improper order will be.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who do not understand Unix are condemned to reinvent it, poorly.<br>&nbsp;-- Henry Spencer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  What''s a light-year?&nbsp;A:  One-third less calories than a regular year.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If a jury in a criminal trial stays out for more than twenty-four&nbsp;hours, it is certain to vote acquittal, save in those instances where&nbsp;it votes guilty.<br>&nbsp;-- Joseph C. Goulden')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;Safety Tips for the Post-Nuclear Existence<br>1)  Never use an elevator in a building that has been hit by a nuclear&nbsp;     bomb; use the stairs.<br>(2)  When you''re flying through the air, remember to roll when you hit&nbsp;     the ground.<br>(3)  If you''re on fire, avoid gasoline and other flammable materials.<br>(4)  Don''t attempt communication with dead people; it will only lead to&nbsp;     psychological problems.<br>(5)  Food will be scarce; you will have to scavenge.  Learn to&nbsp;     recognize foods that will be available after the bomb: mashed&nbsp;     potatoes, shredded wheat, tossed salad, ground beef, etc.<br>(6)  Put your hand over your mouth when you sneeze; internal organs&nbsp;     will be scarce in the post-nuclear age.<br>(7)  Try to be neat; fall only in designated piles.<br>(8)  Drive carefully in "Heavy Fallout" areas; people could be&nbsp;     staggering illegally.<br>(9)  Nutritionally, hundred dollar bills are equal to ones, but more&nbsp;     sanitary due to limited circulation.<br>(10) Accumulate mannequins now; spare parts will be in short supply on&nbsp;     D-Day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Police:&nbsp;Good evening, are you the host?&nbsp;Host:&nbsp;No.<br>Police:&nbsp;We''ve been getting complaints about this party.<br>Host:&nbsp;About the drugs?&nbsp;Police:&nbsp;No.<br>Host:&nbsp;About the guns, then?  Is somebody complaining about the guns?&nbsp;Police:&nbsp;No, the noise.<br>Host:&nbsp;Oh, the noise.  Well that makes sense because there are no guns<br>or drugs here.  (An enormous explosion is heard in the<br>background.)  Or fireworks.  Who''s complaining about the noise?<br>The neighbors?&nbsp;Police:&nbsp;No, the neighbors fled inland hours ago.  Most of the recent<br>complaints have come from Pittsburgh.  Do you think you could<br>ask the host to quiet things down?&nbsp;Host:&nbsp;No Problem.  (At this point, a Volkswagon bug with primitive<br>religious symbols drawn on the doors emerges from the living<br>room and roars down the hall, past the police and onto the<br>lawn, where it smashes into a tree.  Eight guests tumble out<br>onto the grass, moaning.)  See?  Things are starting to wind<br>down.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'They spell it "da Vinci" and pronounce it "da Vinchy".  Foreigners&nbsp;always spell better than they pronounce.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'George Orwell was an optimist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '7:30, Channel 5: The Bionic Dog (Action/Adventure)<br>The Bionic Dog drinks too much and kicks over the National<br>Redwood Forest.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Miss, n.:<br>A title with which we brand unmarried women to indicate that&nbsp;they are in the market.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Loud burping while walking around the airport is prohibited in&nbsp;Halstead, Kansas.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Acquaintance, n.:<br>A person whom we know well enough to borrow from, but not well&nbsp;enough to lend to.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The rhino is a homely beast,<br>For human eyes he''s not a feast.<br>Farewell, farewell, you old rhinoceros,<br>I''ll stare at something less prepoceros.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"These are DARK TIMES for all mankind''s HIGHEST VALUES!"&nbsp;"These are DARK TIMES for FREEDOM and PROSPERITY!"&nbsp;"These are GREAT TIMES to put your money on BAD GUY to kick the CRAP&nbsp;out of MEGATON MAN!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Roman Rule<br>The one who says it cannot be done should never interrupt the<br>one who is doing it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Multiply in your head" (ordered the compassionate Dr. Adams)<br>"365,365,365,365,365,365 by 365,365,365,365,365,365.  He [ten-year-old&nbsp;Truman Henry Safford] flew around the room like a top, pulled his&nbsp;pantaloons over the tops of his boots, bit his hands, rolled his eyes&nbsp;in their sockets, sometimes smiling and talking, and then seeming to be&nbsp;in an agony, until, in not more than one minute, said he,<br>133,491,850,208,566,925,016,658,299,941,583,255!"  An electronic&nbsp;computer might do the job a little faster but it wouldn''t be as much&nbsp;fun to watch.<br>&nbsp;-- James R. Newman (The World of Mathematics)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Time flies like an arrow, but fruit flies like a banana.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God made the integers; all else is the work of Man.<br>&nbsp;-- Kronecker')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Another good night not to sleep in a eucalyptus tree.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A lack of leadership is no substitute for inaction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is better never to have been born.  But who among us has such luck?&nbsp;One in a million, perhaps.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Money is the root of all evil, and man needs roots')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I suggest you locate your hot tub outside your house, so it won''t do&nbsp;too much damage if it catches fire or explodes.  First you decide which&nbsp;direction your hot tub should face for maximum solar energy.  After&nbsp;much trial and error, I have found that the best direction for a hot&nbsp;tub to face is up.<br>&nbsp;-- Dave Barry, "The Taming of the Screw"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Moon, n.:<br>1. A celestial object whose phase is very important to&nbsp;hackers.  See PHASE OF THE MOON.  2. Dave Moon (MOON@MC).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can take all the impact that science considerations have on funding&nbsp;decisions at NASA, put them in the navel of a flea, and have room left&nbsp;over for a caraway seed and Tony Calio''s heart.<br>&nbsp;-- F. Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nasrudin was carrying home a piece of liver and the recipe for liver&nbsp;pie.  Suddenly a bird of prey swooped down and snatched the piece of&nbsp;meat from his hand.  As the bird flew off, Nasrudin called after it,<br>"Foolish bird!  You have the liver, but what can you do with it without&nbsp;the recipe?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Paul Revere was a tattle-tale')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your conscience never stops you from doing anything.  It just stops you&nbsp;from enjoying it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A diplomat is a man who can convince his wife she''d look stout in a fur&nbsp;coat.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When a fly lands on the ceiling, does it do a half roll or a half&nbsp;loop?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maybe Computer Science should be in the College of Theology.<br>&nbsp;-- R. S. Barton')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In 1915 pancake make-up was invented but most people still preferred&nbsp;syrup.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A Los Angeles judge ruled that "a citizen may snore with immunity in&nbsp;his own home, even though he may be in possession of unusual and&nbsp;exceptional ability in that particular field."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Beware of the Turing Tar-pit in which everything is possible but&nbsp;nothing of interest is easy.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Government spending?  I don''t know what it''s all about.  I don''t know&nbsp;any more about this thing than an economist does, and, God knows, he&nbsp;doesn''t know much.<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Tax reform means "Don''t tax you, don''t tax me, tax that fellow behind&nbsp;the tree."<br>&nbsp;-- Russell Long')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once again, we come to the Holiday Season, a deeply religious time that&nbsp;each of us observes, in his own way, by going to the mall of his&nbsp;choice.<br>&nbsp;In the old days, it was not called the Holiday Season; the Christians&nbsp;called it "Christmas" and went to church; the Jews called it "Hanukka"&nbsp;and went to synagogue; the atheists went to parties and drank.  People&nbsp;passing each other on the street would say "Merry Christmas!" or "Happy&nbsp;Hanukka!" or (to the atheists) "Look out for the wall!"<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You worry too much about your job.  Stop it.  You''re not paid enough to&nbsp;worry.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you''ve seen one redwood, you''ve seen them all.<br>&nbsp;-- Ronald Reagan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bore, n.:<br>A guy who wraps up a two-minute idea in a two-hour vocabulary.<br>&nbsp;-- Walter Winchell')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Nine megs for the secretaries fair,<br>Seven megs for the hackers scarce,<br>Five megs for the grads in smoky lairs,<br>Three megs for system source:<br>&nbsp;One disk to rule them all,<br>One disk to bind them,<br>One disk to hold the files&nbsp;And in the darkness grind ''em.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Usage: fortune -P [] -a [xsz] [Q: [file]] [rKe9] -v6[+] dataspec ... inputdir')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The grand leap of the whale up the Fall of Niagara is esteemed, by all&nbsp;who have seen it, as one of the finest spectacles in nature.<br>&nbsp;-- Benjamin Franklin.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God wanted us to be brave, why did he give us legs?<br>&nbsp;-- Marvin Kitman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The bigger the theory the better.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Children aren''t happy without something to ignore,<br>And that''s what parents were created for.<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never be led astray onto the path of virtue.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'At no time is freedom of speech more precious than when a man hits his&nbsp;thumb with a hammer.<br>&nbsp;-- Marshall Lumsden')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Since we have to speak well of the dead, let''s knock them while they''re&nbsp;alive.<br>&nbsp;-- John Sloan')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Whatever the missing mass of the universe is, I hope it''s not&nbsp;cockroaches!"<br>&nbsp;-- Mom')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Unnamed Law:<br>If it happens, it must be possible.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cynic, n.:<br>A blackguard whose faulty vision sees things as they are, not&nbsp;as they ought to be.  Hence the custom among the Scythians of plucking&nbsp;out a cynic''s eyes to improve his vision.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brooke''s Law:<br>Whenever a system becomes completely defined, some damn fool&nbsp;discovers something which either abolishes the system or expands it&nbsp;beyond recognition.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t hate yourself in the morning -- sleep till noon.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I know the answer!  The answer lies within the heart of all mankind!&nbsp;The answer is twelve?  I think I''m in the wrong building."<br>&nbsp;-- Charles Schulz')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"If a team is in a positive frame of mind, it will have a good&nbsp;attitude.  If it has a good attitude, it will make a commitment to&nbsp;playing the game right.  If it plays the game right, it will win --&nbsp;unless, of course, it doesn''t have enough talent to win, and no manager&nbsp;can make goose-liver pate out of goose feathers, so why worry?"<br>&nbsp;-- Sparky Anderson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'One good reason why computers can do more work than people is that they&nbsp;never have to stop and answer the phone.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"It''s men like him that give the Y chromosome a bad name."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Coincidence, n.: <br>You weren''t paying attention to the other half of what was&nbsp;going on.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'SHIFT TO THE LEFT!  SHIFT TO THE RIGHT!&nbsp;POP UP, PUSH DOWN, BYTE, BYTE, BYTE!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Although golf was originally restricted to wealthy, overweight&nbsp;Protestants, today it''s open to anybody who owns hideous clothing.<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Q:  How many mathematicians does it take to screw in a lightbulb?&nbsp;A:  One.  He gives it to six Californians, thereby reducing the problem&nbsp;    to the earlier joke.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An elephant is a mouse with an operating system.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The world''s as ugly as sin,<br>And almost as delightful<br>&nbsp;-- Frederick Locker-Lampson')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;-- Gifts for Men --&nbsp;&nbsp;Men are amused by almost any idiot thing -- that is why professional&nbsp;ice hockey is so popular -- so buying gifts for them is easy.  But you&nbsp;should never buy them clothes.  Men believe they already have all the&nbsp;clothes they will ever need, and new ones make them nervous.  For&nbsp;example, your average man has 84 ties, but he wears, at most, only&nbsp;three of them.  He has learned, through humiliating trial and error,<br>that if he wears any of the other 81 ties, his wife will probably laugh&nbsp;at him ("You''re not going to wear THAT tie with that suit, are you?").<br>So he has narrowed it down to three safe ties, and has gone several&nbsp;years without being laughed at.  If you give him a new tie, he will&nbsp;pretend to like it, but deep inside he will hate you.<br>&nbsp;If you want to give a man something practical, consider tires.  More&nbsp;than once, I would have gladly traded all the gifts I got for a new set&nbsp;of tires.<br>&nbsp;-- Dave Barry, "Christmas Shopping: A Survivor''s Guide"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Texas law forbids anyone to have a pair of pliers in his possession.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A child can go only so far in life without potty training.  It is not&nbsp;mere coincidence that six of the last seven presidents were potty&nbsp;trained, not to mention nearly half of the nation''s state legislators.<br>&nbsp;-- Dave Barry')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'IBM had a PL/I,<br>Its syntax worse than JOSS:<br>And everywhere this language went,<br>It was a total loss.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When properly administered, vacations do not diminish productivity:<br>for every week you''re away and get nothing done, there''s another when&nbsp;your boss is away and you get twice as much done.<br>&nbsp;-- Daniel B. Luten')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Of all the animals, the boy is the most unmanageable.<br>&nbsp;-- Plato')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'More than any time in history, mankind now faces a crossroads.  One&nbsp;path leads to despair and utter hopelessness, the other to total&nbsp;extinction.  Let us pray that we have the wisdom to choose correctly.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Going to church does not make a person religious, nor does going to&nbsp;school make a person educated, any more than going to a garage makes a&nbsp;person a car.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As with most fine things, chocolate has its season.  There is a simple&nbsp;memory aid that you can use to determine whether it is the correct time&nbsp;to order chocolate dishes: any month whose name contains the letter A,<br>E, or U is the proper time for chocolate.<br>&nbsp;-- Sandra Boynton, "Chocolate: The Consuming Passion"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Die?  I should say not, dear fellow.  No Barrymore would allow such a&nbsp;conventional thing to happen to him."<br>&nbsp;-- John Barrymore''s dying words')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maryel brought her bat into Exit once and started whacking people on&nbsp;the dance floor.  Now everyone''s doing it.  It''s called grand slam&nbsp;dancing.<br>&nbsp;-- Ransford, Chicago Reader 10/7/83')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There are really not many jobs that actually require a penis or a&nbsp;vagina, and all other occupations should be open to everyone.<br>&nbsp;-- Gloria Steinem')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In the olden days in England, you could be hung for stealing a sheep or&nbsp;a loaf of bread.  However, if a sheep stole a loaf of bread and gave it&nbsp;to you, you would only be tried for receiving, a crime punishable by&nbsp;forty lashes with the cat or the dog, whichever was handy.  If you&nbsp;stole a dog and were caught, you were punished with twelve rabbit&nbsp;punches, although it was hard to find rabbits big enough or strong&nbsp;enough to punch you.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'For your penance, say five Hail Marys and one loud BLAH!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Sex without love is an empty experience, but, as empty experiences go,<br>it''s one of the best.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Osborn''s Law:<br>Variables won''t; constants aren''t.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m N-ary the tree, I am,<br>N-ary the tree, I am, I am.<br>I''m getting traversed by the parser next door,<br>She''s traversed me seven times before.<br>And ev''ry time it was an N-ary (N-ary!)<br>Never wouldn''t ever do a binary.  (No sir!)<br>I''m ''er eighth tree that was N-ary.<br>N-ary the tree I am, I am,<br>N-ary the tree I am.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is one of the superstitions of the human mind to have imagined that&nbsp;virginity could be a virtue.<br>&nbsp;-- Voltaire')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Accordion, n.:<br>A bagpipe with pleats.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Software, n.:<br>Formal evening attire for female computer analysts.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '99 blocks of crud on the disk,<br>99 blocks of crud!&nbsp;You patch a bug, and dump it again:<br>100 blocks of crud on the disk!&nbsp;&nbsp;100 blocks of crud on the disk,<br>100 blocks of crud!&nbsp;You patch a bug, and dump it again:<br>101 blocks of crud on the disk! ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Please ignore previous fortune.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Writing about music is like dancing about architecture.<br>&nbsp;-- Frank Zappa')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Pro is to con as progress is to Congress.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everything is controlled by a small evil group to which, unfortunately,<br>no one we know belongs.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Old soldiers never die.  Young ones do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The state law of Pennsylvania prohibits singing in the bathtub.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Weinberg''s Second Law:<br>If builders built buildings the way programmers wrote programs,<br>then the first woodpecker that came along would destroy civilization.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Crash programs fail because they are based on the theory that, with&nbsp;nine women pregnant, you can get a baby a month.<br>&nbsp;-- Wernher von Braun')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Documentation is like sex: when it is good, it is very, very good; and&nbsp;when it is bad, it is better than nothing.<br>&nbsp;-- Dick Brandon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is by the fortune of God that, in this country, we have three&nbsp;benefits: freedom of speech, freedom of thought, and the wisdom never&nbsp;to use either.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If scientific reasoning were limited to the logical processes of&nbsp;arithmetic, we should not get very far in our understanding of the&nbsp;physical world.  One might as well attempt to grasp the game of poker&nbsp;entirely by the use of the mathematics of probability.<br>&nbsp;-- Vannevar Bush')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The polite thing to do has always been to address people as they wish&nbsp;to be addressed, to treat them in a way they think dignified.  But it&nbsp;is equally important to accept and tolerate different standards of&nbsp;courtesy, not expecting everyone else to adapt to one''s own&nbsp;preferences.  Only then can we hope to restore the insult to its proper&nbsp;social function of expressing true distaste.<br>&nbsp;-- Judith Martin, "Miss Manners'' Guide to<br>&nbsp;   Excruciatingly Correct Behavior"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Zymurgy''s Law of Volunteer Labor:<br>People are always available for work in the past tense.<br>')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The surest protection against temptation is cowardice.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As I was passing Project MAC,<br>I met a Quux with seven hacks.<br>Every hack had seven bugs:<br>Every bug had seven manifestations:<br>Every manifestation had seven symptoms.<br>Symptoms, manifestations, bugs, and hacks,<br>How many losses at Project MAC?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'God is a polytheist.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The geographical center of Boston is in Roxbury.  Due north of the&nbsp;center we find the South End.  This is not to be confused with South&nbsp;Boston which lies directly east from the South End.  North of the South&nbsp;End is East Boston and southwest of East Boston is the North End.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All I ask of life is a constant and exaggerated sense of my own&nbsp;importance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'This is an especially good time for you vacationers who plan to fly,<br>because the Reagan administration, as part of the same policy under&nbsp;which it recently sold Yellowstone National Park to Wayne Newton, has&nbsp;"deregulated" the airline industry.  What this means for you, the&nbsp;consumer, is that the airlines are no longer required to follow any&nbsp;rules whatsoever.  They can show snuff movies.  They can charge for&nbsp;oxygen.  They can hire pilots right out of Vending Machine Refill&nbsp;Person School.  They can conserve fuel by ejecting husky passengers&nbsp;over water.  They can ram competing planes in mid-air.  These&nbsp;innovations have resulted in tremendous cost savings which have been&nbsp;passed along to you, the consumer, in the form of flights with&nbsp;amazingly low fares, such as $29.  Of course, certain restrictions do&nbsp;apply, the main one being that all these flights take you to Newark,<br>and you must pay thousands of dollars if you want to fly back out.<br>&nbsp;-- Dave Barry, "Iowa -- Land of Secure Vacations"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Those who can''t write, write manuals.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I couldn''t remember when I had been so disappointed.  Except perhaps&nbsp;the time I found out that M&Ms really *do* melt in your hand ..."<br>&nbsp;-- Peter Oakley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Saturday night in Toledo Ohio,<br>Is like being nowhere at all,<br>All through the day how the hours rush by,<br>You sit in the park and you watch the grass die.<br>&nbsp;-- John Denver, "Saturday Night in Toledo Ohio"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You have the body of a 19 year old.  Please return it before it gets&nbsp;wrinkled.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It is illegal to say "Oh, Boy" in Jonesboro, Georgia.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A witty saying proves nothing, but saying something pointless gets&nbsp;people''s attention.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;After his Ignoble Disgrace, Satan was being expelled from&nbsp;Heaven.  As he passed through the Gates, he paused a moment in thought,<br>and turned to God and said, "A new creature called Man, I hear, is soon&nbsp;to be created."<br>"This is true," He replied.<br>"He will need laws," said the Demon slyly.<br>"What!  You, his appointed Enemy for all Time!  You ask for the&nbsp;right to make his laws?"<br>"Oh, no!"  Satan replied, "I ask only that he be allowed to&nbsp;make his own."<br>It was so granted.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'And I heard Jeff exclaim,<br>As they strolled out of sight,<br>"Merry Christmas to all --&nbsp;You take credit cards, right?"<br>&nbsp;-- "Outsiders" comic')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The universe does not have laws -- it has habits, and habits can be&nbsp;broken.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Government lies, and newspapers lie, but in a democracy they are&nbsp;different lies.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All the passions make us commit faults; love makes us commit the most&nbsp;ridiculous ones.<br>&nbsp;-- La Rochefoucauld')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You cannot achieve the impossible without attempting the absurd.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A lack of leadership is no substitute for inaction.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I am returning this otherwise good typing paper to you because someone&nbsp;has printed gibberish all over it and put your name at the top."<br>&nbsp;-- English Professor, Ohio University')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Now that you''ve read Fortune''s diet truths, you''ll be prepared the next&nbsp;time some housewife or boutique-owner-turned-diet-expert appears on TV&nbsp;to plug her latest book.  And, if you still feel a twinge of guilt for&nbsp;eating coffee cake while listening to her exhortations, ask yourself&nbsp;the following questions:<br><br>1) Do I dare trust a person who actually considers alfalfa sprouts a&nbsp;    food?<br>2) Was the author''s sole motive in writing this book to get rich&nbsp;    exploiting the forlorn hopes of chubby people like me?<br>3) Would a longer life be worthwhile if it had to be lived as&nbsp;    prescribed ... without French-fried onion rings, pizza with&nbsp;    double cheese, or the occasional Mai-Tai?  (Remember, living&nbsp;    right doesn''t really make you live longer, it just *seems* like&nbsp;    longer.)<br>&nbsp;That, and another piece of coffee cake, should do the trick.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you can''t be good, be careful.  If you can''t be careful, give me a&nbsp;call.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You buttered your bread, now lie in it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you think the United States has stood still, who built the largest&nbsp;shopping center in the world?<br>&nbsp;-- Richard M. Nixon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do not believe in miracles -- rely on them.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Valerie: Aww, Tom, you''re going maudlin on me ...<br>Tom:&nbsp; I reserve the right to wax maudlin as I wane eloquent ...<br>&nbsp;-- Tom Chapin')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The road to hell is paved with good intentions.  And littered with&nbsp;sloppy analysis!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bugs, pl. n.:<br>Small living things that small living boys throw on small&nbsp;living girls.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Dimensions will always be expressed in the least usable term.<br>Velocity, for example, will be expressed in furlongs per fortnight.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Take it easy, we''re in a hurry.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bacchus, n.:<br>A convenient deity invented by the ancients as an excuse for&nbsp;getting drunk.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Weinberg''s First Law:<br>Progress is made on alternate Fridays.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The revolution will not be televised.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Let''s just say that where a change was required, I adjusted.  In every&nbsp;relationship that exists, people have to seek a way to survive.  If you&nbsp;really care about the person, you do what''s necessary, or that''s the&nbsp;end.  For the first time, I found that I really could change, and the&nbsp;qualities I most admired in myself I gave up.  I stopped being loud and&nbsp;bossy ...  Oh, all right.  I was still loud and bossy, but only behind&nbsp;his back."<br>&nbsp;-- Kate Hepburn, on Tracy and Hepburn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be wary of strong drink.  It can make you shoot at tax collectors and&nbsp;miss<br>&nbsp;-- Lazarus Long, "Time Enough for Love"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;MORE SPORTS RESULTS:<br>The Beverly Hills Freudians tied the Chicago Rogerians 0-0 last&nbsp;Saturday night.  The match started with a long period of silence while&nbsp;the Freudians waited for the Rogerians to free associate and the&nbsp;Rogerians waited for the Freudians to say something they could&nbsp;paraphrase.  The stalemate was broken when the Freudians'' best player&nbsp;took the offensive and interpreted the Rogerians'' silence as reflecting&nbsp;their anal-retentive personalities.  At this the Rogerians'' star player&nbsp;said "I hear you saying you think we''re full of ka-ka."  This started a&nbsp;fight and the match was called by officials.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The misnaming of fields of study is so common as to lead to what might&nbsp;be general systems laws.  For example, Frank Harary once suggested the&nbsp;law that any field that had the word "science" in its name was&nbsp;guaranteed thereby not to be a science.  He would cite as examples&nbsp;Military Science, Library Science, Political Science, Homemaking&nbsp;Science, Social Science, and Computer Science.  Discuss the generality&nbsp;of this law, and possible reasons for its predictive&nbsp;power.<br>&nbsp;-- Gerald Weinberg, "An Introduction to General Systems<br>&nbsp;   Thinking."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Idiot Box, n.:<br>The part of the envelope that tells a person where to place the&nbsp;stamp when they can''t quite figure it out for themselves.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What publishers are looking for these days isn''t radical feminism.<br>It''s corporate feminism -- a brand of feminism designed to sell books&nbsp;and magazines, three-piece suits, airline tickets, Scotch, cigarettes&nbsp;and, most important, corporate America''s message, which runs: "Yes,<br>women were discriminated against in the past, but that unfortunate&nbsp;mistake has been remedied; now every woman can attain wealth, prestige&nbsp;and power by dint of individual rather than collective effort."<br>&nbsp;-- Susan Gordon')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never call a man a fool.  Borrow from him.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A triangle which has an angle of 135 degrees is called an obscene&nbsp;triangle.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Fortune''s Fictitious Country Song Title of the Week:<br>"How Can I Miss You if You Won''t Go Away?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The first riddle I ever heard, one familiar to almost every Jewish&nbsp;child, was propounded to me by my father:<br>"What is it that hangs on the wall, is green, wet -- and&nbsp;whistles?"<br>I knit my brow and thought and thought, and in final perplexity&nbsp;gave up.<br>"A herring," said my father.<br>"A herring," I echoed.  "A herring doesn''t hang on the wall!"<br>"So hang it there."<br>"But a herring isn''t green!"  I protested.<br>"Paint it."<br>"But a herring isn''t wet."<br>"If it''s just painted it''s still wet."<br>"But -- " I sputtered, summoning all my outrage, "-- a herring&nbsp;doesn''t whistle!!"<br>"Right, " smiled my father.  "I just put that in to make it&nbsp;hard."<br>&nbsp;-- Leo Rosten, "The Joys of Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Excellent day for putting Slinkies on an escalator.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;"Gee, Mudhead, everyone at More Science High has an&nbsp;extracurricular activity except you."<br>"Well, gee, doesn''t Louise count?"<br>"Only to ten, Mudhead."&nbsp;<br>&nbsp;&nbsp;-- Firesign Theater')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Last yeer I kudn''t spel Engineer.  Now I are won.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Beware of self-styled experts: an ex is a has-been, and a spurt is a&nbsp;drip under pressure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Good day to avoid cops.  Crawl to school.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Antonym, n.:<br>The opposite of the word you''re trying to think of.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In Columbia, Pennsylvania, it is against the law for a pilot to tickle&nbsp;a female flying student under her chin with a feather duster in order&nbsp;to get her attention.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I want to buy a husband who, every week when I sit down to watch `St.<br>Elsewhere'', won''t scream, `FORGET IT, BLANCHE ... IT''S TIME FOR "HEE&nbsp;HAW"!!''"<br>&nbsp;-- Berke Breathed, "Bloom County"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Don''t go surfing in South Dakota for a while.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Cecil, you''re my final hope&nbsp;Of finding out the true Straight Dope&nbsp;For I have been reading of Schrodinger''s cat&nbsp;But none of my cats are at all like that.<br>This unusual animal (so it is said)<br>Is simultaneously alive and dead!&nbsp;What I don''t understand is just why he&nbsp;Can''t be one or the other, unquestionably.<br>My future now hangs in between eigenstates.<br>In one I''m enlightened, in the other I ain''t.<br>If *you* understand, Cecil, then show me the way&nbsp;And rescue my psyche from quantum decay.<br>But if this queer thing has perplexed even you,<br>Then I will *___^H^H^Hand* I won''t see you in Schrodinger''s zoo.<br>&nbsp;-- Randy F., Chicago, "The Straight Dope, a compendium<br>&nbsp;   of human knowledge" by Cecil Adams')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Next to being shot at and missed, nothing is really quite as satisfying&nbsp;as an income tax refund.<br>&nbsp;-- F. J. Raymond')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'To understand this important story, you have to understand how the&nbsp;telephone company works.  Your telephone is connected to a local&nbsp;computer, which is in turn connected to a regional computer, which is&nbsp;in turn connected to a loudspeaker the size of a garbage truck on the&nbsp;lawn of Edna A. Bargewater of Lawrence, Kan.<br>&nbsp;Whenever you talk on the phone, your local computer listens in.  If it&nbsp;suspects you''re going to discuss an intimate topic, it notifies the&nbsp;computer above it, which listens in and decides whether to alert the&nbsp;one above it, until finally, if you really humiliate yourself, maybe&nbsp;break down in tears and tell your closest friend about a sordid&nbsp;incident from your past involving a seedy motel, a neighbor''s spouse,<br>an entire religious order, a garden hose and six quarts of tapioca&nbsp;pudding, the top computer feeds your conversation into Edna''s&nbsp;loudspeaker, and she and her friends come out on the porch to listen&nbsp;and drink gin and laugh themselves silly.<br>&nbsp;-- Dave Barry, "Won''t It Be Just Great Owning Our Own<br>&nbsp;   Phones?"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Impossible, adj.:<br>(1) I wouldn''t like it and when it happens I won''t approve:<br>(2) I can''t be bothered; (3) God can''t be bothered.  Meaning (3) may&nbsp;perhaps be valid but the others are 101% whaledreck.<br>&nbsp;-- Chad C. Mulligan, "The Hipcrime Vocab"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Maybe you can''t buy happiness, but these days you can certainly charge&nbsp;it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A language that doesn''t have everything is actually easier to program&nbsp;in than some that do.<br>&nbsp;-- Dennis M. Ritchie')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Endless Loop: n., see Loop, Endless.<br>Loop, Endless: n., see Endless Loop.<br>&nbsp;-- Random Shack Data Processing Dictionary')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Lizzie Borden took an axe,<br>And plunged it deep into the VAX:<br>Don''t you envy people who&nbsp;Do all the things ___^H^H^HYOU want to do?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A strong conviction that something must be done is the parent of many&nbsp;bad measures.<br>&nbsp;-- Daniel Webster')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'How do you explain school to a higher intelligence?<br>&nbsp;-- Elliot, "E.T."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I went into a general store, and they wouldn''t sell me anything&nbsp;specific".<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"So she went into the garden to cut a cabbage leaf to make an apple&nbsp;pie; and at the same time a great she-bear, coming up the street pops&nbsp;its head into the shop. "What! no soap?"  So he died, and she very&nbsp;imprudently married the barber; and there were present the Picninnies,<br>and the Grand Panjandrum himself, with the little round button at top,<br>and they all fell to playing the game of catch as catch can, till the&nbsp;gunpowder ran out at the heels of their boots."<br>&nbsp;-- Samuel Foote')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'In India, "cold weather" is merely a conventional phrase and has come&nbsp;into use through the necessity of having some way to distinguish&nbsp;between weather which will melt a brass door-knob and weather which&nbsp;will only make it mushy.<br>&nbsp;-- Mark Twain')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never commit yourself!  Let someone else commit you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'O give me a home,<br>Where the buffalo roam,<br>Where the deer and the antelope play,<br>Where seldom is heard&nbsp;A discouraging word,<br>''Cause what can an antelope say?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone can make an omelet with eggs.  The trick is to make one with&nbsp;none.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When a Banker jumps out of a window, jump after him -- that''s where the&nbsp;money is.<br>&nbsp;-- Robespierre')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;&nbsp;ACHTUNG!!!&nbsp;&nbsp;Das machine is nicht fur gefingerpoken und mittengrabben.  Ist easy&nbsp;schnappen der springenwerk, blowenfusen und corkenpoppen mit&nbsp;spitzensparken.  Ist nicht fur gewerken by das dummkopfen.  Das&nbsp;rubbernecken sightseeren keepen hands in das pockets.  Relaxen und&nbsp;vatch das blinkenlights!!!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Passionate hatred can give meaning and purpose to an empty life.<br>&nbsp;-- Eric Hoffer')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It may be bad manners to talk with your mouth full, but it isn''t too&nbsp;good either if you speak when your head is empty.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What is worth doing is worth the trouble of asking somebody to do.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Crown is full of it!<br>&nbsp;-- Nate Harris, 1775')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your lucky color has faded.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bypasses are devices that allow some people to dash from point A to&nbsp;point B very fast while other people dash from point B to point A very&nbsp;fast.  People living at point C, being a point directly in between, are&nbsp;often given to wonder what''s so great about point A that so many people&nbsp;from point B are so keen to get there and what''s so great about point B&nbsp;that so many people from point A are so keen to get _____^H^H^H^H^Hthere.  They often&nbsp;wish that people would just once and for all work out where the hell&nbsp;they wanted to be.<br>&nbsp;-- Douglas Adams, "The Hitchhiker''s Guide to the Galaxy"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You can create your own opportunities this week.  Blackmail a senior&nbsp;executive.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bizarreness is the essence of the exotic')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Why are we importing all these highbrow plays like `Amadeus''?  I could&nbsp;have told you Mozart was a jerk for nothing."<br>&nbsp;-- Ian Shoales')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A recent study has found that concentrating on difficult off-screen&nbsp;objects, such as the faces of loved ones, causes eye strain in computer&nbsp;scientists.  Researchers into the phenomenon cite the added&nbsp;concentration needed to "make sense" of such unnatural three&nbsp;dimensional objects ...')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When we understand knowledge-based systems, it will be as before --&nbsp;except our fingertips will have been singed.<br>&nbsp;-- Epigrams in Programming, ACM SIGPLAN Sept. 1982')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Be free and open and breezy!  Enjoy!  Things won''t get any better so&nbsp;get used to it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'No matter what other nations may say about the United States,<br>immigration is still the sincerest form of flattery.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Anyone who hates Dogs and Kids Can''t be All Bad.<br>&nbsp;-- W. C. Fields')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The sooner you make your first 5000 mistakes, the sooner you will be&nbsp;able to correct them.<br>&nbsp;-- Nicolaides')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Preacher, the Politician, the Teacher,<br>Were each of them once a kiddie.<br>A child, indeed, is a wonderful creature.<br>Do I want one?  God Forbiddie!<br>&nbsp;-- Ogden Nash')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Mistakes are often the stepping stones to utter failure.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you think last Tuesday was a drag, wait till you see what happens&nbsp;tomorrow!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I just need enough to tide me over until I need more."<br>&nbsp;-- Bill Hoest')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Frobnitz, pl. Frobnitzem (frob''nitsm) n.:<br>An unspecified physical object, a widget.  Also refers to&nbsp;electronic black boxes.  This rare form is usually abbreviated to&nbsp;FROTZ, or more commonly to FROB.  Also used are FROBNULE, FROBULE, and&nbsp;FROBNODULE.  Starting perhaps in 1979, FROBBOZ (fruh-bahz''), pl.<br>FROBBOTZIM, has also become very popular, largely due to its exposure&nbsp;via the Adventure spin-off called Zork (Dungeon).  These can also be&nbsp;applied to non-physical objects, such as data structures.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hi there!  This is just a note from me, to you, to tell you, the person&nbsp;reading this note, that I can''t think up any more famous quotes, jokes,<br>nor bizarre stories, so you may as well go home.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'He had occasional flashes of silence that made his conversation&nbsp;perfectly delightful.<br>&nbsp;-- Sydney Smith')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Keep Cool, but Don''t Freeze<br>&nbsp;- Hellman''s Mayonnaise')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;&nbsp;Answers to Last Fortune''s Questions:<br><br>1) None.  (Moses didn''t have an ark).<br>(2) Your mother, by the pigeonhole principle.<br>(3) I don''t know.<br>(4) Who cares?<br>5) 6 (or maybe 4, or else 3).  Mr. Alfred J. Duncan of Podunk,<br>    Montana, submitted an interesting solution to Problem 5.<br>(6) There is an interesting solution to this problem on page 1029 of my&nbsp;    book, which you can pick up for $23.95 at finer bookstores and&nbsp;    bathroom supply outlets (or 99 cents at the table in front of&nbsp;    Papyrus Books).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It''s so stupid of modern civilization to have given up believing in the&nbsp;Devil when he is the only explanation of it.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If life is a stage, I want some better lighting.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'What if everything is an illusion and nothing exists?  In that case, I&nbsp;definitely overpaid for my carpet.<br>&nbsp;-- Woody Allen, "Without Feathers"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All of the true things I am about to tell you are shameless lies.<br>&nbsp;-- The Book of Bokonon / Kurt Vonnegut Jr.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There is a Massachusetts law requiring all dogs to have their hind legs&nbsp;tied during the month of April.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Imagine if every Thursday your shoes exploded if you tied them the&nbsp;usual way.  This happens to us all the time with computers, and nobody&nbsp;thinks of complaining."<br>&nbsp;-- Jeff Raskin, interviewed in Doctor Dobb''s Journal')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Frankfort, Kentucky, makes it against the law to shoot off a&nbsp;policeman''s tie.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Do not meddle in the affairs of troff, for it is subtle and quick to&nbsp;anger.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'default, n.:<br>[Possibly from Black English "De fault wid dis system is you,<br>mon."] The vain attempt to avoid errors by inactivity.  "Nothing will&nbsp;come of nothing: speak again." -- King Lear.<br>&nbsp;-- Stan Kelly-Bootle, "The Devil''s DP Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I think sex is better than logic, but I can''t prove it."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The easiest way to figure the cost of living is to take your income and&nbsp;add ten percent.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... indifference is a militant thing ... when it goes away it leaves&nbsp;smoking ruins, where lie citizens bayonetted through the throat.  It is&nbsp;not a children''s pastime like mere highway robbery.<br>&nbsp;-- Stephen Crane')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"The other day I put instant coffee in my microwave oven ... I almost&nbsp;went back in time."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"A raccoon tangled with a 23,000 volt line today.  The results blacked&nbsp;out 1400 homes and, of course, one raccoon."<br>&nbsp;-- Steel City News')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Laughter is the closest distance between two people."  <br>&nbsp;-- Victor Borge')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Army needs leaders the way a foot needs a big toe.<br>&nbsp;-- Bill Murray')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I do hate sums.  There is no greater mistake than to call arithmetic an&nbsp;exact science.  There are permutations and aberrations discernible to&nbsp;minds entirely noble like mine; subtle variations which ordinary&nbsp;accountants fail to discover; hidden laws of number which it requires a&nbsp;mind like mine to perceive.  For instance, if you add a sum from the&nbsp;bottom up, and then again from the top down, the result is always&nbsp;different.<br>&nbsp;-- Mrs. La Touche (19th cent.)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"I have two very rare photographs: one is a picture of Houdini locking&nbsp;his keys in his car; the other is a rare photograph of Norman Rockwell&nbsp;beating up a child."<br>&nbsp;-- Steven Wright')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Rules for driving in New York:<br>(1) Anything done while honking your horn is legal.<br>(2) You may park anywhere if you turn your four-way flashers<br>    on.<br>(3) A red light means the next six cars may go through the<br>    intersection.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'First Law of Procrastination:<br>Procrastination shortens the job and places the responsibility&nbsp;for its termination on someone else (i.e., the authority who imposed&nbsp;the deadline).')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Eeny, Meeny, Jelly Beanie, the spirits are about to speak!<br>&nbsp;-- Bullwinkle Moose')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'As Zeus said to Narcissus, "Watch yourself."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hindsight is an exact science.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ours is a world of nuclear giants and ethical infants.<br>&nbsp;-- General Omar N. Bradley')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Wrong," said Renner.<br>&nbsp;"The tactful way," Rod said quietly, "the polite way to disagree with&nbsp;the Senator would be to say, `That turns out not to be the case.''"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A lady with one of her ears applied&nbsp;To an open keyhole heard, inside,<br>Two female gossips in converse free --&nbsp;The subject engaging them was she.<br>"I think", said one, "and my husband thinks&nbsp;That she''s a prying, inquisitive minx!"&nbsp;As soon as no more of it she could hear&nbsp;The lady, indignant, removed her ear.<br>"I will not stay," she said with a pout,<br>"To hear my character lied about!"<br>&nbsp;-- Gopete Sherany')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Murphy''s Law, that brash proletarian restatement of Godel''s Theorem ..."<br>&nbsp;-- Thomas Pynchon, "Gravity''s Rainbow"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Everything is worth precisely as much as a belch, the difference being&nbsp;that a belch is more satisfying.<br>&nbsp;-- Ingmar Bergman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hier liegt ein Mann ganz obnegleich:<br>Im Leibe dick, an Suden reich.<br>Wir haben ihn in das Grab gesteckt,&nbsp;Here lies a man with sundry flaws&nbsp;Weil es uns dunkt er sei verreckt.&nbsp;And numerous Sins upon his head;<br>&nbsp;&nbsp;&nbsp;&nbsp;We buried him today because<br>&nbsp;&nbsp;&nbsp;&nbsp;As far as we can tell, he''s dead.<br>&nbsp;-- PDQ Bach''s epitaph, as requested by his cousin Betty<br>&nbsp;   Sue Bach and written by the local doggerel catcher;<br>&nbsp;   "The Definitive Biography of PDQ Bach", Peter<br>&nbsp;   Schickele')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'History is curious stuff<br>You''d think by now we had enough&nbsp;Yet the fact remains I fear<br>They make more of it every year.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Even if you''re on the right track, you''ll get run over if you just sit&nbsp;there."<br>&nbsp;-- Will Rogers')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Those who do not do politics will be done in by politics."<br>&nbsp;-- French Proverb')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If God had meant for us to be naked, we would have been born that way.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Official MBA Handbook on business cards:<br>Avoid overly pretentious job titles such as "Lord of the Realm,<br>Defender of the Faith, Emperor of India" or "Director of Corporate&nbsp;Planning."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'ASHes to ASHes, DOS to DOS.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The United States also has its native Fascists who say that they are&nbsp;"100 percent American"...<br>&nbsp;-- U. S. Army (1945)')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A nuclear war can ruin your whole day.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Yinkel, n.:<br>A person who combs his hair over his bald spot, hoping no one&nbsp;will notice.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '... The Anarchists'' [national] anthem is an international anthem that&nbsp;consists of 365 raspberries blown in very quick succession to the tune&nbsp;of "Camptown Races".  Nobody has to stand up for it, nobody has to&nbsp;listen to it, and, even better, nobody has to play it.<br>&nbsp;-- Mike Harding, "The Armchair Anarchist''s Almanac"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Alden''s Laws:<br>(1) Giving away baby clothes and furniture is the major cause<br>    of pregnancy.<br>(2) Always be backlit.<br>(3) Sit down whenever possible.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Furbling, v.:<br>Having to wander through a maze of ropes at an airport or bank&nbsp;even when you are the only person in line.<br>&nbsp;-- Rich Hall, "Sniglets"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Ah, but the choice of dreams to live, &nbsp;there''s the rub.<br>&nbsp;For all dreams are not equal,<br>some exit to nightmare&nbsp;most end with the dreamer&nbsp;&nbsp;But at least one must be lived ... and died.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'It will be generally found that those who sneer habitually at human&nbsp;nature and affect to despise it, are among its worst and least pleasant&nbsp;examples.<br>&nbsp;-- Charles Dickens')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You possess a mind not merely twisted, but actually sprained.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Losing your drivers'' license is just God''s way of saying "BOOGA,<br>BOOGA!"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Every program has at least one bug and can be shortened by at least one&nbsp;instruction -- from which, by induction, one can deduce that every&nbsp;program can be reduced to one instruction which doesn''t work.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;THE LESSER-KNOWN PROGRAMMING LANGUAGES #12: LITHP&nbsp;&nbsp;This otherwise unremarkable language is distinguished by the absence of&nbsp;an "S" in its character set; users must substitute "TH".  LITHP is said&nbsp;to be useful in protheththing lithtth.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You are here:   <br>&nbsp;***<br>&nbsp;***<br>     *********<br>      *******<br>       *****<br>&nbsp;***<br>&nbsp; *&nbsp;<br>&nbsp; But you''re not all there.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Five is a sufficiently close approximation to infinity.<br>&nbsp;-- Robert Firth')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Asked by reporters about his upcoming marriage to a forty-two-year-old&nbsp;woman, director Roman Polanski told reporters, `The way I look at it,<br>she''s the equivalent of three fourteen-year-olds.''"<br>&nbsp;-- David Letterman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'You know you''re a little fat if you have stretch marks on your car.<br>&nbsp;-- Cyrus, Chicago Reader 1/22/82')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'If you can lead it to water and force it to drink, it isn''t a horse.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'MOCK APPLE PIE (No Apples Needed)<br>&nbsp;  Pastry to two crust 9-inch pie&nbsp;36 RITZ Crackers&nbsp;2 cups water&nbsp;&nbsp;&nbsp;&nbsp; 2 cups sugar&nbsp;2 teaspoons cream of tartar&nbsp;&nbsp; 2 tablespoons lemon juice&nbsp;  Grated rind of one lemon&nbsp;&nbsp;   Butter or margarine&nbsp;  Cinnamon&nbsp;&nbsp;Roll out bottom crust of pastry and fit into 9-inch pie plate.  Break&nbsp;RITZ Crackers coarsely into pastry-lined plate.  Combine water, sugar&nbsp;and cream of tartar in saucepan, boil gently for 15 minutes.  Add lemon&nbsp;juice and rind.  Cool.  Pour this syrup over Crackers, dot generously&nbsp;with butter or margarine and sprinkle with cinnamon.  Cover with top&nbsp;crust.  Trim and flute edges together.  Cut slits in top crust to let&nbsp;steam escape.  Bake in a hot oven (425 F) 30 to 35 minutes, until crust&nbsp;is crisp and golden.  Serve warm.  Cut into 6 to 8 slices.<br>&nbsp;-- Found lurking on a Ritz Crackers box')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Brain, v. [as in "to brain"]:<br>To rebuke bluntly, but not pointedly; to dispel a source of&nbsp;error in an opponent.<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'After a few boring years, socially meaningful rock ''n'' roll died out.<br>It was replaced by disco, which offers no guidance to any form of life&nbsp;more advanced than the lichen family.<br>&nbsp;-- Dave Barry, "Kids Today: They Don''t Know Dum Diddly<br>&nbsp;   Do"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Never try to outstubborn a cat.<br>&nbsp;-- Lazarus Long, "Time Enough for Love"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The Heineken Uncertainty Principle:<br>You can never be sure how many beers you had last night.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The lion and the calf shall lie down together but the calf won''t get&nbsp;much sleep.<br>&nbsp;-- Woody Allen')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bucy''s Law:<br>Nothing is ever accomplished by a reasonable man.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Turnaucka''s Law:<br>The attention span of a computer is only as long as its&nbsp;electrical cord.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Experience is what you get when you were expecting something else.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'we will invent new lullabies, new songs, new acts of love,<br>we will cry over things we used to laugh &&nbsp;our new wisdom will bring tears to eyes of gentile&nbsp;creatures from other planets who were afraid of us till then &&nbsp;in the end a summer with wild winds &&nbsp;new friends will be.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hanlon''s Razor:<br>Never attribute to malice that which is adequately explained by&nbsp;stupidity.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The faster we go, the rounder we get.<br>&nbsp;-- The Grateful Dead')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'All theoretical chemistry is really physics:<br>and all theoretical chemists know it.<br>&nbsp;-- Richard P. Feynman')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'An attorney was defending his client against a charge of first-degree&nbsp;murder.  "Your Honor, my client is accused of stuffing his lover''s&nbsp;mutilated body into a suitcase and heading for the Mexican border.<br>Just north of Tijuana a cop spotted her hand sticking out of the&nbsp;suitcase.  Now, I would like to stress that my client is *not* a&nbsp;murderer.  A sloppy packer, maybe..."')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Surprise your boss.  Get to work on time.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Does the name Pavlov ring a bell?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"This is a job for BOB VIOLENCE and SCUM, the INCREDIBLY STUPID MUTANT&nbsp;DOG."<br>&nbsp;-- Bob Violence')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Your analyst has you mixed up with another patient.  Don''t believe a&nbsp;thing he tells you.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A person is just about as big as the things that make them angry.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Once at a social gathering, Gladstone said to Disraeli, "I predict,<br>Sir, that you will die either by hanging or of some vile disease".<br>Disraeli replied, "That all depends upon whether I embrace your&nbsp;principals or your mistress".')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Whenever anyone says, "theoretically", they really mean, "not really".<br>&nbsp;-- Dave Parnas')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hard work may not kill you, but why take chances?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'A baby is God''s opinion that the world should go on.<br>&nbsp;-- Carl Sandburg')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Swipple''s Rule of Order:<br>He who shouts the loudest has the floor.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Honorable, adj.:<br>Afflicted with an impediment in one''s reach.  In legislative&nbsp;bodies, it is customary to mention all members as honorable; as, "the&nbsp;honorable gentleman is a scurvy cur."<br>&nbsp;-- Ambrose Bierce, "The Devil''s Dictionary"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'With every passing hour our solar system comes forty-three thousand&nbsp;miles closer to globular cluster M13 in the constellation Hercules, and&nbsp;still there are some misfits who continue to insist that there is no&nbsp;such thing as progress.<br>&nbsp;-- Ransom K. Ferm')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'I''m a Lisp variable -- bind me!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '&nbsp;There are some goyisha names that just about guarantee that&nbsp;someone isn''t Jewish.  For example, you''ll never meet a Jew named&nbsp;Johnson or Wright or Jones or Sinclair or Ricks or Stevenson or Reid or&nbsp;Larsen or Jenks.  But some goyisha names just about guarantee that&nbsp;every other person you meet with that name will be Jewish.  Why is&nbsp;this?<br>Who knows?  Learned rabbis have pondered this question for&nbsp;centuries and have failed to come up with an answer, and you think ___^H^H^Hyou&nbsp;can find one?  Get serious.  You don''t even understand why it''s&nbsp;forbidden to eat crab -- fresh cold crab with mayonnaise -- or lobster&nbsp;-- soft tender morsels of lobster dipped in melted butter.  You don''t&nbsp;even understand a simple thing like that, and yet you hope to discover&nbsp;why there are more Jews named Miller than Katz?  Fat Chance.<br>&nbsp;-- Arthur Naiman, "Every Goy''s Guide to Yiddish"')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Canada Post doesn''t really charge 32 cents for a stamp.  It''s 2 cents&nbsp;for postage and 30 cents for storage.<br>&nbsp;-- Gerald Regan, Cabinet Minister, 12/31/83 Financial<br>&nbsp;   Post')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'There''s no easy quick way out, we''re gonna have to live through our&nbsp;whole lives, win, lose, or draw.<br>&nbsp;-- Walt Kelly')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'When you don''t know what you are doing, do it neatly.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Bureaucrat, n.:<br>A person who cuts red tape sideways.<br>&nbsp;-- J. McCabe')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"Well," Brahma said, "even after ten thousand explanations, a fool is&nbsp;no wiser, but an intelligent man requires only two thousand five&nbsp;hundred."<br>&nbsp;-- The Mahabharata.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Love is sentimental measles.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The generation of random numbers is too important to be left to&nbsp;chance.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Experience is the worst teacher.  It always gives the test first and&nbsp;the instruction afterward.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Review Questions&nbsp;<br>1) If Nerd on the planet Nutley starts out in his spaceship at 20 KPH,<br>    and his speed doubles every 3.2 seconds, how long will it be before&nbsp;    he exceeds the speed of light?  How long will it be before the&nbsp;    Galactic Patrol picks up the pieces of his spaceship?&nbsp;<br>2) If Roger Rowdy wrecks his car every week, and each week he breaks&nbsp;    twice as many bones as before, how long will it be before he breaks&nbsp;    every bone in his body?  How long will it be before they cut off&nbsp;    his insurance?  Where does he get a new car every week?&nbsp;<br>3) If Johnson drinks one beer the first hour (slow start), four beers&nbsp;    the next hour, nine beers the next, etc., and stacks the cans in a&nbsp;    pyramid, how soon will Johnson''s pyramid be larger than King&nbsp;    Tut''s?  When will it fall on him?  Will he notice?')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Carmel, New York, has an ordinance forbidding men to wear coats and&nbsp;trousers that don''t match.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'Hail to the sun god&nbsp;He sure is a fun god&nbsp;Ra!  Ra!  Ra!')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'New Hampshire law forbids you to tap your feet, nod your head, or in&nbsp;any way keep time to the music in a tavern, restaurant, or cafe.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'NEWS FLASH!!<br>Today the East German pole-vault champion became the West<br>German pole-vault champion.')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, 'The fact that it works is immaterial.<br>&nbsp;-- L. Ogborn')
GO

INSERT INTO Quote (Guid, LegacyID, Data) VALUES (NEWID(), null, '"His mind is like a steel trap -- full of mice"<br>&nbsp;-- Foghorn Leghorn')
GO
