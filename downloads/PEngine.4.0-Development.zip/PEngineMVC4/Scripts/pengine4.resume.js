﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    resume: {
        display_section_src: null,

        editor_template_src: null,

        editor_template: null,

        editor_data: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        editor_launch: function () {
            var ajaxProps = [{
                url: pengine.resume.editor_get_url, cache: false, type: "GET", success: function (data) {
                    pengine.resume.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can edit the resume." }, false, function () { pengine.resume.editor_launch(); });
                    }
                }
            }];

            if (!pengine.resume.editor_template_src && !pengine.resume.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.resume.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.resume.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.resume.editor_template) {
                    pengine.resume.editor_template = pengine.template.compile(pengine.resume.editor_template_src);
                }
                var form = pengine.resume.editor_template(pengine.resume.editor_data);
                $("body").append($(form).attr("id", "pengine_resume_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                pengine.resume.editor_current_change();
                $("#pengine_resume_editor").slideDown('fast', function () { pengine.resume.editor_configure(); });
            });
        },

        editor_configure: function () {
            $("#resume_edit_button_save").on("click", function () {
                pengine.resume.editor_save();
                return false;
            });

            $("#resume_edit_button_close").on("click", function () {
                pengine.resume.editor_dispose();
                return false;
            });

            $("#resume_edit_currentsection").on("change", function () {
                pengine.resume.editor_current_change();
            });

            $("#skilltype_edit_button_add").on("click", function () {
                pengine.resume.editor_section_add_skilltype();
                return false;
            });

            $("#education_edit_button_add").on("click", function () {
                pengine.resume.editor_section_add_education();
                return false;
            });

            $("#workhistory_edit_button_add").on("click", function () {
                pengine.resume.editor_section_add_workhistory();
                return false;
            });

            $("#resume_edit_button_delete").on("click", function () {
                pengine.resume.editor_section_delete();
                return false;
            });

            $("#pengine_resume_editor .resume_edit_page").each(function(idx, ele) {
                if (!$(ele).attr("id") || $(ele).attr("id") == '') {
                    pengine.resume.editor_configure_section(ele);
                }
            });

            $("#resume_edit_currentsection").focus();

            pengine.focus.set_default_button("#pengine_resume_editor", null, true);
            pengine.window.resize();
        },

        editor_configure_section: function (container) {
            $(container).find(".sectionidfield").on("change", function () {
                var container = $(this).closest(".resume_edit_page");
                var prefix = "";
                if ($(container).hasClass("resume_edit_skilltype_data")) {
                    prefix = "SkillTypeSection_";
                }
                if ($(container).hasClass("resume_edit_education_data")) {
                    prefix = "EducationSection_";
                }
                if ($(container).hasClass("resume_edit_workhistory_data")) {
                    prefix = "WorkHistorySection_";
                }
                var oldName = prefix + $(container).attr("data-section-name");
                var newName = prefix + $(this).val();
                if (oldName != newName) {
                    if ($("#resume_edit_currentsection option[value=\"" + newName + "\"]").length > 0) {
                        $(this).val(oldName);
                        pengine.notification.display_one("A section of this type with this name already exists within this resume!", "error", 1000, true);
                    }
                    else {
                        $("#resume_edit_currentsection option[value=\"" + oldName + "\"]").attr("value", newName).text("[Section] " + newName);
                        $(container).attr("data-section-name", newName);
                    }
                }
            });

            $(container).find(".datepicker").datepicker({ showOn: "focus" });

            pengine.focus.set_default_button(container, null, true);

        },

        editor_current_change: function () {
            switch ($("#resume_edit_currentsection").val().toLowerCase())
            {
                case "PersonalSection":
                case "ObjectiveSection":
                    $("#resume_edit_button_delete").hide();
                    break;
                default:
                    $("#resume_edit_button_delete").show();
                    break;
            }
            $(".resume_edit_page").hide();
            $(".resume_edit_page[data-section-name=\"" + $("#resume_edit_currentsection").val() + "\"]").css("display", "block");
        },

        editor_section_add_skilltype: function () {
            pengine.resume.editor_section_add("SkillTypeSection_", "3 [SkillType]", "New SkillType",
                "#resume_edit_skilltype_container", ".resume_edit_skilltype_data", ".sectionidfield",
                "#resume_edit_skilltype_new");
        },

        editor_section_add_education: function () {
            pengine.resume.editor_section_add("EducationSection_", "4 [Education]", "New Education",
                "#resume_edit_education_container", ".resume_edit_education_data", ".sectionidfield",
                "#resume_edit_education_new");
        },

        editor_section_add_workhistory: function () {
            pengine.resume.editor_section_add("WorkHistory_", "5 [WorkHistory]", "New Work History",
                "#resume_edit_workhistory_container", ".resume_edit_workhistory_data", ".sectionidfield",
                "#resume_edit_workhistory_new");
        },

        editor_section_add: function (name_prefix, text_prefix, default_text, containerid, sectionclass, idctlclass, newid) {
            var tmpCtr = 1;
            var tmpName = default_text + " " + tmpCtr;
            while ($("#resume_edit_currentsection option[value=\"" + name_prefix + tmpName + "\"]").length > 0) {
                tmpCtr++;
                tmpName = default_text + " " + tmpCtr
            }
            $(containerid).append($(newid).clone().attr("id", null).css("display", "none").attr("data-section-name", name_prefix + tmpName));
            pengine.resume.editor_configure_section($(containerid + " " + sectionclass).last());
            $(containerid + " " + sectionclass).last().find(idctlclass).val(tmpName);
            $("#resume_edit_currentsection").append($("<option></option>").attr("value", name_prefix + tmpName).text(text_prefix + " " + tmpName));

            var items = $("#resume_edit_currentsection").children('option').get();
            items.sort(function (a, b) {
                var compA = $(a).text().toUpperCase();
                var compB = $(b).text().toUpperCase();
                return (compA < compB) ? -1 : (compA > compB) ? 1 : 0;
            });

            $("#resume_edit_currentsection").children('option').remove();
            $(items).appendTo("#resume_edit_currentsection");

            $("#resume_edit_currentsection").val(name_prefix + tmpName);
            pengine.resume.editor_current_change();
        },

        editor_section_delete: function () {
            if ($("#resume_edit_currentsection").val() != '') {
                $(".resume_edit_page[data-section-name=\"" + $("#resume_edit_currentsection").val() + "\"]").remove();
                $("#resume_edit_currentsection option[value=\"" + $("#resume_edit_currentsection").val() + "\"]").remove();
                $("#resume_edit_currentsection").val("PersonalSection");
                pengine.resume.editor_current_change();
            }
        },

        editor_save: function () {
            var jsonObj = {
                Personal: [],
                Objective: [],
                Skill: [],
                Education: [],
                WorkHistory: []
            };
            $(".resume_edit_personal_data").each(function (idx, ele) {
                var perData = {
                    Fullname: $("#personal_edit_fullname").val(),
                    Email: $("#personal_edit_email").val(),
                    WebsiteURL: $("#personal_edit_web").val(),
                    Phone: $("#personal_edit_phone").val(),
                    Fax: $("#personal_edit_fax").val(),
                    Address1: $("#personal_edit_address1").val(),
                    Address2: $("#personal_edit_address2").val(),
                    City: $("#personal_edit_city").val(),
                    State: $("#personal_edit_state").val(),
                    Zip: $("#personal_edit_zip").val()
                };
                if ($("#personal_edit_guid").val() != '') {
                    perData["Guid"] = $("#personal_edit_guid").val();
                }
                $.merge(jsonObj["Personal"], [perData]);
            });
            $(".resume_edit_objective_data").each(function (idx, ele) {
                var objData = {
                    Data: $("#objective_edit_data").val()
                };
                if ($("#objective_edit_guid").val() != '') {
                    objData["Guid"] = $("#objective_edit_guid").val();
                }
                $.merge(jsonObj["Objective"], [objData]);
            });
            $(".resume_edit_skilltype_data").each(function (idx, ele) {
                if ($(ele).attr("data-section-name")) {
                    var skillType = $(this).find(".skilltype_edit_type").val();
                    var skills = $(this).find(".skilltype_edit_skills").val().split('\n');
                    for (var skill in skills) {
                        var skillData = {
                            Type: skillType,
                            Name: skills[skill]
                        }
                        $.merge(jsonObj["Skill"], [skillData]);
                    }
                }
            });
            $(".resume_edit_education_data").each(function (idx, ele) {
                if ($(ele).attr("data-section-name")) {
                    var eduData = {
                        Institute: $(this).find(".education_edit_institute").val(),
                        InstituteURL: $(this).find(".education_edit_institute_url").val(),
                        Program: $(this).find(".education_edit_program").val(),
                        Started: $(this).find(".education_edit_started").val(),
                        Completed: $(this).find(".education_edit_completed").val()
                    };
                    if ($(this).find(".education_edit_guid").val() != '') {
                        eduData["Guid"] = $(this).find(".education_edit_guid").val();
                    }
                    $.merge(jsonObj["Education"], [eduData]);
                }
            });
            $(".resume_edit_workhistory_data").each(function (idx, ele) {
                if ($(ele).attr("data-section-name")) {
                    var workData = {
                        Employer: $(this).find(".workhistory_edit_employer").val(),
                        EmployerURL: $(this).find(".workhistory_edit_employer_url").val(),
                        JobTitle: $(this).find(".workhistory_edit_jobtitle").val(),
                        Started: $(this).find(".workhistory_edit_started").val(),
                        Completed: $(this).find(".workhistory_edit_completed").val(),
                        JobDescription: $(this).find(".workhistory_edit_jobdescription").val()
                    };
                    if ($(this).find(".workhistory_edit_guid").val() != '') {
                        workData["Guid"] = $(this).find(".workhistory_edit_guid").val();
                    }
                    $.merge(jsonObj["WorkHistory"], [workData]);
                }
            });
            $.ajax({
                type: "POST",
                url: pengine.resume.editor_post_url,
                data: { json: JSON.stringify(jsonObj) },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can save changes to the resume." }, false, function () { pengine.resume.editor_save(); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_resume_editor").slideUp('fast', function () {
                $("#pengine_resume_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    }
});