﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;
using PEngine4.Core.Model;
using Newtonsoft.Json;

namespace PEngine4.MVC.Controllers
{
    public class AdminController : PEngineController
    {
        [HttpPost]
        public string Login()
        {
            this.SetupPEngineViewBag();
            Helpers.LoginType ltype = Helpers.LoginType.system;
            string loginid = string.Empty;
            bool success = false;
            List<string> errors = new List<string>();
            if (Request.Params["type"] != null)
            {
                Enum.TryParse(Request.Params["type"], out ltype);
            }
            if (Request.Params["loginid"] != null)
            {
                loginid = Request.Params["loginid"];
            }
            string password = string.Empty;
            bool cookie = false;
            if (Request.Params["password"] != null)
            {
                password = Request.Params["password"];
            }
            if (Request.Params["cookie"] != null && Request.Params["cookie"] == "1")
            {
                if (!string.IsNullOrEmpty(password))
                {
                    cookie = true;
                }
            }
            switch (ltype)
            {
                case Helpers.LoginType.system:
                    if (Helpers.PasswordEncryptAndCompare(password, (string)Settings.Query(Settings.AppSettingKey.app_pass_god)))
                    {
                        _token.Add(Helpers.AccessLevel.god, cookie);
                        _token.Add(Helpers.AccessLevel.admin, cookie);
                        success = true;
                    }
                    else if (Helpers.PasswordEncryptAndCompare(password, (string)Settings.Query(Settings.AppSettingKey.app_pass_admin)))
                    {
                        _token.Add(Helpers.AccessLevel.admin, cookie);
                        success = true;
                    }
                    else
                    {
                        errors.Add("Incorrect credentials were provided for system access.");
                    }
                    break;
                case Helpers.LoginType.article:
                    if (!string.IsNullOrEmpty(loginid))
                    {
                        ArticleService articleService = new ArticleService();
                        Article article = articleService.ArticleGet(new Guid(loginid), true);
                        if (Helpers.PasswordEncryptAndCompare(password, (string)Settings.Query(Settings.AppSettingKey.app_pass_god)))
                        {
                            _token.Add(Helpers.AccessLevel.god, cookie);
                            _token.Add(Helpers.AccessLevel.admin, cookie);
                            success = true;
                        }
                        else if (Helpers.PasswordEncryptAndCompare(password, (string)Settings.Query(Settings.AppSettingKey.app_pass_admin)))
                        {
                            _token.Add(Helpers.AccessLevel.admin, cookie);
                            success = true;
                        }
                        if (_token.Has(Helpers.AccessLevel.admin) && (Helpers.PasswordEncryptAndCompare(password, article.AdminPass)))
                        {
                            _token.Article_Add(new Guid(loginid), cookie);
                            success = true;
                        }
                        else
                        {
                            errors.Add("Incorrect credentials were provided for this article.");
                        }
                    }
                    break;
            }
            Response.ContentType = "application/json";
            var result = new { success = success, errors = errors.ToArray() };
            return JsonConvert.SerializeObject(result);
        }

        public ActionResult Logout()
        {
            this.SetupPEngineViewBag();
            Helpers.LoginType ltype = Helpers.LoginType.system;
            string loginid = string.Empty;
            if (Request.Params["type"] != null)
            {
                Enum.TryParse(Request.Params["type"], out ltype);
            }
            if (Request.Params["loginid"] != null)
            {
                loginid = Request.Params["loginid"];
            }
            switch (ltype)
            {
                case Helpers.LoginType.system:
                    _token.Remove(Helpers.AccessLevel.admin);
                    _token.Remove(Helpers.AccessLevel.god);
                    break;
                case Helpers.LoginType.article:
                    if (!string.IsNullOrEmpty(loginid))
                    {
                        _token.Article_Remove(new Guid(loginid));
                    }
                    break;
            }
            return RedirectToAction("Index", "Post");
        }

        [HttpGet]
        public string SettingGet()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                var data = new
                {
                    themes = PEngine4.Core.Helpers.ThemeList(System.Web.HttpContext.Current, false).Select(o => new { id = o.Text, name = o.Text }).ToArray(),
                    ownerName = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_owner_name),
                    ownerEmail = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_owner_email),
                    defaultTitle = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_default_title),
                    defaultTheme = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_default_theme),
                    frontPageLogo = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_logo_frontpage),
                    leetOnLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_leet),
                    leetOffLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_leet2),
                    adminOnLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_admin),
                    adminOffLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_admin2),
                    homeLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_home),
                    themeLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_theme),
                    resumeLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_resume),
                    printLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_print),
                    quoteLabel = (string)Core.Settings.Query(Core.Settings.AppSettingKey.app_label_quote),
                    pagePostSummary = (int)Core.Settings.Query(Core.Settings.AppSettingKey.app_recpage_news_summary),
                    pagePost = (int)Core.Settings.Query(Core.Settings.AppSettingKey.app_recpage_news),
                    pageRSS = (int)Core.Settings.Query(Core.Settings.AppSettingKey.app_recpage_rss),
                    pageSearch = (int)Core.Settings.Query(Core.Settings.AppSettingKey.app_recpage_search_results),
                    sessionTimeout = (int)Core.Settings.Query(Core.Settings.AppSettingKey.app_timelimit_admin_login),
                    excludeQuote = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_quotes) ? "1" : "0",
                    excludeRSS = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_rss) ? "1" : "0",
                    excludeLeet = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_leet) ? "1" : "0",
                    excludeResume = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_resume) ? "1" : "0",
                    excludeTheme = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_theme) ? "1" : "0",
                    excludePrint = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_print) ? "1" : "0",
                    excludeSearch = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_search) ? "1" : "0",
                    excludeClippyButton = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_clippy_button) ? "1" : "0",
                    excludeClippyShortcut = (bool)Core.Settings.Query(Core.Settings.AppSettingKey.app_exclude_clippy_shortcut) ? "1" : "0",
                    clippyButtonLabel = (string)Core.Settings.Query(Settings.AppSettingKey.app_label_clippy_button),
                    clippyQuoteMode = (bool)Core.Settings.Query(Settings.AppSettingKey.app_clippy_quote_mode) ? "1" : "0",
                    clippyShortcutKeyCode = (int)Core.Settings.Query(Settings.AppSettingKey.app_clippy_shortcut_keycode),
                    clippyShortcutKeyCount = (int)Core.Settings.Query(Settings.AppSettingKey.app_clippy_shortcut_keycount),
                    clippyRandomChance = (int)Core.Settings.Query(Settings.AppSettingKey.app_clippy_random_chance),
                    adminPassAllowed = _token.Has(Helpers.AccessLevel.god) ? "1" : "0",
                    adminPassEmpty = _token.Has(Helpers.AccessLevel.god) ? (!string.IsNullOrEmpty((string)Core.Settings.Query(Core.Settings.AppSettingKey.app_pass_admin)) ? "0" : "1") : string.Empty,
                    godPassEmpty = _token.Has(Helpers.AccessLevel.god) ? (!string.IsNullOrEmpty((string)Core.Settings.Query(Core.Settings.AppSettingKey.app_pass_god)) ? "0" : "1") : string.Empty
                };
                retvalue = JsonConvert.SerializeObject(data);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string SettingPost()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                System.Collections.Specialized.NameValueCollection settings = Core.Settings.Snapshot();
                Core.Settings.Update(Core.Settings.AppSettingKey.app_owner_name, Request.Form["OwnerName"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_owner_email, Request.Form["OwnerEmail"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_default_title, Request.Form["DefaultTitle"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_default_theme, Request.Form["DefaultTheme"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_logo_frontpage, Request.Form["FrontPageLogo"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_leet, Request.Form["LeetOnLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_leet2, Request.Form["LeetOffLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_admin, Request.Form["AdminOnLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_admin2, Request.Form["AdminOffLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_home, Request.Form["HomeLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_theme, Request.Form["ThemeLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_resume, Request.Form["ResumeLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_print, Request.Form["PrintLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_quote, Request.Form["QuoteLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_recpage_news_summary, Request.Form["PagePostSummary"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_recpage_news, Request.Form["PagePost"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_recpage_rss, Request.Form["PageRSS"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_recpage_search_results, Request.Form["PageSearch"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_timelimit_admin_login, Request.Form["SessionTimeout"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_quotes, Request.Form["ExcludeQuote"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_rss, Request.Form["ExcludeRSS"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_leet, Request.Form["ExcludeLeet"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_resume, Request.Form["ExcludeResume"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_theme, Request.Form["ExcludeTheme"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_print, Request.Form["ExcludePrint"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_search, Request.Form["ExcludeSearch"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_clippy_button, Request.Form["ExcludeClippyButton"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_exclude_clippy_shortcut, Request.Form["ExcludeClippyShortcut"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_label_clippy_button, Request.Form["ClippyButtonLabel"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_clippy_quote_mode, Request.Form["ClippyQuoteMode"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_clippy_shortcut_keycode, Request.Form["ClippyShortcutKeyCode"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_clippy_shortcut_keycount, Request.Form["ClippyShortcutKeyCount"], ref settings, false);
                Core.Settings.Update(Core.Settings.AppSettingKey.app_clippy_random_chance, Request.Form["ClippyRandomChance"], ref settings, false);
                if (_token.Has(Helpers.AccessLevel.god))
                {
                    if (!string.IsNullOrEmpty(Request.Form["AdminPass"]))
                    {
                        if (Request.Form["AdminPass"] != "[none]")
                        {
                            Core.Settings.Update(Core.Settings.AppSettingKey.app_pass_admin, Helpers.PasswordEncrypt(Request.Form["AdminPass"]), ref settings, false);
                        }
                        else
                        {
                            Core.Settings.Update(Core.Settings.AppSettingKey.app_pass_admin, Helpers.PasswordEncrypt(string.Empty), ref settings, false);
                        }
                    }
                    if (!string.IsNullOrEmpty(Request.Form["GodPass"]))
                    {
                        if (Request.Form["GodPass"] != "[none]")
                        {
                            Core.Settings.Update(Core.Settings.AppSettingKey.app_pass_god, Helpers.PasswordEncrypt(Request.Form["GodPass"]), ref settings, false);
                        }
                        else
                        {
                            Core.Settings.Update(Core.Settings.AppSettingKey.app_pass_god, Helpers.PasswordEncrypt(string.Empty), ref settings, false);
                        }
                    }
                }
                List<string> errors = Core.Settings.Save(ref settings);
                var retdata = new
                {
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }
    }
}
