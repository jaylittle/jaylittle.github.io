﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Model;
using PEngine4.Core.Services;
using PEngine4.Core.TempClasses;
using Newtonsoft.Json;
using System.Text;

namespace PEngine4.MVC.Controllers
{
    public class ResumeController : PEngineController
    {
        //
        // GET: /Resume/

        public ActionResult Index()
        {
            this.SetupPEngineViewBag();
            ResumeService resumeService = new ResumeService();
            ResumeComplete data = new ResumeComplete();
            data.Personal = resumeService.PersonalList();
            data.Objective = resumeService.ObjectiveList();
            data.Skill = resumeService.SkillList();
            data.Education = resumeService.EducationList();
            data.WorkHistory = resumeService.WorkHistoryList();
            ViewBag.SummaryTitle = (data.Personal.Count > 0 ? data.Personal[0].FullName + " " : string.Empty) + ViewBag.LabelResume;
            ViewBag.SummaryDescription = (data.Objective.Count > 0 ? data.Objective[0].Data : string.Empty);
            return View(data);
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                ResumeService resumeService = new ResumeService();
                ResumeComplete resumeComplete = new ResumeComplete();
                resumeComplete.Personal = resumeService.PersonalList();
                if (resumeComplete.Personal.Count <= 0)
                {
                    resumeComplete.Personal.Add(new ResumePersonal());
                }
                resumeComplete.Objective = resumeService.ObjectiveList();
                if (resumeComplete.Objective.Count <= 0)
                {
                    resumeComplete.Objective.Add(new ResumeObjective());
                }
                resumeComplete.Skill = resumeService.SkillList();
                resumeComplete.Education = resumeService.EducationList();
                resumeComplete.WorkHistory = resumeService.WorkHistoryList();
                var data = ResumeToJSON(resumeComplete);
                retvalue = JsonConvert.SerializeObject(data);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Post()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                if (!string.IsNullOrEmpty(Request.Params["json"]))
                {
                    //Deserialize JSON Here
                    ResumeComplete resume = JsonConvert.DeserializeObject<ResumeComplete>(Request.Params["json"]);
                    ResumeService resumeService = new ResumeService();
                    List<string> errors = new List<string>();
                    ResumeComplete result = new ResumeComplete();
                    try
                    {
                        if (resume.Personal.Count > 0)
                        {
                            result.Personal.Add(resumeService.PersonalSave(resume.Personal[0], ref errors));
                        }
                        if (errors.Count <= 0)
                        {
                            if (resume.Objective.Count > 0)
                            {
                                result.Objective.Add(resumeService.ObjectiveSave(resume.Objective[0], ref errors));
                            }
                        }
                        if (errors.Count <= 0)
                        {
                            resumeService.SkillInvertDelete(new List<Guid>() { });
                            foreach (ResumeSkill skill in resume.Skill)
                            {
                                if (!string.IsNullOrEmpty(skill.Name) && !string.IsNullOrEmpty(skill.Type))
                                {
                                    result.Skill.Add(resumeService.SkillSave(skill, ref errors));
                                }
                            }
                        }
                        if (errors.Count <= 0)
                        {
                            List<Guid> currentEducationGuids = resume.Education.Where(o => o.Guid != Guid.Empty).Select(o => o.Guid).ToList();
                            resumeService.EducationInvertDelete(currentEducationGuids);
                            foreach (ResumeEducation education in resume.Education)
                            {
                                result.Education.Add(resumeService.EducationSave(education, ref errors));
                            }
                        }
                        if (errors.Count <= 0)
                        {
                            List<Guid> currentWorkHistoryGuids = resume.WorkHistory.Where(o => o.Guid != Guid.Empty).Select(o => o.Guid).ToList();
                            foreach (ResumeWorkHistory workHistory in resume.WorkHistory)
                            {
                                result.WorkHistory.Add(resumeService.WorkHistorySave(workHistory, ref errors));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                    var retdata = new
                    {
                        data = ResumeToJSON(errors.Count > 0 || result == null ? resume : result),
                        errors = errors.ToArray()
                    };
                    retvalue = JsonConvert.SerializeObject(retdata);
                    Response.ContentType = "application/json";
                }
                else
                {
                    Response.StatusCode = 404;
                }
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        private object ResumeToJSON(ResumeComplete resumeComplete)
        {
            var personal = resumeComplete.Personal.Select(o => new
            {
                guid = o.Guid != Guid.Empty ? o.Guid.ToString() : null,
                fullName = o.FullName,
                email = o.Email,
                web = o.WebsiteURL,
                phone = o.Phone,
                fax = o.Fax,
                address1 = o.Address1,
                address2 = o.Address2,
                city = o.City,
                state = o.State,
                zip = o.Zip
            });
            var objective = resumeComplete.Objective.Select(o => new
            {
                guid = o.Guid != Guid.Empty ? o.Guid.ToString() : null,
                data = o.Data
            });
            List<object> skillTypes = new List<object>();
            StringBuilder skillList = new StringBuilder();
            string lastSkillType = string.Empty;
            foreach (ResumeSkill skill in resumeComplete.Skill)
            {
                if (skill.Type.ToLower() != lastSkillType.ToLower())
                {
                    if (!string.IsNullOrEmpty(lastSkillType))
                    {
                        skillTypes.Add(new { skillType = lastSkillType, skills = skillList.ToString() });
                    }
                    lastSkillType = skill.Type;
                    skillList.Clear();
                }
                skillList.AppendLine(skill.Name);
            }
            if (!string.IsNullOrEmpty(lastSkillType))
            {
                skillTypes.Add(new { skillType = lastSkillType, skills = skillList.ToString() });
            }
            var education = resumeComplete.Education.Select(o => new
            {
                guid = o.Guid != Guid.Empty ? o.Guid.ToString() : null,
                institute = o.Institute,
                intituteUrl = o.InstituteURL,
                program = o.Program,
                started = PEngine4.Core.Helpers.FormatDate(o.Started, true),
                completed = PEngine4.Core.Helpers.FormatDate(o.Completed, true)
            });
            var workHistory = resumeComplete.WorkHistory.Select(o => new
            {
                guid = o.Guid != Guid.Empty ? o.Guid.ToString() : null,
                employer = o.Employer,
                employerUrl = o.EmployerURL,
                jobTitle = o.JobTitle,
                jobDescription = o.JobDescription,
                started = PEngine4.Core.Helpers.FormatDate(o.Started, true),
                completed = PEngine4.Core.Helpers.FormatDate(o.Completed, true)
            });
            var data = new
            {
                personal = personal,
                objective = objective,
                skillType = skillTypes.ToArray(),
                education = education,
                workHistory = workHistory
            };
            return data;
        }
    }
}
