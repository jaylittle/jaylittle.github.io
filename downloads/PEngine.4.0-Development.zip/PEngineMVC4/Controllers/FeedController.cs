﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PEngine4.MVC.Controllers
{
    public class FeedController : Controller
    {
        //
        // GET: /Feed/

        public string RSS()
        {
            string retvalue = null;
            if (!System.IO.File.Exists(Server.MapPath("~/App_Data/rss.xml")))
            {
                PEngine4.Core.Feeds.RSS.Generate(Url.RouteUrl("NamedPost", new { action = "View", controller = "Post", year = "PostYear", month = "PostMonth", uniqueName = "PostUniqueName" }));
            }
            if (System.IO.File.Exists(Server.MapPath("~/App_Data/rss.xml")))
            {
                Response.ContentType = "application/rss+xml";
                retvalue = System.IO.File.ReadAllText(Server.MapPath("~/App_Data/rss.xml"));
            }
            else
            {
                Response.StatusCode = 404;
            }
            return retvalue;
        }

    }
}
