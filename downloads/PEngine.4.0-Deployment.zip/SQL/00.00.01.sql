﻿/* This script will build the initial Presentation Engine Database Structure */
/* Note: This script has been modified in order to work with SQL Server Compact Edition */

/****** Object:  Table [Article]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [Article](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_Article] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](2048) NOT NULL,
	[Category] [nvarchar](100) NOT NULL,
	[ContentURL] [nvarchar](1024) NULL,
	[DefaultSection] [nvarchar](100) NOT NULL,
	[VisibleFlag] [bit] NOT NULL,
	[UniqueName] [nvarchar](512) NOT NULL,
	[HideButtonsFlag] [bit] NOT NULL,
	[HideDropDownFlag] [bit] NOT NULL,
	[AdminPass] [nvarchar](255) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_Article_Category] ON [Article] 
(
	[Category] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_Article_LegacyID] ON [Article] 
(
	[LegacyID] ASC
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Article_UniqueNameCreatedUTC] ON [Article] 
(
	[UniqueName] ASC,
	[CreatedUTC] ASC
)
GO
/****** Object:  Table [Version]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [Version](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_Version] PRIMARY KEY,
	[Major] [int] NOT NULL,
	[Minor] [int] NOT NULL,
	[Build] [int] NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Version_MajorMinorBuild] ON [Version] 
(
	[Major] ASC,
	[Minor] ASC,
	[Build] ASC
)
GO
/****** Object:  Table [ResumeWorkHistory]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [ResumeWorkHistory](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ResumeWorkHistory] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[Employer] [nvarchar](100) NOT NULL,
	[EmployerURL] [nvarchar](1024) NOT NULL,
	[JobTitle] [nvarchar](255) NOT NULL,
	[JobDescription] [ntext] NOT NULL,
	[Started] [datetime] NULL,
	[Completed] [datetime] NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ResumeWorkHistory_LegacyID] ON [ResumeWorkHistory] 
(
	[LegacyID] ASC
)
GO
/****** Object:  Table [ResumeSkill]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [ResumeSkill](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ResumeSkill] PRIMARY KEY ,
	[LegacyID] [int] NULL,
	[Type] [nvarchar](100) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Hint] [nvarchar](255) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ResumeSkill_LegacyID] ON [ResumeSkill] 
(
	[LegacyID] ASC
)
GO
/****** Object:  Table [ResumePersonal]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [ResumePersonal](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ResumePersonal] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[FullName] [nvarchar](255) NOT NULL,
	[Address1] [nvarchar](255) NOT NULL,
	[Address2] [nvarchar](255) NOT NULL,
	[City] [nvarchar](100) NOT NULL,
	[State] [nvarchar](4) NOT NULL,
	[Zip] [nvarchar](15) NOT NULL,
	[Phone] [nvarchar](50) NOT NULL,
	[Fax] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](255) NOT NULL,
	[WebsiteURL] [nvarchar](255) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ResumePersonal_LegacyID] ON [ResumePersonal] 
(
	[LegacyID] ASC
)
GO
/****** Object:  Table [ResumeObjective]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [ResumeObjective](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ResumeObjective] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[Data] [ntext] NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ResumeObjective_LegacyID] ON [ResumeObjective] 
(
	[LegacyID] ASC
)
GO
/****** Object:  Table [ResumeEducation]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [ResumeEducation](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ResumeEducation] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[Institute] [nvarchar](50) NOT NULL,
	[InstituteURL] [nvarchar](1024) NOT NULL,
	[Program] [nvarchar](100) NOT NULL,
	[Started] [datetime] NULL,
	[Completed] [datetime] NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ResumeEducation_LegacyID] ON [ResumeEducation] 
(
	[LegacyID] ASC
)
GO
/****** Object:  Table [Quote]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [Quote](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_Quote] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[Data] [ntext] NOT NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_Quote_LegacyID] ON [Quote] 
(
	[LegacyID] ASC
)
GO
/****** Object:  Table [Post]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [Post](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_Post] PRIMARY KEY,
	[LegacyID] [int] NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Data] [ntext] NOT NULL,
	[IconFileName] [nvarchar](255) NULL,
	[VisibleFlag] [bit] NOT NULL,
	[UniqueName] [nvarchar](512) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_Post_LegacyID] ON [Post] 
(
	[LegacyID] ASC
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Post_UniqueNameCreatedUTC] ON [Post] 
(
	[UniqueName] ASC,
	[CreatedUTC] ASC
)
GO
/****** Object:  Table [ArticleSection]    Script Date: 11/29/2012 10:33:07 ******/
CREATE TABLE [ArticleSection](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ArticleSection] PRIMARY KEY,
	[ArticleGuid] [uniqueidentifier] NOT NULL CONSTRAINT [FK_ArticleSection_Article] REFERENCES [Article] ([Guid]),
	[Name] [nvarchar](100) NOT NULL,
	[Data] [ntext] NOT NULL,
	[SortOrder] [int] NOT NULL,
	[UniqueName] [nvarchar](512) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ArticleSection_ArtictleGuidSortOrder] ON [ArticleSection] 
(
	[ArticleGuid] ASC,
	[SortOrder] ASC
)
GO
/****** Object:  Default [DF_Table_1_IsVisible]    Script Date: 11/29/2012 10:33:07 ******/
ALTER TABLE [Article] ADD  CONSTRAINT [DF_Table_1_IsVisible]  DEFAULT ((0)) FOR [VisibleFlag]
GO
/****** Object:  Default [DF_Article_HideButtonsFlag]    Script Date: 11/29/2012 10:33:07 ******/
ALTER TABLE [Article] ADD  CONSTRAINT [DF_Article_HideButtonsFlag]  DEFAULT ((0)) FOR [HideButtonsFlag]
GO
/****** Object:  Default [DF_Article_HideDropDownFlag]    Script Date: 11/29/2012 10:33:07 ******/
ALTER TABLE [Article] ADD  CONSTRAINT [DF_Article_HideDropDownFlag]  DEFAULT ((0)) FOR [HideDropDownFlag]
GO
/****** Object:  Default [DF_ArticleSection_SortOrder]    Script Date: 11/29/2012 10:33:07 ******/
ALTER TABLE [ArticleSection] ADD  CONSTRAINT [DF_ArticleSection_SortOrder]  DEFAULT ((0)) FOR [SortOrder]
GO
/****** Object:  Default [DF_Post_VisibleFlag]    Script Date: 11/29/2012 10:33:07 ******/
ALTER TABLE [Post] ADD  CONSTRAINT [DF_Post_VisibleFlag]  DEFAULT ((0)) FOR [VisibleFlag]
GO
