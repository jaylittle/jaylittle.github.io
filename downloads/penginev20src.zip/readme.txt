Presentation Engine 2.0
Developer's Release
Documentation

System Files:

default.asp 		(main function routing page for application)
settings.asp		(contains user defined PEngine settings)
inc\admin.asp		(contains code for changing PEngine settings)
inc\articles.asp	(handles anything to do with articles)
inc\display.asp		(contains code for routing system defined page displays)
inc\init.asp		(general system/database code such as menu functions)
inc\news.asp		(handles anything to do with news updates)
inc\resume.asp		(handles anything to do with the resume)
themes\mode.asp		(handles specific mode overrides for themes - not used)
themes\theme.asp	(general theme loader)
data\			(holds database files for PEngine)
downloads\		(holds user defined downloads)
images\articles		(holds images for articles)
images\icons		(holds images used as story icons)
images\raw		(holds raw unconverted images)
images\system		(holds system images such as front page logo)

Most of the site expansion in the PEngine system is done through the use of
articles.  Articles allow you to transparently create and edit parts of a PEngine
site without uploading or downloading of HTML files.  (You do have to upload custom images however).  Articles have their own specific tags for content that are encased in [] brackets. The list of tags is as follows:

[IMAGE xxxx]
	Displays an image for the article directory or from another site if a
	full HTTP address was used.  For an image in the article directory only use
	the image filename as a parameter.

[SUBHEADER xxxx]
	Places a SubHeader on the page.  The parameter allows you to set the text
	that is displayed on the SubHeader.

[LINK xxxx]
	Provides an easy way of placing an Anchor Hyperlink.  The parameter is the
	address you would like to link to.

[ICON xxxx]
	Like the IMAGE tag above but this one uses images in the icon directory.
	You cannot use FULL HTTP address with this tag.

[SYSTEMIMAGE xxxx]
	Like the ICON tag except this one uses images in the system directory.

[SECTION xxxx]
	This tag creates a button which will link to another section of the same
	article.  The paramater is the name of the section you would like to link
	to.

There will be more of these tags in the future.  These are the few that were REQUIRED for the article system to become releasable.  Actual HTTP can be used to supplant the functionality of anything else requested for now.

In order to set up the presentation engine - it does NOT need be an application 
in IIS and it can either reside in a root or subdirectory of some larger site. 
The backend database is in Access97 format though it was primarily developed in 
Access 2002 and converted back to Access 97.

We will probably refresh this release sometime soon with better end user documentation and whatever bugfixes are gathered from this release.

Thanks,

Jason Little
http://www.jaylittle.com