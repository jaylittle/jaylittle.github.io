Imports pengine.Data
Imports System.Data.OleDB
Imports System.Web.Security

Public Class displaynews
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptNews As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public MyArticle As Article
    Public MyEditButtonHTML As String
    Public MyDeleteButtonHTML As String
    Public MyNewButtonHTML As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        Dim MyNews As News = New News(Session.Item("ConnectionString"))
        Dim NewsData As DataSet
        MyArticle = New Article(Session.Item("ConnectionString"))
        NewsData = MyNews.GetNews(Request.Item("ID"))
        If Session.Item("admin") = True Then
            MyEditButtonHTML = MyArticle.CreateHTMLButton("./admin/editnews.aspx?id=" & Request.Item("id"), "Edit Story", "")
            MyNewButtonHTML = MyArticle.CreateHTMLButton("./admin/editnews.aspx", "Create Story", "")
            MyDeleteButtonHTML = MyArticle.CreateHTMLButton("./admin/deletenews.aspx?id=" & Request.Item("id"), "Delete Story", "Are you sure you wish to delete this story?")
        End If
        RptNews.DataSource = NewsData
        RptNews.DataBind()
        MyNews.CloseConn()
        MyArticle.CloseConn()
        PEngine_Header1.NewsTitle = MyNews.Title(Request.Item("ID"))
    End Sub
End Class
