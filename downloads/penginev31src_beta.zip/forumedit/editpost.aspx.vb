Imports pengine.Data
Imports System.Data.OleDB

Public Class editpost
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtbody As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtparentid As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents txttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtipaddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents txttimeposted As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtposts As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtforumid As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtforumname As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblusername As System.Web.UI.WebControls.Label
    Protected WithEvents lblipaddress As System.Web.UI.WebControls.Label
    Protected WithEvents lbltimeposted As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public TitleSubHeader As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim PostData As DataSet
        Dim MySettings As Settings = New Settings
        Dim MyForum As Forum
        Dim MyArticle As Article
        If Not IsPostBack Then
            MyForum = New Forum(Session("FConnectionString"))
            MyArticle = New Article(Session("ConnectionString"))
            If Request.Item("id") <> "" And IsNumeric(Request.Item("id")) Then
                PostData = MyForum.GetMessage(Request.Item("id"))
                If PostData.Tables(0).Rows.Count > 0 Then
                    If Session("forumadmin") = True Or (PostData.Tables(0).Rows(0).Item("UserID") = Session("forumuserid")) Then
                        txtid.Text = PostData.Tables(0).Rows(0).Item("ID")
                        txtparentid.Text = PostData.Tables(0).Rows(0).Item("ParentID")
                        txttitle.Text = PostData.Tables(0).Rows(0).Item("Title")
                        txtbody.Text = PostData.Tables(0).Rows(0).Item("Body")
                        txtforumid.Text = PostData.Tables(0).Rows(0).Item("ForumID")
                        txtforumname.Text = MyForum.GetForumName(txtforumid.Text)
                        lblusername.Text = MyForum.GetUserName(PostData.Tables(0).Rows(0).Item("UserID"))
                        lblipaddress.Text = PostData.Tables(0).Rows(0).Item("IPAddress")
                        lbltimeposted.Text = PostData.Tables(0).Rows(0).Item("TimePosted")
                        TitleSubHeader = MyArticle.CreateHTMLSubHeader("Edit Existing Post")
                        btnsave.Text = "Save Changes"
                    Else
                        lblerrors.Text = "You must have forum admin access to edit a post that does not belong to you."
                        btnsave.Enabled = False
                    End If
                Else
                    lblerrors.Text = "You specified a userid that does not exist."
                    btnsave.Enabled = False
                End If
            Else
                If Request.Item("forumid") <> "" And IsNumeric(Request.Item("forumid")) = True Then
                    txtid.Text = "-1"
                    txtforumid.Text = Request.Item("forumid")
                    txtforumname.Text = MyForum.GetForumName(Request.Item("forumid"))
                    lblusername.Text = ""
                    lblipaddress.Text = ""
                    lbltimeposted.Text = ""
                    If Request.Item("replyid") <> "" And IsNumeric(Request.Item("replyid")) Then
                        PostData = MyForum.GetMessage(Request.Item("replyid"))
                        If PostData.Tables(0).Rows.Count > 0 Then
                            txtbody.Text = "[QUOTE]Originally posted by " _
                            & MyForum.GetUserName(PostData.Tables(0).Rows(0).Item("UserID")) _
                            & ":" & System.Environment.NewLine & PostData.Tables(0).Rows(0).Item("Body") & "[/QUOTE]"
                            txttitle.Text = PostData.Tables(0).Rows(0).Item("Title")
                            If txttitle.Text.StartsWith("Re:") = False Then
                                txttitle.Text = "Re: " & txttitle.Text
                            End If
                        Else
                            txtbody.Text = ""
                            txttitle.Text = "New Post"
                        End If
                    Else
                        txtbody.Text = ""
                        txttitle.Text = "New Post"
                    End If
                    If Request.Item("parentid") <> "" And IsNumeric(Request.Item("parentid")) Then
                        txtparentid.Text = Request.Item("parentid")
                        TitleSubHeader = MyArticle.CreateHTMLSubHeader("Add Post")
                        btnsave.Text = "Save Post"
                    Else
                        txtparentid.Text = "-1"
                        TitleSubHeader = MyArticle.CreateHTMLSubHeader("Add Thread")
                        btnsave.Text = "Save Thread"
                    End If
                Else
                    lblerrors.Text = "You must provide a forumid for a new thread/post."
                    btnsave.Enabled = False
                End If
            End If
            MyArticle.CloseConn()
            MyForum.CloseConn()
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyForum As Forum
        Dim ErrorText As String = ""
        lblerrors.Text = ""
        MyForum = New Forum(Session.Item("FConnectionString"))
        ErrorText = MyForum.SaveMessage(txtid.Text, txttitle.Text, txtbody.Text, Request.ServerVariables("REMOTE_HOST"), txtforumid.Text, Session.Item("forumuserid"), txtparentid.Text)
        MyForum.CloseConn()
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully."
            Response.Redirect("../browsemessages.aspx?threadid=" & txtparentid.Text & "&postid=" & txtid.Text & "#" & txtid.Text)
        End If
    End Sub
End Class
