Imports pengine.Data
Imports System.Web.Security

Public Class PEngine_Header
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ImgHeaderLeft As System.Web.UI.WebControls.Image
    Protected WithEvents ImgHeaderRight As System.Web.UI.WebControls.Image
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyPageSize As String
    Public MyHeaderText As String
    Public MyPageTitle As String
    Public MyTextAlign As String
    Public MyBackground As String
    Public MyLeftImage As String
    Public MyRightImage As String
    Public MyCSS As String
    Public ArticleID As Integer
    Public ArticleCategory As String
    Public NewsTitle As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim MyTheme As Theme = New Theme
        Dim MyArticle As Article = New Article(Session("ConnectionString"))
        'Put user code to initialize the page here
        If Session.Item("settings") <> 1 Then
            Dim MySettings As Settings = New Settings
            MySettings.LoadIntoSession()
        End If
        If Session.Item("theme") = "" Or Session.Item("basethemepath") = "" Then
            Session.Item("basethemepath") = ResolveUrl("./") & "themes/"
            Session.Item("basepath") = ResolveUrl("./")
            MyTheme.LoadTheme(Session.Item("defaulttheme"))
            MyCSS = MyTheme.CSSCode
        ElseIf Session.Item("themecss") = "" Then
            MyTheme.LoadTheme(Session.Item("theme"))
            MyCSS = MyTheme.CSSCode
        Else
            MyCSS = Session.Item("themecss")
        End If
        If ArticleID > 0 Then
            MyPageTitle = Session.Item("defaultpagetitle") & " - " & ArticleCategory & ": " & MyArticle.Title(ArticleID)
        ElseIf ArticleCategory <> "" Then
            MyPageTitle = Session.Item("defaultpagetitle") & " - " & ArticleCategory & ": "
        ElseIf NewsTitle <> "" Then
            MyPageTitle = Session.Item("defaultpagetitle") & " - " & NewsTitle
        Else
            MyPageTitle = Session.Item("defaultpagetitle")
        End If
        MyTextAlign = Session.Item("headertextalign")
        If Session("pagesize") > 0 Then
            MyPageSize = Session("pagesize")
        Else
            MyPageSize = "100%"
        End If
        If Session.Item("HeaderNoTextFlag") = False Then
            'MyHeader = ConvertToElite(GenerateHeader)
            If ArticleID > 0 Then
                MyHeaderText = Session.Item("defaultpagetitle") & " - " & MyArticle.Title(ArticleID)
            Else
                MyHeaderText = Session.Item("defaultpagetitle")
            End If
        Else
            MyHeaderText = ""
        End If
        If Session.Item("HeaderRImage") <> "" Then
            ImgHeaderRight.Visible = True
            ImgHeaderRight.ImageUrl = Session.Item("HeaderRImage")
            MyRightImage = Session.Item("HeaderRImage")
        Else
            ImgHeaderRight.Visible = False
        End If
        If Session.Item("HeaderLImage") <> "" Then
            ImgHeaderLeft.Visible = True
            ImgHeaderLeft.ImageUrl = Session.Item("HeaderLImage")
            MyLeftImage = Session.Item("HeaderLImage")
        Else
            ImgHeaderLeft.Visible = False
        End If
        MyBackground = Session.Item("HeaderMImage")
        MyPageTitle = MyArticle.ConvertToElite(MyPageTitle)
        MyHeaderText = MyArticle.ConvertToElite(MyHeaderText)
        MyArticle.CloseConn()
    End Sub

End Class
