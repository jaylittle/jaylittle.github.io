Imports System.Data.OleDB

Namespace Data
    Public Class SessionAccess
        Inherits System.Web.UI.Page
    End Class

    Public Class DBAccess
        Dim conPEngine As OleDbConnection
        Dim dapPEngine As OleDbDataAdapter
        Protected MyConnString As String
        Private ConnFlag As Boolean
        Public Sub SetConnString(ByVal ConnString As String)
            MyConnString = ConnString
            ConnFlag = False
        End Sub
        Public Sub OpenConn()
            If ConnFlag = True Then
                Call CloseConn()
            End If
            conPEngine = New OleDbConnection(MyConnString)
            conPEngine.Open()
            ConnFlag = True
        End Sub
        Public Function GetDataset(ByVal SQL As String) As DataSet
            If ConnFlag = False Then
                OpenConn()
            End If
            GetDataset = New DataSet
            dapPEngine = New OleDbDataAdapter(SQL, conPEngine)
            dapPEngine.Fill(GetDataset)
        End Function
        Public Sub SetDataset(ByVal TableName As String, ByRef MyDataset As DataSet)
            Dim cmdPEngine As OleDbCommandBuilder
            If ConnFlag = False Then
                OpenConn()
            End If
            cmdPEngine = New OleDbCommandBuilder(dapPEngine)
            dapPEngine.Update(MyDataset, TableName)
        End Sub
        Public Function GetScalar(ByVal SQL As String) As Object
            Dim cmdPEngine As OleDbCommand
            If ConnFlag = False Then
                OpenConn()
            End If
            cmdPEngine = New OleDbCommand(SQL, conPEngine)
            GetScalar = cmdPEngine.ExecuteScalar
            cmdPEngine = Nothing
        End Function
        Public Function ExecuteSQL(ByVal SQL As String) As Integer
            Dim cmdPEngine As OleDbCommand
            If ConnFlag = False Then
                OpenConn()
            End If
            cmdPEngine = New OleDbCommand(SQL, conPEngine)
            cmdPEngine.ExecuteNonQuery()
            cmdPEngine = Nothing
        End Function
        Public Sub CloseConn()
            dapPEngine = Nothing
            Try
                conPEngine.Close()
                conPEngine = Nothing
            Catch
            End Try
            ConnFlag = False
        End Sub
        Public Sub New(ByVal ConnectionString As String)
            MyConnString = ConnectionString
            'If ConnFlag = False Then
            'Call OpenConn()
            'End If
        End Sub
        Protected Overloads Overrides Sub Finalize()
            If ConnFlag = True Then
                Call CloseConn()
            End If
        End Sub
    End Class

    Public Class Article
        Inherits pengine.Data.DBAccess
        Dim MySess As SessionAccess
        Function ProcessDate(ByVal DateString As String) As String
            Dim MyDate As DateTime
            Dim CurDate As DateTime = DateTime.Now
            MyDate = System.Convert.ToDateTime(DateString)
            If MyDate > CurDate Then
                ProcessDate = "Present"
            Else
                ProcessDate = MyDate.ToShortDateString
            End If
        End Function
        Function CategoryList(ByVal AdminFlag As Boolean) As DataSet
            If AdminFlag = True Then
                Return GetDataset("Select category,http from Articles Group By category,http")
            Else
                Return GetDataset("Select category,http from Articles where visible = true group by category,http")
            End If
        End Function
        Function GetArticles(ByVal Category As String, ByVal AdminFlag As Boolean) As DataSet
            If AdminFlag = False Then
                If Category <> "" Then
                    GetArticles = GetDataset("Select * from Articles where category='" & Category & "' and visible=true order by name ASC")
                Else
                    GetArticles = GetDataset("Select * from Articles where visible=true order by name ASC")
                End If
            Else
                If Category <> "" Then
                    GetArticles = GetDataset("Select * from Articles where category='" & Category & "' order by name ASC")
                Else
                    GetArticles = GetDataset("Select * from Articles order by name ASC")
                End If
            End If
        End Function
        Function GetArticle(ByVal ID As Integer)
            Dim ArticleData As DataSet
            ArticleData = GetDataset("Select * From Articles where id = " & System.Convert.ToString(ID))
            Return ArticleData
        End Function
        Function SaveArticle(ByRef ID As Integer, ByVal Name As String, ByVal Description As String, ByVal Category As String, ByVal http As String, ByVal DefaultSection As String, ByVal Visible As Boolean, ByVal HideDropDown As Boolean, ByVal HideButtons As Boolean, ByVal AdminPass As String) As String
            Dim ArticleRecord As DataRow
            Dim ArticleData As DataSet
            If Name = "" Then
                SaveArticle &= "You must supply a name for this article.|"
            End If
            If Description = "" Then
                SaveArticle &= "You must supply a description for this article.|"
            End If
            If Category = "" Then
                SaveArticle &= "You must supply a category for this article.|"
            End If
            If SaveArticle = "" Then
                If ID > 0 Then
                    ArticleData = GetDataset("Select * from Articles where ID = " & System.Convert.ToString(ID))
                    ArticleRecord = ArticleData.Tables(0).Rows(0)
                Else
                    ArticleData = GetDataset("Select * from Articles")
                    ArticleRecord = ArticleData.Tables(0).NewRow
                End If
                ArticleRecord.Item("Name") = Name
                ArticleRecord.Item("Description") = Description
                ArticleRecord.Item("Category") = Category
                ArticleRecord.Item("http") = http
                ArticleRecord.Item("DefaultSection") = DefaultSection
                ArticleRecord.Item("Visible") = Visible
                ArticleRecord.Item("HideButtons") = HideButtons
                ArticleRecord.Item("HideDropDown") = HideDropDown
                ArticleRecord.Item("AdminPass") = AdminPass
                If ID > 0 Then
                    SetDataset(ArticleData.Tables(0).TableName, ArticleData)
                Else
                    ArticleData.Tables(0).Rows.Add(ArticleRecord)
                    SetDataset(ArticleData.Tables(0).TableName, ArticleData)
                    ID = GetScalar("SELECT @@IDENTITY")
                End If
            End If
        End Function
        Function DeleteArticle(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Articles where ID = " & System.Convert.ToString(ID))
                ExecuteSQL("Delete from ArticleSection where ArticleID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Function GetArticleSection(ByVal ID As Integer, ByVal Section As String) As DataSet
            Dim DefaultSection As String
            Dim ArticleData As DataSet
            Dim HideDropDownFlag As Boolean
            Dim SectionCount As Integer = 0
            ArticleData = GetDataset("Select * from Articles where id = " & System.Convert.ToString(ID))
            If ArticleData.Tables(0).Rows.Count > 0 Then
                'If ArticleData.Read Then
                If Section = "" Then
                    DefaultSection = ArticleData.Tables(0).Rows(0).Item("DefaultSection") & ""
                Else
                    DefaultSection = Section
                End If
                HideDropDownFlag = ArticleData.Tables(0).Rows(0).Item("HideDropDown")
                'HideDropDownFlag = ArticleData.Item("HideDropDown")
                'ArticleData.Close()
                If HideDropDownFlag = True Then
                    SectionCount = 1
                Else
                    SectionCount = GetScalar("Select count(*) from ArticleSection where ArticleID = " & System.Convert.ToString(ID))
                End If
                If DefaultSection = "" Then
                    ArticleData = GetDataset("Select TOP 1 * from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " order by sortorder,name")
                Else
                    ArticleData = GetDataset("Select TOP 1 * from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " and name = '" & DefaultSection & "' order by sortorder,name")
                End If
            Else
                'Article Data not Found.
            End If
            'Invalid data provided for Article ID.
            Return ArticleData
        End Function
        Function SaveArticleSection(ByRef ArticleID As Integer, ByVal OldName As String, ByVal Name As String, ByVal Data As String, ByVal SortOrder As Integer) As String
            Dim SectionRecord As DataRow
            Dim SectionData As DataSet
            If Name = "" Then
                SaveArticleSection &= "You must supply a name for this section.|"
            End If
            If Data = "" Then
                SaveArticleSection &= "You must supply data for this section.|"
            End If
            If SaveArticleSection = "" Then
                If OldName <> "" Then
                    SectionData = GetDataset("Select * from ArticleSection where Name = '" & OldName & "' and ArticleID = " & System.Convert.ToString(ArticleID))
                    SectionRecord = SectionData.Tables(0).Rows(0)
                Else
                    SectionData = GetDataset("Select * from ArticleSection")
                    SectionRecord = SectionData.Tables(0).NewRow
                End If
                SectionRecord.Item("ArticleID") = ArticleID
                SectionRecord.Item("Name") = Name
                SectionRecord.Item("Data") = Data
                SectionRecord.Item("SortOrder") = SortOrder
                If OldName = "" Then
                    SectionData.Tables(0).Rows.Add(SectionRecord)
                End If
                SetDataset(SectionData.Tables(0).TableName, SectionData)
            End If
        End Function
        Function DeleteArticleSection(ByVal ArticleID As Integer, ByVal SectionName As String) As Boolean
            If ArticleID > 0 And SectionName <> "" Then
                ExecuteSQL("Delete from ArticleSection where Name = '" & SectionName & "' and ArticleID = " & System.Convert.ToString(ArticleID))
                Return True
            Else
                Return False
            End If
        End Function
        Function SectionList(ByVal ID As Integer) As ArrayList
            Dim ArticleData As DataSet
            Dim RowPtr As Integer = 0
            SectionList = New ArrayList
            ArticleData = GetDataset("Select * from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " order by sortorder,name")
            'While ArticleData.Read
            While RowPtr < ArticleData.Tables(0).Rows.Count
                SectionList.Add(ArticleData.Tables(0).Rows(RowPtr).Item("name"))
                RowPtr += 1
            End While
            'End While
        End Function
        Function DefaultSection(ByVal ID As Integer) As String
            DefaultSection = GetScalar("Select defaultsection from Articles where ID = " & System.Convert.ToString(ID))
            If DefaultSection = "" Then
                DefaultSection = GetScalar("Select top 1 name from ArticleSection where ArticleID = " & System.Convert.ToString(ID) & " order by sortorder,name asc")
            End If
        End Function
        Function CategoryCount(ByVal Category As String, ByVal AdminFlag As Boolean) As Integer
            If AdminFlag = False Then
                If Category <> "" Then
                    CategoryCount = GetScalar("Select count(*) from Articles where category='" & Category & "' and visible=true")
                Else
                    CategoryCount = GetScalar("Select count(*) from Articles where visible=true")
                End If
            Else
                If Category <> "" Then
                    CategoryCount = GetScalar("Select count(*) from Articles where category='" & Category & "'")
                Else
                    CategoryCount = GetScalar("Select count(*) from Articles")
                End If
            End If
        End Function
        Function Category(ByVal ID As Integer) As String
            Category = GetScalar("Select category from Articles where id = " & System.Convert.ToString(ID))
        End Function
        Function MenuIsHidden(ByVal ID As Integer) As Boolean
            MenuIsHidden = GetScalar("Select hidebuttons from Articles where id = " & System.Convert.ToString(ID))
        End Function
        Function Title(ByVal ID As Integer) As String
            Title = GetScalar("Select name from Articles where id = " & System.Convert.ToString(ID))
        End Function
        Function ConverttoHTML(ByVal secdata As String, ByVal forumflag As Boolean, Optional ByVal ArticleID As Integer = 0) As String
            Dim cpos As Integer = 0
            Dim lpos As Integer = 0
            Dim tag As String
            Dim tagname As String
            Dim tagdata As String
            Dim tagspace As Integer = 0
            Dim tagelements() As String
            Dim rawhtmlflag As Boolean = False
            Dim rawhtmlstart As Integer
            Dim rawhtmlend As Integer
            Dim outdata As String
            Dim resforumtags() As String = {"SCRIPT", "/SCRIPT", "IFRAME", "/IFRAME", "EMBED", "BLINK", "TR", "TD", "TABLE", "/TR", "/TD", "/TABLE", "FRAMESET", "/FRAMESET"}
            Dim restagflag As Boolean
            Dim OutputHTML As String = ""
            'Filter for obfusacated tags if Forum Flag is True
            'Remove HTML Content if Forum Flag is True
            If forumflag = True Then
                While InStr(1, secdata, "[" & vbNewLine) > 0
                    secdata = secdata.Replace("[" & vbNewLine, "[ ")
                End While
                While InStr(1, secdata, "<" & vbNewLine) > 0
                    secdata = secdata.Replace("<" & vbNewLine, "< ")
                End While
                While InStr(1, secdata, "[ ") > 0
                    secdata = secdata.Replace("[ ", "[")
                End While
                While InStr(1, secdata, "< ") > 0
                    secdata = secdata.Replace("< ", "<")
                End While
                cpos = InStr(1, secdata, "<")
                While cpos > 0
                    lpos = InStr(cpos + 1, secdata, ">")
                    If lpos > 0 Then
                        secdata = Left(secdata, cpos - 1) & Right(secdata, Len(secdata) - lpos)
                        'OutputHTML &= secdata
                        'response.end
                    End If
                    cpos = InStr(cpos, secdata, "<")
                End While
            End If
            lpos = 0
            cpos = InStr(1, secdata, "[")
            While cpos > 0
                If rawhtmlflag = False Then
                    outdata = Mid(secdata, lpos + 1, (cpos - 1) - lpos)
                    OutputHTML &= Replace(ConvertToElite(outdata), vbNewLine, "<br>" & vbNewLine)
                End If
                lpos = InStr(cpos + 1, secdata, "]")
                tag = Mid(secdata, cpos + 1, lpos - (cpos + 1))
                tagspace = InStr(1, tag, " ")
                If tagspace > 0 Then
                    tagname = Mid(tag, 1, tagspace - 1)
                    tagdata = Mid(tag, tagspace + 1, Len(tag) - (tagspace))
                Else
                    tagname = tag
                End If
                If rawhtmlflag = False Or UCase(tagname) = "/RAWHTML" Then
                    Select Case Trim(UCase(tagname))
                        Case "IMAGE"
                            If InStr(1, UCase(tagdata), "HTTP") > 0 Or Left(tagdata, 2) = "./" Or Left(tagdata, 1) = "/" Then
                                OutputHTML &= "<img src=""" & tagdata & """>"
                            Else
                                If MySess.Session.Item("basepath") <> "" Then
                                    OutputHTML &= "<img src=""" & MySess.Session.Item("basepath") & "/images/articles/" & tagdata & """>"
                                Else
                                    OutputHTML &= "<img src=""./images/articles/" & tagdata & """>"
                                End If

                            End If
                        Case "SUBHEADER"
                            If forumflag = False Then
                                OutputHTML &= CreateHTMLSubHeader(tagdata)
                            End If
                        Case "LINK"
                            tagelements = Split(tagdata, " ")
                            OutputHTML &= "<a href=""" & tagelements(0) & """>"
                            Dim i As Integer
                            For i = 0 To UBound(tagelements)
                                If i > 0 Then
                                    If i > 1 Then
                                        OutputHTML &= " "
                                    End If
                                    OutputHTML &= tagelements(i)
                                End If
                            Next
                            If UBound(tagelements) < 1 Then OutputHTML &= (tagelements(0))
                            OutputHTML &= "</A>"
                        Case "ICON"
                            If MySess.Session.Item("basepath") <> "" Then
                                OutputHTML &= "<img src=""" & MySess.Session.Item("basepath") & "/images/icons/" & tagdata & """>"
                            Else
                                OutputHTML &= "<img src=""./images/icons/" & tagdata & """>"
                            End If
                        Case "SYSTEMIMAGE"
                            If MySess.Session.Item("basepath") <> "" Then
                                OutputHTML &= "<img src=""" & MySess.Session.Item("basepath") & "/images/system/" & tagdata & """>"
                            Else
                                OutputHTML &= "<img src=""./images/system/" & tagdata & """>"
                            End If
                        Case "SECTION"
                            If forumflag = False Then
                                If ArticleID > 0 Then
                                    OutputHTML &= CreateHTMLButton("displayarticle.aspx?id=" & ArticleID & "&section=" & tagdata, tagdata, "")
                                End If
                            End If
                        Case "RAWHTML"
                            'This tag indicates that any code enclosed within this tag is raw HTML and NOT to be touched
                            'If forumflag = false then
                            rawhtmlflag = True
                            rawhtmlstart = cpos + 9
                            rawhtmlend = rawhtmlstart
                            'End If
                        Case "/RAWHTML"
                            'This tag indicates that any code following it should be processed as if it was not HTML.
                            'If forumflag = false then
                            rawhtmlflag = False
                            rawhtmlend = cpos
                            OutputHTML &= Mid(secdata, rawhtmlstart, rawhtmlend - rawhtmlstart)
                            'End If
                        Case "QUOTE"
                            'This tag indicates that the content inside is to be quoted
                            OutputHTML &= "<blockquote><table border=1><tr><td>"
                        Case "/QUOTE"
                            'This closes out the quotes
                            OutputHTML &= "</td></tr></table></blockquote>"
                        Case Else
                            restagflag = False
                            If forumflag = True Then
                                Dim i As Integer
                                For i = LBound(resforumtags) To UBound(resforumtags)
                                    If UCase(resforumtags(i)) = UCase(tagname) Then
                                        restagflag = True
                                    End If
                                Next
                            End If
                            If restagflag = False Then
                                OutputHTML &= "<" & tag & ">"
                            End If
                    End Select
                End If
                cpos = InStr(lpos + 1, secdata, "[")
            End While
            If lpos <> 0 Then
                outdata = Mid(secdata, lpos + 1, Len(secdata) - lpos)
                If rawhtmlflag = False Then
                    OutputHTML &= Replace(ConvertToElite(outdata), vbNewLine, "<br>" & vbNewLine)
                Else
                    OutputHTML &= outdata
                End If
            Else
                OutputHTML &= Replace(ConvertToElite(secdata), vbNewLine, "<br>" & vbNewLine)
            End If
            If OutputHTML <> "" Then
                Return OutputHTML
            Else
                Return "There was no data to convert."
            End If
        End Function
        Function CreateHTMLSubHeader(ByVal text As String) As String
            Dim OutputHTML As String = ""
            OutputHTML &= "<a name=""" & text.Replace(" ", "") & """>"
            OutputHTML &= "<table id width=""100%"" cellspacing=""0"" cellpadding=""0"">" & System.Environment.NewLine
            OutputHTML &= "<tr>" & System.Environment.NewLine
            OutputHTML &= "<td id=""sheaderleftcell"">"
            If MySess.Session.Item("SHeaderLImage") <> "" Then
                OutputHTML &= "<img src=""" & MySess.Session.Item("SHeaderLImage") & """>"
            End If
            OutputHTML &= "</td>" & System.Environment.NewLine
            OutputHTML &= "<td id=""sheadermidcell"" width=""100%"">"
            OutputHTML &= "<span id=""sheadermidtext"">" & ConvertToElite(text) & "</span>"
            OutputHTML &= "</td>" & System.Environment.NewLine
            OutputHTML &= "<td id=""sheaderrightcell"">"
            If MySess.Session.Item("SHeaderRImage") <> "" Then
                OutputHTML &= "<img src=""" & MySess.Session.Item("SHeaderRImage") & """>"
            End If
            OutputHTML &= "</td>" & System.Environment.NewLine
            OutputHTML &= "</tr>" & System.Environment.NewLine
            OutputHTML &= "</table>" & System.Environment.NewLine
            Return OutputHTML
        End Function
        Function CreateHTMLIcon(ByVal URL As String) As String
            Dim OutputHTML As String = ""
            If URL <> "" Then
                OutputHTML &= "<img src=""./images/icons/" & URL & """ align=right hspace=20 vspace=10>"
            End If
            Return OutputHTML
        End Function
        Function CreateHTMLButton(ByVal URL As String, ByVal Text As String, ByVal ConfirmMessage As String) As String
            Dim OutputHTML As String = ""
            If ConfirmMessage <> "" Then
                ConfirmMessage = ConfirmMessage.Replace("'", "\'")
                ConfirmMessage = ConfirmMessage.Replace("(", "\(")
                ConfirmMessage = ConfirmMessage.Replace(")", "\)")
            End If
            If URL <> "" Then
                OutputHTML &= "<table><tr><form action=""" & URL & """ method=""post"" "
                If ConfirmMessage <> "" Then
                    OutputHTML &= "onsubmit=""javascript:return confirmform('" & ConfirmMessage & "');"""
                End If
                OutputHTML &= "><td><input type=""submit"" value=""" & Text & """></td></form></tr></table>"
            Else
                OutputHTML &= "<table><tr><td><input type=button disabled value=""" & Text & """></td></tr></table>"
            End If
            Return OutputHTML
        End Function
        Function ConvertToElite(ByVal OrigText As String) As String
            'This function was originally stolen from somewhere on the internet.
            'I translated the original Javascript version into VBScript and now into VB.NET
            'Due to all of the work I've put into it I am now claiming ownership of it.
            'Note:  I can't remember where in the hell it came from anyway.
            Dim words() As String
            Dim wordptr As Integer
            Dim cword As String
            Dim charptr As Integer
            Dim curchar As String
            Dim newword As String
            Dim Randomizer As System.Random = New System.Random(Date.Now.Millisecond)
            If MySess.Session.Item("leetflag") = False Then
                ConvertToElite = OrigText
            Else
                words = OrigText.ToLower.Split(" ")
                For wordptr = words.GetLowerBound(0) To words.GetUpperBound(0)
                    cword = words(wordptr)
                    'Process special words
                    Select Case words(wordptr)
                        Case "am"
                            If wordptr < words.GetUpperBound(0) Then
                                If words(wordptr + 1) = "good" Then
                                    cword = "ownz0r"
                                    wordptr = wordptr + 1
                                End If
                            End If
                        Case "is"
                            If wordptr < words.GetUpperBound(0) Then
                                If words(wordptr + 1) = "good" Then
                                    cword = "ownz0rz"
                                    wordptr = wordptr + 1
                                End If
                            End If
                        Case "cool"
                            cword = "k3wl"
                        Case "dude"
                            cword = "d00d"
                        Case "dudes"
                            cword = "d00dz"
                        Case "elite"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "l33t"
                            Else
                                cword = "31337"
                            End If
                        Case "hacker"
                            cword = "hax0r"
                        Case "hacked"
                            cword = "hax0red"
                        Case "the"
                            If Randomizer.Next Mod 100 < 60 Then
                                cword = "teh"
                            End If
                        Case "mp3s"
                            cword = "mp3z"
                        Case "own"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "pwn"
                            Else
                                cword = "0wnzor"
                            End If
                        Case "owned"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "pwned"
                            Else
                                cword = "0wnzored"
                            End If
                        Case "porn"
                            If Randomizer.Next Mod 100 < 50 Then
                                cword = "pr0n"
                            End If
                        Case "quake"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaek"
                            End If
                        Case "quake2"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaek2"
                            End If
                        Case "quake3"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaek3"
                            End If
                        Case "quakeworld"
                            If Randomizer.Next Mod 100 < 20 Then
                                cword = "quaekworld"
                            End If
                        Case "rock"
                            cword = "r0x0r"
                        Case "rocks"
                            cword = "r0x0rez"
                        Case "you"
                            cword = "j00"
                    End Select

                    'Process Special Characters
                    newword = ""
                    For charptr = 1 To cword.Length
                        curchar = cword.Substring(charptr - 1, 1)
                        Select Case curchar
                            Case "a"
                                If Randomizer.Next Mod 100 < 30 Then
                                    curchar = "@"
                                Else
                                    curchar = "4"
                                End If
                            Case "b"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "8"
                                End If
                            Case "d"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|)"
                                End If
                            Case "e"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "3"
                                End If
                            Case "f"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "ph"
                                End If
                            Case "g"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "9"
                                End If
                            Case "h"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|-|"
                                End If
                            Case "i"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "1"
                                End If
                            Case "k"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|&lt;"
                                End If
                            Case "m"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|\\\/|"
                                End If
                            Case "n"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "|\\|"
                                End If
                            Case "o"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "0"
                                End If
                            Case "q"
                                If charptr < cword.Length Then
                                    If curchar = "q" And cword.Substring(charptr, 1) = "u" Then
                                        curchar = "kw"
                                        charptr = charptr + 1
                                    End If
                                End If
                            Case "s"
                                If Randomizer.Next Mod 100 < 30 Then
                                    curchar = "$"
                                Else
                                    curchar = "5"
                                End If
                            Case "t"
                                If Randomizer.Next Mod 100 < 50 Then
                                    curchar = "+"
                                End If
                            Case "v"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "\\\/"
                                End If
                            Case "w"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "\\\/\\\/"
                                End If
                            Case "x"
                                If Randomizer.Next Mod 100 < 10 Then
                                    curchar = "&gt;&lt;"
                                End If
                        End Select
                        'Randomize case
                        If Randomizer.Next Mod 100 < 50 Then
                            curchar = curchar.ToUpper
                        End If
                        newword = newword & curchar
                    Next
                    ConvertToElite = ConvertToElite & newword & " "
                Next
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
            MySess = New SessionAccess
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

    Public Class News
        Inherits pengine.Data.DBAccess
        Dim MySess As SessionAccess
        Function GetNews(ByVal ID As Integer) As DataSet
            GetNews = GetDataset("Select TOP 1 * from SystemNews where id = " & System.Convert.ToString(ID) & " order by timeposted DESC")
        End Function
        Function GetCurrentNews() As DataSet
            GetCurrentNews = GetDataset("Select TOP 5 * from SystemNews order by timeposted DESC")
        End Function
        Function GetNewsRange(ByVal LastStoryID As Integer, ByVal StoryCount As Integer, ByVal ReverseFlag As Boolean) As DataSet
            Dim StartStoryID As Integer = -1
            Dim RowPtr As Integer = 0
            If LastStoryID > 0 And ReverseFlag = True Then
                GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                & " * from SystemNews where ID > " & System.Convert.ToString(LastStoryID) & " order by timeposted ASC")
                If GetNewsRange.Tables(0).Rows.Count > 0 Then
                    While RowPtr < GetNewsRange.Tables(0).Rows.Count
                        StartStoryID = GetNewsRange.Tables(0).Rows(RowPtr).Item("ID")
                        RowPtr += 1
                    End While
                    GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                    & " * from SystemNews where ID <= " & System.Convert.ToString(StartStoryID) & " order by timeposted DESC")
                End If
            Else
                StartStoryID = LastStoryID
                If StartStoryID > 0 Then
                    GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                    & " * from SystemNews where ID < " & System.Convert.ToString(StartStoryID) & " order by timeposted DESC")
                Else
                    GetNewsRange = GetDataset("Select TOP " & System.Convert.ToString(StoryCount) _
                    & " * from SystemNews order by timeposted DESC")
                End If

            End If
        End Function
        Function GetTopNewsID() As Integer
            GetTopNewsID = GetScalar("Select TOP 1 ID from SystemNews order by timeposted DESC")
        End Function
        Function GetBottomNewsID() As Integer
            GetBottomNewsID = GetScalar("Select TOP 1 ID from SystemNews order by timeposted ASC")
        End Function
        Function Title(ByVal ID As Integer) As String
            Title = GetScalar("Select TOP 1 title from SystemNews where id = " & System.Convert.ToString(ID) & " order by timeposted ASC")
        End Function
        Function TruncateStory(ByVal StoryData As String) As String
            If StoryData.Length > 75 Then
                StoryData = Left(StoryData, 75) & "..."
            End If
            StoryData = Replace(StoryData, "[", "")
            StoryData = Replace(StoryData, "]", "")
            StoryData = Replace(StoryData, "<", "")
            StoryData = Replace(StoryData, ">", "")
            Return StoryData
        End Function
        Function SaveNews(ByRef ID As Integer, ByVal Title As String, ByVal DateTime As Date, ByVal Text As String, ByVal IconFileName As String) As String
            Dim NewsRecord As DataRow
            Dim NewsData As DataSet
            If Title = "" Then
                SaveNews &= "You must supply a title for this news posting.|"
            End If
            If Text = "" Then
                SaveNews &= "You must input some text for this news posting.|"
            End If
            If SaveNews = "" Then
                If ID > 0 Then
                    NewsData = GetDataset("Select * from SystemNews where ID = " & System.Convert.ToString(ID))
                    NewsRecord = NewsData.Tables(0).Rows(0)
                    'NewsRecord.BeginEdit()
                Else
                    NewsData = GetDataset("Select * from SystemNews")
                    NewsRecord = NewsData.Tables(0).NewRow
                End If
                NewsRecord.Item("Title") = Title
                NewsRecord.Item("ArticleData") = Text
                NewsRecord.Item("timeposted") = DateTime.ToString
                NewsRecord.Item("IconFileName") = IconFileName
                If ID > 0 Then
                    'NewsRecord.AcceptChanges()
                    SetDataset(NewsData.Tables(0).TableName, NewsData)
                Else
                    NewsData.Tables(0).Rows.Add(NewsRecord)
                    SetDataset(NewsData.Tables(0).TableName, NewsData)
                    ID = GetScalar("SELECT @@IDENTITY")
                End If
            End If
        End Function
        Function DeleteNews(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from SystemNews where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetIconList() As ArrayList
            GetIconList = New ArrayList
            Dim FSInfo As System.IO.DirectoryInfo
            Dim FileList() As System.IO.FileInfo
            Dim FilePtr As Integer
            If MySess.Session.Item("basepath") <> "" Then
                FSInfo = New System.IO.DirectoryInfo(MySess.Server.MapPath(MySess.Session.Item("basepath") & "/images/icons/"))
            Else
                FSInfo = New System.IO.DirectoryInfo(MySess.Server.MapPath("./images/icons/"))
            End If
            FileList = FSInfo.GetFiles("*")
            For FilePtr = FileList.GetLowerBound(0) To FileList.GetUpperBound(0)
                GetIconList.Add(FileList(FilePtr).Name)
            Next
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
            MySess = New SessionAccess
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

    Public Class ResumeParts
        Inherits pengine.Data.DBAccess
        Dim MySess As SessionAccess
        Public Function GetPersonals() As DataSet
            GetPersonals = GetDataset("Select * from ResumePersonal")
        End Function
        Public Function GetPersonal(ByVal ID As Integer) As DataSet
            GetPersonal = GetDataset("Select TOP 1 * from ResumePersonal where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SavePersonal(ByRef ID As Integer, ByVal Name As String, ByVal Address As String, ByVal City As String _
        , ByVal State As String, ByVal Zip As String, ByVal Phone As String, ByVal Fax As String _
        , ByVal Email As String, ByVal Web As String) As String
            Dim PersonalRecord As DataRow
            Dim PersonalData As DataSet
            If Name = "" Then
                SavePersonal &= "You must supply a name for the personal information.|"
            End If
            If Email = "" Then
                SavePersonal &= "You must supply an email address for the personal information.|"
            End If
            If SavePersonal = "" Then
                If ID > 0 Then
                    PersonalData = GetDataset("Select * from ResumePersonal where ID = " & System.Convert.ToString(ID))
                    PersonalRecord = PersonalData.Tables(0).Rows(0)
                Else
                    PersonalData = GetDataset("Select * from ResumePersonal")
                    PersonalRecord = PersonalData.Tables(0).NewRow
                End If
                PersonalRecord.Item("Name") = Name
                PersonalRecord.Item("Address") = Address
                PersonalRecord.Item("City") = City
                PersonalRecord.Item("State") = State
                PersonalRecord.Item("Zip") = Zip
                PersonalRecord.Item("Phone") = Phone
                PersonalRecord.Item("Fax") = Fax
                PersonalRecord.Item("Email") = Email
                PersonalRecord.Item("Web") = Web
                If ID <= 0 Then
                    PersonalData.Tables(0).Rows.Add(PersonalRecord)
                    SetDataset(PersonalData.Tables(0).TableName, PersonalData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(PersonalData.Tables(0).TableName, PersonalData)
                End If
            End If
        End Function
        Function DeletePersonal(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumePersonal where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetObjectives() As DataSet
            GetObjectives = GetDataset("Select * from ResumeObjective")
        End Function
        Public Function GetObjective(ByVal ID As Integer) As DataSet
            GetObjective = GetDataset("Select TOP 1 * from ResumeObjective where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveObjective(ByRef ID As Integer, ByVal Description As String) As String
            Dim ObjectiveRecord As DataRow
            Dim ObjectiveData As DataSet
            If Description = "" Then
                SaveObjective &= "You must at least fill in the description field for this objective.|"
            End If
            If SaveObjective = "" Then
                If ID > 0 Then
                    ObjectiveData = GetDataset("Select * from ResumeObjective where ID = " & System.Convert.ToString(ID))
                    ObjectiveRecord = ObjectiveData.Tables(0).Rows(0)
                Else
                    ObjectiveData = GetDataset("Select * from ResumeObjective")
                    ObjectiveRecord = ObjectiveData.Tables(0).NewRow
                End If
                ObjectiveRecord.Item("Description") = Description
                If ID <= 0 Then
                    ObjectiveData.Tables(0).Rows.Add(ObjectiveRecord)
                    SetDataset(ObjectiveData.Tables(0).TableName, ObjectiveData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(ObjectiveData.Tables(0).TableName, ObjectiveData)
                End If
            End If
        End Function
        Function DeleteObjective(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeObjective where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetSkills() As DataSet
            GetSkills = GetDataset("Select * from ResumeSkills order by Type ASC")
        End Function
        Public Function GetSkill(ByVal ID As Integer) As DataSet
            GetSkill = GetDataset("Select TOP 1 * from ResumeSkills where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveSkill(ByRef ID As Integer, ByVal Name As String, ByVal Type As String) As String
            Dim SkillRecord As DataRow
            Dim SkillData As DataSet
            If Name = "" Then
                SaveSkill &= "You must supply a name for the skill.|"
            End If
            If Type = "" Then
                SaveSkill &= "You must supply a type for the skill to be listed with.|"
            End If
            If SaveSkill = "" Then
                If ID > 0 Then
                    SkillData = GetDataset("Select * from ResumeSkills where ID = " & System.Convert.ToString(ID))
                    SkillRecord = SkillData.Tables(0).Rows(0)
                Else
                    SkillData = GetDataset("Select * from ResumeSkills")
                    SkillRecord = SkillData.Tables(0).NewRow
                End If
                SkillRecord.Item("Name") = Name
                SkillRecord.Item("Type") = Type
                If ID <= 0 Then
                    SkillData.Tables(0).Rows.Add(SkillRecord)
                    SetDataset(SkillData.Tables(0).TableName, SkillData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(SkillData.Tables(0).TableName, SkillData)
                End If
            End If
        End Function
        Function DeleteSkill(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeSkills where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetEducations() As DataSet
            GetEducations = GetDataset("Select * from ResumeEducation order by DateStarted DESC")
        End Function
        Public Function GetEducation(ByVal ID As Integer) As DataSet
            GetEducation = GetDataset("Select TOP 1 * from ResumeEducation where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveEducation(ByRef ID As Integer, ByVal Institute As String, ByVal HTTP As String _
        , ByVal Program As String, ByVal DateStarted As DateTime, ByVal DateLeft As DateTime) As String
            Dim EducationRecord As DataRow
            Dim EducationData As DataSet
            If Institute = "" Then
                SaveEducation &= "You must supply the name of an institute for this education record.|"
            End If
            If Program = "" Then
                SaveEducation &= "You must supply a program of study for this education record.|"
            End If
            If HTTP = "" Then
                SaveEducation &= "You must provide a URL for the institute.|"
            End If
            If SaveEducation = "" Then
                If ID > 0 Then
                    EducationData = GetDataset("Select * from ResumeEducation where ID = " & System.Convert.ToString(ID))
                    EducationRecord = EducationData.Tables(0).Rows(0)
                Else
                    EducationData = GetDataset("Select * from ResumeEducation")
                    EducationRecord = EducationData.Tables(0).NewRow
                End If
                EducationRecord.Item("Institute") = Institute
                EducationRecord.Item("HTTP") = HTTP
                EducationRecord.Item("Program") = Program
                EducationRecord.Item("DateStarted") = DateStarted.ToShortDateString
                EducationRecord.Item("DateLeft") = DateStarted.ToShortDateString
                If ID <= 0 Then
                    EducationData.Tables(0).Rows.Add(EducationRecord)
                    SetDataset(EducationData.Tables(0).TableName, EducationData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(EducationData.Tables(0).TableName, EducationData)
                End If
            End If
        End Function
        Function DeleteEducation(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeEducation where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetWorkHistories() As DataSet
            GetWorkHistories = GetDataset("Select * from ResumeWorkHistory order by DateStarted DESC")
        End Function
        Public Function GetWorkHistory(ByVal ID As Integer) As DataSet
            GetWorkHistory = GetDataset("Select TOP 1 * from ResumeWorkHistory where id = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveWorkHistory(ByRef ID As Integer, ByVal Employer As String, ByVal HTTP As String _
        , ByVal Title As String, ByVal DateStarted As DateTime, ByVal DateLeft As DateTime _
        , ByVal Description As String) As String
            Dim WorkHistoryRecord As DataRow
            Dim WorkHistoryData As DataSet
            If Employer = "" Then
                SaveWorkHistory &= "You must supply an employer name for this work history record.|"
            End If
            If Title = "" Then
                SaveWorkHistory &= "You must supply a title name for this work history record.|"
            End If
            If Description = "" Then
                SaveWorkHistory &= "You must supply a description for this work history record.|"
            End If
            If SaveWorkHistory = "" Then
                If ID > 0 Then
                    WorkHistoryData = GetDataset("Select * from ResumeWorkHistory where ID = " & System.Convert.ToString(ID))
                    WorkHistoryRecord = WorkHistoryData.Tables(0).Rows(0)
                Else
                    WorkHistoryData = GetDataset("Select * from ResumeWorkHistory")
                    WorkHistoryRecord = WorkHistoryData.Tables(0).NewRow
                End If
                WorkHistoryRecord.Item("Employer") = Employer
                WorkHistoryRecord.Item("HTTP") = HTTP
                WorkHistoryRecord.Item("Title") = Title
                WorkHistoryRecord.Item("DateStarted") = DateStarted.ToShortDateString
                WorkHistoryRecord.Item("DateLeft") = DateLeft.ToShortDateString
                WorkHistoryRecord.Item("Description") = Description
                If ID <= 0 Then
                    WorkHistoryData.Tables(0).Rows.Add(WorkHistoryRecord)
                    SetDataset(WorkHistoryData.Tables(0).TableName, WorkHistoryData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(WorkHistoryData.Tables(0).TableName, WorkHistoryData)
                End If
            End If
        End Function
        Function DeleteWorkHistory(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from ResumeWorkHistory where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
            MySess = New SessionAccess
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

    Public Class Forum
        Inherits pengine.Data.DBAccess
        Dim MySess As SessionAccess
        Public Function GetForumName(ByVal ForumID As Integer) As String
            GetForumName = GetScalar("Select Name from Forums where ID = " & System.Convert.ToString(ForumID))
        End Function
        Public Function GetThreadName(ByVal ThreadID As Integer) As String
            GetThreadName = GetScalar("Select Title from Messages where ID = " & System.Convert.ToString(ThreadID))
        End Function
        Public Function GetThreadPosts(ByVal ThreadID As Integer) As Integer
            GetThreadPosts = GetScalar("Select Posts from Messages where ID = " & System.Convert.ToString(ThreadID))
        End Function
        Public Function GetThreadForumID(ByVal ThreadID As Integer) As Integer
            GetThreadForumID = GetScalar("Select ForumID from Messages where ID = " & System.Convert.ToString(ThreadID))
        End Function
        Public Function GetForums() As DataSet
            GetForums = GetDataset("Select ID,Name,Description, (Select count(*) from Messages where Forums.ID = Messages.ForumID) as Posts " _
            & ", (Select max(TimePosted) from Messages where Forums.ID = Messages.ForumID) as LastPost " _
            & "from Forums order by Name ASC")
        End Function
        Public Function GetForum(ByVal ID As Integer) As DataSet
            GetForum = GetDataset("Select * from Forums where ID = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveForum(ByRef ID As Integer, ByVal Name As String, ByVal Description As String) As String
            Dim ForumRecord As DataRow
            Dim ForumData As DataSet
            If Description = "" Then
                SaveForum &= "You must supply a description for this forum.|"
            End If
            If Name = "" Then
                SaveForum &= "You must supply a name for the forum.|"
            End If
            If SaveForum = "" Then
                If ID > 0 Then
                    ForumData = GetDataset("Select * from Forums where ID = " & System.Convert.ToString(ID))
                    ForumRecord = ForumData.Tables(0).Rows(0)
                Else
                    ForumData = GetDataset("Select * from Forums")
                    ForumRecord = ForumData.Tables(0).NewRow
                End If
                ForumRecord.Item("Name") = Name
                ForumRecord.Item("Description") = Description
                If ID <= 0 Then
                    ForumData.Tables(0).Rows.Add(ForumRecord)
                    SetDataset(ForumData.Tables(0).TableName, ForumData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(ForumData.Tables(0).TableName, ForumData)
                End If
            End If
        End Function
        Function DeleteForum(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Forums where ID = " & System.Convert.ToString(ID))
                ExecuteSQL("Delete from Messages where ForumID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetThreads(ByVal ForumID As Integer, ByVal StartPoint As Integer, ByVal Count As Integer) As DataSet
            Dim TempDataset As DataSet
            Dim StartID As Integer
            If StartPoint > 0 And Count > 0 Then
                GetThreads = New DataSet
                TempDataset = GetDataset("Select TOP " & System.Convert.ToString(StartPoint) _
                & " ID from Messages where ForumID = " & System.Convert.ToString(ForumID) _
                & " and ParentID = Messages.ID order by TimePosted DESC")
                If TempDataset.Tables(0).Rows.Count > 0 Then
                    StartID = TempDataset.Tables(0).Rows(TempDataset.Tables(0).Rows.Count - 1).Item("ID")
                    GetThreads = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                    & " Messages.*,Users.Name as UserName from Messages,Users where UserID = Users.ID and ForumID = " _
                    & System.Convert.ToString(ForumID) & " and ParentID = ID and Messages.ID <= " _
                    & System.Convert.ToString(StartID) & " order by TimePosted DESC")
                End If
            ElseIf Count > 0 Then
                GetThreads = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                & " Messages.*,Users.Name as UserName from Messages,Users where UserID = Users.ID and ForumID = " _
                & System.Convert.ToString(ForumID) & " and ParentID = Messages.ID order by TimePosted DESC")
            Else
                GetThreads = GetDataset("Select Messages.*,Users.Name as UserName from Messages,Users where " _
                & "UserID = Users.ID and ForumID = " & System.Convert.ToString(ForumID) _
                & " and ParentID = Messages.ID order by TimePosted DESC")
            End If
        End Function
        Public Function GetMessagePageNum(ByVal MessageID As Integer, ByVal Count As Integer) As Integer
            Dim TempDataset As DataSet
            Dim PostCount As Integer
            TempDataset = GetDataset("Select ID from Messages where ID <= " & System.Convert.ToString(MessageID) & " order by TimePosted ASC")
            PostCount = TempDataset.Tables(0).Rows.Count
            GetMessagePageNum = (PostCount - (PostCount Mod Count)) / Count
        End Function
        Public Function GetMessages(ByVal ThreadID As Integer, ByVal StartPoint As Integer, ByVal Count As Integer) As DataSet
            Dim TempDataset As DataSet
            Dim StartID As Integer
            If StartPoint > 0 And Count > 0 Then
                GetMessages = New DataSet
                TempDataset = GetDataset("Select TOP " & System.Convert.ToString(StartPoint) _
                & " ID from ParentID = " & System.Convert.ToString(ThreadID) & " order by TimePosted ASC")
                If TempDataset.Tables(0).Rows.Count > 0 Then
                    StartID = TempDataset.Tables(0).Rows(TempDataset.Tables(0).Rows.Count - 1).Item("ID")
                    GetMessages = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                    & " Messages.*,User.Name as UserName,User.Title as UserTitle from Messages,Users where" _
                    & " Messages.UserID = Users.ID and ParentID = " & System.Convert.ToString(ThreadID) _
                    & " and Messages.ID <= " & System.Convert.ToString(StartID) & " order by TimePosted ASC")
                End If
            ElseIf Count > 0 Then
                GetMessages = GetDataset("Select TOP " & System.Convert.ToString(Count) _
                & " Messages.*,Users.Name as username, Users.Title as UserTitle from Messages, Users where " _
                & "Messages.UserID = Users.ID and ParentID = " & System.Convert.ToString(ThreadID) _
                & " order by TimePosted ASC")
            Else
                GetMessages = GetDataset("Select Messages.*, User.Name as UserName, User.Title as UserTitle " _
                & "from Messages,Users where Messages.UserID = Users.ID and ParentID = " _
                & System.Convert.ToString(ThreadID) & " order by TimePosted ASC")
            End If
        End Function
        Public Function CreateThreadPageHTML(ByVal ThreadID As Integer, ByVal Posts As Integer _
        , ByVal PostsPerPage As Integer, ByVal URLStart As String, ByVal URLEnd As String _
        , ByVal CSSID As String, Optional ByVal CurrentPage As Integer = 0) As String
            Dim PostPtr As Integer
            For PostPtr = 0 To Posts Step PostsPerPage
                If PostPtr > 0 Then
                    CreateThreadPageHTML &= " "
                End If
                If CurrentPage <= 0 Or CurrentPage <> (PostPtr + PostsPerPage) / PostsPerPage Then
                    If CSSID <> "" Then
                        CreateThreadPageHTML &= "<a id=""" & CSSID & """ href="""
                    Else
                        CreateThreadPageHTML &= "<a href="""
                    End If
                    CreateThreadPageHTML &= URLStart & System.Convert.ToString(ThreadID)
                    CreateThreadPageHTML &= URLEnd & System.Convert.ToString((PostPtr + PostsPerPage) / PostsPerPage)
                    CreateThreadPageHTML &= """>" & System.Convert.ToString((PostPtr + PostsPerPage) / PostsPerPage)
                    CreateThreadPageHTML &= "</a>"
                Else
                    CreateThreadPageHTML &= System.Convert.ToString((PostPtr + PostsPerPage) / PostsPerPage)
                End If
            Next
        End Function
        Public Function CreateTitleHTML(ByVal TitleData As String)
            If TitleData <> "" Then
                CreateTitleHTML = """" & TitleData & """"
            Else
                CreateTitleHTML = ""
            End If
        End Function
        Public Function ValidateUser(ByVal UserName As String, ByVal Password As String) As DataSet
            If Password = "" Then
                ValidateUser = GetDataset("Select * from Users where Name = '" & MySess.Server.HtmlEncode(UserName) & "' and (UserPass = '' or UserPass is null)")
            Else
                ValidateUser = GetDataset("Select * from Users where Name = '" & MySess.Server.HtmlEncode(UserName) & "' and UserPass = '" & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(Password, "MD5") & "'")
            End If
        End Function
        Public Function GetLastPostTime(ByVal UserID As Integer) As String
            GetLastPostTime = GetScalar("Select TOP 1 timeposted from messages where userid = " & System.Convert.ToString(UserID) & " order by timeposted DESC")
        End Function
        Public Function GetLastIP(ByVal UserID As Integer) As String
            GetLastIP = GetScalar("Select TOP 1 ipaddress from messages where userid = " & System.Convert.ToString(UserID) & " order by timeposted DESC")
        End Function
        Public Function GetUsers() As DataSet
            GetUsers = GetDataset("Select * from Users")
        End Function
        Public Function GetUser(ByVal UserID As Integer) As DataSet
            GetUser = GetDataset("Select * from Users where ID = " & System.Convert.ToString(UserID))
        End Function
        Public Function GetUserName(ByVal UserID As Integer) As String
            GetUserName = GetScalar("Select Name from Users where ID = " & System.Convert.ToString(UserID))
        End Function
        Public Function SaveUser(ByRef ID As Integer, ByVal Name As String, ByVal FullName As String _
        , ByVal Title As String, ByVal Description As String, ByVal PublicEmail As String _
        , ByVal PrivateEmail As String, ByVal HomeURL As String, ByVal AIMAccount As String _
        , ByVal ICQAccount As String, ByVal YahooAccount As String, ByVal MSNAccount As String _
        , ByVal ModeratorFlag As Boolean, ByVal DisableFlag As Boolean, ByVal NewPassword As String)
            Dim UserRecord As DataRow
            Dim UserData As DataSet
            If Name = "" Then
                SaveUser &= "You must supply a name for this user"
            End If
            If PrivateEmail = "" Then
                SaveUser &= "You must supply a private email address.|"
            End If
            If ID <= 0 And NewPassword = "" Then
                SaveUser &= "You must provide a password for this user.|"
            End If
            If SaveUser = "" Then
                If ID > 0 Then
                    UserData = GetDataset("Select * from Users where ID = " & System.Convert.ToString(ID))
                    UserRecord = UserData.Tables(0).Rows(0)
                Else
                    UserData = GetDataset("Select * from Users")
                    UserRecord = UserData.Tables(0).NewRow
                    UserRecord.Item("JoinDate") = DateTime.Now.ToShortDateString
                    UserRecord.Item("PostCount") = 0
                End If
                UserRecord.Item("Name") = Name
                UserRecord.Item("FullName") = FullName
                UserRecord.Item("Title") = Title
                UserRecord.Item("Description") = Description
                UserRecord.Item("Name") = Name
                If NewPassword <> "" Then
                    UserRecord.Item("UserPass") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(NewPassword, "MD5")
                End If
                UserRecord.Item("PublicEmail") = PublicEmail
                UserRecord.Item("PrivateEmail") = PrivateEmail
                UserRecord.Item("HomeURL") = HomeURL
                UserRecord.Item("AIMAccount") = AIMAccount
                UserRecord.Item("ICQAccount") = ICQAccount
                UserRecord.Item("YahooAccount") = YahooAccount
                UserRecord.Item("MSNAccount") = MSNAccount
                UserRecord.Item("ModeratorFlag") = ModeratorFlag
                UserRecord.Item("DisabledFlag") = DisableFlag
                If ID <= 0 Then
                    UserData.Tables(0).Rows.Add(UserRecord)
                    SetDataset(UserData.Tables(0).TableName, UserData)
                    ID = GetScalar("SELECT @@IDENTITY")
                Else
                    SetDataset(UserData.Tables(0).TableName, UserData)
                End If
            End If
        End Function
        Public Function DeleteUser(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Users where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function VerifyIP(ByVal IP As String) As Boolean
            Dim LookupIP As String
            LookupIP = GetScalar("Select IP from IPBanList where IP = '" & IP & "'")
            If LookupIP <> "" Then
                VerifyIP = False
            Else
                VerifyIP = True
            End If
        End Function
        Public Function GetIPBans() As DataSet
            GetIPBans = GetDataset("Select * from IPBanList")
        End Function
        Public Function SaveIPBan(ByRef IP As String)
            Dim IPBanRecord As DataRow
            Dim IPBanData As DataSet
            If IP = "" Then
                SaveIPBan &= "You must provide an IP address.|"
            End If
            If SaveIPBan = "" Then
                IPBanData = GetDataset("Select * from IPBanList")
                IPBanRecord = IPBanData.Tables(0).NewRow
                IPBanRecord.Item("IP") = IP
                IPBanData.Tables(0).Rows.Add(IPBanRecord)
                SetDataset(IPBanData.Tables(0).TableName, IPBanData)
            End If
        End Function
        Public Function DeleteIPBan(ByVal IP As String) As Boolean
            If IP <> "" Then
                ExecuteSQL("Delete from IPBanList where IP = " & IP)
                Return True
            Else
                Return False
            End If
        End Function
        Public Function GetMessage(ByVal ID As Integer) As DataSet
            GetMessage = GetDataset("Select * from Messages where ID = " & System.Convert.ToString(ID))
        End Function
        Public Function SaveMessage(ByRef ID As Integer, ByVal Title As String, ByVal Body As String _
        , ByVal IPAddress As String, ByVal ForumID As Integer, ByVal UserID As Integer _
        , ByRef ParentID As Integer) As String
            Dim MessageRecord As DataRow
            Dim MessageData As DataSet
            Dim ThreadFlag As Boolean = False
            Dim TimeStamp As String
            TimeStamp = DateTime.Now.ToString
            If Title = "" Then
                SaveMessage &= "You must supply a title for this post/thread.|"
            End If
            If Body = "" Then
                SaveMessage &= "You must supply content for this post/thread.|"
            End If
            If SaveMessage = "" Then
                If ID > 0 Then
                    MessageData = GetDataset("Select * from Messages where ID = " & System.Convert.ToString(ID))
                    MessageRecord = MessageData.Tables(0).Rows(0)
                Else
                    MessageData = GetDataset("Select TOP 1 * from Messages")
                    MessageRecord = MessageData.Tables(0).NewRow
                    MessageRecord.Item("TimePosted") = TimeStamp
                End If
                MessageRecord.Item("Title") = Title
                MessageRecord.Item("Body") = Body
                MessageRecord.Item("IPAddress") = IPAddress
                MessageRecord.Item("ForumID") = ForumID
                MessageRecord.Item("UserID") = UserID
                If ParentID > 0 Then
                    MessageRecord.Item("ParentID") = ParentID
                    MessageRecord.Item("Posts") = 0
                Else
                    MessageRecord.Item("Posts") = 1
                    ThreadFlag = True
                End If
                If ID <= 0 Then
                    MessageData.Tables(0).Rows.Add(MessageRecord)
                    SetDataset(MessageData.Tables(0).TableName, MessageData)
                    ID = GetScalar("SELECT @@IDENTITY")
                    If ThreadFlag = True Then
                        ExecuteSQL("Update Messages set ParentID = ID where ID = " & System.Convert.ToString(ID))
                        ParentID = ID
                    Else
                        ExecuteSQL("Update Messages set Posts = Posts + 1 where ID = " & System.Convert.ToString(ParentID))
                        ExecuteSQL("Update Messages set LastUpdated = '" & TimeStamp & "' where ID = " & System.Convert.ToString(ParentID))
                    End If
                Else
                    SetDataset(MessageData.Tables(0).TableName, MessageData)
                End If
            End If
        End Function
        Function DeleteMessage(ByVal ID As Integer) As Boolean
            If ID > 0 Then
                ExecuteSQL("Delete from Messages where ID = " & System.Convert.ToString(ID))
                Return True
            Else
                Return False
            End If
        End Function
        Public Function CreateMessageOptionButtons(ByVal MyUserID As Integer, ByVal ForumID As Integer, ByVal MessageID As Integer, ByVal ThreadID As Integer, ByVal MessageUserID As Integer, ByVal AdminFlag As Boolean) As String
            Dim MyArticle As Article
            MyArticle = New Article(MyConnString)
            CreateMessageOptionButtons &= "<table><tr>"
            If MyUserID = MessageUserID Or AdminFlag = True Then
                CreateMessageOptionButtons &= "<td>" & MyArticle.CreateHTMLButton("forumedit/editpost.aspx?id=" & System.Convert.ToString(MessageID), "Edit Post", "") & "</td>"
            End If
            CreateMessageOptionButtons &= "<td>" & MyArticle.CreateHTMLButton("forumedit/editpost.aspx?forumid=" & System.Convert.ToString(ForumID) & "&parentid=" & System.Convert.ToString(ThreadID) & "&replyid=" & System.Convert.ToString(MessageID), "Reply to Post", "") & "</td>"
            CreateMessageOptionButtons &= "</tr></table>"
            MyArticle.CloseConn()
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
            MySess = New SessionAccess
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

    Public Class Search
        Inherits pengine.Data.DBAccess
        Dim MySess As SessionAccess
        Public Function BuildLink(ByVal ID As Integer, ByVal Type As String, Optional ByVal ExtraHTML As String = "") As String
            Select Case Type.ToUpper
                Case "ARTICLE"
                    BuildLink = "displayarticle.aspx?id=" & System.Convert.ToString(ID) & ExtraHTML
                Case "NEWS"
                    BuildLink = "displaynews.aspx?id=" & System.Convert.ToString(ID)
                Case "FORUM"
                    BuildLink = "browsemessages.aspx?threadid=" & System.Convert.ToString(ID) & ExtraHTML
            End Select
        End Function
        Public Function Query(ByVal QueryTerm As String, ByVal UserID As Integer, ByVal ForumFlag As Boolean) As DataSet
            Dim sql As String
            If ForumFlag = True Then
                sql = "SELECT Distinct ""FORUM"" as Type, Parent.Title as SectionName,messages.ID,Messages.Title as Name" _
                & ",messages.body as content,messages.timeposted as created, parent.id as parentid, parent.forumid as forumid" _
                & ",users.name as username from messages,messages as parent,users where messages.userid = users.id " _
                & "and messages.parentid = parent.id"
                If QueryTerm <> "" Then
                    sql = sql & " and (messages.body like ""%" & QueryTerm & "%"" or messages.title like ""%" & QueryTerm & "%"")"
                End If
                If UserID > 0 Then
                    sql = sql & " and users.id = " & System.Convert.ToString(UserID)
                End If
                sql = sql & " order by messages.timeposted DESC,messages.id DESC"
                Query = GetDataset(sql)
            ElseIf QueryTerm <> "" Then
                sql = "SELECT Distinct ""ARTICLE"" as Type,ArticleSection.Name as SectionName,ID,Articles.Name" _
                & ",description as content,#1/1/1990# as created from Articles,ArticleSection where " _
                & "Articles.ID = ArticleSection.ArticleID and (data like ""%" & QueryTerm & "%"" " _
                & "or ArticleSection.Name like ""%" & QueryTerm & "%"" or Articles.Name like ""%" & QueryTerm & "%"") " _
                & "and visible = true " _
                & "UNION Select Distinct ""NEWS"" as Type,""-NA-"" as SectionName,ID,Title as Name,ArticleData as content " _
                & ",TimePosted as created from SystemNews where (ArticleData like ""%" & QueryTerm & "%"" " _
                & "or title like ""%" & QueryTerm & "%"") order by Type ASC,created DESC,id DESC"
                Query = GetDataset(sql)
            Else
                Query = New DataSet
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
            MySess = New SessionAccess
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

    Public Class Theme
        Dim MySess As SessionAccess
        Public CSSCode As String
        Public Function GetThemeList() As ArrayList
            GetThemeList = New ArrayList
            Dim FSInfo As System.IO.DirectoryInfo
            Dim DirList() As System.IO.DirectoryInfo
            Dim DirPtr As Integer
            If MySess.Session.Item("basepath") <> "" Then
                FSInfo = New System.IO.DirectoryInfo(MySess.Server.MapPath(MySess.Session.Item("basepath") & "/themes/"))
            Else
                FSInfo = New System.IO.DirectoryInfo(MySess.Server.MapPath("./themes/"))
            End If
            DirList = FSInfo.GetDirectories("*")
            For DirPtr = DirList.GetLowerBound(0) To DirList.GetUpperBound(0)
                GetThemeList.Add(DirList(DirPtr).Name)
            Next
        End Function
        Public Sub LoadTheme(ByVal ThemeName As String)
            Dim FSInfo As System.IO.FileInfo
            Dim FSStream As System.IO.TextReader
            Dim DataRecord As String
            Dim DataFields() As String
            If MySess.Session.Item("basethemepath") <> "" Then
                FSInfo = New System.IO.FileInfo(MySess.Server.MapPath(MySess.Session.Item("basethemepath") & ThemeName & "/" & ThemeName & ".csv"))
            Else
                FSInfo = New System.IO.FileInfo(MySess.Server.MapPath("./themes/" & ThemeName & "/" & ThemeName & ".csv"))
            End If
            If FSInfo.Exists Then
                MySess.Trace.Write("Theme file located - parsing settings from this file.")
                FSStream = FSInfo.OpenText
                While FSStream.Peek() >= 0
                    DataRecord = FSStream.ReadLine()
                    DataFields = DataRecord.Split(",")
                    DataFields(0) = DataFields(0).ToUpper.Trim
                    DataFields(1) = DataFields(1).ToUpper.Trim
                    If DataFields(0).StartsWith("PAGE") Or DataFields(0).StartsWith("HEADER") _
                    Or DataFields(0).StartsWith("SHEADER") Or DataFields(0).StartsWith("CONTENT") _
                    Or DataFields(0).StartsWith("FOOTER") Or DataFields(0).StartsWith("MENU") Then
                        If DataFields(1) = "TRUE" Then
                            MySess.Session(DataFields(0).ToLower) = True
                        ElseIf DataFields(1) = "FALSE" Then
                            MySess.Session(DataFields(0).ToLower) = False
                        Else
                            MySess.Session(DataFields(0).ToLower) = DataFields(1)
                        End If
                    End If
                End While
                FSStream.Close()
                MySess.Session.Item("theme") = ThemeName
                MapThemeImages()
                CSSCode = BuildCSS()
                MySess.Session.Item("themecss") = CSSCode
            Else
                MySess.Trace.Write("Theme file not located. Throwing an Error.")
            End If
        End Sub
        Private Sub MapThemeImages()
            Dim themeroot As String
            Dim listptr As Integer
            Dim imagelist() As String = {"PageLImage", "PageRImage", "PageBGImage", "HeaderLImage", "HeaderMImage", "HeaderRImage" _
            , "SHeaderLImage", "SHeaderMImage", "SHeaderRImage", "FooterLImage", "FooterRImage", "FooterMImage", "MenuLImage" _
            , "MenuMImage", "MenuRImage", "ContentBGImage", "MenuBarBGImage"}
            If MySess.Session.Item("basethemepath") <> "" Then
                themeroot = MySess.Session.Item("basethemepath") & MySess.Session("theme") & "/"
            Else
                themeroot = "./themes/" & MySess.Session.Item("theme") & "/"
            End If
            For listptr = LBound(imagelist) To UBound(imagelist)
                If MySess.Session.Item(imagelist(listptr)) <> "" Then
                    MySess.Session.Item(imagelist(listptr)) = themeroot & MySess.Session.Item(imagelist(listptr))
                End If
            Next
        End Sub
        Private Function BuildCSS() As String
            Dim MyCSS As String
            MyCSS = "A:link {color: " & MySess.Session.Item("pagelinkcolor") & "}" & System.Environment.NewLine
            MyCSS &= "A:visited {color: " & MySess.Session.Item("pagevlinkcolor") & "}" & System.Environment.NewLine
            MyCSS &= "A:active {color: " & MySess.Session.Item("pagealinkcolor") & "}" & System.Environment.NewLine
            MyCSS &= "B {color: " & MySess.Session.Item("contentboldcolor") & "}" & System.Environment.NewLine

            MyCSS &= "#pagebody {"
            MyCSS &= "margin-top: " & MySess.Session.Item("pagetopmargin") & "; "
            MyCSS &= "margin-left: " & MySess.Session.Item("pageleftmargin") & "; "
            MyCSS &= "margin-right: " & MySess.Session.Item("pagerightmargin") & "; "
            If MySess.Session.Item("PageBGImage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("pagebgimage") & """); "
            End If
            MyCSS &= "background-color: " & MySess.Session.Item("pagebgcolor") & "; }" & System.Environment.NewLine

            MyCSS &= "#contentbody {"
            If MySess.Session.Item("contentfont") <> "" Then
                MyCSS &= "font-family: " & MySess.Session.Item("contentfont") & "; "
            End If
            If IsNumeric(MySess.Session.Item("contentfontsize")) Then
                MyCSS &= "font-size: " & MySess.Session.Item("contentfontsize") & "px; "
            End If
            MyCSS &= "color: " & MySess.Session.Item("ContentFGColor") & "; "
            If MySess.Session.Item("contentbgimage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("contentbgimage") & """); "
            End If
            MyCSS &= "background-color: " & MySess.Session.Item("ContentBGColor") & "; }" & System.Environment.NewLine


            MyCSS &= "#menubody {"
            If MySess.Session.Item("menubarbgimage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("menubarbgimage") & """); "
            End If
            MyCSS &= "background-color: " & MySess.Session.Item("menubarbgcolor") & "; }" & System.Environment.NewLine

            MyCSS &= "#headerleftcell {"
            If MySess.Session.Item("headerbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("headerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#headermidcell {"
            If MySess.Session.Item("headermimage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("headermimage") & """); "
            End If
            If MySess.Session.Item("headerbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("headerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#headermidtext {"
            If MySess.Session.Item("headerfont") <> "" Then
                MyCSS &= "font-family: " & MySess.Session.Item("headerfont") & "; "
            End If
            If MySess.Session.Item("headerfontsize") <> "" Then
                MyCSS &= "font-size: " & MySess.Session.Item("headerfontsize") & "px; "
            End If
            If MySess.Session.Item("headerfgcolor") <> "" Then
                MyCSS &= "color: " & MySess.Session.Item("headerfgcolor") & "; "
            End If
            MyCSS &= "font-weight:bold; }" & System.Environment.NewLine

            MyCSS &= "#headerrightcell {"
            If MySess.Session.Item("headerbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("headerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#sheaderleftcell {"
            If MySess.Session.Item("sheaderbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("sheaderbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#sheadermidcell {"
            If MySess.Session.Item("sheadermimage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("sheadermimage") & """); "
            End If
            If MySess.Session.Item("sheaderbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("sheaderbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#sheadermidtext {"
            If MySess.Session.Item("sheaderfont") <> "" Then
                MyCSS &= "font-family: " & MySess.Session.Item("sheaderfont") & "; "
            End If
            If MySess.Session.Item("sheaderfontsize") <> "" Then
                MyCSS &= "font-size: " & MySess.Session.Item("sheaderfontsize") & "; "
            End If
            If MySess.Session.Item("sheaderfgcolor") <> "" Then
                MyCSS &= "color: " & MySess.Session.Item("sheaderfgcolor") & "; "
            End If
            MyCSS &= "font-weight:bold; }" & System.Environment.NewLine

            MyCSS &= "#sheaderrightcell {"
            If MySess.Session.Item("sheaderbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("sheaderbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#footerleftcell {"
            If MySess.Session.Item("footerbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("footerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#footermidcell {"
            If MySess.Session.Item("footermimage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("footermimage") & """); "
            End If
            If MySess.Session.Item("footerbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("footerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#footerrightcell {"
            If MySess.Session.Item("footerbgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("footerbgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#lheadercell {"
            MyCSS &= "background-color: " & MySess.Session.Item("contentlheadbgcolor") & "; "
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#lheadertext {"
            MyCSS &= "color: " & MySess.Session.Item("contentlheadfgcolor") & "; "
            MyCSS &= "font-weight: bold }" & System.Environment.NewLine

            MyCSS &= "#lcontentcell {"
            MyCSS &= "background-color: " & MySess.Session.Item("contentlistbgcolor1") & "; "
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#lcontenttext {"
            MyCSS &= "color: " & MySess.Session.Item("contentlistfgcolor1") & "; "
            MyCSS &= "font-weight: normal }" & System.Environment.NewLine

            MyCSS &= "#lcontentcellb {"
            MyCSS &= "background-color: " & MySess.Session.Item("contentlistbgcolor2") & "; "
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#lcontenttextb {"
            MyCSS &= "color: " & MySess.Session.Item("contentlistfgcolor2") & "; "
            MyCSS &= "font-weight: normal }" & System.Environment.NewLine

            MyCSS &= "#menutable {"
            If MySess.Session.Item("menuborder") = "" Or MySess.Session("menuborder") = 0 Then
                MyCSS &= "border-style: none; border-collapse: collapse; "
            Else
                MyCSS &= "border: " & MySess.Session.Item("menuborder") & "px; border-style: solid; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#menurow {"
            If MySess.Session.Item("menubgcolor") <> "" Then
                MyCSS &= "background-color: " & MySess.Session.Item("menubgcolor") & "; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#menumidrow {"
            If MySess.Session.Item("menumimage") <> "" Then
                MyCSS &= "background-image:url(""" & MySess.Session.Item("menumimage") & """); "
            End If
            If MySess.Session.Item("MenuFontCenter") = 1 Then
                MyCSS &= "text-align: center; "
            End If
            MyCSS &= "}" & System.Environment.NewLine

            MyCSS &= "#menutext {"
            If MySess.Session.Item("menufont") <> "" Then
                MyCSS &= "font-family: " & MySess.Session.Item("menufont") & "; "
            End If
            If MySess.Session.Item("menufontsize") <> "" Then
                MyCSS &= "font-size: " & MySess.Session.Item("menufontsize") & "; "
            End If
            If MySess.Session.Item("menufgcolor") <> "" Then
                MyCSS &= "color: " & MySess.Session.Item("menufgcolor") & "; "
            End If
            MyCSS &= "font-weight:bold; }" & System.Environment.NewLine

            Return MyCSS
        End Function
        Public Sub New()
            MySess = New SessionAccess
        End Sub
    End Class

    Public Class Quote
        Inherits DBAccess
        Public Function Count() As Integer
            Count = GetScalar("Select Max(ID) from QuoteList")
        End Function
        Public Function Random() As String
            Dim QuoteCount As Integer
            Dim QuoteID As Integer
            Dim Randomizer As System.Random = New System.Random(DateTime.Now.Millisecond)
            QuoteCount = Count()
            If QuoteCount > 0 Then
                QuoteID = (Randomizer.Next() Mod QuoteCount)
                Random = GetScalar("Select Text from QuoteList where ID = " & System.Convert.ToString(QuoteID))
            Else
                Random = "There are no quotes available to choose from."
            End If
        End Function
        Public Sub New(ByVal ConnString As String)
            MyBase.New(ConnString)
        End Sub
        Protected Overloads Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

    Public Class Settings
        Dim MySess As SessionAccess
        Public Sub LoadIntoSession()
            MySess.Trace.Write("Loading Settings into Session Variable")
            'Code here should be replaced to pull settings from some external source such as a CSV file.
            Dim SettingData As System.IO.StreamReader
            Dim FSInfo As System.IO.FileInfo
            Dim FSStream As System.IO.TextReader
            Dim DataRecord As String
            Dim DataFields() As String
            If MySess.Session.Item("basepath") <> "" Then
                FSInfo = New System.IO.FileInfo(MySess.Server.MapPath(MySess.Session.Item("basepath")) & "settings.asp")
            Else
                FSInfo = New System.IO.FileInfo(MySess.Server.MapPath("./") & "\settings.asp")
            End If
            If FSInfo.Exists Then
                MySess.Trace.Write("Settings file located - parsing settings from this file.")
                FSStream = FSInfo.OpenText
                While FSStream.Peek() >= 0
                    DataRecord = FSStream.ReadLine()
                    If DataRecord.StartsWith("'") Then
                        'Remove Leading Comment from Line
                        DataRecord = DataRecord.Substring(1, DataRecord.Length - 1)
                        DataFields = DataRecord.Split(",")
                        MySess.Session(DataFields(0)) = DataFields(1)
                    End If
                End While
                FSStream.Close()
            Else
                MySess.Trace.Write("Settings file could not be found - loading default settings.")
                MySess.Session.Item("ownername") = "PEngine User"
                MySess.Session.Item("owneremail") = "pengineuser@pengine.com"
                MySess.Session.Item("defaultpagetitle") = "Presentation Engine 3.0"
                MySess.Session.Item("defaulttheme") = "default"
                MySess.Session.Item("frontpagelogo") = "penginelogo.png"
                MySess.Session.Item("newssummaryperpage") = 10
                MySess.Session.Item("newsperpage") = 5
                MySess.Session.Item("searchresultsperpage") = 20
                MySess.Session.Item("forumpostsperpage") = 15
                MySess.Session.Item("forumeditlimit") = 30
                MySess.Session.Item("pagesize") = 0
                MySess.Session.Item("menusize") = 150
                MySess.Session.Item("excluderesume") = 0
                MySess.Session.Item("excludetheme") = 0
                MySess.Session.Item("excludeleet") = 0
                MySess.Session.Item("excludequotes") = 0
                MySess.Session.Item("excludesearch") = 0
                MySess.Session.Item("homelabel") = "Home"
                MySess.Session.Item("themelabel") = "Theme"
                MySess.Session.Item("resumelabel") = "Resume"
                MySess.Session.Item("leetlabel") = "I am Elite"
                MySess.Session.Item("leetlabel2") = "I am a Loser"
                MySess.Session.Item("adminlabel") = "Admin"
                MySess.Session.Item("adminlabel2") = "Standard"
                MySess.Session.Item("dbrelativepath") = "./data"
                MySess.Session.Item("dbfilename") = "pengine.mdb"
                MySess.Session.Item("timeout") = 30
                MySess.Session.Item("adminpass") = ""
                MySess.Session.Item("godpass") = ""
            End If
            'Build Connection String
            MySess.Session.Item("ConnectionString") = "PROVIDER=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Locking Mode=1;Data Source=" & MySess.Server.MapPath(MySess.Session("basepath")) _
            & MySess.Session.Item("dbrelativepath") & "/" & MySess.Session.Item("dbfilename")
            FSInfo = New System.IO.FileInfo(MySess.Server.MapPath(MySess.Session("basepath")) & MySess.Session.Item("dbrelativepath") & "/forum.mdb")
            If FSInfo.Exists Then
                MySess.Session.Item("FConnectionString") = "PROVIDER=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Locking Mode=1;Data Source=" & MySess.Server.MapPath(MySess.Session("basepath")) _
                & MySess.Session.Item("dbrelativepath") & "/forum.mdb"
                MySess.Session.Item("forum") = True
            Else
                MySess.Session.Item("forum") = False
            End If
            MySess.Session.Item("settings") = 1
        End Sub
        Public Function SaveIntoASPFile(ByVal OwnerName As String, ByVal OwnerEmail As String, ByVal DefaultPageTitle As String _
        , ByVal DefaultTheme As String, ByVal FrontPageLogo As String, ByVal NewsSummaryPerPage As String, ByVal NewsPerPage As String _
        , ByVal SearchResultsPerPage As String, ByVal ForumPostsPerPage As String, ByVal ForumEditLimit As String _
        , ByVal PageSize As String, ByVal MenuSize As String, ByVal ExcludeResume As Integer, ByVal ExcludeTheme As Integer _
        , ByVal ExcludeLeet As Integer, ByVal ExcludeQuotes As Integer, ByVal ExcludeSearch As Integer, ByVal HomeLabel As String _
        , ByVal ThemeLabel As String, ByVal ResumeLabel As String, ByVal LeetLabel As String, ByVal LeetLabel2 As String _
        , ByVal AdminLabel As String, ByVal AdminLabel2 As String, ByVal DbRelativePath As String, ByVal DbFileName As String _
        , ByVal Timeout As String, ByVal AdminPass As String, ByVal GodPass As String) As String
            Dim SettingsFile As System.IO.FileInfo
            Dim DBFile As System.IO.FileInfo
            Dim OutputStream As System.IO.TextWriter
            If Not IsNumeric(NewsSummaryPerPage) Or Not IsNumeric(NewsPerPage) Or Not IsNumeric(SearchResultsPerPage) _
            Or Not IsNumeric(ForumPostsPerPage) Or Not IsNumeric(ForumEditLimit) Or Not IsNumeric(PageSize) _
            Or Not IsNumeric(MenuSize) Or Not IsNumeric(Timeout) Then
                SaveIntoASPFile &= "You provide a non-numeric value for a numeric field.  Please recheck your input values.|"
            End If
            DBFile = New System.IO.FileInfo(MySess.Server.MapPath(MySess.Session.Item("basepath")) & DbRelativePath & "/" & DbFileName)
            If DBFile.Exists = False Then
                SaveIntoASPFile &= "The combination of the Database Relative Path and the Database filename you provided points to a non-existant file.|"
            End If
            If SaveIntoASPFile = "" Then
                SettingsFile = New System.IO.FileInfo(MySess.Server.MapPath(MySess.Session.Item("basepath")) & "settings.asp")
                If SettingsFile.Exists Then
                    SettingsFile.Delete()
                End If
                OutputStream = SettingsFile.AppendText
                OutputStream.WriteLine("<%")
                OutputStream.WriteLine("'ownername," & OwnerName)
                OutputStream.WriteLine("'owneremail," & OwnerEmail)
                OutputStream.WriteLine("'defaultpagetitle," & DefaultPageTitle)
                OutputStream.WriteLine("'defaulttheme," & DefaultTheme)
                OutputStream.WriteLine("'frontpagelogo," & FrontPageLogo)
                OutputStream.WriteLine("'newsperpage," & NewsPerPage)
                OutputStream.WriteLine("'newssummaryperpage," & NewsSummaryPerPage)
                OutputStream.WriteLine("'newsperpage," & NewsPerPage)
                OutputStream.WriteLine("'searchresultsperpage," & SearchResultsPerPage)
                OutputStream.WriteLine("'forumpostsperpage," & ForumPostsPerPage)
                OutputStream.WriteLine("'forumeditlimit," & ForumEditLimit)
                OutputStream.WriteLine("'pagesize," & PageSize)
                OutputStream.WriteLine("'menusize," & MenuSize)
                OutputStream.WriteLine("'excluderesume," & ExcludeResume)
                OutputStream.WriteLine("'excludetheme," & ExcludeTheme)
                OutputStream.WriteLine("'excludeleet," & ExcludeLeet)
                OutputStream.WriteLine("'excludequotes," & ExcludeQuotes)
                OutputStream.WriteLine("'excludesearch," & ExcludeSearch)
                OutputStream.WriteLine("'homelabel," & HomeLabel)
                OutputStream.WriteLine("'themelabel," & ThemeLabel)
                OutputStream.WriteLine("'resumelabel," & ResumeLabel)
                OutputStream.WriteLine("'leetlabel," & LeetLabel)
                OutputStream.WriteLine("'leetlabel2," & LeetLabel2)
                OutputStream.WriteLine("'adminlabel," & AdminLabel)
                OutputStream.WriteLine("'adminlabel2," & AdminLabel2)
                OutputStream.WriteLine("'dbrelativepath," & DbRelativePath)
                OutputStream.WriteLine("'dbfilename," & DbFileName)
                OutputStream.WriteLine("'timeout," & Timeout)
                If AdminPass <> "" Then
                    OutputStream.WriteLine("'adminpass," & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(AdminPass, "MD5"))
                Else
                    OutputStream.WriteLine("'adminpass," & MySess.Session.Item("adminpass"))
                End If
                If GodPass <> "" Then
                    OutputStream.WriteLine("'godpass," & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(GodPass, "MD5"))
                Else
                    OutputStream.WriteLine("'godpass," & MySess.Session.Item("godpass"))
                End If
                OutputStream.WriteLine("%>")
                OutputStream.Close()
            End If
        End Function
        Public Sub New()
            MySess = New SessionAccess
            If MySess.Session.Item("settings") <> 1 Then
                Call LoadIntoSession()
            End If
            If MySess.Session.Item("theme") = "" Then
                Dim MyTheme As Theme = New Theme
                MyTheme.LoadTheme(MySess.Session.Item("defaulttheme"))
                MyTheme = Nothing
            End If
        End Sub
    End Class
End Namespace
