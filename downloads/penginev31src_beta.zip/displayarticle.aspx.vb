Imports pengine.Data
Imports System.Data.OleDB

Public Class displayarticle
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lstsection As System.Web.UI.WebControls.DropDownList
    Protected WithEvents RptArticle As System.Web.UI.WebControls.Repeater
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblsection As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyArticle As Article
    Public ArticleID As Integer = 0
    Public SectionList As ArrayList = New ArrayList
    Public SectionPtr As Integer = 0
    Public MyEditButtonHTML As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        Dim ArticleData As DataSet
        Dim DefaultSection As String
        Dim CurrentSection As String
        MyArticle = New Article(Session.Item("ConnectionString"))
        lstsection.Visible = True
        lblsection.Visible = True
        'The following code automatically initializes fields based on querystring input on first access.
        If IsPostBack = False Then
            If txtid.Text = "" Then
                txtid.Text = Request.Item("id")
            End If
            ArticleID = txtid.Text
            SectionList = MyArticle.SectionList(ArticleID)
            DefaultSection = MyArticle.DefaultSection(ArticleID)
            If SectionList.Count > 1 Then
                lstsection.Items.Clear()
                For SectionPtr = 0 To SectionList.Count - 1
                    lstsection.Items.Add(New ListItem(SectionList.Item(SectionPtr), SectionList.Item(SectionPtr)))
                    If Request.Item("Section") <> "" Then
                        CurrentSection = SectionList.Item(SectionPtr)
                        If CurrentSection.ToUpper = Request.Item("Section").ToUpper Then
                            lstsection.Items(SectionPtr).Selected = True
                        End If
                    Else
                        If SectionList.Item(SectionPtr) = DefaultSection Then
                            lstsection.Items(SectionPtr).Selected = True
                        End If
                    End If
                Next
            Else
                lstsection.Visible = False
                lblsection.Visible = False
            End If
        End If
        If Session.Item("admin") = True Then
            MyEditButtonHTML = MyArticle.CreateHTMLButton("./admin/editarticle.aspx?id=" & txtid.Text, "Edit Article", "")
        End If
        'The following code actually binds the article data to the page.
        If IsNumeric(txtid.Text) Then
            ArticleID = txtid.Text
            PEngine_Menu1.ArticleID = txtid.Text
            PEngine_Header1.ArticleID = txtid.Text
            PEngine_Header1.ArticleCategory = MyArticle.Category(txtid.Text)
            If lstsection.SelectedIndex >= 0 Then
                ArticleData = MyArticle.GetArticleSection(ArticleID, lstsection.SelectedItem.Text)
            Else
                ArticleData = MyArticle.GetArticleSection(ArticleID, "")
            End If
            RptArticle.DataSource = ArticleData
            RptArticle.DataBind()
        End If
        MyArticle.CloseConn()
    End Sub

End Class
