Imports pengine.Data
Imports System.Data.OleDB

Public Class editnews
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lbltitle As System.Web.UI.WebControls.Label
    Protected WithEvents txttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbliconfilename As System.Web.UI.WebControls.Label
    Protected WithEvents lsticonfilename As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbldatetime As System.Web.UI.WebControls.Label
    Protected WithEvents txtdatetime As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbltext As System.Web.UI.WebControls.Label
    Protected WithEvents txttext As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String = ""
    Public MyArticle As Article
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        Dim MyNews As News
        Dim NewsData As DataSet = New DataSet
        Dim IconList As ArrayList = New ArrayList
        Dim IconPtr As Integer = 0
        MyArticle = New Article(Session("ConnectionString"))
        MyNews = New News(Session.Item("ConnectionString"))
        If txtid.Text = "" Then
            txtid.Text = Request.Item("id")
        End If
        If Not IsPostBack Then
            IconList = MyNews.GetIconList
            lsticonfilename.Items.Clear()
            For IconPtr = 0 To IconList.Count - 1
                lsticonfilename.Items.Add(New ListItem(IconList.Item(IconPtr)))
            Next
            If (txtid.Text <> "" And IsNumeric(txtid.Text)) Then
                NewsData = MyNews.GetNews(txtid.Text)
                If NewsData.Tables(0).Rows.Count > 0 Then
                    txttitle.Text = NewsData.Tables(0).Rows(0).Item("title")
                    txtdatetime.Text = NewsData.Tables(0).Rows(0).Item("timeposted")
                    txttext.Text = NewsData.Tables(0).Rows(0).Item("articledata")
                    For IconPtr = 0 To lsticonfilename.Items.Count - 1
                        If lsticonfilename.Items(IconPtr).Text = NewsData.Tables(0).Rows(0).Item("iconfilename") Then
                            lsticonfilename.Items(IconPtr).Selected = True
                        End If
                    Next
                End If
            Else
                txttitle.Text = ""
                txtdatetime.Text = DateTime.Now
                txttext.Text = ""
                txtid.Text = "-1"
            End If
        End If
        If txtid.Text <> "-1" Then
            MyTitle = "Editing News Story #" & txtid.Text
        Else
            MyTitle = "Creating a News Story"
        End If
        MyArticle.CloseConn()
        MyNews.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyNews As News
        Dim ErrorText As String
        MyNews = New News(Session.Item("ConnectionString"))
        If IsDate(txtdatetime.Text) And txtdatetime.Text <> "" Then
            ErrorText = MyNews.SaveNews(txtid.Text, txttitle.Text, txtdatetime.Text, txttext.Text, lsticonfilename.SelectedItem.Text)
            If ErrorText <> "" Then
                lblerrors.Text = ErrorText.Replace("|", "<br>")
            Else
                lblerrors.Text = "Your changes were saved successfully."
                MyTitle = "Editing News Story #" & txtid.Text
            End If
        Else
            lblerrors.Text = "The Date/Time value you provided is in an incorrect format.  It should be (MM/DD/YYYY HH:MM:SS)."
        End If
        MyNews.CloseConn()
    End Sub
End Class
