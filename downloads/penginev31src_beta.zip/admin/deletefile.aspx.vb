Imports pengine.Data
Imports System.Data.OleDB

Public Class deletefile
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lbltitle As System.Web.UI.WebControls.Label
    Protected WithEvents txttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbliconfilename As System.Web.UI.WebControls.Label
    Protected WithEvents lsticonfilename As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbldatetime As System.Web.UI.WebControls.Label
    Protected WithEvents txtdatetime As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbltext As System.Web.UI.WebControls.Label
    Protected WithEvents txttext As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        Dim FileInfo As System.IO.FileInfo
        If Session("lastuploadlocation") <> "" And Request.Item("file") <> "" Then
            FileInfo = New System.IO.FileInfo(Session("lastuploadlocation") & Request.Item("file"))
            FileInfo.Delete()
        End If
        Response.Redirect("browsefiles.aspx")
    End Sub
End Class
