Imports pengine.Data
Imports System.Data.OleDB

Public Class editipban
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents lblposts As System.Web.UI.WebControls.Label
    Protected WithEvents lbljoindate As System.Web.UI.WebControls.Label
    Protected WithEvents txttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtdescription As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtpublicemail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtprivateemail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txthomeurl As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtaimaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txticqaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtyahooaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtmsnaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtnewpassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtconfirmpassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtfullname As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents chkmoderatorflag As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkdisabledflag As System.Web.UI.WebControls.CheckBox
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbllastpost As System.Web.UI.WebControls.Label
    Protected WithEvents lbllastip As System.Web.UI.WebControls.Label
    Protected WithEvents txtip As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyRecentPostsButtonHTML As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        If Not IsPostBack Then
            txtip.Text = ""
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyForum As Forum
        Dim ErrorText As String = ""
        Dim MyPassword As String = ""
        MyForum = New Forum(Session.Item("FConnectionString"))
        lblerrors.Text = ""
        ErrorText = MyForum.SaveIPBan(txtip.Text)
        MyForum.CloseConn()
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully."
            Response.Redirect("browseipbans.aspx")
        End If
    End Sub
End Class
