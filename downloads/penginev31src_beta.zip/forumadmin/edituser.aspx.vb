Imports pengine.Data
Imports System.Data.OleDB

Public Class edituser
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents lblposts As System.Web.UI.WebControls.Label
    Protected WithEvents lbljoindate As System.Web.UI.WebControls.Label
    Protected WithEvents txttitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtdescription As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtpublicemail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtprivateemail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txthomeurl As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtaimaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txticqaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtyahooaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtmsnaccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtnewpassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtconfirmpassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtfullname As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents chkmoderatorflag As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkdisabledflag As System.Web.UI.WebControls.CheckBox
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtusername As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbllastpost As System.Web.UI.WebControls.Label
    Protected WithEvents lbllastip As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyRecentPostsButtonHTML As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim UserData As DataSet
        Dim MySettings As Settings = New Settings
        Dim MyForum As Forum
        Dim MyArticle As Article
        If Not IsPostBack Then
            MyForum = New Forum(Session("FConnectionString"))
            MyArticle = New Article(Session("ConnectionString"))
            If Request.Item("id") <> "" And IsNumeric(Request.Item("id")) Then
                UserData = MyForum.GetUser(Request.Item("id"))
                If UserData.Tables(0).Rows.Count > 0 Then
                    txtid.Text = UserData.Tables(0).Rows(0).Item("ID")
                    txtusername.Text = UserData.Tables(0).Rows(0).Item("Name") & ""
                    txtfullname.Text = UserData.Tables(0).Rows(0).Item("FullName") & ""
                    lbljoindate.Text = UserData.Tables(0).Rows(0).Item("JoinDate") & ""
                    lblposts.Text = UserData.Tables(0).Rows(0).Item("PostCount")
                    txttitle.Text = UserData.Tables(0).Rows(0).Item("Title") & ""
                    txtdescription.Text = UserData.Tables(0).Rows(0).Item("Description") & ""
                    txtpublicemail.Text = UserData.Tables(0).Rows(0).Item("PublicEmail") & ""
                    txtprivateemail.Text = UserData.Tables(0).Rows(0).Item("PrivateEmail") & ""
                    txthomeurl.Text = UserData.Tables(0).Rows(0).Item("HomeURL") & ""
                    txtaimaccount.Text = UserData.Tables(0).Rows(0).Item("AIMAccount") & ""
                    txticqaccount.Text = UserData.Tables(0).Rows(0).Item("ICQAccount") & ""
                    txtyahooaccount.Text = UserData.Tables(0).Rows(0).Item("YahooAccount") & ""
                    txtmsnaccount.Text = UserData.Tables(0).Rows(0).Item("MSNAccount") & ""
                    chkmoderatorflag.Checked = UserData.Tables(0).Rows(0).Item("ModeratorFlag")
                    chkdisabledflag.Checked = UserData.Tables(0).Rows(0).Item("DisabledFlag")
                    lbllastip.Text = MyForum.GetLastIP(Request.Item("id"))
                    lbllastpost.Text = MyForum.GetLastPostTime(Request.Item("id"))
                Else
                    lblerrors.Text = "You specified a userid that does not exist."
                End If
                MyRecentPostsButtonHTML = MyArticle.CreateHTMLButton(Session.Item("basepath") & "displaysearch.aspx?queryterm=&source=forum&uid=" & Request.Item("id"), "Recent Posts", "")
            Else
                lblerrors.Text = "You specified a userid that does not exist."
            End If
            MyArticle.CloseConn()
            MyForum.CloseConn()
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyForum As Forum
        Dim ErrorText As String = ""
        Dim MyPassword As String = ""
        MyForum = New Forum(Session.Item("FConnectionString"))
        lblerrors.Text = ""
        If (txtnewpassword.Text = "" And txtconfirmpassword.Text = "") Or txtnewpassword.Text = txtconfirmpassword.Text Then
            MyPassword = txtnewpassword.Text
            ErrorText = MyForum.SaveUser(txtid.Text, txtusername.Text, txtfullname.Text, txttitle.Text, txtdescription.Text, txtpublicemail.Text, txtprivateemail.Text, txthomeurl.Text, txtaimaccount.Text, txticqaccount.Text, txtyahooaccount.Text, txtmsnaccount.Text, chkmoderatorflag.Checked, chkdisabledflag.Checked, MyPassword)
            If ErrorText <> "" Then
                lblerrors.Text = ErrorText.Replace("|", "<br>")
            Else
                lblerrors.Text = "Your changes were saved successfully."
            End If
        Else
            lblerrors.Text = "You must confirm your password correctly before your changes can be saved."
        End If
        MyForum.CloseConn()
    End Sub
End Class
