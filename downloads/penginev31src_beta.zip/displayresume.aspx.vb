Imports pengine.Data
Imports System.Data.OleDB

Public Class displayresume
    Inherits System.Web.UI.Page
    Public MyArticle As Article
    Public MyResume As ResumeParts
    Public MySkillHTML As String = ""

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents RptPersonal As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptObjective As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptEducation As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptWorkHistory As System.Web.UI.WebControls.Repeater

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        Dim PersonalData As DataSet
        Dim ObjectiveData As DataSet
        Dim SkillData As DataSet
        Dim EducationData As DataSet
        Dim WorkHistoryData As DataSet
        Dim OldType As String = ""
        Dim RowPtr As Integer = 0
        MyArticle = New Article(Session.Item("ConnectionString"))
        MyResume = New ResumeParts(Session.Item("ConnectionString"))

        PersonalData = MyResume.GetPersonals()
        RptPersonal.DataSource = PersonalData
        RptPersonal.DataBind()

        ObjectiveData = MyResume.GetObjectives()
        RptObjective.DataSource = ObjectiveData
        RptObjective.DataBind()

        SkillData = MyResume.GetSkills()
        If SkillData.Tables(0).Rows.Count > 0 Then
            MySkillHTML &= MyArticle.CreateHTMLSubHeader("Skills")
            While RowPtr < SkillData.Tables(0).Rows.Count - 1
                If OldType <> SkillData.Tables(0).Rows(RowPtr).Item("Type") Then
                    If OldType <> "" Then
                        MySkillHTML &= "<br></blockquote>" & System.Environment.NewLine
                    End If
                    MySkillHTML &= "<b>" & SkillData.Tables(0).Rows(RowPtr).Item("Type") & "</b><blockquote>" & System.Environment.NewLine
                    OldType = SkillData.Tables(0).Rows(RowPtr).Item("Type")
                    MySkillHTML &= MyArticle.ConvertToElite(SkillData.Tables(0).Rows(RowPtr).Item("Name"))
                    If Session.Item("admin") = True Then
                        MySkillHTML &= "<table><tr><td>" & MyArticle.CreateHTMLButton("./admin/editresumeskill.aspx?id=" _
                        & SkillData.Tables(0).Rows(RowPtr).Item("id"), "Edit", "")
                        MySkillHTML &= "</td><td>"
                        MySkillHTML &= MyArticle.CreateHTMLButton("./admin/deleteresumeskill.aspx?id=" _
                        & SkillData.Tables(0).Rows(RowPtr).Item("id"), "Delete", "Are you sure you wish to delete the skill '" _
                        & SkillData.Tables(0).Rows(RowPtr).Item("Name") & "' ?") & "</td></tr></table>" & System.Environment.NewLine
                    End If
                Else
                    If Session.Item("admin") = True Then
                        MySkillHTML &= MyArticle.ConvertToElite(SkillData.Tables(0).Rows(RowPtr).Item("Name"))
                        MySkillHTML &= "<table><tr><td>" & MyArticle.CreateHTMLButton("./admin/editresumeskill.aspx?id=" _
                        & SkillData.Tables(0).Rows(RowPtr).Item("id"), "Edit", "")
                        MySkillHTML &= "</td><td>"
                        MySkillHTML &= MyArticle.CreateHTMLButton("./admin/deleteresumeskill.aspx?id=" _
                        & SkillData.Tables(0).Rows(RowPtr).Item("id"), "Delete", "Are you sure you wish to delete the skill '" _
                        & SkillData.Tables(0).Rows(RowPtr).Item("Name") & "' ?") & "</td></tr></table>" & System.Environment.NewLine
                    Else
                        MySkillHTML &= ", " & MyArticle.ConvertToElite(SkillData.Tables(0).Rows(RowPtr).Item("Name"))
                    End If
                End If
                RowPtr += 1
            End While
            MySkillHTML &= "</blockquote>" & System.Environment.NewLine
            If Session.Item("admin") = True Then
                MySkillHTML &= MyArticle.CreateHTMLButton("./admin/editresumeskill.aspx", "New Skill", "")
            End If
        End If

        EducationData = MyResume.GetEducations()
        RptEducation.DataSource = EducationData
        RptEducation.DataBind()

        WorkHistoryData = MyResume.GetWorkHistories()
        RptWorkHistory.DataSource = WorkHistoryData
        RptWorkHistory.DataBind()

        MyResume.CloseConn()
        MyArticle.CloseConn()
    End Sub
End Class
