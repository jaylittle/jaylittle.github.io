Imports pengine.Data
Imports System.Data.OleDB

Public Class _default
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents imgpenginelogo As System.Web.UI.WebControls.Image
    Protected WithEvents RptNews As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyArticle As Article
    Public MyNews As News
    Public MyNewButtonHTML As String
    Public MyQuoteHTML As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        MyNews = New News(Session.Item("ConnectionString"))
        MyArticle = New Article(Session.Item("ConnectionString"))
        If Session.Item("frontpagelogo") <> "" Then
            imgpenginelogo.ImageUrl = "./images/system/" & Session.Item("frontpagelogo")
            imgpenginelogo.Visible = True
        Else
            imgpenginelogo.Visible = False
        End If
        If Session.Item("admin") = True Then
            MyNewButtonHTML = MyArticle.CreateHTMLButton("./admin/editnews.aspx", "Create Story", "")
        End If
        Dim NewsData As DataSet
        NewsData = MyNews.GetCurrentNews()
        RptNews.DataSource = NewsData
        RptNews.DataBind()
        If Session("excludequote") = 0 Then
            Dim MyQuote As Quote
            MyQuote = New Quote(Session.Item("ConnectionString"))
            MyQuoteHTML = "<center>" & MyArticle.ConvertToElite(MyQuote.Random()) & "</center><br>"
            MyQuote.CloseConn()
        End If
        MyNews.CloseConn()
    End Sub

End Class
