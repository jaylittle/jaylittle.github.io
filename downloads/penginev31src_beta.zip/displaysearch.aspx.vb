Imports pengine.Data
Imports System.Data.OleDB

Public Class displaysearch
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptForum As System.Web.UI.WebControls.Repeater
    Protected WithEvents RptPEngine As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyArticle As Article
    Public MyNews As News
    Public MyNextPageButtonHTML As String
    Public MyPrevPageButtonHTML As String
    Public MyForumFlag As Boolean = False
    Public MyPage As Integer = 0
    Public MyTotalPages As Integer = 0
    Public MyUserID As Integer = 0
    Public MyQueryTerm As String = ""
    Public MySource As String = ""
    Public MySearch As Search
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MySettings As Settings = New Settings
        Dim SearchResults As DataSet
        Dim ArticleID As Integer = 0
        Dim RowPtr As Integer = 0
        Dim PagePtr As Integer = 0
        Dim PostPtr As Integer = 0
        MyNews = New News(Session("ConnectionString"))
        MyArticle = New Article(Session("ConnectionString"))
        If Request.Item("Source").ToLower = "forum" Then
            MyForumFlag = True
            MySource = "forum"
        Else
            MyForumFlag = False
            MySource = "pengine"
        End If
        If Request.Item("uid") <> "" And IsNumeric(Request.Item("uid")) Then
            MyUserID = Request.Item("uid")
        End If
        If Request.Item("queryterm") <> "" Then
            MyQueryTerm = Request.Item("queryterm")
        End If
        If Request.Item("page") <> "" And IsNumeric(Request.Item("page")) Then
            MyPage = Request.Item("page")
        Else
            MyPage = 1
        End If
        If MyForumFlag = True Then
            MySearch = New Search(Session.Item("FConnectionString"))
            SearchResults = MySearch.Query(MyQueryTerm, MyUserID, MyForumFlag)
            MyTotalPages = ((SearchResults.Tables(0).Rows.Count - _
            (SearchResults.Tables(0).Rows.Count Mod Session.Item("SearchResultsPerPage"))) _
            / Session.Item("SearchResultsPerPage")) + 1
            For PagePtr = 1 To MyPage - 1
                For PostPtr = 1 To Session.Item("SearchResultsPerPage")
                    SearchResults.Tables(0).Rows(0).Delete()
                Next
            Next
            If SearchResults.Tables(0).Rows.Count > Session.Item("SearchResultsPerPage") Then
                For PostPtr = SearchResults.Tables(0).Rows.Count - 1 To Session.Item("SearchResultsPerPage") - 1 Step -1
                    SearchResults.Tables(0).Rows(PostPtr).Delete()
                Next
            End If
            RptForum.DataSource = SearchResults
            RptForum.DataBind()
            RptForum.Visible = True
            RptPEngine.Visible = False
            MySearch.CloseConn()
        Else
            MySearch = New Search(Session.Item("ConnectionString"))
            SearchResults = MySearch.Query(MyQueryTerm, MyUserID, MyForumFlag)
            MyTotalPages = ((SearchResults.Tables(0).Rows.Count - _
            (SearchResults.Tables(0).Rows.Count Mod Session.Item("SearchResultsPerPage"))) _
            / Session.Item("SearchResultsPerPage")) + 1
            For PagePtr = 1 To MyPage - 1
                For PostPtr = 1 To Session.Item("SearchResultsPerPage")
                    SearchResults.Tables(0).Rows(PostPtr - 1).Delete()
                Next
            Next
            If SearchResults.Tables(0).Rows.Count > Session.Item("SearchResultsPerPage") Then
                For PostPtr = SearchResults.Tables(0).Rows.Count - 1 To (MyPage * Session.Item("SearchResultsPerPage")) - 1 Step -1
                    SearchResults.Tables(0).Rows(PostPtr).Delete()
                Next
            End If
            RptPEngine.DataSource = SearchResults
            RptPEngine.DataBind()
            RptForum.Visible = False
            RptPEngine.Visible = True
            MySearch.CloseConn()
        End If
        If MyPage = 1 Then
            MyPrevPageButtonHTML = MyArticle.CreateHTMLButton("", "Prev Page", "")
        Else
            MyPrevPageButtonHTML = MyArticle.CreateHTMLButton("displaysearch.aspx?queryterm=" & MyQueryTerm _
            & "&uid=" & MyUserID & "&source=" & MySource & "&page=" & System.Convert.ToString(MyPage - 1), "Prev Page", "")
        End If
        If MyTotalPages = MyPage Then
            MyNextPageButtonHTML = MyArticle.CreateHTMLButton("", "Next Page", "")
        Else
            MyNextPageButtonHTML = MyArticle.CreateHTMLButton("displaysearch.aspx?queryterm=" & MyQueryTerm _
            & "&uid=" & MyUserID & "&source=" & MySource & "&page=" & System.Convert.ToString(MyPage + 1), "Next Page", "")
        End If
        MyArticle.CloseConn()
        MyNews.CloseConn()
    End Sub

End Class
