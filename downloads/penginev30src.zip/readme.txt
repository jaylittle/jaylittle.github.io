Presentation Engine 3.0
Developer's Release


ChangeLog from version 2.1:

	(1)	Integrated File Uploading System added.  This includes file/directory/upload
		management functions for all non source code / data portions of the application.
	(2)	Integrated Forum function added.  This allows for multiple user accounts,
		use of certain ARTICLE tags within posts (including [QUOTE][/QUOTE], IP bans,
		user profiles and full moderation capabilities.
	(3)	Two types of admin accounts are now available.  Admin and God.  God can do
		anything and Admin may have to provide additional passwords to edit certain
		parts of the system (including some settings).
	(4)	More granular security options enabled on a per article basis.  It is now
		possible to set a specific admin password on each article so that non god
		accounts will have to authenticate again when attempting to edit them.
	(5)	Administrative Session Restoration has been added.  This allows an admin user
		to recover a timed out session by reauthenticating and picking up where they
		left off.  This saves admin users from losing the contents of articles which
		took quite a bit of time to write and from having to save every few minutes
		in order to circumvent it.
	(6)	Random Quoting capability added.  It randomly prints a quote from the QuoteList
		table on the Front Page.
	(7)	System Settings options extended.  There are many more options to set here
		especially the capability to enable or disable certain features as well as
		change the text of several system generated menu buttons.
	(8)	This system is 90% CSS compatible now which means that the HTML code it
		generates is far cleaner and easier to read.
	(9)	Cross platforming aspects of the system have been improved.  The Engine now
		displays correctly on KHTML, Internet Explorer, and Gecko based browsers.
	(10)	The theming engine has been rewritten from scratch to allow for easier
		theme creation.  Themes are now a collection of image files and a csv file
		that are placed within their own subdirectory within the \themes subdirectory
		of the engine.
	(11)	All passwords within the system are now encypted using an MD5 hash routine.
	(12)	The special "I am Elite" feature has been added which will render all dynamic
		portions of the page in the infamous language of the wannabe hacker elite.
	(13)	Articles can now optionally display a drop down box containing the section
		names and/or the normal menu buttons down the side of the page.
	(14)	Using the "HTTP Link" field for the Article it is possible to make
		a single button on the menu bar into an external link.
	
	
System Files:

default.asp 		(main function routing page for application)
settings.asp		(contains user defined PEngine settings)
inc\admin.asp		(contains code for changing PEngine settings)
inc\articles.asp	(handles anything to do with articles)
inc\css.asp		(handles css encoding for the application)
inc\display.asp		(contains code for routing system defined page displays)
inc\forum_act.asp	(handles forum data processing related functions)
inc\forum_disp.asp	(handles forum page display related functions)
inc\init.asp		(general system/database code such as menu functions)
inc\md5.asp		(provides routines required to enable MD5 encryption for passwords)
inc\news.asp		(handles anything to do with news updates)
inc\quotes.asp		(handles the automatic displaying of quotes on front page)
inc\resume.asp		(handles anything to do with the resume)
inc\search.asp		(handles searching of articles/news/forum postings)
inc\uploader.asp	(handles file uploading and file management interface)
inc\upload\*		(third party code to enable easy upload and MIME decoding of files)
themes\theme.asp	(general theme loader)
data\			(holds database files for PEngine)
downloads\		(holds user defined downloads)
images\articles		(holds images for articles)
images\icons		(holds images used as story icons)
images\raw		(holds raw unconverted images)
images\system		(holds system images such as front page logo)

Most of the site expansion in the PEngine system is done through the use of
articles.  Articles allow you to transparently create and edit parts of a PEngine
site without uploading or downloading of HTML files.  (You do have to upload custom
images however). Articles have their own specific tags for content that are encased
in [] brackets. The list of tags is as follows:

[QUOTE][/QUOTE]
	Displays a portion of text within a quoted block.  This was added mainly to
	facilitate postings in the forums.

[IMAGE xxxx]
	Displays an image for the article directory or from another site if a
	full HTTP address was used.  For an image in the article directory only use
	the image filename as a parameter.

[SUBHEADER xxxx]
	Places a SubHeader on the page.  The parameter allows you to set the text
	that is displayed on the SubHeader.

[LINK address name]
	Provides an easy way of placing an Anchor Hyperlink.  The parameter is the
	address you would like to link to followed by the name of the link.

[ICON xxxx]
	Like the IMAGE tag above but this one uses images in the icon directory.
	You cannot use FULL HTTP address with this tag.

[SYSTEMIMAGE xxxx]
	Like the ICON tag except this one uses images in the system directory.

[SECTION xxxx]
	This tag creates a button which will link to another section of the same
	article.  The paramater is the name of the section you would like to link
	to.

[B][/B]
	Any content between these tags will be bolded.

[I][/I]
	Any content between these tags will be in italics.

[CENTER][/CENTER]
	Any content between these tags will be centered.

[RAWHTML][/RAWHTML]
	Any content in between these two tags will not processed by the article
	engine.  This would be useful if you were trying to create a page that
	explained how to use the Presentation Engine and these custom tags. Also
	keep in mind that carriage returns in between these tags will not be
	changed into <BR> tags.  This means you must supply your own <BR> tags.
[?]
	Any HTML tag can be written with the [] instead of the <> enclosures.  This
	functionality is not particular useful but it does help to lessen the
	learning curve associated with the application.  This way a user will not
	have to choose between [] and <>.  They can simply use [] and assume that
	its a Presentation Engine tag.


Note: These tags can also be used in News Stories and only a small subset of them
are allowed in Forum Postings for security reasons.

In order to set up the presentation engine - it does NOT need be an application 
in IIS and it can either reside in a root or subdirectory of some larger site. 
The backend database(s) are in Access97 format though it was primarily developed in 
Access 2002 and converted back to Access 97.

If you are upgrading from Version 2.1 you will probably want to run the 
UpgradeDatabase_to_30.vbs script located in the script directory.  It will make 
any structural changes required to upgrade the database.  Trust Me:  It will 
ease your pain.  Also be sure to edit the database location inside of the script 
file before running it.  

It is on the very top line.  Simply change the location inside the quotes and
double click the script file. 

If you need to convert from a Presentation Engine 2.0 Database (god forbid) then
a slightly modified (ie better commented) version of that script is included as well
but the file extension has been changed to ~vbs to prevent you from running it
accidentaly since it can corrupt your data if run on a 3.0/2.1 Database or twice on 
a 2.0 database.

Thanks,

Jason Little
http://www.jaylittle.com