Presentation Engine 2.1
User's Release

ChangeLog from version 2.0DR:

	(1) Carriage Returns in Articles and Stories are now changed into <BR> tags on
	    the fly.
	(2) A wider subset of PEngine tags has been implemented allowing for full HTML
	    functionality.
	(3) It is now possible to set body margin properties in the setup screen.
	(4) You can now switch the placement of the menu and content sections in 
	    the setup screen.
	(5) A new theme by the name of Linux was added. This theme is based on the look
	    of http://www.linux.com
	(6) A [RAWHTML] tag was added allowing a user to designate sections of content
	    that were not to be touched by the Article2HTML processor.
	(7) An UpgradeDatabase.vbs script was created to assist in moving from version 2
	    to version 2.1.  Backup your data before attempting this.  (Note: the script
	    must be edited to point to your 2.0 database).
	(8) PageLColor, PageRColor, and PageButton size were added to the theme engine.
	    These allow you to set the bgcolors of the left/right header sections and
	    define the non-menu width of PEngine themed buttons throughout the site.
	(9) Options were added to the setup screen that would allow a user to exclude
	    the Resume and Theme sections from the default menu configuration.  This
	    allows a PEngine site to look slightly more business like and to enforce
	    a single theme for all of its users.
       (10) Added a Sort Order field to the Article Section table.  This allows the
	    author to specify which order the section buttons appear in on the side
	    of the article.
	
System Files:

default.asp 		(main function routing page for application)
settings.asp		(contains user defined PEngine settings)
inc\admin.asp		(contains code for changing PEngine settings)
inc\articles.asp	(handles anything to do with articles)
inc\display.asp		(contains code for routing system defined page displays)
inc\init.asp		(general system/database code such as menu functions)
inc\news.asp		(handles anything to do with news updates)
inc\resume.asp		(handles anything to do with the resume)
themes\mode.asp		(handles specific mode overrides for themes - not used)
themes\theme.asp	(general theme loader)
data\			(holds database files for PEngine)
downloads\		(holds user defined downloads)
images\articles		(holds images for articles)
images\icons		(holds images used as story icons)
images\raw		(holds raw unconverted images)
images\system		(holds system images such as front page logo)

Most of the site expansion in the PEngine system is done through the use of
articles.  Articles allow you to transparently create and edit parts of a PEngine
site without uploading or downloading of HTML files.  (You do have to upload custom
images however). Articles have their own specific tags for content that are encased
in [] brackets. The list of tags is as follows:

[IMAGE xxxx]
	Displays an image for the article directory or from another site if a
	full HTTP address was used.  For an image in the article directory only use
	the image filename as a parameter.

[SUBHEADER xxxx]
	Places a SubHeader on the page.  The parameter allows you to set the text
	that is displayed on the SubHeader.

[LINK address name]
	Provides an easy way of placing an Anchor Hyperlink.  The parameter is the
	address you would like to link to followed by the name of the link.

[ICON xxxx]
	Like the IMAGE tag above but this one uses images in the icon directory.
	You cannot use FULL HTTP address with this tag.

[SYSTEMIMAGE xxxx]
	Like the ICON tag except this one uses images in the system directory.

[SECTION xxxx]
	This tag creates a button which will link to another section of the same
	article.  The paramater is the name of the section you would like to link
	to.

[B][/B]
	Any content between these tags will be bolded.

[I][/I]
	Any content between these tags will be in italics.

[CENTER][/CENTER]
	Any content between these tags will be centered.

[RAWHTML][/RAWHTML]
	Any content in between these two tags will not processed by the article
	engine.  This would be useful if you were trying to create a page that
	explained how to use the Presentation Engine and these custom tags. Also
	keep in mind that carriage returns in between these tags will not be
	changed into <BR> tags.  This means you must supply your own <BR> tags.
[?]
	Any HTML tag can be written with the [] instead of the <> enclosures.  This
	functionality is not particular useful but it does help to lessen the
	learning curve associated with the application.  This way a user will not
	have to choose between [] and <>.  They can simply use [] and assume that
	its a Presentation Engine tag.


Note: These tags can also be used in News Stories now as the Article2HTML engine 
has become more modularized. 

In order to set up the presentation engine - it does NOT need be an application 
in IIS and it can either reside in a root or subdirectory of some larger site. 
The backend database is in Access97 format though it was primarily developed in 
Access 2002 and converted back to Access 97.

If you are upgrading from Version 2.0 DR you will probably want to run the 
UpgradeDatabase.vbs script located in the script directory.  Run this once 
because it will change your <BR> tags into simple carriage returns and remove
all extraneous simple carriage returns.  It will also make any structural changes
required to upgrade the database.  Trust Me:  It will ease your pain.  Also be 
sure to edit the database location inside of the script file before running it.  
It is on the very top line.  Simply change the location inside the quotes and
double click the script file.  DO NOT RUN IT TWICE ON THE SAME DATABASE OR IT
WILL CORRUPT YOUR DATA.

Thanks,

Jason Little
http://www.jaylittle.com