Imports pengine.Data
Imports System.Data.OleDB

Public Class browsenews
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptNews As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public FirstStoryID As Integer = -1
    Public LastStoryID As Integer = -1
    Public TopStoryID As Integer = -1
    Public BottomStoryID As Integer = -1
    Public MyNews As News
    Public MyArticle As Article
    Public MyPrevPageButtonHTML As String = ""
    Public MyNextPageButtonHTML As String = ""
    Public MyNewButtonHTML As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim NewsData As DataSet
        Dim RowPtr As Integer = 0
        MyNews = New News(Application.Item("ConnectionString"))
        MyArticle = New Article(Application.Item("ConnectionString"))
        If IsNumeric(Request.Item("startstory")) Then
            NewsData = MyNews.GetNewsRange(Request.Item("startstory"), Application.Item("newssummaryperpage"), False)
        ElseIf IsNumeric(Request.Item("endstory")) Then
            NewsData = MyNews.GetNewsRange(Request.Item("endstory"), Application.Item("newssummaryperpage"), True)
        Else
            NewsData = MyNews.GetNewsRange(-1, Application.Item("newssummaryperpage"), True)
        End If
        If NewsData.Tables(0).Rows.Count > 0 Then
            FirstStoryID = NewsData.Tables(0).Rows(0).Item("ID")
            LastStoryID = FirstStoryID
            While RowPtr < NewsData.Tables(0).Rows.Count
                LastStoryID = NewsData.Tables(0).Rows(RowPtr).Item("ID")
                RowPtr += 1
            End While
        End If
        TopStoryID = MyNews.GetTopNewsID
        BottomStoryID = MyNews.GetBottomNewsID
        If FirstStoryID <> TopStoryID Then
            MyPrevPageButtonHTML = MyArticle.CreateHTMLButton("browsenews.aspx?endstory=" & System.Convert.ToString(FirstStoryID), "Previous Page", "")
        Else
            MyPrevPageButtonHTML = MyArticle.CreateHTMLButton("", "Previous Page", "")
        End If
        If LastStoryID <> BottomStoryID Then
            MyNextPageButtonHTML = MyArticle.CreateHTMLButton("browsenews.aspx?startstory=" & System.Convert.ToString(LastStoryID), "Next Page", "")
        Else
            MyNextPageButtonHTML = MyArticle.CreateHTMLButton("", "Next Page", "")
        End If
        If Session.Item("admin") = True Then
            MyNewButtonHTML = MyArticle.CreateHTMLButton("./admin/editnews.aspx", "Create Story", "")
        End If
        RptNews.DataSource = NewsData
        RptNews.DataBind()
        MyNews.CloseConn()
        Session.Item("LastNewsBrowse") = Request.Url.ToString
        MyArticle.CloseConn()
    End Sub

End Class
