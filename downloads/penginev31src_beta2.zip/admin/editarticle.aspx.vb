Imports pengine.Data
Imports System.Data.OleDB

Public Class editarticle
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents lblname As System.Web.UI.WebControls.Label
    Protected WithEvents txtname As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbldescription As System.Web.UI.WebControls.Label
    Protected WithEvents txtdescription As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbladminpass As System.Web.UI.WebControls.Label
    Protected WithEvents txtadminpass As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblcategory As System.Web.UI.WebControls.Label
    Protected WithEvents txtcategory As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblhttp As System.Web.UI.WebControls.Label
    Protected WithEvents txthttp As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbldefaultsection As System.Web.UI.WebControls.Label
    Protected WithEvents lstdefaultsection As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lblsectionsortorder As System.Web.UI.WebControls.Label
    Protected WithEvents txtsectionsortorder As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblsectionname As System.Web.UI.WebControls.Label
    Protected WithEvents txtsectionname As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblsectiondata As System.Web.UI.WebControls.Label
    Protected WithEvents txtsectiondata As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsavesection As System.Web.UI.WebControls.Button
    Protected WithEvents lstsection As System.Web.UI.WebControls.DropDownList
    Protected WithEvents chkvisible As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkhidebuttons As System.Web.UI.WebControls.CheckBox
    Protected WithEvents chkhidedropdown As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lbloptions As System.Web.UI.WebControls.Label
    Protected WithEvents txtsectionoldname As System.Web.UI.WebControls.TextBox
    Protected WithEvents btndisplaysection As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String = ""
    Public MyArticle As Article
    Public MySectionDeleteButtonHTML As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ArticleData As DataSet = New DataSet
        Dim SectionData As DataSet = New DataSet
        Dim SectionList As DataSet
        Dim SectionPtr As Integer = 0
        MyArticle = New Article(Application.Item("ConnectionString"))
        If Not IsPostBack Then
            Session.Item("LASTARTICLEEDITED") = Request.RawUrl
            lstdefaultsection.Items.Clear()
            lstsection.Items.Clear()
            txtid.Text = Request.Item("id")
            If txtid.Text <> "" Then
                SectionList = MyArticle.SectionList(Request.Item("ID"))
                For SectionPtr = 0 To SectionList.Tables(0).Rows.Count - 1
                    lstdefaultsection.Items.Add(New ListItem(SectionList.Tables(0).Rows(SectionPtr).Item("Name")))
                    lstsection.Items.Add(New ListItem(SectionList.Tables(0).Rows(SectionPtr).Item("Name")))
                Next
                ArticleData = MyArticle.GetArticle(txtid.Text)
                If ArticleData.Tables(0).Rows.Count > 0 Then
                    If ArticleData.Tables(0).Rows(0).Item("adminpass") & "" = "" _
                    Or Session("articleadmin" & ArticleData.Tables(0).Rows(0).Item("id")) = True _
                    Or Session.Item("god") = True Then
                        btnsavesection.Visible = True
                        txtname.Text = ArticleData.Tables(0).Rows(0).Item("Name") & ""
                        txtdescription.Text = ArticleData.Tables(0).Rows(0).Item("Description") & ""
                        txtcategory.Text = ArticleData.Tables(0).Rows(0).Item("Category") & ""
                        txthttp.Text = ArticleData.Tables(0).Rows(0).Item("http") & ""
                        chkvisible.Checked = ArticleData.Tables(0).Rows(0).Item("Visible")
                        chkhidebuttons.Checked = ArticleData.Tables(0).Rows(0).Item("HideButtons")
                        chkhidedropdown.Checked = ArticleData.Tables(0).Rows(0).Item("HideDropDown")
                        txtadminpass.Text = ""
                        If lstdefaultsection.SelectedIndex >= 0 Then
                            SectionData = MyArticle.GetArticleSection(txtid.Text, lstdefaultsection.SelectedItem.Text)
                        Else
                            SectionData = MyArticle.GetArticleSection(txtid.Text, "")
                        End If
                        If SectionData.Tables(0).Rows.Count > 0 Then
                            btndisplaysection.Visible = True
                            For SectionPtr = 0 To lstdefaultsection.Items.Count - 1
                                If lstdefaultsection.Items(SectionPtr).Text = SectionData.Tables(0).Rows(0).Item("Name") Then
                                    lstdefaultsection.Items(SectionPtr).Selected = True
                                End If
                                If lstsection.Items(SectionPtr).Text = SectionData.Tables(0).Rows(0).Item("Name") Then
                                    lstsection.Items(SectionPtr).Selected = True
                                End If
                            Next
                            txtsectionsortorder.Text = SectionData.Tables(0).Rows(0).Item("SortOrder")
                            txtsectionname.Text = SectionData.Tables(0).Rows(0).Item("Name")
                            txtsectionoldname.Text = SectionData.Tables(0).Rows(0).Item("Name")
                            txtsectiondata.Text = SectionData.Tables(0).Rows(0).Item("Data")
                        Else
                            txtsectionname.Text = "New Section"
                            txtsectionoldname.Text = ""
                            txtsectiondata.Text = "Section Data"
                            txtsectionsortorder.Text = "0"
                        End If
                    Else
                        MyArticle.CloseConn()
                        Response.Redirect("../login.aspx?mode=article&id=" & ArticleData.Tables(0).Rows(0).Item("id"))
                    End If
                End If
            Else
                txtname.Text = "New Article"
                txtdescription.Text = "This is a new Article"
                txtcategory.Text = "default"
                txthttp.Text = ""
                txtid.Text = "-1"
                chkvisible.Checked = False
                chkhidebuttons.Checked = False
                chkhidedropdown.Checked = False
                txtadminpass.Text = ""
                txtsectionname.Text = "New Section"
                txtsectionoldname.Text = ""
                txtsectiondata.Text = "Section Data"
                txtsectionsortorder.Text = "0"
            End If
            lstsection.Items.Add(New ListItem("[NEW]"))
        End If
        If txtid.Text <> "-1" Then
            MyTitle = "Editing Article #" & txtid.Text
        Else
            MyTitle = "Creating a New Article"
        End If
        If txtid.Text <> "-1" And txtsectionname.Text <> "" And btndisplaysection.Visible = True Then
            MySectionDeleteButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "admin/deletearticlesection.aspx?id=" & txtid.Text & "&section=" & Server.UrlEncode(txtsectionname.Text), "Delete", "Are you sure that you wish to delete this section?")
        End If
        MyArticle.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyArticle As Article
        Dim ErrorText As String
        Dim DefaultSection As String
        If lstdefaultsection.SelectedIndex >= 0 Then
            DefaultSection = lstdefaultsection.SelectedItem.Text
        Else
            DefaultSection = ""
        End If
        MyArticle = New Article(Application.Item("ConnectionString"))
        ErrorText = MyArticle.SaveArticle(txtid.Text, txtname.Text, txtdescription.Text, txtcategory.Text, txthttp.Text, DefaultSection, chkvisible.Checked, chkhidedropdown.Checked, chkhidebuttons.Checked, txtadminpass.Text)
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully in record #" & txtid.Text & "."
            btnsavesection.Visible = True
            MyTitle = "Editing Article #" & txtid.Text

            'Rebuild Category Listings
            MyArticle.WriteXML(MyArticle.CategoryList(True), Application.Item("cachefile_categories_admin"))
            MyArticle.WriteXML(MyArticle.CategoryList(False), Application.Item("cachefile_categories"))

            'Rebuild Category Article Lists
            Dim CategoryPtr As Integer
            Dim CategoryList As DataSet = MyArticle.CategoryList(True)
            For CategoryPtr = 0 To CategoryList.Tables(0).Rows.Count - 1
                Dim CategoryName As String = CategoryList.Tables(0).Rows(CategoryPtr).Item("category")
                Application.Item("cachefile_cat_" & CategoryName & "_file_admin") _
                = Application.Item("cachepath") & "\category_" & CategoryName & "_admin.xml"
                Application.Item("cachefile_cat_" & CategoryName & "_file") _
                = Application.Item("cachepath") & "\category_" & CategoryName & ".xml"
                MyArticle.WriteXML(MyArticle.GetArticles(CategoryName, True), Application.Item("cachefile_cat_" & CategoryName & "_file_admin"))
                MyArticle.WriteXML(MyArticle.GetArticles(CategoryName, False), Application.Item("cachefile_cat_" & CategoryName & "_file"))
            Next
            MyArticle.WriteXML(MyArticle.GetArticles("", True), Application.Item("cachefile_cat_all_file_admin"))
            MyArticle.WriteXML(MyArticle.GetArticles("", False), Application.Item("cachefile_cat_all_file"))
            MyArticle.WriteXML(MyArticle.GetArticle(txtid.Text), Application.Item("cachefile_article_" & txtid.Text))
        End If
        MyArticle.CloseConn()
    End Sub

    Private Sub lstsection_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstsection.SelectedIndexChanged
        Dim SectionData As DataSet
        Dim MyArticle As Article
        lblerrors.Text = ""
        MyArticle = New Article(Application.Item("ConnectionString"))
        txtsectionname.Text = "New Section"
        txtsectionoldname.Text = ""
        txtsectiondata.Text = "Section Data"
        txtsectionsortorder.Text = "0"
        If IsNumeric(txtid.Text) And txtid.Text <> "" And lstsection.SelectedItem.Text <> "[NEW]" Then
            SectionData = MyArticle.GetArticleSection(txtid.Text, lstsection.SelectedItem.Text)
            If SectionData.Tables(0).Rows.Count > 0 Then
                txtsectionsortorder.Text = SectionData.Tables(0).Rows(0).Item("SortOrder")
                txtsectionname.Text = SectionData.Tables(0).Rows(0).Item("Name")
                txtsectionoldname.Text = SectionData.Tables(0).Rows(0).Item("Name")
                txtsectiondata.Text = SectionData.Tables(0).Rows(0).Item("Data")
                btndisplaysection.Visible = True
            End If
        Else
            btndisplaysection.Visible = False
        End If
        If txtid.Text <> "-1" And txtsectionname.Text <> "" And btndisplaysection.Visible = True Then
            MySectionDeleteButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "admin/deletearticlesection.aspx?id=" & txtid.Text & "&section=" & Server.UrlEncode(txtsectionname.Text).Replace("+", "%20"), "Delete", "Are you sure that you wish to delete this section?")
        End If
        MyArticle.CloseConn()
    End Sub

    Private Sub btnsavesection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsavesection.Click
        Dim MyArticle As Article
        Dim ErrorText As String
        Dim SectionList As DataSet
        Dim SectionPtr As Integer
        Dim DefaultSectionText As String = ""
        Dim DefaultExists As Boolean = False
        Dim SectionFile As String
        Dim SectionFileLoc As String
        MyArticle = New Article(Application.Item("ConnectionString"))
        ErrorText = MyArticle.SaveArticleSection(txtid.Text, txtsectionoldname.Text, txtsectionname.Text, txtsectiondata.Text, txtsectionsortorder.Text)
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully in record '" & txtsectionname.Text & "'"

            'Recache Article Data for this Section and Article Level Section List
            If txtsectionname.Text <> txtsectionoldname.Text Then
                System.IO.File.Delete(Application.Item("cachepath") & "\article_" & txtid.Text & "_section_" & MyArticle.CleanSectionName(txtsectionoldname.Text) & ".xml")
                MyArticle.WriteXML(MyArticle.SectionList(txtid.Text), Application.Item("cachefile_article_" & txtid.Text & "_sectionlist"))
            End If
            SectionFile = MyArticle.CleanSectionName(txtsectionname.Text)
            SectionFileLoc = Application.Item("cachepath") & "\article_" & txtid.Text & "_section_" & SectionFile & ".xml"
            Application.Item("cachefile_article_" & txtid.Text & "_section_" & SectionFile) = SectionFileLoc
            MyArticle.WriteXML(MyArticle.GetArticleSection(txtid.Text, txtsectionname.Text), SectionFileLoc)

            'Rebuild and Set values in Section Dropdowns
            txtsectionoldname.Text = txtsectionname.Text
            SectionList = MyArticle.SectionList(Request.Item("ID"))
            If lstdefaultsection.SelectedIndex > -1 Then
                DefaultSectionText = lstdefaultsection.SelectedItem.Text
            End If

            'Clear Existing Dropdowns
            lstdefaultsection.Items.Clear()
            lstsection.Items.Clear()
            'Rebuild dropdowns
            For SectionPtr = 0 To SectionList.Tables(0).Rows.Count - 1
                lstdefaultsection.Items.Add(New ListItem(SectionList.Tables(0).Rows(SectionPtr).Item("Name")))
                lstsection.Items.Add(New ListItem(SectionList.Tables(0).Rows(SectionPtr).Item("Name")))
                If SectionList.Tables(0).Rows(SectionPtr).Item("Name") = DefaultSectionText Then
                    DefaultExists = True
                End If
            Next
            'Set Values for new Dropdowns - if selected entry for lstdefaultsection doesnt exist
            'use the last saved section
            For SectionPtr = 0 To SectionList.Tables(0).Rows.Count - 1
                If lstsection.Items(SectionPtr).Text = txtsectionname.Text Then
                    lstsection.Items(SectionPtr).Selected = True
                End If
                If DefaultExists = True Then
                    If lstdefaultsection.Items(SectionPtr).Text = DefaultSectionText Then
                        lstdefaultsection.Items(SectionPtr).Selected = True
                    End If
                Else
                    If lstdefaultsection.Items(SectionPtr).Text = txtsectionname.Text Then
                        lstdefaultsection.Items(SectionPtr).Selected = True
                    End If
                End If
            Next
            lstsection.Items.Add(New ListItem("[NEW]"))
            btndisplaysection.Visible = True
            End If
            If txtid.Text <> "-1" And txtsectionname.Text <> "" And btndisplaysection.Visible = True Then
                MySectionDeleteButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "admin/deletearticlesection.aspx?id=" & txtid.Text & "&section=" & Server.UrlEncode(txtsectionname.Text).Replace("+", "%20"), "Delete", "Are you sure that you wish to delete this section?")
            End If
            MyArticle.CloseConn()
    End Sub

    Private Sub btndisplaysection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplaysection.Click
        Response.Redirect("../displayarticle.aspx?id=" & txtid.Text & "&section=" & Server.UrlEncode(txtsectionname.Text))
    End Sub
End Class
