Imports pengine.Data
Imports System.Data.OleDB

Public Class editresumeeducation
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblinstitution As System.Web.UI.WebControls.Label
    Protected WithEvents lblhttp As System.Web.UI.WebControls.Label
    Protected WithEvents txthttp As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblprogram As System.Web.UI.WebControls.Label
    Protected WithEvents txtprogram As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbldatestarted As System.Web.UI.WebControls.Label
    Protected WithEvents txtdatestarted As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbldateleft As System.Web.UI.WebControls.Label
    Protected WithEvents txtdateleft As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtinstitute As System.Web.UI.WebControls.TextBox
    Protected WithEvents btndisplay As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String = ""
    Public MyArticle As Article
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyResume As ResumeParts
        Dim EducationData As DataSet = New DataSet
        MyArticle = New Article(Application("ConnectionString"))
        MyResume = New ResumeParts(Application.Item("ConnectionString"))
        If txtid.Text = "" Then
            txtid.Text = Request.Item("id")
        End If
        If Not IsPostBack Then
            If (txtid.Text <> "" And IsNumeric(txtid.Text)) Then
                EducationData = MyResume.GetEducation(txtid.Text)
                If EducationData.Tables(0).Rows.Count > 0 Then
                    txtinstitute.Text = EducationData.Tables(0).Rows(0).Item("Institute")
                    txthttp.Text = EducationData.Tables(0).Rows(0).Item("HTTP")
                    txtprogram.Text = EducationData.Tables(0).Rows(0).Item("Program")
                    txtdatestarted.Text = EducationData.Tables(0).Rows(0).Item("datestarted")
                    txtdateleft.Text = EducationData.Tables(0).Rows(0).Item("dateleft")
                End If
            Else
                txtinstitute.Text = "Educational Insitute"
                txthttp.Text = ""
                txtprogram.Text = "Diploma"
                txtdatestarted.Text = DateTime.Now.ToShortDateString
                txtdateleft.Text = DateTime.Now.ToShortDateString
                txtid.Text = "-1"
            End If
        End If
        If txtid.Text <> "-1" Then
            MyTitle = "Editing Education Resume Entry #" & txtid.Text
        Else
            MyTitle = "Creating Education Resume Entry"
        End If
        MyArticle.CloseConn()
        MyResume.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyResume As ResumeParts
        Dim ErrorText As String
        MyResume = New ResumeParts(Application.Item("ConnectionString"))
        If IsDate(txtdatestarted.Text) = True And IsDate(txtdateleft.Text) = True And txtdatestarted.Text <> "" _
        And txtdateleft.Text <> "" Then
            ErrorText = MyResume.SaveEducation(txtid.Text, txtinstitute.Text, txthttp.Text, txtprogram.Text _
            , System.Convert.ToDateTime(txtdatestarted.Text), System.Convert.ToDateTime(txtdateleft.Text))
            If ErrorText <> "" Then
                lblerrors.Text = ErrorText.Replace("|", "<br>")
            Else
                lblerrors.Text = "Your changes were saved successfully."
                MyResume.WriteXML(MyResume.GetEducations(), Application.Item("cachefile_resume_education"))
            End If
        Else
            lblerrors.Text = "One or more of your date fields was not in the correct format. It should be (MM/DD/YYYY HH:MM:SS)."
        End If
        MyResume.CloseConn()
    End Sub

    Private Sub btndisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay.Click
        Response.Redirect("../displayresume.aspx#Education")
    End Sub
End Class
