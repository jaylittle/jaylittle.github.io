Imports pengine.Data
Imports System.Data.OleDB

Public Class editresumepersonal
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents lblemail As System.Web.UI.WebControls.Label
    Protected WithEvents txtemail As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblName As System.Web.UI.WebControls.Label
    Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblweb As System.Web.UI.WebControls.Label
    Protected WithEvents txtweb As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblphone As System.Web.UI.WebControls.Label
    Protected WithEvents txtphone As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblfax As System.Web.UI.WebControls.Label
    Protected WithEvents txtfax As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbladdress As System.Web.UI.WebControls.Label
    Protected WithEvents txtaddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblcity As System.Web.UI.WebControls.Label
    Protected WithEvents txtcity As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblstate As System.Web.UI.WebControls.Label
    Protected WithEvents txtstate As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblzip As System.Web.UI.WebControls.Label
    Protected WithEvents txtzip As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents txtid As System.Web.UI.WebControls.TextBox
    Protected WithEvents btndisplay As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyTitle As String = ""
    Public MyArticle As Article
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyResume As ResumeParts
        Dim PersonalData As DataSet = New DataSet
        MyArticle = New Article(Application("ConnectionString"))
        MyResume = New ResumeParts(Application.Item("ConnectionString"))
        If txtid.Text = "" Then
            txtid.Text = Request.Item("id")
        End If
        If Not IsPostBack Then
            If (txtid.Text <> "" And IsNumeric(txtid.Text)) Then
                PersonalData = MyResume.GetPersonal(txtid.Text)
                If PersonalData.Tables(0).Rows.Count > 0 Then
                    txtName.Text = PersonalData.Tables(0).Rows(0).Item("Name")
                    txtaddress.Text = PersonalData.Tables(0).Rows(0).Item("Address")
                    txtcity.Text = PersonalData.Tables(0).Rows(0).Item("City")
                    txtstate.Text = PersonalData.Tables(0).Rows(0).Item("State")
                    txtzip.Text = PersonalData.Tables(0).Rows(0).Item("Zip")
                    txtfax.Text = PersonalData.Tables(0).Rows(0).Item("Fax")
                    txtphone.Text = PersonalData.Tables(0).Rows(0).Item("Phone")
                    txtemail.Text = PersonalData.Tables(0).Rows(0).Item("Email")
                    txtweb.Text = PersonalData.Tables(0).Rows(0).Item("Web")
                End If
            Else
                txtName.Text = Application.Item("ownername")
                txtaddress.Text = ""
                txtcity.Text = ""
                txtstate.Text = ""
                txtzip.Text = ""
                txtfax.Text = ""
                txtphone.Text = ""
                txtemail.Text = Application.Item("owneremail")
                txtweb.Text = ""
                txtid.Text = "-1"
            End If
        End If
        If txtid.Text <> "-1" Then
            MyTitle = "Editing Personal Resume Entry #" & txtid.Text
        Else
            MyTitle = "Creating Personal Resume Entry"
        End If
        MyArticle.CloseConn()
        MyResume.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim MyResume As ResumeParts
        Dim ErrorText As String
        MyResume = New ResumeParts(Application.Item("ConnectionString"))
        ErrorText = MyResume.SavePersonal(txtid.Text, txtName.Text, txtaddress.Text, txtcity.Text, txtstate.Text _
        , txtzip.Text, txtphone.Text, txtfax.Text, txtemail.Text, txtweb.Text)
        If ErrorText <> "" Then
            lblerrors.Text = ErrorText.Replace("|", "<br>")
        Else
            lblerrors.Text = "Your changes were saved successfully."
            MyTitle = "Editing Personal Resume Entry #" & txtid.Text
            MyResume.WriteXML(MyResume.GetPersonals(), Application.Item("cachefile_resume_personal"))
        End If
        MyResume.CloseConn()
    End Sub

    Private Sub btndisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay.Click
        Response.Redirect("../displayresume.aspx")
    End Sub
End Class
