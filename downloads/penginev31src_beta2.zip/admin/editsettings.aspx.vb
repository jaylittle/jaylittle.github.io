Imports pengine.Data
Imports System.Data.OleDB

Public Class editsettings
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer
    Protected WithEvents lblerrors As System.Web.UI.WebControls.Label
    Protected WithEvents txtownername As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtowneremail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtdefaultpagetitle As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtfrontpagelogo As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtnewssummaryperpage As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtnewsperpage As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtsearchresultsperpage As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtforumpostsperpage As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtforumeditlimit As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtpagesize As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtmenusize As System.Web.UI.WebControls.TextBox
    Protected WithEvents txthomelabel As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtresumelabel As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtthemelabel As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtleetlabel As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtleetlabel2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtadminlabel As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtadminlabel2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtdbfilename As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtdbrelativepath As System.Web.UI.WebControls.TextBox
    Protected WithEvents txttimeout As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtadminpass As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtgodpass As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnsave As System.Web.UI.WebControls.Button
    Protected WithEvents lstdefaulttheme As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstexcluderesume As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstexcludetheme As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstexcludeleet As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstexcludequotes As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstexcludesearch As System.Web.UI.WebControls.DropDownList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyArticle As Article
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyTheme As Theme = New Theme
        Dim ThemeList As ArrayList
        Dim ThemePtr As Integer
        Dim BoolPtr As Integer
        MyArticle = New Article(Application.Item("connectionstring"))
        If Not IsPostBack Then
            ThemeList = MyTheme.GetThemeList
            txtownername.Text = Application.Item("OwnerName")
            txtowneremail.Text = Application.Item("OwnerEmail")
            txtdefaultpagetitle.Text = Application.Item("DefaultPageTitle")
            For ThemePtr = 0 To ThemeList.Count - 1
                lstdefaulttheme.Items.Add(ThemeList.Item(ThemePtr))
                If lstdefaulttheme.Items(ThemePtr).Text = Application.Item("defaulttheme") Then
                    lstdefaulttheme.Items(ThemePtr).Selected = True
                End If
            Next
            txtfrontpagelogo.Text = Application.Item("FrontPageLogo")
            txtnewssummaryperpage.Text = Application.Item("NewsSummaryPerPage")
            txtnewsperpage.Text = Application.Item("NewsPerPage")
            txtsearchresultsperpage.Text = Application.Item("SearchResultsPerPage")
            txtforumpostsperpage.Text = Application.Item("ForumPostsPerPage")
            txtforumeditlimit.Text = Application.Item("ForumEditLimit")
            txtpagesize.Text = Application.Item("PageSize")
            txtmenusize.Text = Application.Item("MenuSize")
            txthomelabel.Text = Application.Item("homelabel")
            txtthemelabel.Text = Application.Item("themelabel")
            txtresumelabel.Text = Application.Item("resumelabel")
            txtleetlabel.Text = Application.Item("leetlabel")
            txtleetlabel2.Text = Application.Item("leetlabel2")
            txtadminlabel.Text = Application.Item("adminlabel")
            txtadminlabel2.Text = Application.Item("adminlabel2")
            txtdbrelativepath.Text = Application.Item("dbrelativepath")
            txtdbfilename.Text = Application.Item("dbfilename")
            txttimeout.Text = Application.Item("timeout")
            txtadminpass.Text = ""
            txtgodpass.Text = ""
            lstexcluderesume.Items.Clear()
            lstexcludetheme.Items.Clear()
            lstexcludeleet.Items.Clear()
            lstexcludequotes.Items.Clear()
            lstexcludesearch.Items.Clear()
            For BoolPtr = 0 To 1
                If BoolPtr = 0 Then
                    lstexcluderesume.Items.Add(New ListItem("No", 0))
                    lstexcludetheme.Items.Add(New ListItem("No", 0))
                    lstexcludeleet.Items.Add(New ListItem("No", 0))
                    lstexcludequotes.Items.Add(New ListItem("No", 0))
                    lstexcludesearch.Items.Add(New ListItem("No", 0))
                Else
                    lstexcluderesume.Items.Add(New ListItem("Yes", 1))
                    lstexcludetheme.Items.Add(New ListItem("Yes", 1))
                    lstexcludeleet.Items.Add(New ListItem("Yes", 1))
                    lstexcludequotes.Items.Add(New ListItem("Yes", 1))
                    lstexcludesearch.Items.Add(New ListItem("Yes", 1))
                End If
            Next
            lstexcluderesume.Items(Application.Item("excluderesume")).Selected = True
            lstexcludetheme.Items(Application.Item("excludetheme")).Selected = True
            lstexcludeleet.Items(Application.Item("excludeleet")).Selected = True
            lstexcludequotes.Items(Application.Item("excludequotes")).Selected = True
            lstexcludesearch.Items(Application.Item("excludesearch")).Selected = True
        End If
        MyArticle.CloseConn()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim ErrorMessages As String = ""
        Dim MySettings As Settings = New Settings
        ErrorMessages = MySettings.SaveIntoASPFile(txtownername.Text, txtowneremail.Text, txtdefaultpagetitle.Text _
        , lstdefaulttheme.SelectedItem.Text, txtfrontpagelogo.Text, txtnewssummaryperpage.Text, txtnewsperpage.Text _
        , txtsearchresultsperpage.Text, txtforumpostsperpage.Text, txtforumeditlimit.Text, txtpagesize.Text _
        , txtmenusize.Text, lstexcluderesume.SelectedItem.Value, lstexcludetheme.SelectedItem.Value, lstexcludeleet.SelectedItem.Value _
        , lstexcludequotes.SelectedItem.Value, lstexcludesearch.SelectedItem.Value, txthomelabel.Text, txtthemelabel.Text _
        , txtresumelabel.Text, txtleetlabel.Text, txtleetlabel2.Text, txtadminlabel.Text, txtadminlabel2.Text _
        , txtdbrelativepath.Text, txtdbfilename.Text, txttimeout.Text, txtadminpass.Text, txtgodpass.Text)
        If ErrorMessages = "" Then
            lblerrors.Text = "Your changes to the System Settings have been successfully saved."
            MySettings.LoadIntoApplication()
        Else
            lblerrors.Text = ErrorMessages.Replace("|", "<br>")
        End If
    End Sub
End Class
