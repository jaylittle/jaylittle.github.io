Public Class PEngine_Footer
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ImgFooterLeft As System.Web.UI.WebControls.Image
    Protected WithEvents ImgFooterRight As System.Web.UI.WebControls.Image

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyPageSize As String
    Public ForumsActive As Integer
    Public ExcludeSearch As Integer
    Public MyOwnerEmail As String
    Public MyBackground As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Application.Item("pagesize") > 0 Then
            MyPageSize = Application.Item("pagesize")
        Else
            MyPageSize = "100%"
        End If
        If Session.Item("FooterRImage") <> "" Then
            ImgFooterRight.Visible = True
            ImgFooterRight.ImageUrl = Session.Item("FooterRImage")
        Else
            ImgFooterRight.Visible = False
        End If
        If Session.Item("FooterLImage") <> "" Then
            ImgFooterLeft.Visible = True
            ImgFooterLeft.ImageUrl = Session.Item("FooterLImage")
        Else
            ImgFooterLeft.Visible = False
        End If
        MyBackground = Session.Item("FooterMImage")
        ExcludeSearch = Application.Item("ExcludeSearch")
        MyOwnerEmail = Application.Item("owneremail")
        'Temporarily Set this Variable to 0
        ForumsActive = 0
    End Sub

End Class
