Imports pengine.Data
Imports System.Data.OleDB

Public Class browsethreads
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptThreads As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyForum As Forum
    Public MyAddThreadButtonHTML As String = ""
    Public MyForumName As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ThreadsData As DataSet
        Dim MyArticle As Article
        MyForum = New Forum(Application("FConnectionString"))
        If Request.Item("forumid") <> "" And IsNumeric(Request.Item("forumid")) Then
            MyForumName = MyForum.GetForumName(Request.Item("forumid"))
            MyArticle = New Article(Application("ConnectionString"))
            If Request.Item("page") = "" Or IsNumeric(Request.Item("page")) = False Then
                ThreadsData = MyForum.GetThreads(Request.Item("forumid"), -1, Application.Item("forumpostsperpage"))
            Else
                ThreadsData = MyForum.GetThreads(Request.Item("forumid") _
                , (Request.Item("page") - 1) * Application.Item("forumpostsperpage"), Application.Item("forumpostsperpage"))
            End If
            If Session.Item("forumloggedin") = True Then
                MyAddThreadButtonHTML = MyArticle.CreateHTMLButton("./forumedit/editpost.aspx?forumid=" & Request.Item("forumid"), "Create Thread", "")
            End If
            RptThreads.DataSource = ThreadsData
            RptThreads.DataBind()
            MyArticle.CloseConn()
        End If
        MyForum.CloseConn()
    End Sub

End Class
