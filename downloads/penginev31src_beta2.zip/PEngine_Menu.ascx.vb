Imports pengine.Data
Imports System.Data.OleDB
Public Class PEngine_Menu
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents PLHButtons As System.Web.UI.WebControls.PlaceHolder

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyMenuSize As Integer = 0
    Public ArticleID As Integer = 0
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ctlButton As Control
        Dim DtrCats As DataSet
        Dim MyArticle As Article = New Article(Application.Item("ConnectionString"))
        Dim ArticleData As DataSet
        Dim ArticleSectionList As DataSet
        Dim ArticleMenuIsHidden As Boolean
        Dim SectionPtr As Integer
        Dim RowPtr As Integer = 0

        MyMenuSize = Application.Item("menusize")

        'Display Home Button
        ctlButton = LoadControl("PEngine_Button.ascx")
        CType(ctlButton, PEngine_Button).ButtonText = Application.Item("homelabel")
        CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "default.aspx"
        PLHButtons.Controls.Add(ctlButton)

        'Display Theme Button
        If Application.Item("ExcludeTheme") = 0 Then
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = Application.Item("themelabel")
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "displaytheme.aspx"
            PLHButtons.Controls.Add(ctlButton)
        End If

        'Display Resume Button
        If Application.Item("ExcludeResume") = 0 Then
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = Application.Item("resumelabel")
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "displayresume.aspx"
            PLHButtons.Controls.Add(ctlButton)
        End If

        'Display Article Category buttons
        If Session.Item("admin") = True Then
            DtrCats = MyArticle.ReadXML(Application.Item("cachefile_categories_admin"))
        Else
            DtrCats = MyArticle.ReadXML(Application.Item("cachefile_categories"))
        End If
        While RowPtr < DtrCats.Tables(0).Rows.Count
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = DtrCats.Tables(0).Rows(RowPtr).Item("category")
            If DtrCats.Tables(0).Rows(RowPtr).Item("http") & "" <> "" Then
                CType(ctlButton, PEngine_Button).URL = DtrCats.Tables(0).Rows(RowPtr).Item("http")
            Else
                CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "browsearticles.aspx?category=" & Server.UrlEncode(DtrCats.Tables(0).Rows(RowPtr)("category"))
            End If
            PLHButtons.Controls.Add(ctlButton)
            RowPtr += 1
        End While

        'Display Admin mode Buttons
        If Session.Item("admin") = False Then
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = Application.Item("adminlabel")
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "login.aspx?mode=admin"
            PLHButtons.Controls.Add(ctlButton)
        Else
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = ""
            CType(ctlButton, PEngine_Button).URL = ""
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = "New Article"
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "admin/editarticle.aspx"
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = "Settings"
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "admin/editsettings.aspx"
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = "Uploader"
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "admin/browsefiles.aspx"
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = Application.Item("adminlabel2")
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "logout.aspx?mode=admin"
            PLHButtons.Controls.Add(ctlButton)
        End If

        'Display Other Functionality Buttons (Forums and Elite)
        If Application.Item("forum") = True Then
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = ""
            CType(ctlButton, PEngine_Button).URL = ""
            PLHButtons.Controls.Add(ctlButton)
            ctlButton = LoadControl("PEngine_Button.ascx")
            CType(ctlButton, PEngine_Button).ButtonText = "Forums"
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "browseforums.aspx"
            PLHButtons.Controls.Add(ctlButton)
        End If

        If Application.Item("excludeleet") = 0 Then
            ctlButton = LoadControl("PEngine_Button.ascx")
            If Session("leetflag") = False Then
                CType(ctlButton, PEngine_Button).ButtonText = Application.Item("leetlabel")
            Else
                CType(ctlButton, PEngine_Button).ButtonText = Application.Item("leetlabel2")
            End If
            CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "seteliteflag.aspx"
            PLHButtons.Controls.Add(ctlButton)
        End If

        If ArticleID > 0 Then
            'Display Article Section buttons
            ArticleData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID))
            ArticleMenuIsHidden = ArticleData.Tables(0).Rows(0).Item("hidebuttons")
            If ArticleMenuIsHidden = False Then
                ArticleSectionList = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID & "_sectionlist"))
                ctlButton = LoadControl("PEngine_Button.ascx")
                CType(ctlButton, PEngine_Button).ButtonText = ""
                CType(ctlButton, PEngine_Button).URL = ""
                PLHButtons.Controls.Add(ctlButton)
                If ArticleSectionList.Tables(0).Rows.Count > 1 Then
                    For SectionPtr = 0 To ArticleSectionList.Tables(0).Rows.Count - 1
                        ctlButton = LoadControl("PEngine_Button.ascx")
                        CType(ctlButton, PEngine_Button).ButtonText = ArticleSectionList.Tables(0).Rows(SectionPtr).Item("Name")
                        CType(ctlButton, PEngine_Button).URL = Application.Item("basepath") & "displayarticle.aspx?id=" _
                        & System.Convert.ToString(ArticleID) & "&section=" & ArticleSectionList.Tables(0).Rows(SectionPtr).Item("Name")
                        PLHButtons.Controls.Add(ctlButton)
                    Next
                End If
            End If
        End If
        MyArticle.CloseConn()
    End Sub

End Class
