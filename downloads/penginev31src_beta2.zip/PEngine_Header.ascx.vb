Imports pengine.Data
Imports System.Web.Security

Public Class PEngine_Header
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ImgHeaderLeft As System.Web.UI.WebControls.Image
    Protected WithEvents ImgHeaderRight As System.Web.UI.WebControls.Image
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyPageSize As String
    Public MyHeaderText As String
    Public MyPageTitle As String
    Public MyTextAlign As String
    Public MyBackground As String
    Public MyLeftImage As String
    Public MyRightImage As String
    Public MyCSS As String
    Public ArticleID As Integer
    Public ArticleCategory As String
    Public NewsTitle As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim MyTheme As Theme = New Theme
        Dim MyArticle As Article = New Article(Application("ConnectionString"))
        Dim ArticleData As DataSet
        'Put user code to initialize the page here
        If Session.Item("theme") = "" Then
            MyTheme.LoadTheme(Application.Item("defaulttheme"))
            MyCSS = MyTheme.CSSCode
        ElseIf Session.Item("themecss") = "" Then
            MyTheme.LoadTheme(Session.Item("theme"))
            MyCSS = MyTheme.CSSCode
        Else
            MyCSS = Session.Item("themecss")
        End If
        If ArticleID > 0 Then
            ArticleData = MyArticle.ReadXML(Application.Item("cachefile_article_" & ArticleID))
            If ArticleData.Tables(0).Rows.Count > 0 Then
                MyPageTitle = Application.Item("defaultpagetitle") & " - " & ArticleCategory & ": " & ArticleData.Tables(0).Rows(0).Item("name")
            End If
        ElseIf ArticleCategory <> "" Then
            MyPageTitle = Application.Item("defaultpagetitle") & " - " & ArticleCategory & ": "
        ElseIf NewsTitle <> "" Then
            MyPageTitle = Application.Item("defaultpagetitle") & " - " & NewsTitle
        Else
            MyPageTitle = Application.Item("defaultpagetitle")
        End If
        MyTextAlign = Session.Item("headertextalign")
        If Application.Item("pagesize") > 0 Then
            MyPageSize = Application.Item("pagesize")
        Else
            MyPageSize = "100%"
        End If
        If Session.Item("HeaderNoTextFlag") = False Then
            'MyHeader = ConvertToElite(GenerateHeader)
            If ArticleID > 0 Then
                If ArticleData.Tables(0).Rows.Count > 0 Then
                    MyHeaderText = Application.Item("defaultpagetitle") & " - " & ArticleData.Tables(0).Rows(0).Item("name")
                End If
            Else
                MyHeaderText = Application.Item("defaultpagetitle")
            End If
        Else
            MyHeaderText = ""
        End If
        If Session.Item("HeaderRImage") <> "" Then
            ImgHeaderRight.Visible = True
            ImgHeaderRight.ImageUrl = Session.Item("HeaderRImage")
            MyRightImage = Session.Item("HeaderRImage")
        Else
            ImgHeaderRight.Visible = False
        End If
        If Session.Item("HeaderLImage") <> "" Then
            ImgHeaderLeft.Visible = True
            ImgHeaderLeft.ImageUrl = Session.Item("HeaderLImage")
            MyLeftImage = Session.Item("HeaderLImage")
        Else
            ImgHeaderLeft.Visible = False
        End If
        MyBackground = Session.Item("HeaderMImage")
        MyPageTitle = MyArticle.ConvertToElite(MyPageTitle)
        MyHeaderText = MyArticle.ConvertToElite(MyHeaderText)
        MyArticle.CloseConn()
        'Set Cache View Mode
        Cache.Item(Session.SessionID & "ViewMode") = Session.Item("theme") & "-" & Session.Item("leetflag") & "-" & Session.Item("admin")
    End Sub

End Class
