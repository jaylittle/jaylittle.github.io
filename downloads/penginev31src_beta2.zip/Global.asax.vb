Imports System.Web
Imports System.Web.SessionState

Public Class Global
    Inherits System.Web.HttpApplication

#Region " Component Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        'Initialize Settings and Application Variables
        Dim MySettings As pengine.Data.Settings = New pengine.Data.Settings
        MySettings.LoadIntoApplication()
        Application.Item("basethemepath") = HttpContext.Current.Request.ApplicationPath() & "/themes/"
        Application.Item("basepath") = HttpContext.Current.Request.ApplicationPath() & "/"
        Application.Item("cachepath") = Server.MapPath(Application.Item("basepath") & "/cache/")
        Application.Item("temppath") = Server.MapPath(Application.Item("basepath") & "/temp/")
        Application.Item("cachefile_news") = Application.Item("cachepath") & "\news.xml"
        Application.Item("cachefile_quotes") = Application.Item("cachepath") & "\quotes.xml"
        Application.Item("cachefile_categories_admin") = Application.Item("cachepath") & "\categories_admin.xml"
        Application.Item("cachefile_categories") = Application.Item("cachepath") & "\categories.xml"
        Application.Item("cachefile_resume_personal") = Application.Item("cachepath") & "\resume_personal.xml"
        Application.Item("cachefile_resume_objective") = Application.Item("cachepath") & "\resume_objective.xml"
        Application.Item("cachefile_resume_skills") = Application.Item("cachepath") & "\resume_skills.xml"
        Application.Item("cachefile_resume_education") = Application.Item("cachepath") & "\resume_education.xml"
        Application.Item("cachefile_resume_workhistory") = Application.Item("cachepath") & "\resume_workhistory.xml"

        'Set up Directory for XML Caching
        If System.IO.Directory.Exists(Application.Item("cachepath")) Then
            System.IO.Directory.Delete(Application.Item("cachepath"), True)
        End If
        System.IO.Directory.CreateDirectory(Application.Item("cachepath"))

        'Set up Directory for XML Caching of Admin Data
        If System.IO.Directory.Exists(Application.Item("cachepath")) Then
            System.IO.Directory.Delete(Application.Item("cachepath"), True)
        End If
        System.IO.Directory.CreateDirectory(Application.Item("cachepath"))

        'Set up Temporary Directory for Filesystem Operations
        If System.IO.Directory.Exists(Application.Item("temppath")) Then
            System.IO.Directory.Delete(Application.Item("temppath"), True)
        End If
        System.IO.Directory.CreateDirectory(Application.Item("temppath"))

        'Rebuild News Cache for Front Page
        Dim MyNews As pengine.Data.News
        Dim NewsData As DataSet
        MyNews = New pengine.Data.News(Application.Item("ConnectionString"))
        MyNews.WriteXML(MyNews.GetCurrentNews(), Application.Item("cachefile_news"))
        MyNews.CloseConn()

        'Rebuild Quote Cache for Front Page
        Dim MyQuote As pengine.Data.Quote
        MyQuote = New pengine.Data.Quote(Application.Item("ConnectionString"))
        MyQuote.WriteXML(MyQuote.GetAll, Application.Item("cachefile_quotes"))
        MyQuote.CloseConn()

        'Rebuild Category Cache for Menus
        Dim MyArticle As pengine.Data.Article
        Dim CategoryList As DataSet
        Dim CategoryPtr As Integer
        Dim ArticleList As DataSet
        MyArticle = New pengine.Data.Article(Application.Item("ConnectionString"))
        CategoryList = MyArticle.CategoryList(True)
        MyArticle.WriteXML(CategoryList, Application.Item("cachefile_categories_admin"))
        MyArticle.WriteXML(MyArticle.CategoryList(False), Application.Item("cachefile_categories"))

        'Rebuild Category Article Lists Cache
        For CategoryPtr = 0 To CategoryList.Tables(0).Rows.Count - 1
            Dim CategoryName As String = CategoryList.Tables(0).Rows(CategoryPtr).Item("category")
            Application.Item("cachefile_cat_" & CategoryName & "_file_admin") _
            = Application.Item("cachepath") & "\category_" & CategoryName & "_admin.xml"
            Application.Item("cachefile_cat_" & CategoryName & "_file") _
            = Application.Item("cachepath") & "\category_" & CategoryName & ".xml"
            MyArticle.WriteXML(MyArticle.GetArticles(CategoryName, True), Application.Item("cachefile_cat_" & CategoryName & "_file_admin"))
            MyArticle.WriteXML(MyArticle.GetArticles(CategoryName, False), Application.Item("cachefile_cat_" & CategoryName & "_file"))
        Next
        Application.Item("cachefile_cat_all_file_admin") = Application.Item("cachepath") & "\category_all_admin.xml"
        Application.Item("cachefile_cat_all_file") = Application.Item("cachepath") & "\category_all.xml"
        ArticleList = MyArticle.GetArticles("", True)
        MyArticle.WriteXML(ArticleList, Application.Item("cachefile_cat_all_file_admin"))
        MyArticle.WriteXML(MyArticle.GetArticles("", False), Application.Item("cachefile_cat_all_file"))

        'Rebuild Article Section Data Cache
        Dim ArticlePtr As Integer
        Dim ArticleID As String
        For ArticlePtr = 0 To ArticleList.Tables(0).Rows.Count - 1
            ArticleID = ArticleList.Tables(0).Rows(ArticlePtr).Item("ID")
            Application.Item("cachefile_article_" & ArticleID) = Application.Item("cachepath") & "\article_" & ArticleID & ".xml"
            Application.Item("cachefile_article_" & ArticleID & "_sectionlist") = Application.Item("cachepath") & "\article_" & ArticleID & "_sectionlist.xml"
            MyArticle.WriteXML(MyArticle.GetArticle(System.Convert.ToInt32(ArticleID)), Application.Item("cachefile_article_" & ArticleID))
            MyArticle.WriteXML(MyArticle.SectionList(System.Convert.ToInt32(ArticleID)), Application.Item("cachefile_article_" & ArticleID & "_sectionlist"))
            Dim SectionData As DataSet = MyArticle.GetArticleSections(System.Convert.ToInt32(ArticleID))
            Dim SectionPtr = 0
            Dim SectionFileLoc As String
            Dim SectionFile
            For SectionPtr = 0 To SectionData.Tables(0).Rows.Count - 1
                SectionFile = MyArticle.CleanSectionName(SectionData.Tables(0).Rows(SectionPtr).Item("Name"))
                SectionFileLoc = Application.Item("cachepath") & "\article_" & ArticleID & "_section_" & SectionFile & ".xml"
                Application.Item("cachefile_article_" & ArticleID & "_section_" & SectionFile) = SectionFileLoc
                MyArticle.WriteXML(MyArticle.GetArticleSection(System.Convert.ToInt32(ArticleID), SectionData.Tables(0).Rows(SectionPtr).Item("Name")), SectionFileLoc)
            Next
        Next
        MyArticle.CloseConn()

        'Rebuild Resume Caches
        Dim MyResume As pengine.Data.ResumeParts
        MyResume = New pengine.Data.ResumeParts(Application.Item("ConnectionString"))
        MyResume.WriteXML(MyResume.GetPersonals(), Application.Item("cachefile_resume_personal"))
        MyResume.WriteXML(MyResume.GetObjectives(), Application.Item("cachefile_resume_objective"))
        MyResume.WriteXML(MyResume.GetSkills(), Application.Item("cachefile_resume_skills"))
        MyResume.WriteXML(MyResume.GetEducations(), Application.Item("cachefile_resume_education"))
        MyResume.WriteXML(MyResume.GetWorkHistories(), Application.Item("cachefile_resume_workhistory"))
        MyResume.CloseConn()

    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        'Set Per Session Interface Defaults
        Dim MyTheme As pengine.Data.Theme = New pengine.Data.Theme
        MyTheme.LoadTheme(Application.Item("defaulttheme"))
        Session.Item("leetflag") = False
        Session.Item("admin") = False
        Session.Item("god") = False
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

End Class
