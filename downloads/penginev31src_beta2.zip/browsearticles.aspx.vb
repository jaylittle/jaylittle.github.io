Imports pengine.Data
Imports System.Data.OleDB

Public Class browsearticles
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptArticles As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyArticle As Article
    Public MyNewButtonHTML As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ArticlesData As DataSet
        Dim ArticlesInCategory As Integer = 0
        Dim ArticleID As Integer = 0
        Dim RowPtr As Integer = 0
        Dim CategoryName As String
        If Request.Item("category") <> "" Then
            CategoryName = Request.Item("category")
        Else
            CategoryName = "all"
        End If
        MyArticle = New Article(Application("ConnectionString"))
        If Session.Item("admin") = True Then
            ArticlesData = MyArticle.ReadXML(Application.Item("cachefile_cat_" & CategoryName & "_file_admin"))
        Else
            ArticlesData = MyArticle.ReadXML(Application.Item("cachefile_cat_" & CategoryName & "_file"))
        End If
        ArticlesInCategory = ArticlesData.Tables(0).Rows.Count
        If Session.Item("admin") = True Then
            MyNewButtonHTML = MyArticle.CreateHTMLButton("./admin/editarticle.aspx", "Create Article", "")
        End If
        If ArticlesInCategory > 1 Or Session.Item("admin") = True Then
            RptArticles.DataSource = ArticlesData
            RptArticles.DataBind()
        Else
            While RowPtr < ArticlesData.Tables(0).Rows.Count
                ArticleID = ArticlesData.Tables(0).Rows(RowPtr).Item("ID")
                RowPtr += 1
            End While
            If Session.Item("admin") = False Then
                Response.Redirect("displayarticle.aspx?id=" & System.Convert.ToString(ArticleID))
            End If
        End If
        Session.Item("LastArticlesBrowse") = Request.Url.ToString
        PEngine_Header1.ArticleCategory = Request.Item("category")
        MyArticle.CloseConn()
    End Sub

End Class
