Presentation Engine 3.1
Developer's Release Beta 2

ChangeLog from Version 3.0:

	(1)	The application has been rewritten using Microsoft .NET tools.  In order to run
		this application on a server you will need IIS and the .NET Framework installed.
	(2)	The format of the settings.asp file has changed.  A script has been provided in
		the scripts subdirectory to automatically build the new file for you.
	(3)	A number of database changes have occured.  A script has been provided in the
		the scripts subdirectory to make the structural changes for you.
	(4)	The interface for most of the admin tools has change quite drastically due to
		the increase ease of creating more dynamic interfaces with ASP.NET.
	(5)	The algorithims used to encrypt the admin, god, and article passwords has been
		changed. Since there is no way to easily "crack" the old passwords - you will have
		to reset all of your passwords with this new version.  The aforementioned scripts
		will remove all of your old passwords for you.  You simply need to set the new ones
		using the admin interfaces of the application.
	(6)	The majority of the pages now retrieve the data they need from an XML caching system
		that has been set up.  The XML files are only updated when the backend database is
		updated.  This helps to reduce a lot of load on the Access databases as well as
		allowing the application to scale better in a high traffic situation.  The XML cache
		is recreated automatically when the application is restarted.
	(7)	You WILL need to set up all Presentation Engine sites as Applications within IIS
		starting with this version.  This has everything to do with the .NET architecture
		and could not be avoided.
	(8)	More to come....
	

General Overview on Usage:

Most of the site expansion in the PEngine system is done through the use of
articles.  Articles allow you to transparently create and edit parts of a PEngine
site without uploading or downloading of HTML files.  (You do have to upload custom
images however). Articles have their own specific tags for content that are encased
in [] brackets. The list of tags is as follows:

[QUOTE][/QUOTE]
	Displays a portion of text within a quoted block.  This was added mainly to
	facilitate postings in the forums.

[IMAGE xxxx]
	Displays an image for the article directory or from another site if a
	full HTTP address was used.  For an image in the article directory only use
	the image filename as a parameter.

[SUBHEADER xxxx]
	Places a SubHeader on the page.  The parameter allows you to set the text
	that is displayed on the SubHeader.

[LINK address name]
	Provides an easy way of placing an Anchor Hyperlink.  The parameter is the
	address you would like to link to followed by the name of the link.

[ICON xxxx]
	Like the IMAGE tag above but this one uses images in the icon directory.
	You cannot use FULL HTTP address with this tag.

[SYSTEMIMAGE xxxx]
	Like the ICON tag except this one uses images in the system directory.

[SECTION xxxx]
	This tag creates a button which will link to another section of the same
	article.  The paramater is the name of the section you would like to link
	to.

[B][/B]
	Any content between these tags will be bolded.

[I][/I]
	Any content between these tags will be in italics.

[CENTER][/CENTER]
	Any content between these tags will be centered.

[RAWHTML][/RAWHTML]
	Any content in between these two tags will not processed by the article
	engine.  This would be useful if you were trying to create a page that
	explained how to use the Presentation Engine and these custom tags. Also
	keep in mind that carriage returns in between these tags will not be
	changed into <BR> tags.  This means you must supply your own <BR> tags.
[?]
	Any HTML tag can be written with the [] instead of the <> enclosures.  This
	functionality is not particular useful but it does help to lessen the
	learning curve associated with the application.  This way a user will not
	have to choose between [] and <>.  They can simply use [] and assume that
	its a Presentation Engine tag.


Note: These tags can also be used in News Stories and only a small subset of them
are allowed in Forum Postings for security reasons.

In order to set up the presentation engine - it does NOT need be an application 
in IIS and it can either reside in a root or subdirectory of some larger site. 
The backend database(s) are in Access97 format though it was primarily developed in 
Access 2002 and converted back to Access 97.

If you are upgrading from Version 2.1 you will probably want to run the 
UpgradeDatabase_to_30.vbs script located in the script directory.  It will make 
any structural changes required to upgrade the database.  Trust Me:  It will 
ease your pain.  Also be sure to edit the database location inside of the script 
file before running it.  

It is on the very top line.  Simply change the location inside the quotes and
double click the script file. 

If you need to convert from a Presentation Engine 2.0 Database (god forbid) then
a slightly modified (ie better commented) version of that script is included as well
but the file extension has been changed to ~vbs to prevent you from running it
accidentaly since it can corrupt your data if run on a 3.0/2.1 Database or twice on 
a 2.0 database.

Thanks,

Jason Little
http://www.jaylittle.com