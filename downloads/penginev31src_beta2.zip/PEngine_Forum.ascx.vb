Imports pengine.Data

Public Class PEngine_Forum
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyUsersButtonHTML As String = ""
    Public MyIPButtonHTML As String = ""
    Public MyLogOffButtonHTML As String = ""
    Public MyLogOnButtonHTML As String = ""
    Public MySignUpButtonHTML As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MyArticle As Article
        MyArticle = New Article(Application.Item("ConnectionString"))
        MyUsersButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "forumadmin/browseusers.aspx", "Users", "")
        MyIPButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "forumadmin/browseipbans.aspx", "IPs", "")
        MyLogOffButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "logout.aspx?mode=forum", "Logoff", "")
        MyLogOnButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "login.aspx?mode=forum", "Logon", "")
        MySignUpButtonHTML = MyArticle.CreateHTMLButton(Application.Item("basepath") & "createforumaccount.aspx", "Sign Up", "")
        MyArticle.CloseConn()
    End Sub

End Class
