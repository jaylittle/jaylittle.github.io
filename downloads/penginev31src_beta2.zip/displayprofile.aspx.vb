Imports pengine.Data
Imports System.Data.OleDB

Public Class displayprofile
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptUser As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyRecentPostsButtonHTML As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim UserData As DataSet
        Dim MyForum As Forum
        Dim MyArticle As Article
        MyForum = New Forum(Application("FConnectionString"))
        MyArticle = New Article(Application("ConnectionString"))
        If Request.Item("id") <> "" And IsNumeric(Request.Item("id")) Then
            UserData = MyForum.GetUser(Request.Item("id"))
            MyRecentPostsButtonHTML = MyArticle.CreateHTMLButton("displaysearch.aspx?queryterm=&source=forum&uid=" & Request.Item("id"), "Recent Posts", "")
            RptUser.DataSource = UserData
            RptUser.DataBind()
        End If
        MyArticle.CloseConn()
        MyForum.CloseConn()
    End Sub

End Class
