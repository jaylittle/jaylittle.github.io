Imports pengine.Data
Imports System.Data.OleDB

Public Class browsemessages
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RptMessages As System.Web.UI.WebControls.Repeater
    Protected WithEvents PEngine_Header1 As pengine.PEngine_Header
    Protected WithEvents PEngine_Menu1 As pengine.PEngine_Menu
    Protected WithEvents PEngine_ContentStart1 As pengine.PEngine_ContentStart
    Protected WithEvents PEngine_ContentEnd1 As pengine.PEngine_ContentEnd
    Protected WithEvents PEngine_Footer1 As pengine.PEngine_Footer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public MyForum As Forum
    Public MyAddReplyButtonHTML As String = ""
    Public MyForumName As String = ""
    Public MyForumLinkHTML As String = ""
    Public MyForumID As Integer
    Public MyThreadName As String = ""
    Public MyThreadPosts As Integer
    Public MyThreadID As Integer
    Public MyPage As Integer = -1
    Public MyArticle As Article
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim MessageData As DataSet
        Dim FoundPostFlag As Boolean
        MyForum = New Forum(Application("FConnectionString"))
        MyArticle = New Article(Application("ConnectionString"))
        If Request.Item("threadid") <> "" And IsNumeric(Request.Item("threadid")) Then
            MyThreadID = Request.Item("threadid")
            MyThreadName = MyForum.GetThreadName(Request.Item("threadid"))
            MyThreadPosts = MyForum.GetThreadPosts(Request.Item("threadid"))
            MyForumID = MyForum.GetThreadForumID(Request.Item("threadid"))
            MyForumName = MyForum.GetForumName(MyForumID)
            MyForumLinkHTML = "<a href=""browsethreads.aspx?forumid=" & System.Convert.ToString(MyForumID) & """>" & MyForumName & "</a>"
            If Request.Item("page") = "" Or IsNumeric(Request.Item("page")) = False Then
                If Request.Item("postid") <> "" And IsNumeric(Request.Item("page")) Then
                    MyPage = MyForum.GetMessagePageNum(Request.Item("postid"), Application.Item("forumpostsperpage"))
                    MessageData = MyForum.GetMessages(Request.Item("threadid") _
                    , (MyPage - 1) * Application.Item("forumpostsperpage"), Application.Item("forumpostsperpage"))
                Else
                    MyPage = 1
                    MessageData = MyForum.GetMessages(Request.Item("threadid"), -1, Application.Item("forumpostsperpage"))
                End If
            Else
                MyPage = Request.Item("page")
                MessageData = MyForum.GetMessages(Request.Item("threadid") _
                , (MyPage - 1) * Application.Item("forumpostsperpage"), Application.Item("forumpostsperpage"))
            End If
            If Session.Item("forumloggedin") = True Then
                MyAddReplyButtonHTML = MyArticle.CreateHTMLButton("./forumedit/editpost.aspx?forumid=" & System.Convert.ToString(MyForumID) & "&parentid=" & System.Convert.ToString(MyThreadID), "Add a Reply", "")
            End If
            RptMessages.DataSource = MessageData
            RptMessages.DataBind()
        End If
        MyArticle.CloseConn()
        MyForum.CloseConn()
    End Sub

End Class
