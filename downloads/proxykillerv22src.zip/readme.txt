Proxykiller Version 2.1 Notes:

This is a version of general bugfixes and improvements all around.  Most Notably this version
will attempt to Resume when it encounters fatal errors in the HTML engine.  I'm not proud of it
but it does work.  Also if your IIS server broadcasts on an alternate port - the proxykiller
application now supports it.

Jeez....

Just Kidding. To be honest I just dont have the time to document this code right
now - so take your best shot at wading through it (more up to date info can probably
be found on my website http://24.18.6.248:81)  Here is a quick synopsis of each
file in the archive:

readme.txt	
		DUH
address.asp	
		The address bar portion of the application
browse.asp	
		The portion of the application that handles browse requests
default.asp	
		Generates a two level frameset and passes requests to browse.asp
encrypter.vbs	
		The crappy algorithim used to encode URLs in ProxyKiller (this program
		will both encode and decode - to decode: enter the encoded URL with
		the letters ENC in front of it (it should already be there if PKiller
		generated the address)
encrypterold.vbs
		The older crappier encryption algorithim used in ProxyKiller Version
		1.  It had problems with some essential characters on POST requests so
		it was dumped.
error404.html
		The play error404 HTML page for generating fake errors.  This is shown
		on logout and when unsuccessful attempts are made to log into the
		system.
global.asa
		DuH - intializes application/session settings (you must set PKiller up
		as an application in IIS)
stream.asp
		Streams binary data from the web - uses jayinet.dll for grunt work.
inc\functions.inc
		Contains the bulk of the backend code for PKiller - most importantly -
		it contains the HTML processing engine.
inc\globalvar.inc
		Contains Global (refreshable) variables required for Proxykiller
		operation.
jayinet\jayinet.vbp
		Visual Basic Project containing code for JayInet.dll (used to download
		binary data from the web using HTTP, FTP, and GOPHER protocols.)


Special Notes:

Login passwords have been disabled in this version.  To set a login password - change
the contents of line 52 (approx) - you will also find a few commented lines of code in
browse.asp and stream.asp relating to login password processing (look for secretword)
The password interface isnt very intuitive - though it isnt meant to be.  
Failure/Success to input the correct password will return error404.html pages.

PKiller MUST be set up as an application in IIS.  Global.asa must be run.

You must register jayinet.dll in Windows before this application will function. Use
the command "regsvr32 jayinet.dll" to accomplish this.

To Do:

Alot of redudant code throughout the app can be moved to global.asa for consistency
and ease of reading purposes.

Add support for HTTP POST requests so more web applications will work. (Need to change
jayinet.dll in order to allow this)

Work with the binary streaming (stream.asp) more to allow it correctly identify mime
type dynamically instead of relying upon file extensions.  I have tried this but have
yet to get it to work correctly thus far.

Improve the encryption used in ProxyKiller.

Allow handkeyed address in the address form to be encrypted automatically rather than
having the user perform encryption manually.  (Use Javascript to accomplish this) Note
certain proxy servers check for pieces of the address as well as the ENTIRE address.
For example my company wont let anything with the phrase www.napster go out to the
net. The way around this is to encrypt the address before sending the request to PKiller.

Also http://www.napster.com doesnt work (no good error message)in Version 2 - find out
why.  UPDATE = It does work now - only because of the error resume code.

Thanks alot - and please try not to puke too much when looking through my code.

Jay (darkgamorck@home.com)