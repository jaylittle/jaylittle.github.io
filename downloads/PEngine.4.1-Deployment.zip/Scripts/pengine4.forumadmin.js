﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    forum: {
        editor_template_src: null,

        editor_template: null,

        editor_data: null,

        editor_data_guid: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        editor_launch: function (guid) {
            pengine.forum.editor_data_guid = guid;
            var ajaxProps = [{
                url: pengine.forum.editor_get_url + '/' + guid, cache: false, type: "GET", success: function (data) {
                    pengine.forum.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can edit this forum." }, false, function () { pengine.forum.editor_launch(pengine.forum.editor_data_guid); });
                    }
                }
            }];

            if (!pengine.forum.editor_template_src && !pengine.forum.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.forum.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.forum.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.forum.editor_template) {
                    pengine.forum.editor_template = pengine.template.compile(pengine.forum.editor_template_src);
                }
                var form = pengine.forum.editor_template(pengine.forum.editor_data);
                $("body").append($(form).attr("id", "pengine_forum_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                $("#pengine_forum_editor").slideDown('fast', function () { pengine.forum.editor_configure(); });
            });
        },

        editor_configure: function () {
            $("#forum_edit_button_save").on("click", function () {
                pengine.forum.editor_save();
                return false;
            });

            $("#forum_edit_button_close").on("click", function () {
                pengine.forum.editor_dispose();
                return false;
            });

            $("#forum_edit_button_delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.forum.editor_delete(pengine.forum.editor_data.guid);
                }
                return false;
            });

            $("#forum_edit_name").focus();

            pengine.focus.set_default_button("#pengine_forum_editor", null, true);
            pengine.window.resize();
        },

        editor_save: function () {
            $.ajax({
                type: "POST",
                url: pengine.forum.editor_post_url,
                data: {
                    Guid: $("#forum_edit_guid").val(),
                    Name: $("#forum_edit_name").val(),
                    VisibleFlag: $("#forum_edit_visible").attr("checked") ? "true" : "false",
                    Description: $("#forum_edit_description").val()
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can save changes to this forum." }, false, function () { pengine.forum.editor_save(); });
                    }
                }
            });
        },

        editor_delete: function (guid) {
            pengine.forum.editor_data_guid = guid;
            $.ajax({
                url: pengine.forum.editor_delete_url,
                type: "POST",
                data: {
                    id: guid
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can delete this forum." }, false, function () { pengine.forum.editor_delete(pengine.forum.editor_data_guid); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_forum_editor").slideUp('fast', function () {
                $("#pengine_forum_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    }
});