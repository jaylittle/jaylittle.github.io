﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using PEngine4.Core;

namespace PEngine4.MVC
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            string rawMappingList = (string)Settings.Query(Settings.AppSettingKey.app_mapping_location);
            string[] mappingList = { };
            string legacyController = string.Empty;
            string legacyAction = string.Empty;
            object constraints = null;
            if (!string.IsNullOrEmpty(rawMappingList))
            {
                mappingList = rawMappingList.Split('|').Where(o => !o.StartsWith("/") && !o.StartsWith("~/")).ToArray();
            }
            if (mappingList.Length > 0)
            {
                legacyController = mappingList[0];
                constraints = new { controller = new PEngine4.Core.MVC.NotEqual(legacyController)  };
            }
            if (mappingList.Length > 1)
            {
                legacyAction = mappingList[1];
                constraints = new { controller = new PEngine4.Core.MVC.NotEqual(legacyController), action = new PEngine4.Core.MVC.NotEqual(legacyAction)  };
            }

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "post", action = "index", id = UrlParameter.Optional },
                constraints: constraints
            );

            if (!string.IsNullOrEmpty(legacyController))
            {
                routes.MapRoute(
                    name: "LegacyControllerRedirect",
                    url: legacyController,
                    defaults: new { controller = "redirect", action = "index" }
                );
                if (!string.IsNullOrEmpty(legacyAction))
                {
                    routes.MapRoute(
                    name: "LegacyActionRedirect",
                    url: legacyController + "/" + legacyAction,
                    defaults: new { controller = "redirect", action = "index" }
                );
                }
            }

            routes.MapRoute(
                name: "NamedPost",
                url: "{controller}/{action}/{year}/{month}/{uniqueName}",
                defaults: new { controller = "post", action = "view" }
            );

            routes.MapRoute(
                name: "NamedArticle",
                url: "{controller}/{action}/{id}/{sectionUniqueName}",
                defaults: new { controller = "article", action = "view", sectionUniqueName = UrlParameter.Optional }
            );
        }
    }
}