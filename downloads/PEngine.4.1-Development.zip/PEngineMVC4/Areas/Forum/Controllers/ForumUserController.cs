﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;
using PEngine4.Core.Model;
using Newtonsoft.Json;

namespace PEngine4.MVC.Areas.Forum.Controllers
{
    public class ForumUserController : PEngineController
    {
        //
        // GET: /Forum/ForumUser/

        public ActionResult Index(string forumUniqueName, string uniqueName, int? start, int? count, string sortBy, string sortAsc)
        {
            this.SetupPEngineViewBag();
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                start = start.HasValue ? start : 1;
                count = count.HasValue ? count : (int)PEngine4.Core.Settings.Query(Settings.AppSettingKey.app_recpage_forum_threads);
                sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "UserID";
                sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "1";
                bool sortAscBool = sortAsc == "1" ? true : false;
                this.ViewBag.Title += " Forums : Users";
                ForumService forumService = new ForumService();
                int totalRecs = 0;
                List<Core.Model.ForumUser> forumUsers = forumService.ForumUserList(start.Value, count.Value, sortBy, sortAscBool
                    , ref totalRecs, _token.Has(Helpers.AccessLevel.forumadmin));
                ViewBag.Total = totalRecs;
                ViewBag.Start = start;
                ViewBag.Count = count;
                ViewBag.SortBy = sortBy;
                ViewBag.SortAsc = sortAsc;
                ViewBag.SortAscBool = sortAscBool;
                ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
                return View(forumUsers);
            }
            else
            {
                return new RedirectToRouteResult("BaseForum", null);
            }
        }

        public new ActionResult View(string userID)
        {
            this.SetupPEngineViewBag();
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                this.ViewBag.Title += " Forums : Users";
                ForumService forumService = new ForumService();
                Core.Model.ForumUser forumUser = forumService.ForumUserGet(userID, _token.Has(Helpers.AccessLevel.forumadmin));
                if (forumUser != null)
                {
                    this.ViewBag.Title += " : " + forumUser.UserID;
                    return View(forumUser);
                }
                else
                {
                    Response.StatusCode = 404;
                    return null;
                }
            }
            else
            {
                return new RedirectToRouteResult("BaseForum", null);
            }
        }

        [HttpPost]
        public string Delete(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forumadmin))
            {
                List<string> errors = new List<string>();
                if (id.HasValue)
                {
                    try
                    {
                        ForumService forumService = new ForumService();
                        forumService.ForumUserDelete(id.Value, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                }
                else
                {
                    errors.Add("ID parameter is required!");
                }
                var retdata = new
                {
                    data = new { },
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (!_token.Has(Helpers.AccessLevel.forumadmin) && _token.Has(Helpers.AccessLevel.forum))
            {
                id = _token.ForumUserGuid;
            }
            else if (!_token.Has(Helpers.AccessLevel.forum))
            {
                id = null;
            }
            ForumService forumService = new ForumService();
            Core.Model.ForumUser forumUser = new Core.Model.ForumUser();
            if (id.HasValue && id.Value != Guid.Empty)
            {
                forumUser = forumService.ForumUserGet(id.Value, _token.Has(Helpers.AccessLevel.forumadmin));
            }
            var data = UserToJSON(forumService, forumUser);
            retvalue = JsonConvert.SerializeObject(data);
            Response.ContentType = "application/json";
            return retvalue;
        }

        [HttpPost]
        public string Post()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (!string.IsNullOrEmpty(Request.Params["json"]))
            {
                //Deserialize JSON Here
                ForumUser forumUser = JsonConvert.DeserializeObject<ForumUser>(Request.Params["json"]);
                if ((forumUser.Guid == Guid.Empty || _token.Has(Helpers.AccessLevel.forum)))
                {
                    if (_token.Has(Helpers.AccessLevel.forum) && !_token.Has(Helpers.AccessLevel.forumadmin))
                    {
                        forumUser.Guid = _token.ForumUserGuid;
                    }
                    if (forumUser.Guid == Guid.Empty)
                    {
                        forumUser.LastIPAddress = Request.ServerVariables["REMOTE_ADDR"];
                    }
                    ForumService forumService = new ForumService();
                    List<string> errors = new List<string>();
                    Core.Model.ForumUser result = null;
                    try
                    {
                        result = forumService.ForumUserSave(forumUser, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                    var retdata = new
                    {
                        data = UserToJSON(forumService, errors.Count > 0 || result == null ? forumUser : result),
                        errors = errors.ToArray()
                    };
                    retvalue = JsonConvert.SerializeObject(retdata);
                    Response.ContentType = "application/json";
                }
                else
                {
                    retvalue = "401";
                    Response.StatusCode = 500;
                }
            }
            else
            {
                Response.StatusCode = 404;
            }
            return retvalue;
        }

        private object UserToJSON(ForumService forumService, Core.Model.ForumUser forumUser)
        {
            var data = new
            {
                guid = forumUser.Guid != Guid.Empty ? forumUser.Guid.ToString() : null,
                userID = forumUser.UserID,
                comment = forumUser.Comment,
                email = forumUser.Email,
                website = forumUser.Website,
                admin = forumUser.AdminFlag.ToString().ToLower(),
                ban = forumUser.BanFlag.ToString().ToLower(),
                lastIPAddress = forumUser.LastIPAddress,
                lastLogin = forumUser.LastLogon.HasValue ? PEngine4.Core.Helpers.FormatDate(forumUser.LastLogon) : null,
                created = forumUser.CreatedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forumUser.CreatedUTC) : null,
                modified = forumUser.ModifiedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forumUser.ModifiedUTC) : null
            };
            return data;
        }

    }
}
