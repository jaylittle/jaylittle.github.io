﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;
using PEngine4.Core.Model;
using Newtonsoft.Json;

namespace PEngine4.MVC.Areas.Forum.Controllers
{
    public class ForumController : PEngineController
    {
        //
        // GET: /Forum/Forum/

        public ActionResult Index(int? start, int? count, string sortBy, string sortAsc)
        {
            this.SetupPEngineViewBag();
            start = start.HasValue ? start : 1;
            count = count.HasValue ? count : (int)PEngine4.Core.Settings.Query(Settings.AppSettingKey.app_recpage_forum_threads);
            sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "Name";
            sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "1";
            bool sortAscBool = sortAsc == "1" ? true : false;
            ForumService forumService = new ForumService();
            int totalRecs = 0;
            List<PEngine4.Core.Model.Forum> forums = forumService.ForumList(start.Value, count.Value, sortBy, sortAscBool,
                ref totalRecs, _token.Has(Helpers.AccessLevel.forumadmin));
            ViewBag.Total = totalRecs;
            ViewBag.Start = start;
            ViewBag.Count = count;
            ViewBag.SortBy = sortBy;
            ViewBag.SortAsc = sortAsc;
            ViewBag.SortAscBool = sortAscBool;
            ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
            return View(forums);
        }

        [HttpPost]
        public string Delete(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            this.ViewBag.Title += " Forums";
            if (_token.Has(Helpers.AccessLevel.forumadmin))
            {
                List<string> errors = new List<string>();
                if (id.HasValue)
                {
                    try
                    {
                        ForumService forumService = new ForumService();
                        forumService.ForumDelete(id.Value, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                }
                else
                {
                    errors.Add("ID parameter is required!");
                }
                var retdata = new
                {
                    data = new { },
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forumadmin))
            {
                ForumService forumService = new ForumService();
                Core.Model.Forum forum = new Core.Model.Forum();
                if (id.HasValue)
                {
                    forum = forumService.ForumGet(id.Value, true);
                }
                var data = ForumToJSON(forumService, forum);
                retvalue = JsonConvert.SerializeObject(data);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Post(Core.Model.Forum forum)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forumadmin))
            {
                ForumService forumService = new ForumService();
                List<string> errors = new List<string>();
                Core.Model.Forum result = null;
                try
                {
                    result = forumService.ForumSave(forum, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                }
                catch (Exception ex)
                {
                    errors.Add("Exception Thrown: " + ex.Message);
                }
                var retdata = new
                {
                    data = ForumToJSON(forumService, errors.Count > 0 || result == null ? forum : result),
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        private object ForumToJSON(ForumService forumService, Core.Model.Forum forum)
        {
            var data = new
            {
                guid = forum.Guid != Guid.Empty ? forum.Guid.ToString() : null,
                name = forum.Name,
                description = forum.Description,
                visible = forum.VisibleFlag.ToString().ToLower(),
                created = forum.CreatedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forum.CreatedUTC) : null,
                modified = forum.ModifiedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forum.ModifiedUTC) : null
            };
            return data;
        }
    }
}
