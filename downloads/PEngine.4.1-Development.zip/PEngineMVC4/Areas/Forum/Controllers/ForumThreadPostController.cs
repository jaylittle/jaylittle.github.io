﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;
using PEngine4.Core.Model;
using Newtonsoft.Json;

namespace PEngine4.MVC.Areas.Forum.Controllers
{
    public class ForumThreadPostController : PEngineController
    {
        //
        // GET: /Forum/ForumThreadPost/

        public ActionResult Index(string forumUniqueName, string uniqueName, int? start, int? count, Guid? showPostGuid)
        {
            string sortBy = string.Empty;
            string sortAsc = string.Empty;
            this.SetupPEngineViewBag();
            start = start.HasValue ? start : 1;
            count = count.HasValue ? count : (int)PEngine4.Core.Settings.Query(Settings.AppSettingKey.app_recpage_forum_threads);
            sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "CreatedUTC";
            sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "1";
            bool sortAscBool = sortAsc == "1" ? true : false;
            ForumService forumService = new ForumService();
            if (!showPostGuid.HasValue)
            {
                Core.Model.Forum forum = forumService.ForumGet(forumUniqueName, _token.Has(Helpers.AccessLevel.forumadmin));
                this.ViewBag.Title += " Forums";
                if (forum != null)
                {
                    this.ViewBag.Title += " : " + forum.Name;
                    this.ViewBag.ForumName = forum.Name;
                    this.ViewBag.ForumGuid = forum.Guid.ToString();
                    this.ViewBag.ForumLink = Url.RouteUrl("NamedForum", new { uniqueName = forum.UniqueName });
                }
                else
                {
                    this.ViewBag.ForumName = string.Empty;
                    Response.StatusCode = 404;
                    return null;
                }
                Core.Model.ForumThread forumThread = forumService.ForumThreadGet(forumUniqueName, uniqueName, _token.Has(Helpers.AccessLevel.forumadmin));
                if (forumThread != null)
                {
                    this.ViewBag.Title += " : " + forumThread.Title;
                    this.ViewBag.ForumThreadTitle = forumThread.Title;
                    this.ViewBag.ForumThreadGuid = forumThread.Guid.ToString();
                    this.ViewBag.ForumThreadLock = forumThread.LockFlag;
                    if (forum != null)
                    {
                        this.ViewBag.ForumThreadLink = Url.RouteUrl("NamedThread", new { forumUniqueName = forum.UniqueName, uniqueName = forumThread.UniqueName });
                    }
                }
                else
                {
                    this.ViewBag.ForumThreadTitle = string.Empty;
                    Response.StatusCode = 404;
                    return null;
                }
                int totalRecs = 0;
                List<PEngine4.Core.Model.ForumThreadPost> forumThreadPosts = forumService.ForumThreadPostList(forumUniqueName, uniqueName, start.Value, count.Value, sortBy, sortAscBool,
                    ref totalRecs, _token.Has(Helpers.AccessLevel.forumadmin));
                ViewBag.Total = totalRecs;
                ViewBag.Start = start;
                ViewBag.Count = count;
                ViewBag.SortBy = sortBy;
                ViewBag.SortAsc = sortAsc;
                ViewBag.SortAscBool = sortAscBool;
                ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
                return View(forumThreadPosts);
            }
            else
            {
                int totalRecs = 0;
                int recordPtr = 0;
                bool foundFlag = false;
                List<PEngine4.Core.Model.ForumThreadPost> forumThreadPosts = forumService.ForumThreadPostList(forumUniqueName, uniqueName, 1, 100000, sortBy, sortAscBool,
                    ref totalRecs, _token.Has(Helpers.AccessLevel.forumadmin));
                foreach (PEngine4.Core.Model.ForumThreadPost forumThreadPost in forumThreadPosts)
                {
                    if (!foundFlag && forumThreadPost.Guid != showPostGuid)
                    {
                        recordPtr++;
                    }
                    else
                    {
                        foundFlag = true;
                        break;
                    }
                }
                if (foundFlag)
                {
                    start = (recordPtr - (recordPtr % count)) + 1;
                    return Redirect(Url.RouteUrl("NamedThread", new { forumUniqueName = forumUniqueName, uniqueName = uniqueName, start = start, count = count }) + "#" + showPostGuid.Value.ToString().Replace("-", string.Empty));
                }
                else
                {
                    return RedirectToRoute("NamedThread", new { forumUniqueName = forumUniqueName, uniqueName = uniqueName });
                }
            }
        }

        [HttpPost]
        public string Delete(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                List<string> errors = new List<string>();
                if (id.HasValue)
                {
                    try
                    {
                        ForumService forumService = new ForumService();
                        forumService.ForumThreadPostDelete(id.Value, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                }
                else
                {
                    errors.Add("ID parameter is required!");
                }
                var retdata = new
                {
                    data = new { },
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                ForumService forumService = new ForumService();
                Core.Model.ForumThreadPost forumThreadPost = new Core.Model.ForumThreadPost();
                if (id.HasValue)
                {
                    forumThreadPost = forumService.ForumThreadPostGet(id.Value, true);
                }
                var data = PostToJSON(forumService, forumThreadPost);
                retvalue = JsonConvert.SerializeObject(data);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Post()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                if (!string.IsNullOrEmpty(Request.Params["json"]))
                {
                    //Deserialize JSON Here
                    ForumThreadPost forumThreadPost = JsonConvert.DeserializeObject<ForumThreadPost>(Request.Params["json"]);
                    ForumService forumService = new ForumService();
                    List<string> errors = new List<string>();
                    Core.Model.ForumThreadPost result = null;
                    try
                    {
                        forumThreadPost.VisibleFlag = true;
                        forumThreadPost.IPAddress = Request.ServerVariables["REMOTE_ADDR"];
                        result = forumService.ForumThreadPostSave(forumThreadPost, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                    var retdata = new
                    {
                        data = PostToJSON(forumService, errors.Count > 0 || result == null ? forumThreadPost : result),
                        errors = errors.ToArray()
                    };
                    retvalue = JsonConvert.SerializeObject(retdata);
                    Response.ContentType = "application/json";
                }
                else
                {
                    Response.StatusCode = 404;
                }
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        private object PostToJSON(ForumService forumService, Core.Model.ForumThreadPost forumThreadPost)
        {
            var data = new
            {
                guid = forumThreadPost.Guid != Guid.Empty ? forumThreadPost.Guid.ToString() : null,
                content = forumThreadPost != null ? forumThreadPost.Data : string.Empty,
                visible = forumThreadPost.Guid != Guid.Empty ? forumThreadPost.VisibleFlag.ToString().ToLower() : "true",
                locked = forumThreadPost.Guid != Guid.Empty ? forumThreadPost.LockFlag.ToString().ToLower() : "false",
                created = forumThreadPost.CreatedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forumThreadPost.CreatedUTC) : null,
                modified = forumThreadPost.ModifiedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forumThreadPost.ModifiedUTC) : null,
                createdBy = forumThreadPost.ForumUser != null ? forumThreadPost.ForumUser.UserID : "Me"
            };
            return data;
        }

    }
}
