﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;
using PEngine4.Core.Model;
using Newtonsoft.Json;

namespace PEngine4.MVC.Areas.Forum.Controllers
{
    public class ForumThreadController : PEngineController
    {
        //
        // GET: /Forum/Thread/

        public ActionResult Index(string uniqueName, int? start, int? count, string sortBy, string sortAsc)
        {
            this.SetupPEngineViewBag();
            start = start.HasValue ? start : 1;
            count = count.HasValue ? count : (int)PEngine4.Core.Settings.Query(Settings.AppSettingKey.app_recpage_forum_threads);
            sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "ModifiedUTC";
            sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "0";
            bool sortAscBool = sortAsc == "1" ? true : false;
            ForumService forumService = new ForumService();
            Core.Model.Forum forum = forumService.ForumGet(uniqueName, _token.Has(Helpers.AccessLevel.forumadmin));
            this.ViewBag.Title += " Forums";
            if (forum != null)
            {
                this.ViewBag.Title += " : " + forum.Name;
                this.ViewBag.ForumName = forum.Name;
                this.ViewBag.ForumGuid = forum.Guid.ToString();
                this.ViewBag.ForumLink = Url.RouteUrl("NamedForum", new { uniqueName = forum.UniqueName });
            }
            else
            {
                this.ViewBag.ForumName = string.Empty;
                Response.StatusCode = 404;
                return null;
            }
            int totalRecs = 0;
            List<PEngine4.Core.Model.ForumThread> forumThreads = forumService.ForumThreadList(uniqueName, start.Value, count.Value, sortBy, sortAscBool,
                ref totalRecs, _token.Has(Helpers.AccessLevel.forumadmin));
            ViewBag.Total = totalRecs;
            ViewBag.Start = start;
            ViewBag.Count = count;
            ViewBag.SortBy = sortBy;
            ViewBag.SortAsc = sortAsc;
            ViewBag.SortAscBool = sortAscBool;
            ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
            return View(forumThreads);
        }

        [HttpPost]
        public string Delete(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                List<string> errors = new List<string>();
                if (id.HasValue)
                {
                    try
                    {
                        ForumService forumService = new ForumService();
                        forumService.ForumDelete(id.Value, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                }
                else
                {
                    errors.Add("ID parameter is required!");
                }
                var retdata = new
                {
                    data = new { },
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                ForumService forumService = new ForumService();
                Core.Model.ForumThread forumThread = new Core.Model.ForumThread();
                if (id.HasValue)
                {
                    forumThread = forumService.ForumThreadGet(id.Value, true);
                }
                var data = ThreadToJSON(forumService, forumThread);
                retvalue = JsonConvert.SerializeObject(data);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Post()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.forum))
            {
                if (!string.IsNullOrEmpty(Request.Params["json"]))
                {
                    //Deserialize JSON Here
                    ForumThread forumThread = JsonConvert.DeserializeObject<ForumThread>(Request.Params["json"]);
                    ForumService forumService = new ForumService();
                    List<string> errors = new List<string>();
                    Core.Model.ForumThread result = null;
                    try
                    {
                        forumThread.ForumThreadPosts.First().IPAddress = Request.ServerVariables["REMOTE_ADDR"];
                        forumThread.ForumThreadPosts.First().VisibleFlag = true;
                        forumThread.ForumThreadPosts.First().LockFlag = forumThread.LockFlag;
                        result = forumService.ForumThreadSave(forumThread, ref errors, _token.ForumUserGuid, _token.Has(Helpers.AccessLevel.forumadmin));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                    var retdata = new
                    {
                        data = ThreadToJSON(forumService, errors.Count > 0 || result == null ? forumThread : result),
                        errors = errors.ToArray()
                    };
                    retvalue = JsonConvert.SerializeObject(retdata);
                    Response.ContentType = "application/json";
                }
                else
                {
                    Response.StatusCode = 404;
                }
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        private object ThreadToJSON(ForumService forumService, Core.Model.ForumThread forumThread)
        {
            ForumThreadPost forumThreadPost = forumThread.ForumThreadPosts.OrderBy(o => o.CreatedUTC).FirstOrDefault();
            var data = new
            {
                guid = forumThread.Guid != Guid.Empty ? forumThread.Guid.ToString() : null,
                postGuid = forumThreadPost != null && forumThreadPost.Guid != Guid.Empty ? forumThreadPost.Guid.ToString() : null,
                title = forumThread.Title,
                content = forumThreadPost != null ? forumThreadPost.Data : string.Empty,
                visible = forumThread.Guid != Guid.Empty ? forumThread.VisibleFlag.ToString().ToLower() : "true",
                locked = forumThread.Guid != Guid.Empty ? forumThread.LockFlag.ToString().ToLower() : "false",
                created = forumThread.CreatedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forumThread.CreatedUTC) : null,
                modified = forumThread.ModifiedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(forumThread.ModifiedUTC) : null,
                createdBy = forumThread.ForumUser != null ? forumThread.ForumUser.UserID : "Me"
            };
            return data;
        }

    }
}
