﻿using System.Web.Mvc;

namespace PEngine4.MVC.Areas.Forum
{
    public class ForumAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Forum";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                name: "NamedForum",
                url: "forum/threads/{uniqueName}",
                defaults: new { controller = "ForumThread", action = "Index" }
            );

            context.MapRoute(
                name: "NamedThread",
                url: "forum/thread/{forumUniqueName}/{uniqueName}",
                defaults: new { controller = "ForumThreadPost", action = "Index" }
            );

            context.MapRoute(
                name: "NamedUser",
                url: "forum/user/{userID}",
                defaults: new { controller = "ForumUser", action = "View" }
            );

            context.MapRoute(
                name: "AllUsers",
                url: "forum/user",
                defaults: new { controller = "ForumUser", action = "Index" }
            );

            context.MapRoute(
                "Forum_default",
                "forum/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );

            context.MapRoute(
                name: "BaseForum",
                url: "forum",
                defaults: new { controller = "Forum", action = "Index" }
            );
        }
    }
}
