﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Model;
using PEngine4.Core.Services;

namespace PEngine4.MVC.Controllers
{
    public class RedirectController : PEngineController
    {
        //
        // GET: /Redirect/

        public ActionResult Index()
        {
            this.SetupPEngineViewBag();
            return this.ProcessLegacyRequest(_token.Has(Helpers.AccessLevel.admin));
        }
    }
}
