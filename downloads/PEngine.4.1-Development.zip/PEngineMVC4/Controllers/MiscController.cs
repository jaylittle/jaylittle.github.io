﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;
using PEngine4.Core.Model;
using Newtonsoft.Json;

namespace PEngine4.MVC.Controllers
{
    public class MiscController : PEngineController
    {
        [HttpPost]
        public string Elite()
        {
            bool eliteFlag = false;
            if (!string.IsNullOrEmpty(Request.Form["elite"]))
            {
                eliteFlag = Request.Form["elite"] == "1" ? true : false;
            }
            else if (Session["leetflag"] != null)
            {
                eliteFlag = !(bool)Session["leetflag"];
            }
            else
            {
                eliteFlag = true;
            }
            Session["leetflag"] = eliteFlag;
            return string.Empty;
        }

        [HttpGet]
        public string Template(string name)
        {
            string retvalue = null;
            this.SetupPEngineViewBag();
            //Make sure there are no attempts to break out of the Templates directory
            name = name.Replace("..", string.Empty);
            if (System.IO.File.Exists(Server.MapPath(string.Format("~/Templates/{0}.html", name))))
            {
                Response.ContentType = "text/html";
                Response.Cache.SetMaxAge(new TimeSpan(0, 1, 0, 0));
                retvalue = System.IO.File.ReadAllText(Server.MapPath(string.Format("~/Templates/{0}.html", name)));
            }
            else if (System.IO.File.Exists(Server.MapPath(string.Format("~/Templates/Forum/{0}.html", name))))
            {
                if (_token.Has(Helpers.AccessLevel.forum))
                {
                    Response.ContentType = "text/html";
                    Response.Cache.SetMaxAge(new TimeSpan(0, 1, 0, 0));
                    retvalue = System.IO.File.ReadAllText(Server.MapPath(string.Format("~/Templates/Forum/{0}.html", name)));
                }
                else
                {
                    retvalue = "401";
                    Response.StatusCode = 500;
                }
            }
            else if (System.IO.File.Exists(Server.MapPath(string.Format("~/Templates/ForumAdmin/{0}.html", name))))
            {
                if (_token.Has(Helpers.AccessLevel.forumadmin))
                {
                    Response.ContentType = "text/html";
                    Response.Cache.SetMaxAge(new TimeSpan(0, 1, 0, 0));
                    retvalue = System.IO.File.ReadAllText(Server.MapPath(string.Format("~/Templates/ForumAdmin/{0}.html", name)));
                }
                else
                {
                    retvalue = "401";
                    Response.StatusCode = 500;
                }
            }
            else if (System.IO.File.Exists(Server.MapPath(string.Format("~/Templates/Admin/{0}.html", name))))
            {
                if (_token.Has(Helpers.AccessLevel.admin))
                {
                    Response.ContentType = "text/html";
                    Response.Cache.SetMaxAge(new TimeSpan(0, 1, 0, 0));
                    retvalue = System.IO.File.ReadAllText(Server.MapPath(string.Format("~/Templates/Admin/{0}.html", name)));
                }
                else
                {
                    retvalue = "401";
                    Response.StatusCode = 500;
                }
            }
            else
            {
                Response.StatusCode = 404;
            }
            return retvalue;
        }

        [HttpGet]
        public string Quote()
        {
            string retvalue = null;
            QuoteService quoteService = new QuoteService();
            Quote quote = quoteService.QuoteRandom();
            if (quote != null)
            {
                retvalue = JsonConvert.SerializeObject(new { quote = Helpers.EliteConvert(quote.Data) });
                Response.ContentType = "application/json";
            }
            else
            {
                Response.StatusCode = 404;
            }
            return retvalue;
        }

        [HttpPost]
        public string Theme()
        {
            if (!string.IsNullOrEmpty(Request.Form["theme"]))
            {
                PEngine4.Core.Helpers.ThemeSelect(System.Web.HttpContext.Current, Request.Form["theme"]);
            }
            this.SetupPEngineViewBag();
            return string.Empty;
        }
    }
}
