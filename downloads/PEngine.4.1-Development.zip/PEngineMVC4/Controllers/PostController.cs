﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Model;
using PEngine4.Core.Services;
using Newtonsoft.Json;

namespace PEngine4.MVC.Controllers
{
    public class PostController : PEngineController
    {
        //
        // GET: /Post/

        public ActionResult Index()
        {
            this.SetupPEngineViewBag();
            string cmd = !string.IsNullOrEmpty(Request.QueryString["cmd"]) ? Request.QueryString["cmd"] : string.Empty;
            if (string.IsNullOrEmpty(cmd))
            {
                ViewBag.PageTitle = "Index";
                PostService postService = new PostService();
                int totalRecs = 0;
                return View(postService.PostList(1,
                    (int)PEngine4.Core.Settings.Query(PEngine4.Core.Settings.AppSettingKey.app_recpage_news)
                    , ref totalRecs, _token.Has(Helpers.AccessLevel.admin)));
            }
            else
            {
                return this.ProcessLegacyRequest(_token.Has(Helpers.AccessLevel.admin));
            }
        }

        public ActionResult List(int? start, int? count, string sortBy, string sortAsc)
        {
            this.SetupPEngineViewBag();
            start = start.HasValue ? start : 1;
            count = count.HasValue ? count : (int)PEngine4.Core.Settings.Query(Settings.AppSettingKey.app_recpage_news_summary);
            sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "CreatedUTC";
            sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "0";
            bool sortAscBool = sortAsc == "1" ? true : false;
            PostService postService = new PostService();
            int totalRecs = 0;
            List<Post> posts = postService.PostList(start.Value, count.Value, sortBy, sortAscBool,
                ref totalRecs, _token.Has(Helpers.AccessLevel.admin));
            ViewBag.Total = totalRecs;
            ViewBag.Start = start;
            ViewBag.Count = count;
            ViewBag.SortBy = sortBy;
            ViewBag.SortAsc = sortAsc;
            ViewBag.SortAscBool = sortAscBool;
            ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
            return View(posts);
        }

        public ActionResult ViewByGuid(Guid? id)
        {
            this.SetupPEngineViewBag();
            List<Post> post = new List<Post>(){ };
            if (id.HasValue)
            {
                PostService postService = new PostService();
                post = new List<Post>() { postService.PostGet(id.Value, _token.Has(Helpers.AccessLevel.admin)) };
            }
            if (post != null && post.Count > 0 && post[0] != null)
            {
                ViewBag.PageTitle = post[0].Title;
                return View("index", post);
            }
            Response.StatusCode = 404;
            return null;
        }

        public ActionResult View(int year, int month, string uniqueName)
        {
            this.SetupPEngineViewBag();
            List<Post> post = new List<Post>() { };
            PostService postService = new PostService();
            post = new List<Post>() { postService.PostGet(year, month, uniqueName, _token.Has(Helpers.AccessLevel.admin)) };
            if (post != null && post.Count > 0 && post[0] != null)
            {
                ViewBag.PageTitle = post[0].Title;
                ViewBag.SummaryTitle = post[0].Title;
                ViewBag.SummaryDescription = Helpers.DataTruncate((string)post[0].Data, -1);
                return View("index", post);
            }
            Response.StatusCode = 404;
            return null;
        }

        [HttpPost]
        public string Delete(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                List<string> errors = new List<string>();
                if (id.HasValue)
                {
                    try
                    {
                        PostService postService = new PostService();
                        postService.PostDelete(id.Value);
                        PEngine4.Core.Feeds.RSS.Generate(Url.RouteUrl("NamedPost", new { action = "view", controller = "post", year = "PostYear", month = "PostMonth", uniqueName = "PostUniqueName" }));
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                }
                else
                {
                    errors.Add("ID parameter is required!");
                }
                var retdata = new
                {
                    data = new { },
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                PostService postService = new PostService();
                Post post = new Post();
                if (id.HasValue)
                {
                    post = postService.PostGet(id.Value, true);
                }
                var data = PostToJSON(postService, post);
                retvalue = JsonConvert.SerializeObject(data);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Post(Post post)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            bool hasAccess = _token.Has(Helpers.AccessLevel.god) || (post.Guid != Guid.Empty && _token.Article_Has(post.Guid));
            if (hasAccess)
            {
                PostService postService = new PostService();
                List<string> errors = new List<string>();
                Post result = null;
                try
                {
                    result = postService.PostSave(post, ref errors);
                    PEngine4.Core.Feeds.RSS.Generate(Url.RouteUrl("NamedPost", new { action = "view", controller = "post", year = "PostYear", month = "PostMonth", uniqueName = "PostUniqueName" }));
                }
                catch (Exception ex)
                {
                    errors.Add("Exception Thrown: " + ex.Message);
                }
                var retdata = new {
                    data = PostToJSON(postService, errors.Count > 0 || result == null ? post : result),
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        private object PostToJSON(PostService postService, Post post)
        {
            var icons = PEngine4.Core.Helpers.IconList(System.Web.HttpContext.Current, false).Select(o => new { id = o.Text, name = o.Text }).ToArray();
            var data = new
            {
                guid = post.Guid != Guid.Empty ? post.Guid.ToString() : null,
                legacyId = post.LegacyID,
                title = post.Title,
                iconFileName = post.IconFileName,
                visible = post.VisibleFlag.ToString().ToLower(),
                created = post.CreatedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(post.CreatedUTC) : null,
                modified = post.ModifiedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(post.ModifiedUTC) : null,
                data = post.Data,
                icons = icons
            };
            return data;
        }
    }
}
