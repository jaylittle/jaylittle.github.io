﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using Newtonsoft.Json;

namespace PEngine4.MVC.Controllers
{
    public class FileController : PEngineController
    {
        //
        // GET: /File/
        private List<string> validPathBase = new List<string>() { "downloads", "images" };

        [HttpGet]
        public string Get()
        {
            string retvalue = null;
            this.SetupPEngineViewBag();
            List<string> errors = new List<string>();
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                string pathBase = !string.IsNullOrEmpty(Request.QueryString["pathBase"]) ? Request.QueryString["pathBase"] : string.Empty;
                string path = FilterPath(!string.IsNullOrEmpty(Request.QueryString["path"]) ? Request.QueryString["path"] : string.Empty);
                string filterToType = !string.IsNullOrEmpty(Request.QueryString["filter"]) ? Request.QueryString["filter"] : string.Empty;
                List<object> retdata = List(pathBase, path, filterToType);
                retvalue = JsonConvert.SerializeObject(new { data = retdata.ToArray(), errors = errors.ToArray() });
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Delete()
        {
            string retvalue = null;
            this.SetupPEngineViewBag();
            List<string> errors = new List<string>();
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                string lastPathBase = string.Empty;
                string lastPath = string.Empty;
                string[] pathBases = !string.IsNullOrEmpty(Request.Form["pathBases"]) ? Request.Form["pathBases"].Split('|') : new string[] {};
                string[] paths = !string.IsNullOrEmpty(Request.Form["paths"]) ? Request.Form["paths"].Split('|') : new string[] {};
                string filterToType = !string.IsNullOrEmpty(Request.QueryString["filter"]) ? Request.QueryString["filter"] : string.Empty;
                for (int pptr = 0; pptr < pathBases.Length; pptr++)
                {
                    string pathBase = pathBases[pptr];
                    string path = FilterPath(paths.Length > pptr ? paths[pptr] : string.Empty);
                    string parentPath = "~/" + pathBase + "/" + path;
                    if (!string.IsNullOrEmpty(pathBase) && validPathBase.Contains(pathBase.ToLower().Trim())
                        && !string.IsNullOrEmpty(path))
                    {
                        if (System.IO.File.Exists(Server.MapPath(parentPath)))
                        {
                            System.IO.File.Delete(Server.MapPath(parentPath));
                        }
                        else if (System.IO.Directory.Exists(Server.MapPath(parentPath)))
                        {
                            System.IO.Directory.Delete(Server.MapPath(parentPath), true);
                        }
                        lastPathBase = pathBase;
                        lastPath = path.Substring(0, path.TrimEnd('/').LastIndexOf('/') >= 0 ? path.TrimEnd('/').LastIndexOf('/') : path.Length);
                    }
                }
                List<object> retdata = List(lastPathBase, lastPath, filterToType);
                Response.ContentType = "application/json";
                retvalue = JsonConvert.SerializeObject(new { data = retdata.ToArray(), errors = errors.ToArray() });
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Copy()
        {
            string retvalue = null;
            this.SetupPEngineViewBag();
            List<string> errors = new List<string>();
            List<string> notices = new List<string>();
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                string[] fromPathBases = !string.IsNullOrEmpty(Request.Form["fromPathBases"]) ? Request.Form["fromPathBases"].Split('|') : new string[] { };
                string[] fromPaths = !string.IsNullOrEmpty(Request.Form["fromPaths"]) ? Request.Form["fromPaths"].Split('|') : new string[] { };
                string toPathBase = !string.IsNullOrEmpty(Request.Form["toPathBase"]) ? Request.Form["toPathBase"] : string.Empty;
                string toPath = FilterPath(!string.IsNullOrEmpty(Request.Form["toPath"]) ? Request.Form["toPath"] : string.Empty);
                bool moveFlag = !string.IsNullOrEmpty(Request.Form["moveFlag"]) && Request.Form["moveFlag"] == "1" ? true : false;
                string filterToType = !string.IsNullOrEmpty(Request.QueryString["filter"]) ? Request.QueryString["filter"] : string.Empty;
                if (!string.IsNullOrEmpty(toPathBase) && validPathBase.Contains(toPathBase.ToLower().Trim()) 
                    && fromPaths.Length > 0 && fromPathBases.Length == fromPaths.Length)
                {
                    string toParentPath = "~/" + toPathBase + "/" + toPath;
                    if (System.IO.Directory.Exists(Server.MapPath(toParentPath))) {
                        for (int fptr = 0; fptr < fromPathBases.Length; fptr++)
                        {
                            string fromPathBase = fromPathBases[fptr];
                            string fromPath = FilterPath(fromPaths.Length > fptr ? fromPaths[fptr] : string.Empty);
                            string fromParentPath = "~/" + fromPathBase + "/" + fromPath;
                            if (!string.IsNullOrEmpty(fromPath) && validPathBase.Contains(fromPathBase.ToLower().Trim()))
                            {
                                string name = System.IO.Path.GetFileName(fromParentPath);
                                string tmpPath = toParentPath + "/" + name;
                                if (!tmpPath.Equals(fromParentPath, StringComparison.OrdinalIgnoreCase))
                                {
                                    if (System.IO.File.Exists(Server.MapPath(fromParentPath)))
                                    {
                                        if (moveFlag)
                                        {
                                            System.IO.File.Move(Server.MapPath(fromParentPath), Server.MapPath(tmpPath));
                                        }
                                        else
                                        {
                                            System.IO.File.Copy(Server.MapPath(fromParentPath), Server.MapPath(tmpPath));
                                        }
                                    }
                                    else if (System.IO.Directory.Exists(Server.MapPath(fromParentPath)))
                                    {
                                        if (moveFlag)
                                        {
                                            System.IO.Directory.Move(Server.MapPath(fromParentPath), Server.MapPath(tmpPath));
                                        }
                                        else
                                        {
                                            //System.IO.Directory.Move(Server.MapPath(fromParentPath), Server.MapPath(tmpPath));
                                            notices.Add(fromPathBase + "/" + fromPath + ": Folders cannot be copied!");
                                        }
                                    }
                                }
                                else
                                {
                                    notices.Add(fromPathBase + "/" + fromPath + ": Files and folders cannot be copied or moved onto themselves!");
                                }
                            }
                        }
                        List<object> retdata = List(toPathBase, toPath, filterToType);
                        Response.ContentType = "application/json";
                        retvalue = JsonConvert.SerializeObject(new { data = retdata.ToArray(), errors = errors.ToArray(), notices = notices.ToArray() });
                    }
                }
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public ActionResult Upload()
        {
            string retvalue = null;
            this.SetupPEngineViewBag();
            List<string> errors = new List<string>();
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                string pathBase = !string.IsNullOrEmpty(Request.Form["pathBase"]) ? Request.Form["pathBase"] : string.Empty;
                string path = FilterPath(!string.IsNullOrEmpty(Request.Form["path"]) ? Request.Form["path"] : string.Empty);
                string filterToType = !string.IsNullOrEmpty(Request.QueryString["filter"]) ? Request.QueryString["filter"] : string.Empty;
                if (!string.IsNullOrEmpty(pathBase) && validPathBase.Contains(pathBase.ToLower().Trim()))
                {
                    string parentPath = "~/" + pathBase + "/" + path;
                    int fileCount = 0;
                    for (int fptr = 0; fptr < Request.Files.Count; fptr++)
                    {
                        HttpPostedFileBase file = Request.Files[fptr];
                        if (!string.IsNullOrEmpty(file.FileName))
                        {
                            string tmpPath = parentPath + "/" + file.FileName;
                            if (System.IO.File.Exists(Server.MapPath(tmpPath)))
                            {
                                int ctr = 0;
                                string oldPath = tmpPath + "." + ctr.ToString("000");
                                while (System.IO.File.Exists(Server.MapPath(oldPath)))
                                {
                                    ctr++;
                                    oldPath = tmpPath + "." + ctr.ToString("000");
                                }
                                System.IO.File.Move(Server.MapPath(tmpPath), Server.MapPath(oldPath));
                            }
                            file.SaveAs(Server.MapPath(tmpPath));
                            fileCount++;
                        }
                    }
                    if (fileCount <= 0)
                    {
                        errors.Add("You must select at least one file when uploading!");
                    }
                    List<object> retdata = List(pathBase, path, filterToType);
                    retvalue = JsonConvert.SerializeObject(new { data = retdata.ToArray(), errors = errors.ToArray() });
                }
            }
            else
            {
                retvalue = "401";
            }
            ViewBag.ReturnData = retvalue;
            return View();
        }

        private List<object> List(string pathBase, string path, string filterToType)
        {
            List<object> retdata = new List<object>();
            if (string.IsNullOrEmpty(pathBase))
            {
                retdata.Add(new { name = "Downloads", type = "folder", date = "N/A", size = "N/A" });
                retdata.Add(new { name = "Images", type = "folder", date = "N/A", size = "N/A" });
            }
            else
            {
                if (validPathBase.Contains(pathBase.ToLower().Trim()))
                {
                    string parentPath = "~/" + pathBase + "/" + path + "/";
                    string[] files = System.IO.Directory.GetFiles(Server.MapPath(parentPath.TrimEnd('/')));
                    string[] dirs = System.IO.Directory.GetDirectories(Server.MapPath(parentPath.Trim('/')));
                    if (string.IsNullOrEmpty(filterToType) || filterToType.IndexOf("folder") >= 0)
                    {
                        for (int dptr = 0; dptr < dirs.Length; dptr++)
                        {
                            string name = System.IO.Path.GetFileName(dirs[dptr]);
                            string[] subfiles = new string[] { };
                            string ddate = "N/A";
                            try
                            {
                                subfiles = System.IO.Directory.GetFiles(Server.MapPath(parentPath + name));
                            }
                            catch
                            {
                                subfiles = new string[] { };
                            }
                            try
                            {
                                ddate = PEngine4.Core.Helpers.FormatDate(System.IO.Directory.GetLastWriteTime(Server.MapPath(parentPath + name)));
                            }
                            catch
                            {
                                ddate = "N/A";
                            }
                            retdata.Add(new
                            {
                                name = name,
                                type = "folder",
                                size = subfiles.Length.ToString(),
                                date = ddate
                            });
                        }
                    }
                    if (string.IsNullOrEmpty(filterToType) || filterToType.IndexOf("file") >= 0)
                    {
                        for (int fptr = 0; fptr < files.Length; fptr++)
                        {
                            string name = System.IO.Path.GetFileName(files[fptr]);
                            string size = "N/A";
                            string fdate = "N/A";
                            try
                            {
                                size = new System.IO.FileInfo(Server.MapPath(parentPath + name)).Length.ToString();
                            }
                            catch
                            {
                                size = "N/A";
                            }
                            try
                            {
                                fdate = PEngine4.Core.Helpers.FormatDate(System.IO.File.GetLastWriteTime(Server.MapPath(parentPath + name)));
                            }
                            catch
                            {
                                fdate = "N/A";
                            }
                            var fileInfo = new
                            {
                                name = name,
                                type = "file",
                                size = size,
                                date = fdate
                            };
                            retdata.Add(fileInfo);
                        }
                    }
                }
                else
                {
                    Response.StatusCode = 404;
                }
            }
            return retdata;
        }

        private string FilterPath(string path)
        {
            return path.Replace("..", string.Empty);
        }
    }
}
