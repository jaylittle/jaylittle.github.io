﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Services;

namespace PEngine4.MVC.Controllers
{
    public class SearchController : PEngineController
    {
        public ActionResult Index(string query, int? start, int? count, string sortBy, string sortAsc)
        {
            this.SetupPEngineViewBag();
            start = start.HasValue ? start : 1;
            count = count.HasValue ? count : (int)PEngine4.Core.Settings.Query(Settings.AppSettingKey.app_recpage_search_results);
            sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "Date";
            sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "0";
            bool sortAscBool = sortAsc == "1" ? true : false;
            int totalRecs = 0;
            SearchService searchService = new SearchService();
            List<PEngine4.Core.TempClasses.SearchResult> results = searchService.Search(query,
                Url.RouteUrl("NamedPost", new { action = "view", controller = "post", month = "PostMonth", year = "PostYear", uniqueName = "PostUniqueName" }),
                Url.RouteUrl("NamedArticle", new { action = "view", controller = "article", id = "ArticleUniqueName", sectionUniqueName = "SectionUniqueName" }),
                Url.RouteUrl("NamedThread", new { forumUniqueName = "ForumUniqueName", uniqueName = "ThreadUniqueName", showPostGuid = "ThreadPostGuid" }),
                _token.Has(Helpers.AccessLevel.admin), start.Value, count.Value, sortBy, sortAscBool, ref totalRecs);
            ViewBag.Query = query;
            ViewBag.Total = totalRecs;
            ViewBag.Start = start;
            ViewBag.Count = count;
            ViewBag.SortBy = sortBy;
            ViewBag.SortAsc = sortAsc;
            ViewBag.SortAscBool = sortAscBool;
            ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
            return View(results);
        }

    }
}
