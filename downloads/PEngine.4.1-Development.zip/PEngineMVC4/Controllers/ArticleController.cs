﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.Model;
using PEngine4.Core.Services;
using PEngine4.Core.TempClasses;
using Newtonsoft.Json;

namespace PEngine4.MVC.Controllers
{
    public class ArticleController : PEngineController
    {
        //
        // GET: /Article/

        public ActionResult Category(string id, int? start, int? count, string sortBy, string sortAsc)
        {
            this.SetupPEngineViewBag();
            if (!string.IsNullOrEmpty(id))
            {
                start = start.HasValue ? start : 1;
                count = count.HasValue ? count : 15;
                sortBy = !string.IsNullOrEmpty(sortBy) ? sortBy : "Name";
                sortAsc = !string.IsNullOrEmpty(sortAsc) ? sortAsc : "1";
                bool sortAscBool = sortAsc == "1" ? true : false;
                ArticleService articleService = new ArticleService();
                int totalRecs = 0;
                List<Article> articles = articleService.ArticleList(id, start.Value, count.Value, sortBy,
                    sortAscBool, ref totalRecs, _token.Has(Helpers.AccessLevel.admin));
                //Check to see if a single article in question actually has any sections
                //If so push push the user directly to the article rather than bothering
                //with the category view
                if (articles != null && articles.Count == 1 && articleService.SectionList(articles[0].Guid).Count > 0)
                {
                    return RedirectToRoute("NamedArticle", new { controller = "article", action = "view", id = articles[0].UniqueName, sectionUniqueName = string.Empty });
                }
                if (articles != null && articles.Count >= 1)
                {
                    ViewBag.Total = totalRecs;
                    ViewBag.Start = start;
                    ViewBag.Count = count;
                    ViewBag.SortBy = sortBy;
                    ViewBag.SortAsc = sortAsc;
                    ViewBag.SortAscBool = sortAscBool;
                    ViewBag.SortAscFlip = sortAscBool ? "0" : "1";
                    ViewBag.Category = id;
                    return View(articles);
                }
                else
                {
                    return RedirectToAction("index", "post");
                }
            }
            Response.StatusCode = 404;
            return null;
        }

        public ActionResult ViewByGuid(Guid? id)
        {
            this.SetupPEngineViewBag();
            Article article = null;
            ArticleSection section = null;
            if (id.HasValue)
            {
                ArticleService articleService = new ArticleService();
                article = articleService.ArticleGet(id.Value, _token.Has(Helpers.AccessLevel.admin));
                if (article != null)
                {
                    if (string.IsNullOrEmpty(article.ContentURL))
                    {
                        section = articleService.SectionGet(article.Guid, article.DefaultSection, _token.Has(Helpers.AccessLevel.admin));
                    }
                    else
                    {
                        return Redirect(article.ContentURL);
                    }
                }
            }
            if (article != null)
            {
                return View("view", new ArticleWithSection(article, section));
            }
            Response.StatusCode = 404;
            return null;
        }

        public new ActionResult View(string id, string sectionUniqueName)
        {
            this.SetupPEngineViewBag();
            if (!string.IsNullOrEmpty(id))
            {
                ArticleWithSection articleSection = null;
                ArticleService articleService = new ArticleService();
                articleSection = articleService.ArticleSectionGet(id, sectionUniqueName, _token.Has(Helpers.AccessLevel.admin));
                if (articleSection != null)
                {
                    ViewBag.SummaryTitle = articleSection.Article.Name + " - " + articleSection.Section.Name;
                    ViewBag.SummaryDescription = Helpers.DataTruncate((string)articleSection.Section.Data, -1);
                    return View("view", articleSection);
                }
                else
                {
                    Article article = articleService.ArticleGet(id, _token.Has(Helpers.AccessLevel.admin));
                    if (article != null && !string.IsNullOrEmpty(article.Category))
                    {
                        return RedirectToAction("category", "article", new { id = article.Category });
                    }
                    else
                    {
                        return RedirectToAction("index", "post");
                    }
                }
            }
            Response.StatusCode = 404;
            return null;
        }

        [HttpPost]
        public string Delete(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                List<string> errors = new List<string>();
                if (id.HasValue)
                {
                    try
                    {
                        ArticleService articleService = new ArticleService();
                        Article article = articleService.ArticleGet(id.Value, true);
                        bool accessFlag = true;
                        if (!_token.Has(Helpers.AccessLevel.god) && !string.IsNullOrEmpty(article.AdminPass) && !_token.Article_Has(article.Guid))
                        {
                            accessFlag = false;
                        }
                        if (accessFlag)
                        {
                            articleService.ArticleDelete(id.Value);
                        }
                        else
                        {
                            //Use a special Status Code so that the client knows all that is needed is an article level password
                            retvalue = "409";
                            Response.StatusCode = 500;
                        }
                    }
                    catch (Exception ex)
                    {
                        errors.Add("Exception Thrown: " + ex.Message);
                    }
                }
                else
                {
                    errors.Add("ID parameter is required!");
                }
                var retdata = new
                {
                    data = new { },
                    errors = errors.ToArray()
                };
                retvalue = JsonConvert.SerializeObject(retdata);
                Response.ContentType = "application/json";
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpGet]
        public string Get(Guid? id)
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                ArticleService articleService = new ArticleService();
                Article article = new Article();
                bool accessFlag = true;
                if (id.HasValue)
                {
                    article = articleService.ArticleGet(id.Value, true);
                    if (!_token.Has(Helpers.AccessLevel.god) && !string.IsNullOrEmpty(article.AdminPass) && !_token.Article_Has(article.Guid))
                    {
                        accessFlag = false;
                    }
                }
                if (accessFlag)
                {
                    var data = ArticleToJSON(articleService, article);
                    retvalue = JsonConvert.SerializeObject(data);
                    Response.ContentType = "application/json";
                }
                else
                {
                    //Use a special Status Code so that the client knows all that is needed is an article level password
                    retvalue = "409";
                    Response.StatusCode = 500;
                }
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        [HttpPost]
        public string Post()
        {
            this.SetupPEngineViewBag();
            string retvalue = null;
            if (_token.Has(Helpers.AccessLevel.admin))
            {
                if (!string.IsNullOrEmpty(Request.Params["json"]))
                {
                    //Deserialize JSON Here
                    Article article = JsonConvert.DeserializeObject<Article>(Request.Params["json"]);
                    Article oldArticle = null;
                    ArticleService articleService = new ArticleService();
                    bool accessFlag = true;
                    if (article.Guid != Guid.Empty) {
                        oldArticle = articleService.ArticleGet(article.Guid, true);
                        if (!_token.Has(Helpers.AccessLevel.god) && !string.IsNullOrEmpty(oldArticle.AdminPass) && !_token.Article_Has(oldArticle.Guid))
                        {
                            accessFlag = false;
                        }
                    }
                    if (accessFlag)
                    {
                        List<string> errors = new List<string>();
                        Article result = null;
                        try
                        {
                            if (article.Guid != Guid.Empty && !_token.Has(Helpers.AccessLevel.god))
                            {
                                article.AdminPass = string.Empty;
                            }
                            result = articleService.ArticleSave(article, ref errors);
                            if (errors.Count <= 0)
                            {
                                if (article.Guid != Guid.Empty)
                                {
                                    List<Guid> currentSectionGuids = article.ArticleSections.Where(o => o.Guid != Guid.Empty).Select(o => o.Guid).ToList();
                                    articleService.SectionInvertDelete(article.Guid, currentSectionGuids);
                                }
                                foreach (ArticleSection section in article.ArticleSections)
                                {
                                    section.ArticleGuid = result.Guid;
                                    ArticleSection sectionResult = articleService.SectionSave(section, ref errors);
                                    result.ArticleSections.Add(sectionResult);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            errors.Add("Exception Thrown: " + ex.Message);
                        }
                        var retdata = new
                        {
                            data = ArticleToJSON(articleService, errors.Count > 0 || result == null ? article : result),
                            errors = errors.ToArray()
                        };
                        retvalue = JsonConvert.SerializeObject(retdata);
                        Response.ContentType = "application/json";
                    }
                    else
                    {
                        //Use a special Status Code so that the client knows all that is needed is an article level password
                        retvalue = "409";
                        Response.StatusCode = 500;
                    }
                }
                else
                {
                    Response.StatusCode = 404;
                }
            }
            else
            {
                retvalue = "401";
                Response.StatusCode = 500;
            }
            return retvalue;
        }

        private object ArticleToJSON(ArticleService articleService, Article article)
        {
            var categories = articleService.CategoryList(true).Select(o => o.Name);
            var sections = article.ArticleSections.Select(o => new
            {
                guid = o.Guid,
                title = o.Name,
                sortOrder = o.SortOrder,
                content = o.Data
            });
            var data = new
            {
                guid = article.Guid != Guid.Empty ? article.Guid.ToString() : null,
                legacyId = article.LegacyID,
                title = article.Name,
                description = article.Description,
                contentUrl = article.ContentURL,
                category = article.Category,
                defaultSection = article.DefaultSection,
                adminPassEmpty = string.IsNullOrEmpty(article.AdminPass) ? "1" : "0",
                adminPassAllowed = _token.Has(Helpers.AccessLevel.god) ? "1" : "0",
                visible = article.VisibleFlag.ToString().ToLower(),
                hidebuttons = article.HideButtonsFlag.ToString().ToLower(),
                hidedropdown = article.HideDropDownFlag.ToString().ToLower(),
                created = article.CreatedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(article.CreatedUTC) : null,
                modified = article.ModifiedUTC.HasValue ? PEngine4.Core.Helpers.FormatDate(article.ModifiedUTC) : null,
                categories = categories,
                sections = sections
            };
            return data;
        }
    }
}
