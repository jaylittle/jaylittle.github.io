﻿/* This script will build the initial Presentation Engine Forum Database Structure */
/* Note: This script has been modified in order to work with SQL Server Compact Edition */

/****** Object:  Table [Forum]    Script Date: 6/15/2014 ******/
CREATE TABLE [Forum](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_Forum] PRIMARY KEY,
	[Name] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](2048) NOT NULL,
	[VisibleFlag] [bit] NOT NULL,
	[UniqueName] [nvarchar](512) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Forum_UniqueName] ON [Forum] 
(
	[UniqueName] ASC
)
GO

/****** Object:  Table [ForumUser]    Script Date: 6/15/2014 ******/
CREATE TABLE [ForumUser](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ForumUser] PRIMARY KEY,
	[UserID] [nvarchar](255) NOT NULL,
	[Password] [nvarchar](255) NOT NULL,
	[AdminFlag] [bit] NOT NULL,
	[BanFlag] [bit] NOT NULL,
	[Email] [nvarchar](255) NOT NULL,
	[Website] [nvarchar](255) NOT NULL,
	[Comment] [ntext] NOT NULL,
	[LastIPAddress] [nvarchar](100) NOT NULL,
	[LastLogon] [datetime] NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_ForumUser_UserID] ON [ForumUser] 
(
	[UserID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_ForumUser_LastIPAddress] ON [ForumUser] 
(
	[LastIPAddress] ASC
)
GO

/****** Object:  Table [ForumThread]    Script Date: 6/15/2014 ******/
CREATE TABLE [ForumThread](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ForumThread] PRIMARY KEY,
	[ForumGuid] [uniqueidentifier] NOT NULL CONSTRAINT [FK_ForumThread_Forum] REFERENCES [Forum] ([Guid]),
	[ForumUserGuid] [uniqueidentifier] NOT NULL CONSTRAINT [FK_ForumThread_ForumUser] REFERENCES [ForumUser] ([Guid]),
	[VisibleFlag] [bit] NOT NULL,
	[LockFlag] [bit] NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[UniqueName] [nvarchar](512) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ForumThread_ForumGuid] ON [ForumThread] 
(
	[ForumGuid] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_ForumThread_ForumUserGuid] ON [ForumThread] 
(
	[ForumUserGuid] ASC
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_ForumThread_UniqueName] ON [ForumThread] 
(
	[UniqueName] ASC
)
GO

/****** Object:  Table [ForumThreadPost]    Script Date: 6/15/2014 ******/
CREATE TABLE [ForumThreadPost](
	[Guid] [uniqueidentifier] NOT NULL CONSTRAINT [PK_ForumThreadPost] PRIMARY KEY,
	[ForumThreadGuid] [uniqueidentifier] NOT NULL  CONSTRAINT [FK_ForumThreadPost_ForumThread] REFERENCES [ForumThread] ([Guid]),
	[ForumUserGuid] [uniqueidentifier] NOT NULL CONSTRAINT [FK_ForumThreadPost_ForumUser] REFERENCES [ForumUser] ([Guid]),
	[VisibleFlag] [bit] NOT NULL,
	[LockFlag] [bit] NOT NULL,
	[Data] [ntext] NOT NULL,
	[IPAddress] [nvarchar](80) NOT NULL,
	[CreatedUTC] [datetime] NULL,
	[ModifiedUTC] [datetime] NULL
)
GO
CREATE NONCLUSTERED INDEX [IX_ForumThreadPost_ForumThreadGuid] ON [ForumThreadPost] 
(
	[ForumThreadGuid] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_ForumThreadPost_ForumUserGuid] ON [ForumThreadPost] 
(
	[ForumUserGuid] ASC
)
GO