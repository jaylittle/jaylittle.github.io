﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    forumstate: {
        current_forum_guid: null,
        
        current_thread_guid: null
    },

    forumthread: {
        editor_template_src: null,

        editor_template: null,

        editor_data: null,

        editor_data_guid: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        editor_launch: function (guid) {
            pengine.forumthread.editor_data_guid = guid;
            var ajaxProps = [{
                url: pengine.forumthread.editor_get_url + '/' + guid, cache: false, type: "GET", success: function (data) {
                    pengine.forumthread.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can edit this forum thread." }, false, function () { pengine.forumthread.editor_launch(pengine.forumthread.editor_data_guid); });
                    }
                }
            }];

            if (!pengine.forumthread.editor_template_src && !pengine.forumthread.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.forumthread.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.forumthread.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.forumthread.editor_template) {
                    pengine.forumthread.editor_template = pengine.template.compile(pengine.forumthread.editor_template_src);
                }
                var form = pengine.forumthread.editor_template(pengine.forumthread.editor_data);
                $("body").append($(form).attr("id", "pengine_forumthread_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                $("#pengine_forumthread_editor").slideDown('fast', function () { pengine.forumthread.editor_configure(); });
            });
        },

        editor_configure: function () {
            $("#forumthread_edit_button_save").on("click", function () {
                pengine.forumthread.editor_save();
                return false;
            });

            $("#forumthread_edit_button_close").on("click", function () {
                pengine.forumthread.editor_dispose();
                return false;
            });

            $("#forumthread_edit_button_delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.forumthread.editor_delete(pengine.forumthread.editor_data.guid);
                }
                return false;
            });

            $("#forumthread_edit_title").focus();

            pengine.focus.set_default_button("#pengine_forumthread_editor", null, true);
            pengine.window.resize();
        },

        editor_save: function () {
            var jsonObj = {
                Title: $("#forumthread_edit_title").val(),
                ForumGuid: pengine.forumstate.current_forum_guid && pengine.forumstate.current_forum_guid != '' ? pengine.forumstate.current_forum_guid : null,
                VisibleFlag: $("#forumthread_edit_visible").attr("checked") ? "true" : "false",
                LockedFlag: $("#forumthread_edit_locked").attr("checked") ? "true" : "false",
                ForumThreadPosts: [
                    {
                        Data: $("#forumthread_edit_data").val()
                    }
                ]
            };
            if ($("#forumthread_edit_guid").val() != '') {
                jsonObj["Guid"] = $("#forumthread_edit_guid").val();
            }
            if ($("#forumthread_edit_postguid").val() != '') {
                jsonObj["ForumThreadPosts"][0]["Guid"] = $("#forumthread_edit_postguid").val();
            }
            $.ajax({
                type: "POST",
                url: pengine.forumthread.editor_post_url,
                data: { json: JSON.stringify(jsonObj) },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can save changes to this forum thread." }, false, function () { pengine.forumthread.editor_save(); });
                    }
                }
            });
        },

        editor_delete: function (guid) {
            pengine.forumthread.editor_data_guid = guid;
            $.ajax({
                url: pengine.forumthread.editor_delete_url,
                type: "POST",
                data: {
                    id: guid
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can delete this forum thread." }, false, function () { pengine.forumthread.editor_delete(pengine.forumthread.editor_data_guid); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_forumthread_editor").slideUp('fast', function () {
                $("#pengine_forumthread_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    },

    forumthreadpost: {
        editor_template_src: null,

        editor_template: null,

        editor_data: null,

        editor_data_guid: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        editor_launch: function (guid) {
            pengine.forumthreadpost.editor_data_guid = guid;
            var ajaxProps = [{
                url: pengine.forumthreadpost.editor_get_url + '/' + guid, cache: false, type: "GET", success: function (data) {
                    pengine.forumthreadpost.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can edit this forum thread post." }, false, function () { pengine.forumthreadpost.editor_launch(pengine.forumthreadpost.editor_data_guid); });
                    }
                }
            }];

            if (!pengine.forumthreadpost.editor_template_src && !pengine.forumthreadpost.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.forumthreadpost.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.forumthreadpost.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.forumthreadpost.editor_template) {
                    pengine.forumthreadpost.editor_template = pengine.template.compile(pengine.forumthreadpost.editor_template_src);
                }
                var form = pengine.forumthreadpost.editor_template(pengine.forumthreadpost.editor_data);
                $("body").append($(form).attr("id", "pengine_forumthreadpost_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                $("#pengine_forumthreadpost_editor").slideDown('fast', function () { pengine.forumthreadpost.editor_configure(); });
            });
        },

        editor_configure: function () {
            $("#forumthreadpost_edit_button_save").on("click", function () {
                pengine.forumthreadpost.editor_save();
                return false;
            });

            $("#forumthreadpost_edit_button_close").on("click", function () {
                pengine.forumthreadpost.editor_dispose();
                return false;
            });

            $("#forumthreadpost_edit_button_delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.forumthreadpost.editor_delete(pengine.forumthreadpost.editor_data.guid);
                }
                return false;
            });

            $("#forumthreadpost_edit_title").focus();

            pengine.focus.set_default_button("#pengine_forumthreadpost_editor", null, true);
            pengine.window.resize();
        },

        editor_save: function () {
            var jsonObj = {
                ForumThreadGuid: pengine.forumstate.current_thread_guid && pengine.forumstate.current_thread_guid != '' ? pengine.forumstate.current_thread_guid : null,
                VisibleFlag: $("#forumthreadpost_edit_visible").attr("checked") ? "true" : "false",
                LockedFlag: $("#forumthreadpost_edit_locked").attr("checked") ? "true" : "false",
                Data: $("#forumthreadpost_edit_data").val()
            };
            if ($("#forumthreadpost_edit_guid").val() != '') {
                jsonObj["Guid"] = $("#forumthreadpost_edit_guid").val();
            }
            $.ajax({
                type: "POST",
                url: pengine.forumthreadpost.editor_post_url,
                data: { json: JSON.stringify(jsonObj) },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can save changes to this forum thread post." }, false, function () { pengine.forumthreadpost.editor_save(); });
                    }
                }
            });
        },

        editor_delete: function (guid) {
            pengine.forumthreadpost.editor_data_guid = guid;
            $.ajax({
                url: pengine.forumthreadpost.editor_delete_url,
                type: "POST",
                data: {
                    id: guid
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can delete this forum thread post." }, false, function () { pengine.forumthreadpost.editor_delete(pengine.forumthreadpost.editor_data_guid); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_forumthreadpost_editor").slideUp('fast', function () {
                $("#pengine_forumthreadpost_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    },

    forumuser: {
        editor_template_src: null,

        editor_template: null,

        editor_register_template_src: null,

        editor_register_template: null,

        editor_data: null,

        editor_data_guid: null,

        editor_template_url: null,

        editor_register_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        list_screen_link: null,

        editor_launch: function (guid, registermode) {
            pengine.forumuser.editor_data_guid = guid;
            var ajaxProps = [{
                url: pengine.forumuser.editor_get_url + '/' + guid, cache: false, type: "GET", success: function (data) {
                    pengine.forumuser.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can edit this forum user." }, false, function () { pengine.forumuser.editor_launch(pengine.forumuser.editor_data_guid); });
                    }
                }
            }];

            if (!registermode) {
                if (!pengine.forumuser.editor_template_src && !pengine.forumuser.editor_template) {
                    $.merge(ajaxProps, [{
                        url: pengine.forumuser.editor_template_url, cache: true, type: "GET", success: function (data) {
                            pengine.forumuser.editor_template_src = data; pengine.download.sync_increment();
                        }
                    }]);
                }
                pengine.download.sync(ajaxProps, function () {
                    if (!pengine.forumuser.editor_template) {
                        pengine.forumuser.editor_template = pengine.template.compile(pengine.forumuser.editor_template_src);
                    }
                    var form = pengine.forumuser.editor_template(pengine.forumuser.editor_data);
                    $("body").append($(form).attr("id", "pengine_forumuser_editor").css("display", "none"));
                    pengine.dialog.overlay_show();
                    window.scrollTo(0, 0);
                    $("#pengine_forumuser_editor").slideDown('fast', function () { pengine.forumuser.editor_configure(); });
                });
            }
            else
            {
                if (!pengine.forumuser.editor_register_template_src && !pengine.forumuser.editor_register_template) {
                    $.merge(ajaxProps, [{
                        url: pengine.forumuser.editor_register_template_url, cache: true, type: "GET", success: function (data) {
                            pengine.forumuser.editor_register_template_src = data; pengine.download.sync_increment();
                        }
                    }]);
                }
                pengine.download.sync(ajaxProps, function () {
                    if (!pengine.forumuser.editor_register_template) {
                        pengine.forumuser.editor_register_template = pengine.template.compile(pengine.forumuser.editor_register_template_src);
                    }
                    var form = pengine.forumuser.editor_register_template(pengine.forumuser.editor_data);
                    $("body").append($(form).attr("id", "pengine_forumuser_editor").css("display", "none"));
                    pengine.dialog.overlay_show();
                    window.scrollTo(0, 0);
                    $("#pengine_forumuser_editor").slideDown('fast', function () { pengine.forumuser.editor_configure(); });
                });
            }
        },

        editor_configure: function () {
            $("#forumuser_edit_button_save").on("click", function () {
                pengine.forumuser.editor_save();
                return false;
            });

            $("#forumuser_edit_button_close").on("click", function () {
                pengine.forumuser.editor_dispose();
                return false;
            });

            $("#forumuser_edit_button_delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.forumuser.editor_delete(pengine.forumuser.editor_data.guid);
                }
                return false;
            });

            $("#forumuser_edit_userid").focus();

            pengine.focus.set_default_button("#pengine_forumuser_editor", null, true);
            pengine.window.resize();
        },

        editor_save: function () {
            if ($("#forumuser_edit_password").val() != $("#forumuser_edit_password_confirm").val()) {
                pengine.notification.display(["The specified password has not been confirmed correctly!"]);
            }
            else {
                var jsonObj = {
                    UserID: $("#forumuser_edit_userid").val(),
                    Password: $("#forumuser_edit_password").val(),
                    Email: $("#forumuser_edit_email").val(),
                    Website: $("#forumuser_edit_website").val(),
                    Comment: $("#forumuser_edit_comment").val(),
                    AdminFlag: $("#forumuser_edit_admin").attr("checked") ? "true" : "false",
                    BanFlag: $("#forumuser_edit_ban").attr("checked") ? "true" : "false"
                };
                if ($("#forumuser_edit_guid").val() != '') {
                    jsonObj["Guid"] = $("#forumuser_edit_guid").val();
                }
                $.ajax({
                    type: "POST",
                    url: pengine.forumuser.editor_post_url,
                    data: { json: JSON.stringify(jsonObj) },
                    success: function (data) {
                        if (data.errors && data.errors.length > 0) {
                            pengine.notification.display(data.errors);
                        }
                        else {
                            location.reload(true);
                        }
                    },
                    error: function (data) {
                        if (data.responseText == "401") {
                            pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can save changes to this forum user." }, false, function () { pengine.forumuser.editor_save(); });
                        }
                    }
                });
            }
        },

        editor_delete: function (guid) {
            pengine.forumuser.editor_data_guid = guid;
            $.ajax({
                url: pengine.forumuser.editor_delete_url,
                type: "POST",
                data: {
                    id: guid
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "forum", loginMessage: "You must login before you can delete this forum user." }, false, function () { pengine.forumuser.editor_delete(pengine.forumuser.editor_data_guid); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_forumuser_editor").slideUp('fast', function () {
                $("#pengine_forumuser_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    }
});