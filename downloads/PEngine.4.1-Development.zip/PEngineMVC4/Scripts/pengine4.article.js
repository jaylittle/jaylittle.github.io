﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    article: {
        display_section_src: null,

        editor_template_src: null,

        editor_template: null,

        editor_data: null,

        editor_data_guid: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        editor_launch: function (guid) {
            pengine.article.editor_data_guid = guid;
            var ajaxProps = [{
                url: pengine.article.editor_get_url + '/' + guid, cache: false, type: "GET", success: function (data) {
                    pengine.article.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can edit this article." }, false, function () { pengine.article.editor_launch(pengine.article.editor_data_guid); });
                    }
                    else if (data.responseText == "409") {
                        pengine.login.login_launch({ loginType: "article", loginId: pengine.article.editor_data_guid, loginMessage: "You must provide the article password before you can edit this article." }, false, function () { pengine.article.editor_launch(pengine.article.editor_data_guid); });
                    }
                }
            }];

            if (!pengine.article.editor_template_src && !pengine.article.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.article.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.article.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.article.editor_template) {
                    pengine.article.editor_template = pengine.template.compile(pengine.article.editor_template_src);
                }
                var form = pengine.article.editor_template(pengine.article.editor_data);
                $("body").append($(form).attr("id", "pengine_article_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                pengine.article.editor_current_change();
                $("#pengine_article_editor").slideDown('fast', function () { pengine.article.editor_configure(); });
            });
        },

        editor_configure: function () {
            $("#article_edit_button_save").on("click", function () {
                pengine.article.editor_save();
                return false;
            });

            $("#article_edit_button_close").on("click", function () {
                pengine.article.editor_dispose();
                return false;
            });

            $("#article_edit_button_delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.article.editor_delete(pengine.article.editor_data.guid);
                }
                return false;
            });

            $("#article_edit_currentsection").on("change", function () {
                pengine.article.editor_current_change();
            });

            $("#section_edit_button_add").on("click", function () {
                pengine.article.editor_section_add();
                return false;
            });

            $("#section_edit_button_delete").on("click", function () {
                pengine.article.editor_section_delete();
                return false;
            });

            $("#article_edit_category").autocomplete({
                source: pengine.article.editor_data.categories,
                minLength: 0,
                position: { my: "right top", at: "right bottom" }
            });

            var tmp_apfunc = function () {
                if ($("#article_edit_adminpass_blank").attr("checked")) {
                    $("#article_edit_adminpass").val("");
                    $("#article_edit_adminpass").hide();
                }
                else {
                    $("#article_edit_adminpass").show();
                }
            };
            $("#article_edit_adminpass_blank").on("change", tmp_apfunc);
            tmp_apfunc();

            pengine.article.editor_configure_section("#article_edit_section_container");

            $("#article_edit_currentsection").focus();

            pengine.focus.set_default_button("#pengine_article_editor", null, true);
            pengine.window.resize();
        },

        editor_configure_section: function (container) {
            $(container).find(".section_edit_default").on("change", function () {
                if ($(this).attr("checked")) {
                    var sectionName = $(this).closest(".article_edit_section_data").attr("data-section-name");
                    $(".article_edit_section_data").each(function (idx, ele) {
                        if ($(ele).attr("data-section-name") != sectionName) {
                            $(ele).find(".section_edit_default").attr("checked", null);
                        }
                    });
                }
            });

            $(container).find(".section_edit_title").on("change", function () {
                var oldName = $(this).closest(".article_edit_section_data").attr("data-section-name");
                var newName = $(this).val();
                if (oldName != newName) {
                    if ($("#article_edit_currentsection option[value=\"" + newName + "\"]").length > 0) {
                        $(this).val(oldName);
                        pengine.notification.display_one("This Section Name already exists within this article!", "error", 1000, true);
                    }
                    else {
                        $("#article_edit_currentsection option[value=\"" + oldName + "\"]").attr("value", newName).text("[Section] " + newName);
                        $(this).closest(".article_edit_section_data").attr("data-section-name", newName);
                    }
                }
            });

            $(container).find(".section_edit_button_moveup, .section_edit_button_movedown").on("click", function () {
                var parent = $(this).closest(".article_edit_section_data");
                var name = $(parent).attr("data-section-name");
                var option = $("#article_edit_currentsection option[value=\"" + name + "\"]");
                var target = $(this).hasClass("section_edit_button_moveup") ? $(parent).prev() : $(parent).next();
                var targetoption = $(this).hasClass("section_edit_button_moveup") ? $(option).prev() : $(option).next();
                if (target != null && target.length > 0 && targetoption != null && targetoption.length > 0) {
                    if ($(this).hasClass("section_edit_button_moveup")) {
                        $(target).before($(parent));
                        $(targetoption).before($(option));
                    }
                    else {
                        $(target).after($(parent));
                        $(targetoption).after($(option));
                    }
                }
                return false;
            });
            pengine.focus.set_default_button(container, null, true);
        },

        editor_current_change: function() {
            if ($("#article_edit_currentsection").val() == '') {
                $("#section_edit_button_delete").hide();
                $(".article_edit_section_data").css("display", "none");
                $(".article_edit_article_data").css("display", "block");
            }
            else {
                $(".article_edit_section_data").css("display", "none");
                $(".article_edit_article_data").css("display", "none");
                $(".article_edit_section_data[data-section-name=\"" + $("#article_edit_currentsection").val() + "\"]").css("display", "block");
                $("#section_edit_button_delete").show();
            }
        },

        editor_section_add: function () {
            var tmpCtr = 1;
            var tmpName = "New Section " + tmpCtr;
            while ($("#article_edit_currentsection option[value=\"" + tmpName + "\"]").length > 0) {
                tmpCtr++;
                tmpName = "New Section " + tmpCtr
            }
            $("#article_edit_section_container").append($("#article_edit_section_new").clone().attr("id", null).css("display", "none").attr("data-section-name", tmpName));
            pengine.article.editor_configure_section($("#article_edit_section_container .article_edit_section_data").last());
            $("#article_edit_section_container .article_edit_section_data").last().find(".section_edit_title").val(tmpName);
            $("#article_edit_currentsection").append($("<option></option>").attr("value", tmpName).text("[Section] " + tmpName));
            $("#article_edit_currentsection").val(tmpName);
            pengine.article.editor_current_change();
        },

        editor_section_delete: function() {
            if ($("#article_edit_currentsection").val() != '') {
                $(".article_edit_section_data[data-section-name=\"" + $("#article_edit_currentsection").val() + "\"]").remove();
                $("#article_edit_currentsection option[value=\"" + $("#article_edit_currentsection").val() + "\"]").remove();
                $("#article_edit_currentsection").val('');
                pengine.article.editor_current_change();
            }
        },

        editor_save: function () {
            var jsonObj = {
                Name: $("#article_edit_title").val(),
                Category: $("#article_edit_category").val(),
                Description: $("#article_edit_description").val(),
                ContentURL: $("#article_edit_contenturl").val(),
                VisibleFlag: $("#article_edit_visible").attr("checked") ? "true" : "false",
                HideButtonsFlag: $("#article_edit_hidebuttons").attr("checked") ? "true" : "false",
                HideDropDownFlag: $("#article_edit_hidedropdown").attr("checked") ? "true" : "false",
                DefaultSection: $(".section_edit_default[checked]").length > 0 ?
                    $(".section_edit_default[checked]").closest(".article_edit_section_data").attr("data-section-name") : '',
                Data: $("#article_edit_data").val(),
                AdminPass: $("#article_edit_adminpass_blank").length > 0 ? (!$("#article_edit_adminpass_blank").attr("checked") ? $("#article_edit_adminpass").val() : '[none]') : null,
                ArticleSections: [ ]
            };
            if ($("#article_edit_guid").val() != '') {
                jsonObj["Guid"] = $("#article_edit_guid").val();
            }
            $(".article_edit_section_data").each(function (idx, ele) {
                if ($(ele).attr("data-section-name")) {
                    var secData = {
                        Name: $(ele).find(".section_edit_title").val(),
                        SortOrder: (idx + 1),
                        Data: $(ele).find(".section_edit_data").val()
                    };
                    if ($(ele).find(".section_edit_guid").val() != '') {
                        secData["Guid"] = $(ele).find(".section_edit_guid").val();
                    }
                    if ($(ele).find(".section_edit_default").attr("checked")) {
                        jsonObj["DefaultSection"] = $(ele).find(".section_edit_title").val();
                    }
                    $.merge(jsonObj["ArticleSections"], [secData]);
                }
            });
            $.ajax({
                type: "POST",
                url: pengine.article.editor_post_url,
                data: { json: JSON.stringify(jsonObj) },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can save changes to this article." }, false, function () { pengine.article.editor_save(); });
                    }
                    else if (data.responseText == "409") {
                        pengine.login.login_launch({ loginType: "article", loginId: pengine.article.editor_data_guid, loginMessage: "You must provide the article password before you can save changes to this article." }, false, function () { pengine.article.editor_save(); });
                    }
                }
            });
        },

        editor_delete: function (guid) {
            pengine.article.editor_data_guid = guid;
            $.ajax({
                url: pengine.article.editor_delete_url,
                type: "POST",
                data: {
                    id: guid
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can delete this article." }, false, function () { pengine.article.editor_delete(pengine.article.editor_data_guid); });
                    }
                    else if (data.responseText == "409") {
                        pengine.login.login_launch({ loginType: "article", loginId: guid, loginMessage: "You must provide the article password before you can delete this article." }, false, function () { pengine.article.editor_delete(pengine.article.editor_data_guid); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_article_editor").slideUp('fast', function () {
                $("#pengine_article_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    }
});