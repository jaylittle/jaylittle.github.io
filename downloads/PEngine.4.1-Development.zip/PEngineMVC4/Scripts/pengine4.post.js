﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    post: {
        editor_template_src: null,

        editor_template: null,

        editor_data: null,

        editor_data_guid: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_post_url: null,

        editor_launch: function (guid) {
            pengine.post.editor_data_guid = guid;
            var ajaxProps = [{
                url: pengine.post.editor_get_url + '/' + guid, cache: false, type: "GET", success: function (data) {
                    pengine.post.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can edit this post." }, false, function () { pengine.post.editor_launch(pengine.post.editor_data_guid); });
                    }
                }
            }];

            if (!pengine.post.editor_template_src && !pengine.post.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.post.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.post.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.post.editor_template) {
                    pengine.post.editor_template = pengine.template.compile(pengine.post.editor_template_src);
                }
                var form = pengine.post.editor_template(pengine.post.editor_data);
                $("body").append($(form).attr("id", "pengine_post_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                $("#pengine_post_editor").slideDown('fast', function () { pengine.post.editor_configure(); });
            });
        },

        editor_configure: function () {
            $("#post_edit_button_save").on("click", function () {
                pengine.post.editor_save();
                return false;
            });

            $("#post_edit_button_close").on("click", function () {
                pengine.post.editor_dispose();
                return false;
            });

            $("#post_edit_button_delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.post.editor_delete(pengine.post.editor_data.guid);
                }
                return false;
            });

            $("#post_edit_title").focus();

            pengine.focus.set_default_button("#pengine_post_editor", null, true);
            pengine.window.resize();
        },

        editor_save: function() {
            $.ajax({
                type: "POST",
                url: pengine.post.editor_post_url,
                data: {
                    Guid: $("#post_edit_guid").val(),
                    Title: $("#post_edit_title").val(),
                    VisibleFlag: $("#post_edit_visible").attr("checked") ? "true" : "false",
                    IconFileName: $("#post_edit_iconfilename").val(),
                    Data: $("#post_edit_data").val()
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can save changes to this post." }, false, function () { pengine.post.editor_save(); });
                    }
                }
            });
        },

        editor_delete: function (guid) {
            pengine.post.editor_data_guid = guid;
            $.ajax({
                url: pengine.post.editor_delete_url,
                type: "POST",
                data: {
                    id: guid
                },
                success: function (data) {
                    if (data.errors && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can delete this post." }, false, function () { pengine.post.editor_delete(pengine.post.editor_data_guid); });
                    }
                }
            });
        },

        editor_dispose: function () {
            $("#pengine_post_editor").slideUp('fast', function () {
                $("#pengine_post_editor").remove();
            });
            pengine.dialog.overlay_hide();
        }
    }
});