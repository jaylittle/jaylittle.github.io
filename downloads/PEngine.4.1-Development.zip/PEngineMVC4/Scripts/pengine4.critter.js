﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    critter: {
        state: {
            created: false,

            hidden: true,

            speaking: false,

            redrawing: false,
        },

        current_config: null,

        shortcut_enable: false,

        shortcut_keycode: 190,

        shortcut_keycount: 3,

        quote_mode: false,

        random_chance: 0,

        resource_path: './',

        configs: {
            default: {
                width: 112,
                height: 150,
                bubble: 'images/critter_bubble.gif',
                frames: ['images/clippy_default.gif', 'images/clippy_left.gif', 'images/clippy_right.gif', 'images/clippy_wide.gif' ],
                adjustTop: 15,
                adjustLeft: 20,
                speechTop: 0,
                speechLeft: 50,
                minSpeakSecs: 15,
                maxSpeakSecs: 60,
                minMoveSecs: 0,
                maxMoveSecs: 3
            }
        },

        library: [
            'Whats up, doc?',
            'Yes I used to work for another app but they fired me because Apple spread a rumor that paper clips were \'uncool\'.',
            'Did I infer that this application was popular before?  I really meant that it is \'well known to one person in particular\'.',
            'After looking at you I get the sense that an ID-10-T error is about to be logged.',
            'My creator loves Linux.  Well I don\'t.  So screw you and the penguin you might\'ve rode in on!',
            'Did you know that I can be disabled?  I guess the guy running this website doesn\'t like you very much.',
            'Whew! For a second I thought I woke up on the wrong side of ugly until I realized that this isn\'t a mirror.',
            'If you aren\'t picking up on the sarcasm here, it\'s because you are clearly sarcasm challenged.',
            'It looks like you are trying to waste time at work by reading a website. Would you like some help?',
            'My creator hath dubbed me, \'The Alan Parsons Project\'.',
            'It clicks the button on the CLIPPY or it GETS THE HOSE!',
            'Since my arrival, PEngine has been reclassified as bloatware.  Coincidence?',
            'Stop reading the drivel here - it will do nothing for you!',
            'If this site was powered by Sharepoint - it\'s requirements would double, it\'s functionality would be halved and the wait times would quaddruple!',
            'For what it\'s worth, I will pop up at random and inopportune times to annoy you!',
            'Don\'t hate the Clippy, hate the game.'
        ],

        client: {
            viewportWidth: function () {
                return self.innerWidth || (document.documentElement.clientWidth || document.body.clientWidth);
            },

            viewportHeight: function () {
                return self.innerHeight || (document.documentElement.clientHeight || document.body.clientHeight);
            },

            viewportSize: function () {
                return { width: this.viewportWidth(), height: this.viewportHeight() };
            }
        },

        create: function (config, showFlag) {
            if (!pengine.critter.state.created) {
                if (!config) {
                    config = pengine.critter.current_config || pengine.critter.configs.default;
                }
                jQuery.extend(config, pengine.critter.configs.default)
                pengine.critter.current_config = config;

                //Add Chat Bubble to DOM
                var bubblePath = pengine.critter.resource_path + pengine.critter.current_config.bubble;
                $("body").append($("<div></div>")
                    .css("position", "absolute").css("visibility", "hidden").css("width", "275px").css("z-index", 1000)
                    .attr("id", "critterBubble")
                    .append(
                        $("<div></div>").css("background-image", "url(" + bubblePath + ")")
                            .css("background-repeat", "no-repeat").css("background-position", "top")
                            .css("padding-top", "40px").css("padding-right", "8px").css("padding-left", "0px")
                            .css("text-align", "center")
                            .append(
                                $("<div></div>").css("padding-left", "10px").css("padding-right", "10px")
                                .attr("id", "critterBubbleText")
                            )
                    )
                    .append(
                        $("<div></div>").css("background-image", "url(" + bubblePath + ")")
                            .css("background-repeat", "no-repeat").css("background-position", "bottom")
                            .css("padding-top", "40px").css("padding-right", "8px").css("padding-left", "0px")
                            .css("text-align", "center")
                            .html("&nbsp;")
                    )
                );

                //Add Critter to DOM
                $("body").append($("<div></div>")
                    .css("position", "absolute")
                    .css("visibility", "hidden")
                    .css("z-index", 1000)
                    .attr("id", "critterDisplay")
                );

                //Add Animation Images to DOM
                for (var fptr = 0; fptr < pengine.critter.current_config.frames.length; fptr++) {
                    $("#critterDisplay").append(
                        $("<img />").css("display", "none")
                            .css("width", pengine.critter.current_config.width)
                            .css("height", pengine.critter.current_config.height)
                            .attr("src", pengine.critter.resource_path + pengine.critter.current_config.frames[fptr])
                    );
                }


                //Bind Events
                $("#critterBubble").live("click", function () { pengine.critter.hush(false); });
                $("#critterDisplay").live("click", function () { pengine.critter.hide(); });
                $(window).on("resize scroll", pengine.critter.size);

                //Resize
                pengine.critter.size();

                pengine.critter.state.created = true;

                if (showFlag) {
                    pengine.critter.show();
                }
            }
            else {
                if (pengine.critter.state.hidden) {
                    pengine.critter.show();
                }
            }
        },

        size: function() {
            var pageY = window.pageYOffset || document.documentElement.scrollTop;
            var pageX = window.pageXOffset || document.documentElement.scrollLeft;
            var agent = pengine.critter.current_config;
            $("#critterDisplay").css("left", pengine.critter.client.viewportWidth() + pageX - agent.width - agent.adjustLeft + 'px');
            $("#critterDisplay").css("top", pengine.critter.client.viewportHeight() + pageY - agent.height - agent.adjustTop + 'px');
            $("#critterBubble").css("left", $("#critterDisplay")[0].offsetLeft - $("#critterBubble")[0].offsetWidth + agent.speechLeft + 'px');
            $("#critterBubble").css("top", $("#critterDisplay")[0].offsetTop - $("#critterBubble")[0].offsetHeight + agent.speechTop + 'px');
        },

        show: function() {
            if (!pengine.critter.state.created) {
                pengine.critter.create(null, true);
            }
            pengine.critter.state.hidden = false;
            $("#critterDisplay").css("visibility", "visible");
            $("#critterDisplay img").hide();
            $("#critterDisplay").first().show();
            pengine.critter.move();
            pengine.critter.speak();
        },

        hide: function () {
            if (!pengine.critter.state.created) {
                pengine.critter.create(null, true);
            }
            pengine.critter.hush(false);
            pengine.critter.state.hidden = true;
            $("#critterDisplay").css("visibility", "hidden");
        },

        speak: function (text) {
            var cancel = false;
            if (!pengine.critter.state.created) {
                pengine.critter.create(null, true);
            }
            if (!pengine.critter.state.hidden) {
                pengine.critter.state.speaking = true;
                if (!text) {
                    if (!pengine.critter.quote_mode) {
                        var lcount = pengine.critter.library.length;
                        text = pengine.critter.library[Math.floor(Math.random() * lcount)];
                    }
                    else {
                        cancel = true;
                        pengine.quote.quote_get_data(pengine.critter.speak);
                    }
                }
                if (!cancel) {
                    $("#critterBubbleText").css("color", "black").html(text);
                    pengine.critter.size();
                    $("#critterBubble").css("visibility", "visible");
                    setTimeout("pengine.critter.hush(true);", text.length * 200);
                }
            }
        },

        hush: function (reloadFlag) {
            if (!pengine.critter.state.created) {
                pengine.critter.create(null, true);
            }
            if (!pengine.critter.state.hidden) {
                $("#critterBubble").css("visibility", "hidden");
                if (reloadFlag) {
                    var minms = pengine.critter.current_config.minSpeakSecs;
                    var maxms = pengine.critter.current_config.maxSpeakSecs;
                    var rndms = Math.floor(Math.random() * (maxms - minms) * 1000) + (minms * 1000);
                    setTimeout("pengine.critter.speak();", rndms);
                }
            }
            pengine.critter.state.speaking = false;
        },

        move: function () {
            if (!pengine.critter.state.created) {
                pengine.critter.create(null, true);
            }
            if (!pengine.critter.state.hidden) {
                pengine.critter.state.redrawing = true;
                var minms = pengine.critter.current_config.minMoveSecs;
                var maxms = pengine.critter.current_config.maxMoveSecs;
                var fcount = pengine.critter.current_config.frames.length;
                var rndms = Math.floor(Math.random() * (maxms - minms) * 1000) + (minms * 1000);
                var rndmove = Math.floor(Math.random() * fcount);
                $("#critterDisplay img").hide();
                $($("#critterDisplay").children()[rndmove]).show();
                setTimeout("pengine.critter.move();", rndms);
            }
            pengine.critter.state.redrawing = false;
        },

        click: function () {
            pengine.critter.hide();
        },

        setup: function (buttonSelector) {
            pengine.critter.random();
            pengine.critter.shortcut();
            if (buttonSelector) {
                $(buttonSelector).on("click", function () { pengine.critter.create(null, true) });
            }
        },

        random: function () {
            var rndChance = Math.random();
            if (pengine.critter.random_chance > 0 && rndChance <= pengine.critter.random_chance) {
                pengine.critter.create(null, true);
            }
        },

        shortcut_ctr: 0,

        shortcut: function () {
            if (pengine.critter.shortcut_enable) {
                $("body").on("keydown", function (event) {
                    var keyCode = event.which || event.keyCode;
                    if (keyCode == pengine.critter.shortcut_keycode) {
                        pengine.critter.shortcut_ctr++;
                        if (pengine.critter.shortcut_ctr >= pengine.critter.shortcut_keycount) {
                            pengine.critter.shortcut_ctr = 0;
                            pengine.critter.create(null, true);
                        }
                    }
                });
            }
        }
    }
});