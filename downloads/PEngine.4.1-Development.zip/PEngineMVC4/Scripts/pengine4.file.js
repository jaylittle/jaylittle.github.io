﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    file: {
        editor_data: null,

        editor_template_src: null,

        editor_template: null,

        editor_template_url: null,

        editor_get_url: null,

        editor_delete_url: null,

        editor_upload_url: null,

        editor_copy_url: null,

        editor_first_time: false,

        editor_path_base: '',

        editor_path: '',

        editor_path_base_new: '',

        editor_path_new: '',

        editor_moveflag_new: false,

        editor_select_path_base: '',

        editor_select_path: '',

        editor_app_path: '/',

        editor_launch: function () {
            var ajaxProps = [{
                url: pengine.file.editor_get_url, cache: false, type: "GET", success: function (data) {
                    pengine.file.editor_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can manage the files." }, false, function () { pengine.file.editor_launch(); });
                    }
                }
            }];

            if (!pengine.file.editor_template_src && !pengine.file.editor_template) {
                $.merge(ajaxProps, [{
                    url: pengine.file.editor_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.file.editor_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }

            pengine.download.sync(ajaxProps, function () {
                if (!pengine.file.editor_template) {
                    pengine.file.editor_template = pengine.template.compile(pengine.file.editor_template_src);
                }
                pengine.file.editor_populate();
            });
        },

        editor_populate: function () {
            var form = pengine.file.editor_template(pengine.file.editor_data);
            if (!pengine.file.editor_first_time) {
                pengine.file.editor_first_time = true;
                $("body").append($(form).attr("id", "pengine_file_editor").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                $("#pengine_file_editor").slideDown('fast', function () { pengine.file.editor_configure(); });
            }
            else {
                $("#pengine_file_editor").remove();
                $("body").append($(form).attr("id", "pengine_file_editor"));
                pengine.file.editor_configure();
            }
            $("#file-edit-location").empty();
            var pathdiv = $("<span></span>");
            $(pathdiv).append($("<a href=\"#\">[Root]</a>").attr("data-path-base", "").attr("data-path", ""));
            if (pengine.file.editor_path_base != '') {
                $(pathdiv).append($("<span>&nbsp;:&nbsp;</span>"));
                $(pathdiv).append($("<a href=\"#\"></a>").text(pengine.file.editor_path_base).attr("data-path-base", pengine.file.editor_path_base).attr("data-path", ""));
                var pathParts = pengine.file.editor_path.split("/");
                var pathFull = "";
                for (var pptr = 0; pptr < pathParts.length; pptr++) {
                    if (pathParts[pptr].length > 0) {
                        if (pathFull.length > 0) {
                            pathFull += "/";
                        }
                        pathFull += pathParts[pptr];
                        $(pathdiv).append($("<span>&nbsp;:&nbsp;</span>"));
                        $(pathdiv).append($("<a href=\"#\"></a>").text(pathParts[pptr]).attr("data-path-base", pengine.file.editor_path_base).attr("data-path", pathFull));
                    }
                }
                $("#pengine_file_editor .list-table tbody tr").on("dblclick", function () {
                    $(this).toggleClass("selected");
                    return false;
                });
                $("#file-edit-form-upload").css("display", "inline");
                $("#file-edit-button-delete").css("display", "inline");
                $("#file-edit-button-remember").css("display", "inline");
                $("#file-edit-button-move").css("display", "inline");
                $("#file-edit-button-copy").css("display", "inline");
            }
            else {
                $("#pengine_file_editor .list-table tbody tr").off("dblclick");
                $("#file-edit-form-upload").css("display", "none");
                $("#file-edit-button-delete").css("display", "none");
                $("#file-edit-button-remember").css("display", "none");
                $("#file-edit-button-move").css("display", "none");
                $("#file-edit-button-copy").css("display", "none");
            }
            $("#file-edit-location").append(pathdiv);
            $("#file-edit-location a").on("click", function () {
                pengine.file.editor_change_path($(this).attr("data-path-base"), $(this).attr("data-path"));
            });
        },

        editor_configure: function () {
            $("#pengine_file_editor").find(".list-table tbody tr:odd").addClass("alt");
            $("#pengine_file_editor").find(".list-table tbody tr").hover(function () { $(this).addClass("hover"); }, function () { $(this).removeClass("hover"); });
            $("#file-edit-form-upload").attr("action", pengine.file.editor_upload_url);
            $("#file-edit-button-upload").on("click", function () {
                pengine.file.editor_upload();
                return false;
            });

            $("#file-edit-button-delete").on("click", function () {
                if (pengine.delay.confirm(this)) {
                    pengine.file.editor_delete();
                }
                return false;
            });

            $("#file-edit-button-remember").on("click", function () {
                pengine.file.editor_remember();
                return false;
            });

            $("#file-edit-button-move").on("click", function () {
                pengine.file.editor_copy(true);
                return false;
            });

            $("#file-edit-button-copy").on("click", function () {
                pengine.file.editor_copy(false);
                return false;
            });

            $("#file-edit-button-close").on("click", function () {
                pengine.file.editor_dispose();
                return false;
            });

            $("#pengine_file_editor").find(".file-edit-button-view").on("click", function () {
                var row = $(this).closest("tr");
                pengine.file.editor_view($(row).attr("data-filename"), $(row).attr("data-type"));
            });

            pengine.focus.set_default_button("#pengine_file_editor", null, true);
            pengine.window.resize();
        },

        editor_view: function(name, type) {
            if (type == "file")
            {
                var fullPath = pengine.file.editor_app_path + pengine.file.editor_path_base + '/' + pengine.file.editor_path + '/' + name;
                window.open(fullPath, "_blank");
            }
            else
            {
                if (pengine.file.editor_path_base != '') {
                    if (pengine.file.editor_path.length > 0)
                    {
                        pengine.file.editor_change_path(pengine.file.editor_path_base, pengine.file.editor_path + "/" + name);
                    }
                    else
                    {
                        pengine.file.editor_change_path(pengine.file.editor_path_base, name);
                    }
                }
                else {
                    pengine.file.editor_change_path(name, "");
                }
            }
        },

        editor_change_path: function (pathBase, path) {
            pengine.file.editor_path_base_new = pathBase;
            pengine.file.editor_path_new = path;
            $.ajax({
                url: pengine.file.editor_get_url,
                data: {
                    pathBase: pengine.file.editor_path_base_new,
                    path: pengine.file.editor_path_new,
                },
                cache: false,
                type: "GET",
                success: function (data) {
                    pengine.file.editor_path_base = pengine.file.editor_path_base_new;
                    pengine.file.editor_path = pengine.file.editor_path_new;
                    pengine.file.editor_data = data;
                    pengine.file.editor_populate();
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can manage files in this directory." }, false, function () { pengine.file.editor_change_path(pengine.file.editor_path_base_new, pengine.file.editor_path_new); });
                    }
                }
            });
        },

        editor_remember: function () {
            $("#pengine_file_editor").find(".list-table tbody tr.selected").each(function (idx, ele) {
                if (pengine.file.editor_select_path_base.length > 0) {
                    pengine.file.editor_select_path_base += "|";
                    pengine.file.editor_select_path += "|";
                }
                pengine.file.editor_select_path_base += pengine.file.editor_path_base;
                pengine.file.editor_select_path += pengine.file.editor_path + "/" + $(ele).attr("data-filename");
                $(ele).removeClass("selected");
            });
        },

        editor_upload: function () {
            $("#file-edit-pathbase").val(pengine.file.editor_path_base);
            $("#file-edit-path").val(pengine.file.editor_path);
            $("#file-edit-button-upload").closest("form").submit();
        },

        editor_upload_complete: function(data) {
            //called by child iframe
            if (data != "401") {
                pengine.file.editor_data = eval("(" + data + ")");
                if (pengine.file.editor_data.errors && pengine.file.editor_data.errors.length > 0) {
                    pengine.notification.display(pengine.file.editor_data.errors);
                }
                else {
                    pengine.notification.display_one("Your file has been uploaded sucessfully!", "success", 2000, true);
                    pengine.file.editor_populate();
                }
            }
            else {
                pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can upload files to this directory." }, false, function () { pengine.file.editor_upload(); });
            }
        },

        editor_copy: function (moveflag) {
            pengine.file.editor_moveflag_new = moveflag;
            pengine.file.editor_remember();
            if (pengine.file.editor_select_path_base.length > 0) {
                $.ajax({
                    type: "post",
                    url: pengine.file.editor_copy_url,
                    data: {
                        fromPathBases: pengine.file.editor_select_path_base,
                        fromPaths: pengine.file.editor_select_path,
                        toPathBase: pengine.file.editor_path_base,
                        toPath: pengine.file.editor_path,
                        moveFlag: moveflag ? "1" : "0"
                    },
                    success: function (data) {
                        if (data.errors && data.errors.length > 0) {
                            pengine.notification.display(data.errors);
                        }
                        else {
                            pengine.file.editor_select_path = [];
                            pengine.file.editor_select_path_base = [];
                            pengine.file.editor_data = data;
                            pengine.file.editor_populate();
                        }
                        if (data.notices && data.notices.length > 0) {
                            pengine.notification.display(data.notices, "alert");
                        }
                        else {
                            if (!data.errors || data.errors.length <= 0) {
                                pengine.notification.display_one("Your file(s) have been copied/moved sucessfully!", "success", 2000, true);
                            }
                        }
                    },
                    error: function (data) {
                        if (data.responseText == "401") {
                            pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can copy/move any file(s)." }, false, function () { pengine.file.editor_copy(pengine.file.editor_moveflag_new); });
                        }
                    }
                });
            } else {
                pengine.notification.display_one("You must select at least one file before intiating a copy/move operation!", "error", 2000, true);
            }
        },

        editor_delete: function () {
            pengine.file.editor_remember();
            if (pengine.file.editor_select_path_base.length > 0) {
                $.ajax({
                    type: "POST",
                    url: pengine.file.editor_delete_url,
                    data: {
                        pathBases: pengine.file.editor_select_path_base,
                        paths: pengine.file.editor_select_path
                    },
                    success: function (data) {
                        if (data.errors && data.errors.length > 0) {
                            pengine.notification.display(data.errors);
                        }
                        else {
                            pengine.file.editor_select_path = [];
                            pengine.file.editor_select_path_base = [];
                            pengine.file.editor_data = data;
                            pengine.file.editor_populate();
                            pengine.notification.display_one("Your file(s) have been deleted sucessfully!", "success", 2000, true);
                        }
                    },
                    error: function (data) {
                        if (data.responseText == "401") {
                            pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can delete any file(s)." }, false, function () { pengine.file.editor_delete(); });
                        }
                    }
                });
            } else {
                pengine.notification.display_one("You must select at least one file before intiating a delete operation!", "error", 2000, true);
            }
        },

        editor_dispose: function () {
            $("#pengine_file_editor").slideUp('fast', function () {
                $("#pengine_file_editor").remove();
            });
            pengine.dialog.overlay_hide();
            pengine.file.editor_path_base = '';
            pengine.file.editor_path = '';
            pengine.file.editor_select_path_base = '';
            pengine.file.editor_select_path = '';
            pengine.file.editor_data = null;
            pengine.file.editor_first_time = false;
        }
    }
});