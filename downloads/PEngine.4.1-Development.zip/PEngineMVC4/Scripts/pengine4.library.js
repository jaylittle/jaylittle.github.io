﻿var pengine = pengine || {};

jQuery.extend(pengine,
{
    notification: {
        display: function (notifications, type) {
            $(notifications).each(function (idx, ele) {
                pengine.notification.display_one(ele.message ? ele.message : ele, ele.type ? ele.type : type ? type : "error");
            });
        },

        display_one: function (message, type, timeout, dismiss) {
            var msg = noty({
                dismissQueue: dismiss ? dismiss : false,
                text: message,
                type: type ? type : "alert",
                timeout: timeout ? timeout : null,
                animation: { open: { height: 'toggle' }, close: { height: 'toggle' }, easing: 'swing', speed: 100 }
            });
        },

        process_page: function () {
            var notifications = [];

            $(".notify_messages li").each(function (idx, ele) {
                $.merge(notifications, [{ message: $(ele).text(), type: $(ele).attr("data-messagetype") }]);
            }).remove();

            pengine.notification.display(notifications);
        }
    },

    time: {
        to_local: function (local) {
            var tzoffset = (new Date()).getTimezoneOffset();
            var olddate = Date.parse(local);
            var newdate = new Date(olddate - (tzoffset * 60000));
            return $.datepicker.formatDate("m/d/yy", newdate) + " " + pengine.time.format(newdate);
        },
        
        format: function(dt) {
            var ap = "AM";
            var dhour = dt.getHours();
            var dmin = dt.getMinutes();
            if (dhour <= 0) {
                dhour = 12;
            }
            if (dhour > 12) {
                dhour = dhour - 12;
                ap = "PM";
            }
            var shour = dhour.toString();
            var smin = dmin.toString();
            if (smin.length == 1) {
                smin = "0" + smin;
            }
            return shour + ":" + smin + " " + ap;
        }
    },

    template: {
        init_flag: false,

        init: function() {
            Handlebars.registerHelper('ifEqual', function (a, b, options) {
                if (a == b) { return options.fn(this); } else { return options.inverse(this); }
            });
            Handlebars.registerHelper('ifNotEqual', function (a, b, options) {
                if (a != b) { return options.fn(this); } else { return options.inverse(this); }
            });
            Handlebars.registerHelper('ifEmpty', function (a, options) {
                if (a == null || a == '' || !a) { return options.fn(this); } else { return options.inverse(this); }
            });
            Handlebars.registerHelper('ifNotEmpty', function (a, options) {
                if (a != null && a != '' && a) { return options.fn(this); } else { return options.inverse(this); }
            });
            Handlebars.registerHelper('eitherOr', function (a, b, options) {
                return (a) ? a : b;
            });
        },

        compile: function (template) {
            if (!pengine.template.init_flag) {
                pengine.template.init();
            }
            return Handlebars.compile(template);
        }
    },

    download: {
        sync_total: 0,

        sync_current: 0,

        sync_post: null,

        sync: function (ajaxProps, post) {
            pengine.download.sync_total = ajaxProps.length;
            pengine.download.sync_current = 0;
            pengine.download.sync_post = post;
            if (pengine.download.sync_total > 0) {
                for (var actr = 0; actr < ajaxProps.length; actr++) {
                    $.extend(ajaxProps[actr], {
                        async: true
                    });
                    $.ajax(ajaxProps[actr]);
                }
            }
            else {
                pengine.download.sync_post();
            }
        },

        sync_increment: function () {
            pengine.download.sync_current++;
            if (pengine.download.sync_current >= pengine.download.sync_total) {
                if (pengine.download.sync_post) {
                    pengine.download.sync_post();
                    pengine.download.sync_total = 0;
                    pengine.download.sync_current = 0;
                    pengine.download.sync_post = null;
                }
            }
        }
    },

    delay: {
        confirm: function (target) {
            var cmsg = $(target).attr("data-confirm-message") ? $(target).attr("data-confirm-message") : "Are you sure you wish to do this?";
            return confirm(cmsg);
        }
    },

    quote: {
        quote_get_url: null,

        quote_get: function () {
            pengine.quote.quote_get_data(pengine.quote.quote_display);
        },

        quote_get_data: function (postfunc) {
            $.ajax({
                url: pengine.quote.quote_get_url,
                type: "GET",
                data: null,
                success: function (data) { postfunc(data.quote); },
                error: function (data) {
                    if (data.status == 404) {
                        pengine.notification.display_one('There are no quotes loaded in the system at this time!', 'error', 2500, true);
                    }
                },
                cache: false
            });
        },

        quote_display: function (data) {
            if (data) {
                pengine.notification.display_one(data, "alert", 0, false);
            } else {
                pengine.notification.display([{ message: "No quotes were found!", type: "error" }]);
            }
        }
    },

    search: {
        search_redirect_url: null,

        search_redirect: function (query) {
            window.location = pengine.search.search_redirect_url + '?query=' + query;
        }
    },

    dialog: {
        overlay_show: function () {
            if ($("#modal-overlay").length <= 0) {
                $("body").css("overflow", "hidden");
                $("body").append($("<div></div>")
                    .attr("id", "modal-overlay")
                    .css("opacity", 0.75)
                    .css("top", "0px")
                    .css("left", "0px")
                    .css("position", "absolute")
                    .css("z-index", 999)
                    .css("background-color", "black")
                    .width($(document).width())
                    .height($(document).height())
                );
            }
        },

        overlay_hide: function () {
            if ($("#modal-overlay").length > 0) {
                $("#modal-overlay").remove();
                $("body").css("overflow", "visible");
            }
            pengine.window.resize();
        }
    },

    login: {

        login_template_url: null,

        login_post_url: null,

        logout_post_url: null,

        login_template_src: null,

        login_template: null,

        login_data: null,

        login_reload: false,

        login_post: null,

        login_launch: function (loginData, reload, post) {
            pengine.login.login_reload = reload;
            pengine.login.login_post = post;
            pengine.login.login_data = loginData;
            var ajaxProps = [];
            if (!pengine.login.login_template_src && !pengine.login.login_template) {
                ajaxProps = [{
                    url: pengine.login.login_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.login.login_template_src = data; pengine.download.sync_increment();
                    }
                }];

            }
            pengine.download.sync(ajaxProps, function () {
                if (!pengine.login.login_template) {
                    pengine.login.login_template = pengine.template.compile(pengine.login.login_template_src);
                }
                var form = pengine.login.login_template(pengine.login.login_data);
                $("body").append($(form).attr("id", "pengine_login").css("display", "none"));
                if ($(".dialog-container").length > 0) {
                    $(".dialog-container").slideUp('fast', function () {
                        $("#pengine_login").slideDown('fast', function () { pengine.login.login_configure(); });
                    });
                }
                else {
                    pengine.dialog.overlay_show();
                    window.scrollTo(0, 0);
                    $("#pengine_login").slideDown('fast', function () { pengine.login.login_configure(); });
                }
            });
        },

        login_configure: function() {
            $("#login_button_login").on("click", function () {
                pengine.login.login_verify();
                return false;
            });

            $("#login_button_close").on("click", function () {
                pengine.login.login_dispose();
                return false;
            });
            if ($("#login_type").val() == "forum")
            {
                $("#login_id").focus();
            }
            else
            {
                $("#login_password").focus();
            }
            pengine.focus.set_default_button("#pengine_login", "#login_button_login");
            pengine.window.resize();
        },

        login_verify: function () {
            $.post(
                pengine.login.login_post_url, {
                    login: $("#login_id").val(),
                    type: $("#login_type").val(),
                    loginid: $("#login_id").val(),
                    password: $("#login_password").val(),
                    cookie: $("#login_cookie").attr("checked") ? "1": null
                }, function (data) {
                    if (jQuery.isArray(data.errors) && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                        pengine.login.login_dispose();
                    }
                    else {
                        if (pengine.login.login_post) {
                            pengine.login.login_post();
                        }
                        if (pengine.login.login_reload) {
                            location.reload(true);
                        }
                        pengine.login.login_dispose();
                    }
                }
            );
        },

        login_dispose: function () {
            $("#pengine_login").slideUp('fast', function () {
                $("#pengine_login").remove();
                if ($(".dialog-container").length > 0) {
                    $(".dialog-container").slideDown('fast');
                }
                else {
                    pengine.dialog.overlay_hide();
                }
            });
        },

        logout: function (type) {
            var formData = {};
            if (type) {
                formData["type"] = type;
            }
            $.post(pengine.login.logout_post_url, formData, function (data) {
                location.reload(true);
            });
        }
    },

    theme: {
        theme_post_url: null,

        theme_select: function () {
            $.post(
                pengine.theme.theme_post_url, {
                    theme: $(".pengine-theme-selector").val()
                }, function (data) {
                    location.reload(true);
                }
            );
        },
    },

    elite: {
        elite_post_url: null,

        elite_change: function () {
            $.post(
                pengine.elite.elite_post_url, {
                    elite: $(".pengine-elite-selector").val()
                }, function (data) {
                    location.reload(true);
                }
            )
        }
    },

    window: {
        resize: function () {
            $(".panel").each(function (idx, ele) {
                $(ele).find(".panel-left-inline").css("width", "auto");
                $(ele).find(".panel-right-inline").css("width", "auto");
            });

            setTimeout("pengine.window.resize_images();", 100);

            setTimeout("pengine.window.resize_panels_step_two();", 100);

            setTimeout("pengine.window.resize_dialogs();", 100);
        },

        resize_panels_step_two: function () {
            $(".panel").each(function (idx, ele) {
                var leftWidth = $(ele).find(".panel-left-inline").width();
                var contWidth = $(ele).width();
                var contHeight = $(ele).height();
                var minHeight = $(ele).css("min-height") ? $(ele).css("min-height") : "25px";
                minHeight = parseFloat(minHeight.replace("px", ""));
                if (leftWidth > 0 && $(ele).find(".panel-right-inline").length > 0) {
                    if (contHeight <= minHeight * 1.25) {
                        $(ele).find(".panel-right-inline").width(contWidth - (leftWidth + 20));
                    }
                    else {
                        $(".panel-right-inline").width((contWidth / 2) - 3);
                        $(".panel-left-inline").width((contWidth / 2) - 3);
                    }
                }
            });
        },

        resize_dialogs: function() {
            $(".dialog-container, .dialog-container-login").each(function (idx, ele) {
                var winHeight = $(window).height();
                $(ele).css("max-height", "auto");
                $(ele).find(".list-container-overflow, .form-container-overflow")
                    .css("display", "none");
                var outHeight = $(ele).height();
                $(ele).find(".list-container-overflow, .form-container-overflow")
                    .css("display", "block").css("max-height", ((winHeight * .90) - outHeight) + "px");
                $(ele).css("max-height", winHeight * .90);
            });
        },

        resize_images: function() {
            $(".list-container img, .display-container img").not(".post-icon").each(function (idx, ele) {
                $(ele).bind("load", function () { pengine.window.resize_image(this); });
                pengine.window.resize_image(ele);
            });
        },

        resize_image: function(ele) {
            var container = $(ele).closest(".list-container").length > 0 ? $(ele).closest(".list-container") : $(ele).closest(".display-container");
            if ($(ele).hasClass("resized-image")) {
                $(ele).css("width", "auto");
                $(ele).removeClass("resized-image");
            }
            if ($(ele).hasClass("resized-image-clickable")) {
                $(ele).unbind("click");
                $(ele).removeClass("resized-image-clickable");
            }
            if (container.length > 0 && container.width() > 0 && container.width() < $(ele).width()) {
                $(ele).addClass("resized-image").css("width", container.width() - 10);
                if ($(ele).closest("a").length <= 0) {
                    $(ele).addClass("resized-image-clickable").bind("click", function (e) {
                        window.location = $(this).attr("src");
                        e.preventDefault();
                        e.stopPropagation();
                    });
                }
            }
        },

        open: function (url) {
            window.open(url, 'subwin');
        }
    },

    focus: {
        set_default_button: function (container, button, disable) {
            if (!button && !disable) {
                button = $(container).find("input[type=submit]:enabled[id] button:enabled[id]").first().attr("id");
            }
            $(container).find("input[name!=button], select").each(function (idx, ele) {
                if (!disable) {
                    $(ele).attr("data-default-click", button);
                    $(ele).on("keydown", function (event) {
                        if (event.keyCode == 13) {
                            $($(this).attr("data-default-click")).click();
                        }
                    });
                }
                else {
                    $(ele).on("keydown", function (event) {
                        if (event.keyCode == 13) {
                            return false;
                        }
                    });
                }
            });
        }
    },

    setting: {

        setting_template_url: null,

        setting_get_url: null,

        setting_post_url: null,

        setting_template_src: null,

        setting_template: null,

        setting_data: null,

        setting_launch: function () {
            var ajaxProps = [{
                url: pengine.setting.setting_get_url, cache: false, type: "GET", success: function (data) {
                    pengine.setting.setting_data = data; pengine.download.sync_increment();
                }, error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can edit any settings." }, false, function () { pengine.setting.setting_launch(); });
                    }
                }
            }];

            if (!pengine.setting.setting_template_src && !pengine.setting.setting_template) {
                $.merge(ajaxProps, [{
                    url: pengine.setting.setting_template_url, cache: true, type: "GET", success: function (data) {
                        pengine.setting.setting_template_src = data; pengine.download.sync_increment();
                    }
                }]);
            }
            pengine.download.sync(ajaxProps, function () {
                if (!pengine.setting.setting_template) {
                    pengine.setting.setting_template = pengine.template.compile(pengine.setting.setting_template_src);
                }
                var form = pengine.setting.setting_template(pengine.setting.setting_data);
                $("body").append($(form).attr("id", "pengine_setting").css("display", "none"));
                pengine.dialog.overlay_show();
                window.scrollTo(0, 0);
                $("#pengine_setting").slideDown('fast', function () { pengine.setting.setting_configure(); });
            });
        },

        setting_configure: function () {
            $("#setting_edit_button_save").on("click", function () {
                pengine.setting.setting_save();
                return false;
            });

            $("#setting_edit_button_close").on("click", function () {
                pengine.setting.setting_dispose();
                return false;
            });
            $("#setting_edit_ownername").focus();
            pengine.focus.set_default_button("#pengine_setting", "#setting_button_setting");
            pengine.window.resize();
        },

        setting_save: function () {
            $.ajax({
                type: "POST",
                url: pengine.setting.setting_post_url,
                data: {
                    OwnerName: $("#setting_edit_ownername").val(),
                    OwnerEmail: $("#setting_edit_owneremail").val(),
                    DefaultTitle: $("#setting_edit_defaulttitle").val(),
                    DefaultTheme: $("#setting_edit_defaulttheme").val(),
                    FrontPageLogo: $("#setting_edit_frontpagelogo").val(),
                    LeetOnLabel: $("#setting_edit_leetonlabel").val(),
                    LeetOffLabel: $("#setting_edit_leetofflabel").val(),
                    AdminOnLabel: $("#setting_edit_adminonlabel").val(),
                    AdminOffLabel: $("#setting_edit_adminofflabel").val(),
                    HomeLabel: $("#setting_edit_homelabel").val(),
                    ThemeLabel: $("#setting_edit_themelabel").val(),
                    ResumeLabel: $("#setting_edit_resumelabel").val(),
                    PrintLabel: $("#setting_edit_printlabel").val(),
                    QuoteLabel: $("#setting_edit_quotelabel").val(),
                    PagePostSummary: $("#setting_edit_pagepostsummary").val(),
                    PagePost: $("#setting_edit_pagepost").val(),
                    PageRSS: $("#setting_edit_pagerss").val(),
                    PageSearch: $("#setting_edit_pagesearch").val(),
                    SessionTimeout: $("#setting_edit_sessiontimeout").val(),
                    ExcludeQuote: $("#setting_edit_excludequote").attr("checked") ? "1" : "0",
                    ExcludeRSS: $("#setting_edit_excluderss").attr("checked") ? "1" : "0",
                    ExcludeLeet: $("#setting_edit_excludeleet").attr("checked") ? "1" : "0",
                    ExcludeResume: $("#setting_edit_excluderesume").attr("checked") ? "1" : "0",
                    ExcludeTheme: $("#setting_edit_excludetheme").attr("checked") ? "1" : "0",
                    ExcludePrint: $("#setting_edit_excludeprint").attr("checked") ? "1" : "0",
                    ExcludeSearch: $("#setting_edit_excludesearch").attr("checked") ? "1" : "0",
                    ExcludeClippyButton: $("#setting_edit_excludeclippybutton").attr("checked") ? "1" : "0",
                    ExcludeClippyShortcut: $("#setting_edit_excludeclippyshortcut").attr("checked") ? "1" : "0",
                    ClippyButtonLabel: $("#setting_edit_clippybuttonlabel").val(),
                    ClippyQuoteMode: $("#setting_edit_clippy_quotemode").attr("checked") ? "1" : "0",
                    ClippyShortcutKeyCode: $("#setting_edit_clippy_keycode").val(),
                    ClippyShortcutKeyCount: $("#setting_edit_clippy_keycount").val(),
                    ClippyRandomChance: $("#setting_edit_clippy_randomchance").val(),
                    AdminPass: $("#setting_edit_adminpass_blank").length > 0 ? (!$("#setting_edit_adminpass_blank").attr("checked") ? $("#setting_edit_adminpass").val() : '[none]') : null,
                    GodPass: $("#setting_edit_godpass_blank").length > 0 ? (!$("#setting_edit_godpass_blank").attr("checked") ? $("#setting_edit_godpass").val() : '[none]') : null,
                    ForumLabel: $("#setting_edit_forumlabel").val(),
                    ForumLoginLabel: $("#setting_edit_forumloginlabel").val(),
                    ForumLogoffLabel: $("#setting_edit_forumlogofflabel").val(),
                    ForumThreads: $("#setting_edit_forumthreads").val(),
                    ForumPosts: $("#setting_edit_forumposts").val(),
                    ForumLoginTimeout: $("#setting_edit_forumlogintimeout").val(),
                    ForumEditTimeout: $("#setting_edit_forumedittimeout").val(),
                    ExcludeForum: $("#setting_edit_excludeforum").attr("checked") ? "1" : "0",
                    ForumRegisterLabel: $("#setting_edit_forumregisterlabel").val()
                },
                success: function (data) {
                    if (jQuery.isArray(data.errors) && data.errors.length > 0) {
                        pengine.notification.display(data.errors);
                    }
                    else {
                        pengine.setting.setting_dispose();
                        location.reload(true);
                    }
                },
                error: function (data) {
                    if (data.responseText == "401") {
                        pengine.login.login_launch({ loginType: "system", loginMessage: "You must login before you can save any settings." }, false, function () { pengine.setting.setting_save(); });
                    }
                }
            });
        },

        setting_dispose: function () {
            $("#pengine_setting").slideUp('fast', function () {
                $("#pengine_setting").remove();
            });
            pengine.dialog.overlay_hide();
        },

        logout: function () {
            $.post(pengine.setting.logout_post_url, null, function (data) {
                location.reload(true);
            });
        }
    },

    blink: {
        delay: 500,

        bitstate: false,

        targets: null,

        init: function () {
            pengine.blink.targets = $("blink");
            setInterval(function () {
                if (pengine.blink.bitstate) {
                    $(pengine.blink.targets).css("visibility", "hidden");
                }
                else {
                    $(pengine.blink.targets).css("visibility", "visible");
                }
                pengine.blink.bitstate = !pengine.blink.bitstate;
            }, pengine.blink.delay);
        }
    }
});

$(document).ready(function() {
    $(".autopostback-change").on("change", function () {
        $(this).closest("form").submit();
    });

    $(".confirm-click").on("click", function () {
        var cmsg = $(this).attr("data-confirm-message") ? $(this).attr("data-confirm-message") : "Are you sure you wish to do this?";
        return confirm(cmsg);
    });

    $(".datetime-display").each(function (idx, ele) {
        if ($(ele).text() != '') {
            $(ele).text(pengine.time.to_local($(ele).text()));
        }
    });

    $(".list-table tbody tr").hover(
        function () {
            $(this).addClass("hover")
        },
        function () {
            $(this).removeClass("hover")
    });

    $(".pengine-button-search").on("click", function () {
        var query = $(this).parent().find(".pengine-search-query").val();
        if (query != null && query.length > 0) {
            pengine.search.search_redirect(query);
        }
    });

    $(".pengine-button-login").on("click", function () {
        pengine.login.login_launch({ loginType: "system" }, true, null);
    });

    $(".pengine-button-logout").on("click", function () {
        pengine.login.logout();
    });

    $(".pengine-button-forum-login").on("click", function () {
        pengine.login.login_launch({ loginType: "forum" }, true, null);
    });

    $(".pengine-button-forum-logout").on("click", function () {
        pengine.login.logout("forum");
    });

    $(".pengine-theme-selector").on("change", function () {
        pengine.theme.theme_select();
    });

    $(".pengine-elite-selector").on("change", function () {
        pengine.elite.elite_change();
    });

    $(".pengine-button-print").on("click", function () {
        var url = window.location.toString();
        if (url.indexOf("?") > 0) {
            url = url + "&print=1";
        }
        else {
            url = url + "?print=1";
        }
        pengine.window.open(url);
        return false;
    });

    $(".pengine-button-quote").on("click", function () {
        pengine.quote.quote_get();
    });

    $("a").hover(function () { $(this).addClass("hover"); }, function () { $(this).removeClass("hover"); });

    pengine.window.resize();

    $(window).on("resize", function () { pengine.window.resize(); });

    pengine.notification.process_page();

    pengine.blink.init();
})