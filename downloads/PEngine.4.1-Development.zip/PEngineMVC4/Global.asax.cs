﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using PEngine4.Core;

namespace PEngine4.MVC
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public bool firstSessionFlag = false;

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //Handle Database Creation, Migration and Updating
            if (!Database.Exists())
            {
                Database.Create();
            }
            else
            {
                Database.Update();
            }

            //Make sure to load and fill in missing Settings accordingly
            PEngine4.Core.Settings.Load();

            firstSessionFlag = false;
        }

        protected void Session_start()
        {
            if (!firstSessionFlag)
            {
                firstSessionFlag = true;
            }
        }
    }
}