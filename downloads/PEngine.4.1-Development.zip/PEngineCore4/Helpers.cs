﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using PEngine4.Core.TempClasses;

namespace PEngine4.Core
{
    public class Helpers
    {
        public static char[] BannedChars = { '/', '\\', '?', '!', ';', ':', '\"'
            , '\'', '(', ')', '&', '$', '%', '#', '@', '*', '|', ',', '-' };

        public enum ScreenType
        {
            none,
            article,
            admin,
            elite,
            news,
            quote,
            resume,
            search,
            theme
        }

        public enum ActionType
        {
            none,
            edit,
            list,
            view
        }

        public enum AccessLevel
        {
            none,
            admin,
            god,
            forum,
            forumadmin
        }

        public enum LoginType
        {
            none,
            system,
            article,
            forum
        }

        public enum ResourceType
        {
            Post,
            Article,
            Forum
        }

        public static bool IsNumeric(string value)
        {
            double temp = 0;
            bool retvalue = Double.TryParse(value, out temp);
            return retvalue;
        }

        public static string FormatDate(object dateobj)
        {
            return FormatDate(dateobj, false);
        }

        public static string FormatDate(object dateobj, bool skipPresent)
        {
            DateTime tempobj = DateTime.MinValue;
            if (dateobj is DateTime)
            {
                tempobj = (DateTime)dateobj;
            }
            else if (dateobj is string)
            {
                tempobj = DateTime.Parse((string)dateobj);
            }
            if (tempobj != DateTime.MinValue)
            {
                if (tempobj <= DateTime.UtcNow || skipPresent)
                {
                    return tempobj.ToShortDateString()
                        + (tempobj.TimeOfDay.TotalSeconds > 0 ? " " + tempobj.ToShortTimeString() : string.Empty);
                }
                else
                {
                    return "Present";
                }
            }
            else
            {
                return string.Empty;
            }
        }

        static public string EscapeJavascript(string js)
        {
            return js.Replace("'", "\\'");
        }

        static public string MarkupSubheader(string text)
        {
            return MarkupSubheader(text, true);
        }

        static public string MarkupSubheader(string text, bool anchorFlag)
        {
            return MarkupSubheader(text, anchorFlag, anchorFlag ? text.Replace(" ", string.Empty) : string.Empty);
        }

        static public string MarkupSubheader(string text, bool anchorFlag, string anchorName)
        {
            return (anchorFlag ? string.Format("<a name=\"{0}\"></a>", anchorName) : string.Empty)
                + string.Format("<div class=\"sub-header\">{0}</div>"
                , EliteConvert(text));
        }

        static public string MarkupIcon(string url)
        {
            return !string.IsNullOrEmpty(url) ? string.Format("<img src=\"{0}\" " +
                "class=\"post-icon\" alt=\"Post Icon\" />", AppPath() + "images/icons/" + url) : string.Empty;
        }

        static public string MarkupMenuButton(Button button)
        {
            StringBuilder retvalue = new StringBuilder();
            string template = "<a class=\"menu-button {0}\" href=\"{1}\">{2}</a>";
            if (button.IsButton())
            {
                retvalue.Append(string.Format(template, button.CSSClass, button.URL, EliteConvert(button.Text)));
            }
            else
            {
                retvalue.Append("<div class=\"menu-separator\"></div>");
            }
            return retvalue.ToString();
        }

        static public string MarkupArticle(string secdata, bool forum)
        {
            return MarkupArticle(secdata, forum, 0);
        }

        static public string MarkupArticle(string secdata, bool forum, int articleid)
        {
            int lpos = 0;
            string tag = string.Empty;
            string tagname = string.Empty;
            string tagdata = string.Empty;
            int tagspace = 0;
            string[] tagelements = { };
            bool rawhtmlflag = false;
            int rawhtmlstart = 0;
            int rawhtmlend = 0;
            string outdata = string.Empty;
            string[] resforumtags = {"SCRIPT", "/SCRIPT", "IFRAME", "/IFRAME", "EMBED", "BLINK"
            , "TR", "TD", "TABLE", "/TR", "/TD", "/TABLE", "FRAMESET", "/FRAMESET"};
            bool restagflag = false;
            StringBuilder outputhtml = new StringBuilder();
            //Filter for obfusacated tags if forum flag is true
            //Remove HTML Content if Forum Flag is true
            if (forum)
            {
                while (secdata.IndexOf("[" + Environment.NewLine) >= 0)
                {
                    secdata.Replace("[" + Environment.NewLine, "[ ");
                }
                while (secdata.IndexOf("<" + Environment.NewLine) >= 0)
                {
                    secdata.Replace("<" + Environment.NewLine, "< ");
                }
                while (secdata.IndexOf("[ ") >= 0)
                {
                    secdata.Replace("[ ", "[");
                }
                while (secdata.IndexOf("< ") >= 0)
                {
                    secdata.Replace("< ", "<");
                }
                for (int cpos = secdata.IndexOf("<"); cpos >= 0; cpos = secdata.IndexOf("<", cpos + 1))
                {
                    lpos = secdata.IndexOf(">", cpos + 1);
                    if (lpos >= 0)
                    {
                        secdata = secdata.Substring(0, cpos) + secdata.Substring(lpos, secdata.Length - lpos);
                    }
                }
            }
            lpos = -1;
            for (int cpos = secdata.IndexOf("["); cpos >= 0; cpos = secdata.IndexOf("[", lpos + 1))
            {
                if (!rawhtmlflag)
                {
                    outdata = secdata.Substring(lpos + 1, cpos - (lpos + 1));
                    outdata = EliteConvert(outdata);
                    for (int eptr = 0; eptr < Environment.NewLine.Length; eptr++)
                    {
                        if (outdata.IndexOf(Environment.NewLine[eptr]) >= 0)
                        {
                            outdata = outdata.Replace(Environment.NewLine[eptr].ToString(), "<br/>" + Environment.NewLine);
                            eptr = Environment.NewLine.Length;
                        }
                    }
                    outputhtml.Append(outdata);
                }
                lpos = secdata.IndexOf("]", cpos + 1);
                if (lpos > cpos)
                {
                    tag = secdata.Substring(cpos + 1, lpos - (cpos + 1));
                    tagspace = tag.IndexOf(" ");
                    if (tagspace >= 0)
                    {
                        tagname = tag.Substring(0, tagspace).ToUpper();
                        tagdata = tag.Substring(tagspace + 1, tag.Length - (tagspace + 1));
                    }
                    else
                    {
                        tagname = tag.ToUpper();
                    }
                    if ((!rawhtmlflag) || (tagname == "/RAWHTML"))
                    {
                        switch (tagname)
                        {
                            case "CENTER":
                                outputhtml.Append("<p style=\"text-align: center\">");
                                break;
                            case "/CENTER":
                                outputhtml.Append("</p>");
                                break;
                            case "IMAGE":
                                if ((tagdata.ToUpper().IndexOf("HTTP") >= 0)
                                    || (tagdata.Substring(0, 2) == "./") || (tagdata.Substring(0, 1) == "/"))
                                {
                                    outputhtml.Append("<img src=\"" + ReMapRelativeURL(tagdata) + "\" alt=\"outside image\" />");
                                }
                                else
                                {
                                    outputhtml.Append("<img src=\"" + AppPath() + "images/articles/" + tagdata + "\" alt=\"article image\" />");
                                }
                                break;
                            case "SUBHEADER":
                                if (!forum)
                                {
                                    outputhtml.Append(MarkupSubheader(tagdata));
                                }
                                break;
                            case "LINK":
                                tagelements = tagdata.Split(' ');
                                string url = ReMapRelativeURL(tagelements[0]);
                                outputhtml.Append("<a href=\"" + url + "\">");
                                if (tagelements.Length > 1)
                                {
                                    for (int teptr = 1; teptr < tagelements.Length; teptr++)
                                    {
                                        if (teptr > 1)
                                        {
                                            outputhtml.Append(" " + tagelements[teptr]);
                                        }
                                        else
                                        {
                                            outputhtml.Append(tagelements[teptr]);
                                        }
                                    }
                                }
                                else
                                {
                                    outputhtml.Append(tagelements[0]);
                                }
                                outputhtml.Append("</a>");
                                break;
                            case "ICON":
                                outputhtml.Append(MarkupIcon(AppPath() + "images/icons/" + tagdata));
                                break;
                            case "SYSTEMIMAGE":
                                outputhtml.Append("<img src=\"" + AppPath() + "images/system/" + tagdata + "\" alt=\"system image\" />");
                                break;
                            case "RAWHTML":
                                rawhtmlflag = true;
                                rawhtmlstart = cpos + 9;
                                rawhtmlend = rawhtmlstart;
                                break;
                            case "/RAWHTML":
                                rawhtmlflag = false;
                                rawhtmlend = cpos;
                                outputhtml.Append(secdata.Substring(rawhtmlstart, rawhtmlend - rawhtmlstart));
                                break;
                            case "QUOTE":
                                outputhtml.Append("<blockquote>");
                                break;
                            case "/QUOTE":
                                outputhtml.Append("</blockquote>");
                                break;
                            default:
                                restagflag = false;
                                if (forum)
                                {
                                    for (int fptr = 0; fptr < resforumtags.Length; fptr++)
                                    {
                                        if (resforumtags[fptr].ToUpper() == tagname)
                                        {
                                            restagflag = true;
                                        }
                                    }
                                }
                                if (!restagflag)
                                {
                                    outputhtml.Append("<" + tag + ">");
                                }
                                break;
                        }
                    }
                }
            }
            if (lpos >= -1)
            {
                outdata = secdata.Substring(lpos + 1, secdata.Length - (lpos + 1));
                if (!rawhtmlflag)
                {
                    outdata = EliteConvert(outdata);
                    for (int eptr = 0; eptr < Environment.NewLine.Length; eptr++)
                    {
                        if (outdata.IndexOf(Environment.NewLine[eptr]) >= 0)
                        {
                            outdata = outdata.Replace(Environment.NewLine[eptr].ToString(), "<br/>" + Environment.NewLine);
                            eptr = Environment.NewLine.Length;
                        }
                    }
                    outputhtml.Append(outdata);
                }
                else
                {
                    outputhtml.Append(outdata);
                }
            }
            if (outputhtml.Length <= 0)
            {
                outputhtml.Append("There was no data to convert.");
            }
            return outputhtml.ToString();
        }

        static public string DateProcess(DateTime date)
        {
            return date.Subtract(DateTime.Now).TotalDays > 0 || date == DateTime.MinValue ? "Present" : date.ToShortDateString();
        }

        static public string DateProcess(string date)
        {
            string retvalue = string.Empty;
            try
            {
                DateTime mydt = DateTime.Parse(date);
                retvalue = DateProcess(mydt);
            }
            catch
            {
                retvalue = null;
            }
            return retvalue;
        }

        static public string EliteConvert(string origtext)
        {
            Dictionary<string, string> hword = new Dictionary<string, string>();
            hword.Add("cool", "k3wl");
            hword.Add("dude", "d00d");
            hword.Add("dudes", "d00dz");
            hword.Add("hacker", "hax0r");
            hword.Add("hacked", "hax0red");
            hword.Add("mp3s", "mp3z");
            hword.Add("rock", "r0x0r");
            hword.Add("rocks", "r0x0rez");
            hword.Add("you", "j00");
            hword.Add("elite", "l33t|31337");
            hword.Add("the", "teh|the");
            hword.Add("own", "pwn|0wnzor");
            hword.Add("porn", "porn|pr0n");
            Dictionary<string, string> hchar = new Dictionary<string, string>();
            hchar.Add("a", "@:4");
            hchar.Add("b", "b:8");
            hchar.Add("d", "d:|)");
            hchar.Add("e", "e:3");
            hchar.Add("f", "f:ph");
            hchar.Add("g", "g:9");
            hchar.Add("h", "h:|-|");
            hchar.Add("i", "i:1");
            hchar.Add("k", "k:|&lt;");
            hchar.Add("m", "m:|\\\\\\/|");
            hchar.Add("n", "n:|\\\\|");
            hchar.Add("o", "o:0");
            hchar.Add("s", "$:5");
            hchar.Add("t", "t:+");
            hchar.Add("v", "v:\\\\\\/");
            hchar.Add("w", "w:\\\\\\/\\\\\\/");
            hchar.Add("x", "x:&gt;&lt;");
            StringBuilder retvalue = new StringBuilder();
            System.Random Randomizer = new Random(DateTime.Now.Millisecond);
            if ((HttpContext.Current.Session["leetflag"] == null) || ((bool)HttpContext.Current.Session["leetflag"] == false))
            {
                retvalue.Append(origtext);
            }
            else
            {
                string[] words = origtext.ToLower().Split(' ');
                for (int wordptr = 0; wordptr < words.Length; wordptr++)
                {
                    string cword = words[wordptr];
                    string newword = string.Empty;
                    switch (cword)
                    {
                        case "am":
                            if ((wordptr < words.Length - 1) && (words[wordptr + 1] == "good"))
                            {
                                cword = "ownz0r";
                                wordptr++;
                            }
                            break;
                        case "is":
                            if ((wordptr < words.Length - 1) && (words[wordptr + 1] == "good"))
                            {
                                cword = "ownz0rz";
                                wordptr++;
                            }
                            break;
                        default:
                            if (hword.ContainsKey(words[wordptr]))
                            {
                                string[] tword = hword[words[wordptr]].Split('|');
                                cword = tword[Randomizer.Next(0, tword.Length - 1)];
                            }
                            break;
                    }
                    for (int charptr = 0; charptr < cword.Length; charptr++)
                    {
                        string curchar = cword[charptr].ToString();
                        if (hchar.ContainsKey(curchar))
                        {
                            string[] tchar = hchar[curchar].Split(':');
                            curchar = tchar[Randomizer.Next(0, tchar.Length - 1)];
                        }
                        if (Randomizer.Next(0, 100) > 50)
                        {
                            curchar = curchar.ToUpper();
                        }
                        newword += curchar;
                    }
                    retvalue.Append(newword + " ");
                }
            }
            return retvalue.ToString();
        }

        public static string PasswordEncrypt(string pass)
        {
            if (!string.IsNullOrEmpty(pass))
            {
                System.Security.Cryptography.SHA256CryptoServiceProvider sha256 = new System.Security.Cryptography.SHA256CryptoServiceProvider();
                return BytesToHex(sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(pass)));
            }
            else
            {
                return string.Empty;
            }
        }

        public static bool PasswordEncryptAndCompare(string plainpass, string encryptedhash)
        {
            if (!string.IsNullOrEmpty(encryptedhash) || !string.IsNullOrEmpty(plainpass))
            {
                System.Security.Cryptography.SHA256CryptoServiceProvider sha256 = new System.Security.Cryptography.SHA256CryptoServiceProvider();
                System.Security.Cryptography.MD5CryptoServiceProvider md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
                string comparehash = BytesToHex(sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(plainpass)));
                if (comparehash != encryptedhash)
                {
                    comparehash = BytesToHex(md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(plainpass)));
                    return (comparehash == encryptedhash);
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }

        public static string BytesToHex(byte[] data)
        {
            StringBuilder retvalue = new StringBuilder();
            foreach (byte dbyte in data)
            {
                retvalue.Append(dbyte.ToString("x2").ToUpper());
            }
            return retvalue.ToString();
        }

        public static string UrlLogo()
        {
            return AppPath() + "images/system/" + (string)Settings.Query(Settings.AppSettingKey.app_logo_frontpage);
        }

        public static bool IsLogoEnabled()
        {
            if (((string)Settings.Query(Settings.AppSettingKey.app_logo_frontpage)).Length > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string AppPath()
        {
            string path = VirtualPathUtility.ToAbsolute("~/");
            return path.EndsWith("/") ? path : path + "/";
        }

        public static string DataTruncate(string data)
        {
            return DataTruncate(data, 75);
        }

        public static string DataTruncate(string data, int length)
        {
            string retvalue = string.Empty;
            data = data.Replace("[", string.Empty);
            data = data.Replace("]", string.Empty);
            data = data.Replace("<", string.Empty);
            data = data.Replace(">", string.Empty);
            if (length > 0)
            {
                if (data.Length > length)
                {
                    retvalue = data.Substring(0, length) + "...";
                }
                else
                {
                    retvalue = data;
                }
            }
            else
            {
                string[] delimiters = { Environment.NewLine, "\n", "<br>", "[br]" };
                int strptr = -1;
                int dptr = 0;
                while (strptr < 0 && dptr < delimiters.Length)
                {
                    strptr = data.IndexOf(delimiters[dptr]);
                    dptr++;
                }
                if (strptr >= 0)
                {
                    retvalue = data.Substring(0, strptr);
                }
                else
                {
                    retvalue = data;
                }
            }
            return retvalue;
        }

        public static IEnumerable<SelectListItem> IconList(HttpContext context, bool addBlank)
        {
            List<string> files = System.IO.Directory.GetFiles(context.Server.MapPath("~/Images/Icons")).ToList();
            if (addBlank) { files.Insert(0, string.Empty); }
            return new SelectList(files.Select(o => System.IO.Path.GetFileName(o))).AsEnumerable();
        }

        public static IEnumerable<SelectListItem> ThemeList(HttpContext context, bool addBlank)
        {
            return ThemeList(context, addBlank, true);
        }

        public static IEnumerable<SelectListItem> ThemeList(HttpContext context, bool addBlank, bool setDefault)
        {
            List<string> dirs = System.IO.Directory.GetDirectories(context.Server.MapPath("~/Themes")).ToList();
            if (addBlank) { dirs.Insert(0, string.Empty); }
            return new SelectList(dirs.Select(o => System.IO.Path.GetFileName(o))
                , setDefault ? ThemeChoose(context) : string.Empty).AsEnumerable();
        }

        public static bool ThemeValid(HttpContext context, string theme)
        {
            bool retvalue = false;
            if (System.IO.File.Exists(context.Server.MapPath("~/Themes/" + theme + "/" + theme + ".css")))
            {
                retvalue = true;
            }
            return retvalue;
        }

        public static string ThemeChoose(HttpContext context)
        {
            string retvalue = string.Empty;
            bool forceThemeFlag = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_theme);
            int tctr = 0;
            while (((retvalue == string.Empty) || (ThemeValid(context, retvalue) == false)) && (tctr < 4))
            {
                switch (tctr)
                {
                    case 0:
                        if (!forceThemeFlag && !string.IsNullOrEmpty((string)context.Session["theme"]))
                        {
                            retvalue = (string)context.Session["theme"];
                        }
                        break;
                    case 1:
                        if (!forceThemeFlag && context.Request.Cookies["theme"] != null)
                        {
                            retvalue = (string)context.Request.Cookies["theme"].Value;
                        }
                        break;
                    case 2:
                        string deftheme = (string)Settings.Query(Settings.AppSettingKey.app_default_theme);
                        if (!string.IsNullOrEmpty(deftheme))
                        {
                            retvalue = deftheme;
                        }
                        break;
                    case 3:
                        List<SelectListItem> themes = ThemeList(context, false, false).ToList();
                        if (themes.Count > 0)
                        {
                            retvalue = themes[0].Value;
                        }
                        break;
                }
                tctr++;
            }
            if (!string.IsNullOrEmpty(retvalue))
            {
                context.Session["theme"] = retvalue;
                context.Response.Cookies.Add(new HttpCookie("theme", retvalue));
            }
            return retvalue;
        }

        public static void ThemeSelect(HttpContext context, string theme)
        {
            if (ThemeValid(context, theme))
            {
                context.Session["theme"] = theme;
                context.Response.Cookies.Add(new HttpCookie("theme", theme));
            }
        }

        public static string GenerateUniqueName(string name)
        {
            name = Encoding.ASCII.GetString(Encoding.GetEncoding("Cyrillic").GetBytes(HttpUtility.HtmlDecode(name)));
            var sb = new StringBuilder(Regex.Replace(name, @"[^\w ]", "").Trim());
            sb.Replace(" ", "-");
            sb.Replace("--", "-");
            return sb.ToString().ToLower();
        }

        public static string ReMapRelativeURL(string url)
        {
            if (!url.ToLower().StartsWith("http://") && !url.ToLower()
                                    .StartsWith("https://") && !url.StartsWith("//") && !url.ToLower().StartsWith("ftp://"))
            {
                if (url.StartsWith("./"))
                {
                    url = url.TrimStart('.');
                }
                else if (!url.StartsWith("/"))
                {
                    url = "/" + url;
                }
                url = AppPath().TrimEnd('/') + url;
            }
            return url;
        }

        private static string CacheFormatKey(string cacheKey)
        {
            return cacheKey.ToLower().Replace(" ", "_");
        }

        public static bool CacheAddUpdate(string cacheKey, object cacheObject)
        {
            return CacheAddUpdate(cacheKey, cacheObject, 60);
        }

        public static bool CacheAddUpdate(string cacheKey, object cacheObject, int cacheMinutes)
        {
            bool retvalue = false;
            cacheKey = CacheFormatKey(cacheKey);
            if (cacheObject != null)
            {
                if (HttpContext.Current.Cache[cacheKey] != null)
                {
                    HttpContext.Current.Cache[cacheKey] = cacheObject;
                    retvalue = true;
                }
                else
                {
                    HttpContext.Current.Cache.Add(cacheKey, cacheObject, null, System.Web.Caching.Cache.NoAbsoluteExpiration, new TimeSpan(0, cacheMinutes, 0), System.Web.Caching.CacheItemPriority.Normal, null);
                }
            }
            return retvalue;
        }

        public static bool CacheDelete(params string[] cacheKeys)
        {
            bool retvalue = false;
            cacheKeys.ToList().ForEach(k =>
            {
                string cacheKey = CacheFormatKey(k);
                if (HttpContext.Current.Cache[cacheKey] != null)
                {
                    HttpContext.Current.Cache.Remove(cacheKey);
                    retvalue = true;
                }
            });
            return retvalue;
        }

        public static object CacheRetrieve(string cacheKey)
        {
            return CacheRetrieve<object>(cacheKey);
        }

        public static T CacheRetrieve<T>(string cacheKey)
        {
            T retvalue = default(T);
            cacheKey = CacheFormatKey(cacheKey);
            if (HttpContext.Current.Cache[cacheKey] != null)
            {
                return (T) HttpContext.Current.Cache[cacheKey];
            }
            return retvalue;
        }

        public static bool CacheContains(string cacheKey)
        {
            bool retvalue = false;
            cacheKey = CacheFormatKey(cacheKey);
            if (HttpContext.Current.Cache[cacheKey] != null)
            {
                retvalue = true;
            }
            return retvalue;
        }
    }
}
