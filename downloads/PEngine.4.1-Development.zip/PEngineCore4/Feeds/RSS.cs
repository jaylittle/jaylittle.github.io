﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace PEngine4.Core.Feeds
{
    public class RSS
    {
        public static void Generate(string postBaseUrl)
        {
            int rssperpage = (int)Settings.Query(Settings.AppSettingKey.app_recpage_rss);
            Generate(postBaseUrl, rssperpage);
        }

        public static void Generate(string postBaseUrl, int count)
        {
            bool excluderss = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_rss);
            if (!excluderss)
            {
                if (System.IO.File.Exists(HttpContext.Current.Server.MapPath("~/App_Data/rss.xml")))
                {
                    System.IO.File.Delete(HttpContext.Current.Server.MapPath("~/App_Data/rss.xml"));
                }
                string location = (string)HttpContext.Current.Request.ServerVariables["SERVER_NAME"]
                    + ":" + HttpContext.Current.Request.ServerVariables["SERVER_PORT"]
                    + HttpContext.Current.Request.ApplicationPath;
                string title = (string)Settings.Query(Settings.AppSettingKey.app_default_title);
                string logo = (string)Settings.Query(Settings.AppSettingKey.app_logo_frontpage);
                string framexml = string.Empty;
                System.Xml.XmlDocument rssfeed = new System.Xml.XmlDocument();
                System.Xml.XmlNode rsschannel;

                framexml += "<rss version=\"2.0\"><channel><title>"
                    + title + "</title>" + "<link>http://" + location + "</link><description>"
                    + title + "</description><lastBuildDate>" + String.Format("{0:R}", DateTime.Now)
                    + " " + "</lastBuildDate><language>en-us</language>";
                if (!string.IsNullOrEmpty(logo))
                {
                    framexml += "<image><title>" + title + "</title><link>http://" + location.Trim('/') + "</link>"
                        + "<url>http://" + location + "/images/system/" + logo + "</url></image>";
                }
                framexml += "</channel></rss>";
                rssfeed.LoadXml(framexml);
                rsschannel = rssfeed.SelectSingleNode("/rss/channel");
                Services.PostService postService = new Services.PostService();
                int total = 0;
                List<Model.Post> posts = postService.PostList(1, count, ref total, false);
                if ((posts != null) && (posts.Count > 0))
                {
                    for (int pptr = 0; pptr < posts.Count; pptr++)
                    {
                        rsschannel.InnerXml += "<item><title>"
                            + HttpContext.Current.Server.HtmlEncode((string)posts[pptr].Title)
                            + "</title>" + "<link>http://" + location.TrimEnd('/')
                            + postBaseUrl.Replace("PostUniqueName"
                            , HttpContext.Current.Server.HtmlEncode(posts[pptr].UniqueName))
                            .Replace("PostYear", posts[pptr].CreatedUTC.Value.Year.ToString())
                            .Replace("PostMonth", posts[pptr].CreatedUTC.Value.Month.ToString())
                            + "</link><pubDate>" + String.Format("{0:R}", posts[pptr].CreatedUTC)
                            + "</pubDate><description>"
                            + HttpContext.Current.Server.HtmlEncode(Helpers.DataTruncate((string)posts[pptr].Data, -1))
                            + "</description></item>";
                    }
                    rssfeed.Save(HttpContext.Current.Server.MapPath("~/App_Data/rss.xml"));
                }
            }
        }
    }
}
