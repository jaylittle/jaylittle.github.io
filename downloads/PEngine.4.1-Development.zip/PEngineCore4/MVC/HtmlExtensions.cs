﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using PEngine4.Core;
using System.Web.Routing;

namespace PEngine4.Core.MVC.Extensions
{
    public static class HtmlHelperExtensions
    {
        public static MvcHtmlString PEPager(this HtmlHelper htmlHelper, int start, int count, int total, object routeValues, object htmlAttributes)
        {
            return PEPager(htmlHelper, start, count, total, routeValues, htmlAttributes, "List");
        }

        public static MvcHtmlString PEPager(this HtmlHelper htmlHelper, int start, int count, int total, object routeValues, object htmlAttributes, string action)
        {
            StringBuilder retvalue = new StringBuilder();
            if (start > 1)
            {
                RouteValueDictionary linkRd = new RouteValueDictionary(routeValues);
                linkRd.Add("start", 1);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.ActionLink("[Start]", action, linkRd, new RouteValueDictionary(htmlAttributes)));
                retvalue.Append("&nbsp;");
                linkRd = new RouteValueDictionary(routeValues);
                linkRd.Add("start", start - count);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.ActionLink("[Prev]", action, linkRd, new RouteValueDictionary(htmlAttributes)));
            }
            else
            {
                if (total > count)
                {
                    retvalue.Append(htmlHelper.Raw("[Start]&nbsp;[Prev]"));
                }
            }
            if (total > count)
            {
                retvalue.Append(string.Format("&nbsp;<span>{0} to {1} of {2}</span>&nbsp;", start, total < start + count ? total : start + count - 1, total));
            }
            else
            {
                retvalue.Append(string.Format("&nbsp;<span>{0} of {0}&nbsp;", total));
            }

            if (total > (start + count) - 1)
            {
                RouteValueDictionary linkRd = new RouteValueDictionary(routeValues);
                linkRd.Add("start", start + count);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.ActionLink("[Next]", action, linkRd, new RouteValueDictionary(htmlAttributes)));
                retvalue.Append("&nbsp;");
                linkRd = new RouteValueDictionary();
                linkRd.Add("start", (total - (total % count)) + 1);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.ActionLink("[End]", action, linkRd, new RouteValueDictionary(htmlAttributes)));
            }
            else
            {
                if (total > count)
                {
                    retvalue.Append("[Next]&nbsp;[End]");
                }
            }
            return new MvcHtmlString(retvalue.ToString());
        }

        public static MvcHtmlString PEPagerByRoute(this HtmlHelper htmlHelper, int start, int count, int total, object routeValues, object htmlAttributes, string route)
        {
            StringBuilder retvalue = new StringBuilder();
            if (start > 1)
            {
                RouteValueDictionary linkRd = new RouteValueDictionary(routeValues);
                linkRd.Add("start", 1);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.RouteLink("[Start]", route, linkRd, new RouteValueDictionary(htmlAttributes)));
                retvalue.Append("&nbsp;");
                linkRd = new RouteValueDictionary(routeValues);
                linkRd.Add("start", start - count);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.RouteLink("[Prev]", route, linkRd, new RouteValueDictionary(htmlAttributes)));
            }
            else
            {
                if (total > count)
                {
                    retvalue.Append(htmlHelper.Raw("[Start]&nbsp;[Prev]"));
                }
            }
            if (total > count)
            {
                retvalue.Append(string.Format("&nbsp;<span>{0} to {1} of {2}</span>&nbsp;", start, total < start + count ? total : start + count - 1, total));
            }
            else
            {
                retvalue.Append(string.Format("&nbsp;<span>{0} of {0}&nbsp;", total));
            }

            if (total > (start + count) - 1)
            {
                RouteValueDictionary linkRd = new RouteValueDictionary(routeValues);
                linkRd.Add("start", start + count);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.RouteLink("[Next]", route, linkRd, new RouteValueDictionary(htmlAttributes)));
                retvalue.Append("&nbsp;");
                linkRd = new RouteValueDictionary();
                linkRd.Add("start", (total - (total % count)) + 1);
                linkRd.Add("count", count);
                retvalue.Append(htmlHelper.RouteLink("[End]", route, linkRd, new RouteValueDictionary(htmlAttributes)));
            }
            else
            {
                if (total > count)
                {
                    retvalue.Append("[Next]&nbsp;[End]");
                }
            }
            return new MvcHtmlString(retvalue.ToString());
        }

        public static MvcHtmlString PEPagerLink(this HtmlHelper htmlHelper, string linkText, string actionName, int start, int count, object routeValues)
        {
            RouteValueDictionary linkRd = new RouteValueDictionary(routeValues);
            linkRd.Add("start", start);
            linkRd.Add("count", count);
            return htmlHelper.ActionLink(linkText, actionName, linkRd);
        }

        public static MvcHtmlString PEPagerLinkByRoute(this HtmlHelper htmlHelper, string linkText, string routeName, int start, int count, object routeValues)
        {
            RouteValueDictionary linkRd = new RouteValueDictionary(routeValues);
            linkRd.Add("start", start);
            linkRd.Add("count", count);
            return htmlHelper.RouteLink(linkText, routeName, linkRd);
        }

        public static MvcHtmlString PEMessages(this HtmlHelper htmlHelper, TempDataDictionary tempData)
        {
            StringBuilder retvalue = new StringBuilder();
            retvalue.Append("<ul class=\"notify_messages\" style=\"display: none;\">");
            if (htmlHelper.ViewBag.Errors != null && htmlHelper.ViewBag.Errors is List<string>)
            {
                foreach (string error in (List<string>)htmlHelper.ViewBag.Errors)
                {
                    retvalue.Append("<li data-messagetype=\"error\">" + error + "</li>");
                }
            }
            if (tempData["Errors"] != null && tempData["Errors"] is List<string>)
            {
                foreach (string error in (List<string>)tempData["Errors"])
                {
                    retvalue.Append("<li data-messagetype=\"error\">" + error + "</li>");
                }
            }
            if (htmlHelper.ViewBag.Alerts != null && htmlHelper.ViewBag.Alerts is List<string>)
            {
                foreach (string alert in (List<string>)htmlHelper.ViewBag.Alerts)
                {
                    retvalue.Append("<li data-messagetype=\"alert\">" + alert + "</li>");
                }
            }
            if (tempData["Alerts"] != null && tempData["Alerts"] is List<string>)
            {
                foreach (string alert in (List<string>)tempData["Alerts"])
                {
                    retvalue.Append("<li data-messagetype=\"alert\">" + alert + "</li>");
                }
            }
            retvalue.Append("</ul>");
            return new MvcHtmlString(retvalue.ToString());
        }
    }

    public static class UrlHelperExtensions
    {
        
    }
}