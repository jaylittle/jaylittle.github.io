﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Routing;

namespace PEngine4.Core.MVC
{
    public class NotEqual : IRouteConstraint
    {
        private List<string> _match = new List<string>();

        public NotEqual(string match)
        {
            _match = new List<string>() { match };
        }

        public NotEqual(List<string> match)
        {
            _match = match;
        }

        public bool Match(HttpContextBase httpContext, Route route, string parameterName, RouteValueDictionary values, RouteDirection routeDirection)
        {
            bool retvalue = false;
            foreach (string match in _match)
            {
                //if (String.Compare(values[parameterName].ToString(), match, true) != 0)
                if (!String.Equals(values[parameterName].ToString(), match, StringComparison.OrdinalIgnoreCase))
                {
                    retvalue = true;
                }
            }
            return retvalue;
        }
    }
}
