﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using PEngine4.Core;
using PEngine4.Core.TempClasses;
using PEngine4.Core.Model;
using PEngine4.Core.Services;

namespace PEngine4.Core
{
    public class PEngineController : Controller
    {
        protected PEngine4.Core.Security.Token _token = null;
        protected string _accessText = string.Empty;

        public PEngineController() : base()
        {
            
        }

        public void SetupPEngineViewBag()
        {
            SetupPEngineViewBag(null);
        }

        public void SetupPEngineViewBag(int? articleId)
        {
            string location = (string)Request.ServerVariables["SERVER_NAME"]
                + ":" + Request.ServerVariables["SERVER_PORT"]
                + Request.ApplicationPath;

            if (Session["access"] == null)
            {
                Session["access"] = new PEngine4.Core.Security.Token();
            }
            _token = (PEngine4.Core.Security.Token)Session["access"];
            string[] anames = Enum.GetNames(typeof(Helpers.AccessLevel));
            for (int aptr = 0; aptr < anames.Length; aptr++)
            {
                Helpers.AccessLevel alevel = (Helpers.AccessLevel)Enum.Parse(typeof(Helpers.AccessLevel), anames[aptr], true);
                if ((alevel != Helpers.AccessLevel.none) && (_token.Has(alevel)))
                {
                    if (_accessText != string.Empty)
                    {
                        _accessText += ", ";
                    }
                    _accessText += alevel.ToString();
                }
            }

            this.ViewBag.HeaderText = (string)Settings.Query(Settings.AppSettingKey.app_default_title);
            this.ViewBag.Title = this.ViewBag.HeaderText + (!string.IsNullOrEmpty(_accessText) ? " (" + _accessText + ")" : string.Empty);
            this.ViewBag.ExcludeElite = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_leet);
            this.ViewBag.ExcludeLogo = (!string.IsNullOrEmpty((string)Settings.Query(Settings.AppSettingKey.app_logo_frontpage)) ? false : true);
            this.ViewBag.ExcludeSearch = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_search);
            this.ViewBag.ExcludeEmail = !string.IsNullOrEmpty((string)Settings.Query(Settings.AppSettingKey.app_owner_email)) ? false : true;
            this.ViewBag.ExcludeQuote = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_quotes);
            this.ViewBag.ExcludeQuoteToggle = (bool)Settings.Query(Settings.AppSettingKey.app_notoggle_quote);
            this.ViewBag.ExcludeResume = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_resume);
            this.ViewBag.ExcludeRSS = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_rss);
            this.ViewBag.ExcludeTheme = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_theme);
            this.ViewBag.LabelHome = (string)Settings.Query(Settings.AppSettingKey.app_label_home);
            this.ViewBag.LabelLogin = (string)Settings.Query(Settings.AppSettingKey.app_label_admin);
            this.ViewBag.LabelLogout = (string)Settings.Query(Settings.AppSettingKey.app_label_admin2);
            this.ViewBag.LabelEliteOn = (string)Settings.Query(Settings.AppSettingKey.app_label_leet);
            this.ViewBag.LabelEliteOff = (string)Settings.Query(Settings.AppSettingKey.app_label_leet2);
            this.ViewBag.LabelQuote = (string)Settings.Query(Settings.AppSettingKey.app_label_quote);
            this.ViewBag.LabelResume = (string)Settings.Query(Settings.AppSettingKey.app_label_resume);
            this.ViewBag.LabelTheme = (string)Settings.Query(Settings.AppSettingKey.app_label_theme);
            this.ViewBag.LabelClippyButton = (string)Settings.Query(Settings.AppSettingKey.app_label_clippy_button);
            this.ViewBag.LinkRSS = Url.Action("RSS", "Feed");
            this.ViewBag.LinkEmail = (string)Settings.Query(Settings.AppSettingKey.app_owner_email);
            this.ViewBag.LinkLogo = Helpers.AppPath() + "Images/System/" + (string)Settings.Query(Settings.AppSettingKey.app_logo_frontpage);
            this.ViewBag.HasAdmin = _token.Has(Helpers.AccessLevel.admin);
            this.ViewBag.CurrentTheme = PEngine4.Core.Helpers.ThemeChoose(System.Web.HttpContext.Current);
            this.ViewBag.LinkTheme = "~/Themes/" + this.ViewBag.CurrentTheme + "/" + this.ViewBag.CurrentTheme + ".css";
            this.ViewBag.ClippyRandomChance = Convert.ToDecimal((int)Settings.Query(Settings.AppSettingKey.app_clippy_random_chance)) / 100;
            this.ViewBag.ClippyKeyCode = (int)Settings.Query(Settings.AppSettingKey.app_clippy_shortcut_keycode);
            this.ViewBag.ClippyKeyCount = (int)Settings.Query(Settings.AppSettingKey.app_clippy_shortcut_keycount);
            this.ViewBag.ExcludeClippyButton = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_clippy_button);
            this.ViewBag.ExcludeClippyShortcut = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_clippy_shortcut);
            this.ViewBag.ClippyQuoteMode = (bool)Settings.Query(Settings.AppSettingKey.app_clippy_quote_mode);
            this.ViewBag.SummaryTitle = string.Empty;
            this.ViewBag.SummaryDescription = string.Empty;
            this.ViewBag.SummaryUrl = Request.Url.ToString();
            this.ViewBag.SummaryImage = "http://" + location + "/images/system/" + (string) Settings.Query(Settings.AppSettingKey.app_logo_frontpage);
            this.ViewBag.SummarySite = (string)Settings.Query(Settings.AppSettingKey.app_default_title);
            this.ViewBag.LabelForum = (string)Settings.Query(Settings.AppSettingKey.app_label_forum);
            this.ViewBag.LabelForumLogin = (string)Settings.Query(Settings.AppSettingKey.app_label_forum_login);
            this.ViewBag.LabelForumLogoff = (string)Settings.Query(Settings.AppSettingKey.app_label_forum_logout);
            this.ViewBag.ExcludeForum = (bool)Settings.Query(Settings.AppSettingKey.app_exclude_forum);
            this.ViewBag.HasForum = _token.Has(Helpers.AccessLevel.forum);
            this.ViewBag.HasForumAdmin = _token.Has(Helpers.AccessLevel.forumadmin);
            this.ViewBag.LabelForumRegister = (string)Settings.Query(Settings.AppSettingKey.app_label_forum_register);
            this.ViewBag.BaseForumLink = Url.RouteUrl("BaseForum");
            this.ViewBag.ForumGuid = string.Empty;
            this.ViewBag.ForumName = string.Empty;
            this.ViewBag.ForumLink = "#";
            this.ViewBag.ForumThreadGuid = string.Empty;
            this.ViewBag.ForumThreadTitle = string.Empty;
            this.ViewBag.ForumThreadLink = "#";
            this.ViewBag.ForumThreadLock = false;
            this.ViewBag.ForumUserGuid = _token.ForumUserGuid;
            this.ViewBag.AllUsersLink = Url.RouteUrl("AllUsers");

            if (System.IO.File.Exists(Server.MapPath("~/Scripts/site.custom.js")))
            {
                this.ViewBag.CustomJSFlag = true;
            }
            else
            {
                this.ViewBag.CustomJSFlag = false;
            }

            this.ViewBag.MenuButtons = new List<Button>();
            object areaName = string.Empty;
            ControllerContext.RouteData.DataTokens.TryGetValue("area", out areaName);
            if (areaName != null && areaName is string && !string.IsNullOrEmpty((string)areaName)
                && ((string)areaName).Equals("forum", StringComparison.OrdinalIgnoreCase))
            {
                this.ViewBag.IsForum = true;

                //Handle Menu Buttons
                this.ViewBag.MenuButtons.Add(new Button(Url.Action("index", "post", new { area = string.Empty }), this.ViewBag.LabelHome, string.Empty));
                this.ViewBag.MenuButtons.Add(new Button(Url.RouteUrl("BaseForum"), this.ViewBag.LabelForum, string.Empty));
            }
            else
            {
                this.ViewBag.IsForum = false;

                //Handle Menu Buttons
                this.ViewBag.MenuButtons.Add(new Button(Url.Action("index", "post"), this.ViewBag.LabelHome, string.Empty));
                if (!this.ViewBag.ExcludeResume)
                {
                    this.ViewBag.MenuButtons.Add(new Button(Url.Action("index", "resume"), this.ViewBag.LabelResume, string.Empty));
                }
                if (!this.ViewBag.ExcludeForum)
                {
                    this.ViewBag.MenuButtons.Add(new Button(Url.RouteUrl("BaseForum"), this.ViewBag.LabelForum, string.Empty));
                }

                Services.ArticleService articleService = new Services.ArticleService();
                List<Category> articleCategories = articleService.CategoryList(_token.Has(Helpers.AccessLevel.admin));
                foreach (Category articleCategory in articleCategories)
                {
                    this.ViewBag.MenuButtons.Add(new Button(
                        string.IsNullOrEmpty(articleCategory.LinkURL) ?
                        Url.Action("category", "article", new { id = articleCategory.Name }) :
                        articleCategory.LinkURL, articleCategory.Name, string.Empty)
                    );
                }
            }
        }

        public ActionResult ProcessLegacyRequest(bool adminFlag)
        {
            ActionResult res = res = RedirectToRoute("Default", new { controller = "post", action = "index" });
            Response.StatusCode = 301;
            string cmd = !string.IsNullOrEmpty(Request.QueryString["cmd"]) ? Request.QueryString["cmd"] : string.Empty;
            string sub = !string.IsNullOrEmpty(Request.QueryString["sub"]) ? Request.QueryString["sub"] : string.Empty;
            string id = !string.IsNullOrEmpty(Request.QueryString["id"]) ? Request.QueryString["id"] : string.Empty;
            switch (cmd.ToLower().Trim())
            {
                case "resume":
                    if (sub.ToLower().Trim() == "display")
                    {
                        res = res = RedirectToRoute("Default", new { controller = "resume", action = "index" });
                    }
                    break;
                case "article":
                    if (sub.ToLower().Trim() == "display" && !string.IsNullOrEmpty(id))
                    {
                        int articleId = Convert.ToInt32(id);
                        ArticleService articleService = new ArticleService();
                        Article article = articleService.ArticleGet(articleId, adminFlag);
                        if (article != null)
                        {
                            res = res = RedirectToRoute("Default", new { controller = "article", action = "view", id = article.UniqueName });
                            string sectionName = !string.IsNullOrEmpty(Request.QueryString["section"]) ? Request.QueryString["section"] : string.Empty;
                            if (!string.IsNullOrEmpty(sectionName))
                            {
                                ArticleSection section = articleService.SectionGet(articleId, sectionName, adminFlag);
                                if (section != null)
                                {
                                    res = RedirectToRoute("NamedArticle", new { controller = "article", action = "view", id = article.UniqueName, sectionUniqueName = section.UniqueName });
                                }
                            }
                        }
                    }
                    else if (sub.ToLower().Trim() == "browse" && !string.IsNullOrEmpty(Request.QueryString["category"]))
                    {
                        string category = Request.QueryString["category"];
                        res = RedirectToRoute("Default", new { controller = "article", action = "category", id = category });
                    }
                    break;
                case "news":
                    if (sub.ToLower().Trim() == "display" && !string.IsNullOrEmpty(id))
                    {
                        int postId = Convert.ToInt32(id);
                        PostService postService = new PostService();
                        Post post = postService.PostGet(postId, adminFlag);
                        if (post != null)
                        {
                            res = res = RedirectToRoute("Default", new { controller = "post", action = "view", year = post.CreatedUTC.Value.Year, month = post.CreatedUTC.Value.Month, uniqueName = post.UniqueName });
                        }
                    }
                    else if (sub.ToLower().Trim() == "browse")
                    {
                        res = res = RedirectToRoute("Default", new { controller = "post", action = "list" });
                    }
                    break;
            }
            return res;
        }
    }
}
