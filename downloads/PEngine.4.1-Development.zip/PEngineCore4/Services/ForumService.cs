﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;
using PEngine4.Core.TempClasses;

namespace PEngine4.Core.Services
{
    public class ForumService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();
        private bool _useCacheFlag = true;

        public Model.Forum ForumGet(Guid forumGuid, bool adminFlag)
        {
            string cacheKey = "Forum:Guid:" + forumGuid.ToString() + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.Forum>(cacheKey);
            }
            else
            {
                Model.Forum forum = _dbContext.Fora.Where(o => o.Guid == forumGuid && (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, forum);
                return forum;
            }
        }

        public Model.Forum ForumGet(string uniqueName, bool adminFlag)
        {
            string cacheKey = "Forum:Name:" + uniqueName + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.Forum>(cacheKey);
            }
            else
            {
                Model.Forum forum = _dbContext.Fora.Where(o => o.UniqueName == uniqueName &&
                    (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, forum);
                return forum;
            }
        }

        public List<Model.Forum> ForumList(int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumList(start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.Forum> ForumList(int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.Fora.Where(o => o.VisibleFlag || adminFlag).Count();
            IEntitySorter<Model.Forum> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.Forum>.OrderBy(sortBy) : EntitySorter<Model.Forum>.OrderByDescending(sortBy);
            List<Model.Forum> retvalue = sorter.Sort(_dbContext.Fora).Where(o => o.VisibleFlag || adminFlag)
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public void ForumDelete(Guid forumGuid, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.Forum target = ForumGet(forumGuid, true);
            int totalThreads = 0;
            List<Model.ForumThread> threads = ForumThreadList(forumGuid, 1, 1, ref totalThreads, true);
            if (totalThreads > 0)
            {
                errors.Add("This forum cannot be deleted while there are threads associated with it.");
            }
            if (!adminFlag)
            {
                errors.Add("This forum can only be deleted by an Administrator.");
            }
            if (errors.Count <= 0 && target != null)
            {
                _dbContext.Fora.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("Forum:Guid:" + target.Guid.ToString() + ":true"
                    , "Forum:Name:" + target.UniqueName + ":true"
                    , "Forum:Guid:" + target.Guid.ToString() + ":false"
                    , "Forum:Name:" + target.UniqueName + ":false");
            }
            _useCacheFlag = true;
        }

        public Model.Forum ForumSave(Model.Forum entity, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.Forum retvalue = null;
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Name is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Description))
            {
                errors.Add("Description is a required field!");
            }
            if (!adminFlag)
            {
                errors.Add("Forums can only be edited and created by Administrators.");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.Forum();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Name);
                    List<Model.Forum> dupes = _dbContext.Fora.Where(o => 
                        o.UniqueName.StartsWith(retvalue.UniqueName)).ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = ForumGet(entity.Guid, true);
                }
                retvalue.Name = entity.Name;
                retvalue.Description = entity.Description;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                retvalue.VisibleFlag = entity.VisibleFlag;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.Fora.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("Forum:Guid:" + retvalue.Guid.ToString() + ":true"
                    , "Forum:Guid:" + retvalue.Guid.ToString() + ":false"
                    , "Forum:Name:" + retvalue.UniqueName + ":true"
                    , "Forum:Name:" + retvalue.UniqueName + ":false");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ForumUser ForumUserGet(Guid forumUserGuid, bool adminFlag)
        {
            string cacheKey = "ForumUser:Guid:" + forumUserGuid.ToString() + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.ForumUser>(cacheKey);
            }
            else
            {
                Model.ForumUser forumUser = _dbContext.ForumUsers.Where(o => o.Guid == forumUserGuid).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, forumUser);
                return forumUser;
            }
        }

        public Model.ForumUser ForumUserGet(string userID, bool adminFlag)
        {
            string cacheKey = "ForumUser:UserID:" + userID.ToString() + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.ForumUser>(cacheKey);
            }
            else
            {
                Model.ForumUser forumUser = _dbContext.ForumUsers.Where(o => o.UserID == userID).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, forumUser);
                return forumUser;
            }
        }

        public List<Model.ForumUser> ForumUserList(int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumUserList(start, count, "UserID", true, ref totalRecs, adminFlag);
        }

        public List<Model.ForumUser> ForumUserList(int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumUsers.Count();
            IEntitySorter<Model.ForumUser> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumUser>.OrderBy(sortBy) : EntitySorter<Model.ForumUser>.OrderByDescending(sortBy);
            List<Model.ForumUser> retvalue = sorter.Sort(_dbContext.ForumUsers).Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public void ForumUserDelete(Guid forumUserGuid, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.ForumUser target = ForumUserGet(forumUserGuid, true);
            int totalThreads = 0;
            int totalPosts = 0;
            List<Model.ForumThread> threads = ForumThreadListByUser(forumUserGuid, 1, 1, ref totalThreads, true);
            List<Model.ForumThreadPost> posts = ForumThreadPostListByUser(forumUserGuid, 1, 1, ref totalPosts, true);
            if (totalThreads > 0 || totalPosts > 0)
            {
                errors.Add("This user cannot be deleted while there are threads or posts associated with it.");
            }
            if (!adminFlag)
            {
                errors.Add("This user can only be deleted by an Administrator.");
            }
            if (errors.Count <= 0 && target != null)
            {
                _dbContext.ForumUsers.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ForumUser:Guid:" + target.Guid.ToString() + " :true"
                    , "ForumUser:Guid:" + target.Guid.ToString() + ":false"
                    , "ForumUser:UserID:" + target.UserID + ":true"
                    , "ForumUser:UserID:" + target.UserID + ":false");
            }
            _useCacheFlag = true;
        }

        public Model.ForumUser ForumUserSave(Model.ForumUser entity, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.ForumUser retvalue = null;
            if (entity.Guid == Guid.Empty)
            {
                if (string.IsNullOrEmpty(entity.UserID))
                {
                    errors.Add("User ID is a required field!");
                }
                else
                {
                    if (_dbContext.ForumUsers.Where(o => (o.Guid != entity.Guid && o.UserID.Equals(entity.UserID, StringComparison.OrdinalIgnoreCase))).Count() > 0)
                    {
                        errors.Add("User IDs must be unique!");
                    }
                }
                if (string.IsNullOrEmpty(entity.Password))
                {
                    errors.Add("New User Accounts must have a password assigned to them!");
                }
            }
            if (string.IsNullOrEmpty(entity.Email))
            {
                errors.Add("Email is a required field!");
            }
            else
            {
                if (!entity.Email.Contains("@") || !entity.Email.Contains("."))
                {
                    errors.Add("Email is imporperly formatted!");
                }
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ForumUser();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.UserID = entity.UserID;
                    retvalue.AdminFlag = false;
                    retvalue.BanFlag = false;
                    retvalue.LastLogon = null;
                    retvalue.LastIPAddress = entity.LastIPAddress;
                }
                else
                {
                    retvalue = ForumUserGet(entity.Guid, true);
                }
                retvalue.Comment = entity.Comment;
                retvalue.Email = entity.Email;
                if (!string.IsNullOrEmpty(entity.Password))
                {
                    retvalue.Password = Helpers.PasswordEncrypt(entity.Password);
                }
                retvalue.Website = entity.Website;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (adminFlag)
                {
                    retvalue.AdminFlag = entity.AdminFlag;
                    retvalue.BanFlag = entity.BanFlag;
                    if (!string.IsNullOrEmpty(entity.UserID))
                    {
                        retvalue.UserID = entity.UserID;
                    }
                }
                else if (entity.Guid != currentForumUser && entity.Guid != Guid.Empty)
                {
                    errors.Add("This user can only be edited by itself or an Administrator!");
                }
                if (errors.Count <= 0)
                {
                    if (entity.Guid == Guid.Empty)
                    {
                        _dbContext.ForumUsers.Add(retvalue);
                    }
                    _dbContext.SaveChanges();
                    Helpers.CacheDelete("ForumUser:Guid:" + retvalue.Guid.ToString() + ":true"
                        , "ForumUser:Guid:" + retvalue.Guid.ToString() + ":false"
                        , "ForumUser:UserID:" + retvalue.UserID + ":true"
                        , "ForumUser:UserID:" + retvalue.UserID + ":false");
                }
                else
                {
                    retvalue = null;
                }
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ForumUser ForumUserUpdateLogin(Guid forumUserGuid, string lastIPAddress)
        {
            _useCacheFlag = false;
            Model.ForumUser forumUser = ForumUserGet(forumUserGuid, true);
            if (forumUser != null)
            {
                forumUser.LastIPAddress = lastIPAddress;
                forumUser.LastLogon = DateTime.UtcNow;
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ForumUser:Guid:" + forumUser.Guid.ToString() + ":true"
                    , "ForumUser:Guid:" + forumUser.Guid.ToString() + ":false"
                    , "ForumUser:UserID:" + forumUser.UserID + ":true"
                    , "ForumUser:UserID:" + forumUser.UserID + ":false");
                _useCacheFlag = true;
                return forumUser;
            }
            else
            {
                _useCacheFlag = true;
                return null;
            }
        }

        public Model.ForumThread ForumThreadGet(Guid forumThreadGuid, bool adminFlag)
        {
            string cacheKey = "ForumThread:Guid:" + forumThreadGuid.ToString() + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.ForumThread>(cacheKey);
            }
            else
            {
                Model.ForumThread forumThread = _dbContext.ForumThreads.Where(o => o.Guid == forumThreadGuid && (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, forumThread);
                return forumThread;
            }
        }

        public Model.ForumThread ForumThreadGet(string forumUniqueName, string uniqueName, bool adminFlag)
        {
            string cacheKey = "ForumThread:Name:" + forumUniqueName + ":" + uniqueName + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.ForumThread>(cacheKey);
            }
            else
            {
                Model.ForumThread forumThread = _dbContext.ForumThreads.Where(o => o.UniqueName == uniqueName
                    && o.Forum.UniqueName == forumUniqueName && (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, forumThread);
                return forumThread;
            }
        }

        public List<Model.ForumThread> ForumThreadList(Guid forumGuid, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadList(forumGuid, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThread> ForumThreadList(Guid forumGuid, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumThreads.Where(o => o.ForumGuid == forumGuid && (o.VisibleFlag || adminFlag)).Count();
            IEntitySorter<Model.ForumThread> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumThread>.OrderBy(sortBy) : EntitySorter<Model.ForumThread>.OrderByDescending(sortBy);
            List<Model.ForumThread> retvalue = sorter.Sort(_dbContext.ForumThreads).Where(o => o.ForumGuid == forumGuid && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public List<Model.ForumThread> ForumThreadList(string forumUniqueName, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadList(forumUniqueName, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThread> ForumThreadList(string forumUniqueName, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumThreads.Where(o => o.Forum.UniqueName == forumUniqueName && (o.VisibleFlag || adminFlag)).Count();
            IEntitySorter<Model.ForumThread> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumThread>.OrderBy(sortBy) : EntitySorter<Model.ForumThread>.OrderByDescending(sortBy);
            List<Model.ForumThread> retvalue = sorter.Sort(_dbContext.ForumThreads).Where(o => o.Forum.UniqueName == forumUniqueName && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public List<Model.ForumThread> ForumThreadListByUser(Guid forumUserGuid, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadListByUser(forumUserGuid, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThread> ForumThreadListByUser(Guid forumUserGuid, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumThreads.Where(o => o.ForumUserGuid == forumUserGuid && (o.VisibleFlag || adminFlag)).Count();
            IEntitySorter<Model.ForumThread> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumThread>.OrderBy(sortBy) : EntitySorter<Model.ForumThread>.OrderByDescending(sortBy);
            List<Model.ForumThread> retvalue = sorter.Sort(_dbContext.ForumThreads).Where(o => o.ForumUserGuid == forumUserGuid && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public void ForumThreadDelete(Guid forumThreadGuid, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.ForumThread target = ForumThreadGet(forumThreadGuid, true);
            int maxEditMinutes = (int)Settings.Query(Settings.AppSettingKey.app_timelimit_forum_edit);
            int totalThreadPosts = 0;
            List<Model.ForumThreadPost> threadPosts = ForumThreadPostList(forumThreadGuid, 1, 1, ref totalThreadPosts, true);
            if (totalThreadPosts > 0)
            {
                errors.Add("This thread cannot be deleted while there are posts associated with it.");
            }
            if (!adminFlag && (target.LockFlag || target.ForumUserGuid != currentForumUser || DateTime.UtcNow.Subtract(target.CreatedUTC.Value).TotalMinutes > maxEditMinutes))
            {
                errors.Add("This thread can only be deleted by an Administrator.");
            }
            if (errors.Count <= 0 && target != null)
            {
                _dbContext.ForumThreads.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ForumThread:Guid:" + target.Guid.ToString() + ":true"
                    , "ForumThread:Guid:" + target.Guid.ToString() + ":false"
                    , "ForumThread:Name:" + target.Forum.UniqueName + ":" + target.UniqueName + ":true"
                    , "ForumThread:Name:" + target.Forum.UniqueName + ":" + target.UniqueName + ":false");
            }
            _useCacheFlag = true;
        }

        public Model.ForumThread ForumThreadSave(Model.ForumThread entity, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.ForumThread retvalue = null;
            int maxEditMinutes = (int)Settings.Query(Settings.AppSettingKey.app_timelimit_forum_edit);
            if (string.IsNullOrEmpty(entity.Title))
            {
                errors.Add("Title is a required field!");
            }
            if (entity.ForumGuid == Guid.Empty || _dbContext.Fora.Where(o => o.Guid == entity.ForumGuid).Count() <= 0)
            {
                errors.Add("The thread must be associated with a proper forum!");
            }
            if (entity.Guid == Guid.Empty && (entity.ForumThreadPosts.Count <= 0 || string.IsNullOrEmpty(entity.ForumThreadPosts.First().Data)))
            {
                errors.Add("New threads must have initial post information provided!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ForumThread();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Title);
                    retvalue.ForumUserGuid = currentForumUser;
                    retvalue.VisibleFlag = true;
                    retvalue.LockFlag = false;
                    retvalue.ForumGuid = entity.ForumGuid;
                    List<Model.ForumThread> dupes = _dbContext.ForumThreads.Where(o => 
                        o.ForumGuid == entity.ForumGuid && o.UniqueName.StartsWith(retvalue.UniqueName)).ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = ForumThreadGet(entity.Guid, true);
                    if (!adminFlag && (retvalue.LockFlag || retvalue.ForumUserGuid != currentForumUser || DateTime.UtcNow.Subtract(retvalue.CreatedUTC.Value).TotalMinutes > maxEditMinutes))
                    {
                        errors.Add(string.Format("This thread can only be edited by its creator within {0} minutes of creation or by an Administrator.", maxEditMinutes));
                    }
                }
                if (errors.Count <= 0)
                {
                    retvalue.Title = entity.Title;
                    retvalue.ModifiedUTC = DateTime.UtcNow;
                    if (adminFlag)
                    {
                        retvalue.ForumGuid = entity.ForumGuid;
                        retvalue.VisibleFlag = entity.VisibleFlag;
                        retvalue.LockFlag = entity.LockFlag;
                    }
                    if (entity.Guid == Guid.Empty)
                    {
                        _dbContext.ForumThreads.Add(retvalue);
                    }
                    if (entity.ForumThreadPosts.Count > 0)
                    {
                        Model.ForumThreadPost forumThreadPost = entity.ForumThreadPosts.First();
                        forumThreadPost.ForumThreadGuid = retvalue.Guid;
                        ForumThreadPostSave(forumThreadPost, ref errors, currentForumUser, adminFlag, false);
                    }
                    else
                    {
                        _dbContext.SaveChanges();
                    }
                    Helpers.CacheDelete("ForumThread:Guid:" + retvalue.Guid.ToString() + ":true"
                        , "ForumThread:Guid:" + retvalue.Guid.ToString() + ":false");
                    if (retvalue.Forum != null)
                    {
                        Helpers.CacheDelete("ForumThread:Name:" + retvalue.Forum.UniqueName + ":" + retvalue.UniqueName + ":true"
                            , "ForumThread:Name:" + retvalue.Forum.UniqueName + ":" + retvalue.UniqueName + ":false");
                    }
                    else if (retvalue.ForumGuid != Guid.Empty)
                    {
                        Model.Forum forum = ForumGet(retvalue.ForumGuid, true);
                        if (forum != null)
                        {
                            Helpers.CacheDelete("ForumThread:Name:" + forum.UniqueName + ":" + retvalue.UniqueName + ":true"
                                , "ForumThread:Name:" + forum.UniqueName + ":" + retvalue.UniqueName + ":false");
                        }
                    }
                }
                else
                {
                    retvalue = null;
                }
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ForumThreadPost ForumThreadPostGet(Guid forumThreadPostGuid, bool adminFlag)
        {
            return _dbContext.ForumThreadPosts.Where(o => o.Guid == forumThreadPostGuid && (o.VisibleFlag || adminFlag)).FirstOrDefault();
        }

        public List<Model.ForumThreadPost> ForumThreadPostList(Guid forumThreadGuid, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadPostList(forumThreadGuid, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThreadPost> ForumThreadPostList(Guid forumThreadGuid, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumThreadPosts.Where(o => o.VisibleFlag || adminFlag).Count();
            IEntitySorter<Model.ForumThreadPost> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumThreadPost>.OrderBy(sortBy) : EntitySorter<Model.ForumThreadPost>.OrderByDescending(sortBy);
            List<Model.ForumThreadPost> retvalue = sorter.Sort(_dbContext.ForumThreadPosts).Where(o => o.ForumThreadGuid == forumThreadGuid
                && o.VisibleFlag || adminFlag)
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public List<Model.ForumThreadPost> ForumThreadPostList(Guid forumGuid, string uniqueName, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadPostList(forumGuid, uniqueName, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThreadPost> ForumThreadPostList(Guid forumGuid, string uniqueName, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumThreadPosts.Where(o => o.ForumThread.ForumGuid == forumGuid
                && o.ForumThread.UniqueName == uniqueName && (o.VisibleFlag || adminFlag)).Count();
            IEntitySorter<Model.ForumThreadPost> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumThreadPost>.OrderBy(sortBy) : EntitySorter<Model.ForumThreadPost>.OrderByDescending(sortBy);
            List<Model.ForumThreadPost> retvalue = sorter.Sort(_dbContext.ForumThreadPosts).Where(o =>
                o.ForumThread.ForumGuid == forumGuid && o.ForumThread.UniqueName == uniqueName && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public List<Model.ForumThreadPost> ForumThreadPostList(string forumUniqueName, string uniqueName, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadPostList(forumUniqueName, uniqueName, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThreadPost> ForumThreadPostList(string forumUniqueName, string uniqueName, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            Model.Forum forumData = ForumGet(forumUniqueName, adminFlag);
            return ForumThreadPostList(forumData != null ? forumData.Guid : Guid.Empty, uniqueName, start, count, sortBy, sortAsc, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThreadPost> ForumThreadPostListByUser(Guid forumUserGuid, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ForumThreadPostListByUser(forumUserGuid, start, count, "CreatedUTC", false, ref totalRecs, adminFlag);
        }

        public List<Model.ForumThreadPost> ForumThreadPostListByUser(Guid forumUserGuid, int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.ForumThreadPosts.Where(o => o.ForumUserGuid == forumUserGuid && (o.VisibleFlag || adminFlag)).Count();
            IEntitySorter<Model.ForumThreadPost> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.ForumThreadPost>.OrderBy(sortBy) : EntitySorter<Model.ForumThreadPost>.OrderByDescending(sortBy);
            List<Model.ForumThreadPost> retvalue = sorter.Sort(_dbContext.ForumThreadPosts).Where(o =>
                o.ForumUserGuid == forumUserGuid && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public void ForumThreadPostDelete(Guid forumThreadPostGuid, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            _useCacheFlag = false;
            Model.ForumThreadPost target = ForumThreadPostGet(forumThreadPostGuid, true);
            int maxEditMinutes = (int)Settings.Query(Settings.AppSettingKey.app_timelimit_forum_edit);
            if (!adminFlag && (target.LockFlag || target.ForumThread.LockFlag || target.ForumUserGuid != currentForumUser || DateTime.UtcNow.Subtract(target.CreatedUTC.Value).TotalMinutes > maxEditMinutes))
            {
                errors.Add("This post can only be deleted by an Administrator.");
            }
            if (errors.Count <= 0 && target != null)
            {
                _dbContext.ForumThreadPosts.Remove(target);
                _dbContext.SaveChanges();
            }
            _useCacheFlag = true;
        }

        public Model.ForumThreadPost ForumThreadPostSave(Model.ForumThreadPost entity, ref List<string> errors, Guid currentForumUser, bool adminFlag)
        {
            return ForumThreadPostSave(entity, ref errors, currentForumUser, adminFlag, true);
        }

        public Model.ForumThreadPost ForumThreadPostSave(Model.ForumThreadPost entity, ref List<string> errors, Guid currentForumUser, bool adminFlag, bool updateThreadFlag)
        {
            _useCacheFlag = false;
            Model.ForumThreadPost retvalue = null;
            int maxEditMinutes = (int)Settings.Query(Settings.AppSettingKey.app_timelimit_forum_edit);
            if (string.IsNullOrEmpty(entity.Data))
            {
                errors.Add("Content is a required field!");
            }
            if (entity.ForumThreadGuid == Guid.Empty)
            {
                errors.Add("Thread Posts must be associated with a proper thread!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ForumThreadPost();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.ForumUserGuid = currentForumUser;
                    retvalue.ForumThreadGuid = entity.ForumThreadGuid;
                    retvalue.IPAddress = entity.IPAddress;
                    retvalue.VisibleFlag = true;
                    retvalue.LockFlag = false;
                }
                else
                {
                    retvalue = ForumThreadPostGet(entity.Guid, true);
                    if (!adminFlag && (retvalue.LockFlag || retvalue.ForumThread.LockFlag || retvalue.ForumUserGuid != currentForumUser || DateTime.UtcNow.Subtract(retvalue.CreatedUTC.Value).TotalMinutes > maxEditMinutes))
                    {
                        errors.Add(string.Format("This post can only be edited by its creator within {0} minutes of creation or by an Administrator.", maxEditMinutes));
                    }
                }
                if (errors.Count <= 0)
                {
                    retvalue.Data = entity.Data;
                    retvalue.ModifiedUTC = DateTime.UtcNow;
                    if (adminFlag)
                    {
                        retvalue.VisibleFlag = entity.VisibleFlag;
                        retvalue.LockFlag = entity.LockFlag;
                    }
                    if (entity.Guid == Guid.Empty)
                    {
                        _dbContext.ForumThreadPosts.Add(retvalue);
                    }
                    //Update Thread Modified Date to Match Latest Post (if specified)
                    if (updateThreadFlag)
                    {
                        Model.ForumThread forumThread = ForumThreadGet(retvalue.ForumThreadGuid, true);
                        forumThread.ModifiedUTC = retvalue.ModifiedUTC;
                    }
                    _dbContext.SaveChanges();
                }
                else
                {
                    retvalue = null;
                }
            }
            _useCacheFlag = true;
            return retvalue;
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
