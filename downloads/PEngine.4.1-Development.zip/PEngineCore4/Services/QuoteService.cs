﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;

namespace PEngine4.Core.Services
{
    public class QuoteService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();

        public Model.Quote QuoteRandom()
        {
            int count = _dbContext.Quotes.Count();
            Random rnd = new Random((int)DateTime.Now.TimeOfDay.TotalSeconds);
            if (count > 0)
            {
                return _dbContext.Quotes.OrderBy(o => o.Guid).Skip(rnd.Next(count - 1)).FirstOrDefault();
            }
            else
            {
                return null;
            }
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
