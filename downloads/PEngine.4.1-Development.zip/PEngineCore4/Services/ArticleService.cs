﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;
using PEngine4.Core.TempClasses;

namespace PEngine4.Core.Services
{
    public class ArticleService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();
        private bool _useCacheFlag = true;

        public List<Category> CategoryList(bool adminFlag)
        {
            string cacheKey = "Article:CategoryList:" + adminFlag.ToString().ToLower();
            List<Model.Article> articles = null;
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                articles = Helpers.CacheRetrieve<List<Model.Article>>(cacheKey);
            }
            else
            {
                articles = _dbContext.Articles
                    .Where(o => o.VisibleFlag == true || adminFlag)
                    .ToList();
                Helpers.CacheAddUpdate(cacheKey, articles);
            }
            return articles.OrderBy(o => o.Category)
                .Select(o => new Category(o.Category, o.ContentURL))
                .Distinct(new CategoryComparer())
                .ToList();
        }

        public List<Model.Article> ArticleList(string category, int start, int count, ref int totalRecs, bool adminFlag)
        {
            return ArticleList(category, start, count, "Name", true, ref totalRecs, adminFlag);
        }

        public List<Model.Article> ArticleList(string category,int start, int count, string sortBy, bool sortAsc, ref int totalRecs, bool adminFlag)
        {
            totalRecs = _dbContext.Articles
                .Where(o => o.Category.ToLower() == category.ToLower() && (o.VisibleFlag || adminFlag))
                .Count();
            IEntitySorter<Model.Article> sorter = null;
            sorter = sortAsc ? EntitySorter<Model.Article>.OrderBy(sortBy) : EntitySorter<Model.Article>.OrderByDescending(sortBy);
            List<Model.Article> retvalue = sorter.Sort(_dbContext.Articles)
                .Where(o => o.Category.ToLower() == category.ToLower() && (o.VisibleFlag || adminFlag))
                .Skip(start - 1).Take(count).ToList();
            return retvalue;
        }

        public Model.Article ArticleGet(Guid articleGuid, bool adminFlag)
        {
            string cacheKey = "Article:Guid:" + articleGuid.ToString() + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.Article>(cacheKey);
            }
            else
            {
                Model.Article article = _dbContext.Articles.Where(o => o.Guid == articleGuid && (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, article);
                return article;
            }
        }

        public Model.Article ArticleGet(string uniqueName, bool adminFlag)
        {
            string cacheKey = "Article:Name:" + uniqueName + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.Article>(cacheKey);
            }
            else
            {
                Model.Article article = _dbContext.Articles.Where(o => o.UniqueName == uniqueName && (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, article);
                return article;
            }
        }

        public Model.Article ArticleGet(int articleId, bool adminFlag)
        {
            string cacheKey = "Article:ID:" + articleId.ToString() + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.Article>(cacheKey);
            }
            else
            {
                Model.Article article = _dbContext.Articles.Where(o => o.LegacyID == articleId && (o.VisibleFlag || adminFlag)).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, article);
                return article;
            }
        }

        public void ArticleDelete(Guid articleGuid)
        {
            _useCacheFlag = false;
            Model.Article target = ArticleGet(articleGuid, true);
            if (target != null)
            {
                _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid)
                    .ToList().ForEach(o => { _dbContext.ArticleSections.Remove(o); });
                _dbContext.Articles.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("Article:Guid:" + target.Guid.ToString() + ":true"
                    , "Article:Guid:" + target.Guid.ToString() + ":false"
                    , "Article:Name:" + target.UniqueName + ":true"
                    , "Article:Name:" + target.UniqueName + ":false"
                    , "Article:ID:" + (target.LegacyID.HasValue ? target.LegacyID.ToString() : "DummyLegacyID") + ":true"
                    , "Article:ID:" + (target.LegacyID.HasValue ? target.LegacyID.ToString() : "DummyLegacyID") + ":false"
                    , "Article:CategoryList:true"
                    , "Article.CategoryList:false");
            }
            _useCacheFlag = true;
        }

        public Model.Article ArticleSave(Model.Article entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.Article retvalue = null;
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Article Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Description))
            {
                errors.Add("Article Description is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Category))
            {
                errors.Add("Article Category is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.Article();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Name);
                    List<Model.Article> dupes = _dbContext.Articles
                        .Where(o => o.UniqueName.StartsWith(retvalue.UniqueName))
                        .ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = ArticleGet(entity.Guid, true);
                }
                retvalue.Name = entity.Name;
                retvalue.Description = entity.Description;
                retvalue.Category = entity.Category;
                retvalue.DefaultSection = entity.DefaultSection;
                retvalue.ContentURL = entity.ContentURL;
                retvalue.HideButtonsFlag = entity.HideButtonsFlag;
                retvalue.HideDropDownFlag = entity.HideDropDownFlag;
                retvalue.VisibleFlag = entity.VisibleFlag;
                if (!string.IsNullOrEmpty(entity.AdminPass))
                {
                    if (entity.AdminPass.ToLower() != "[none]")
                    {
                        retvalue.AdminPass = Helpers.PasswordEncrypt(entity.AdminPass);
                    }
                    else
                    {
                        retvalue.AdminPass = string.Empty;
                    }
                }
                else if (retvalue.AdminPass == null)
                {
                    retvalue.AdminPass = string.Empty;
                }
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.Articles.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("Article:Guid:" + retvalue.Guid.ToString() + ":true"
                    , "Article:Guid:" + retvalue.Guid.ToString() + ":false"
                    , "Article:Name:" + retvalue.UniqueName + ":true"
                    , "Article:Name:" + retvalue.UniqueName + ":false"
                    , "Article:ID:" + retvalue.LegacyID + ":true"
                    , "Article:ID:" + retvalue.LegacyID + ":false"
                    , "Article:CategoryList:true"
                    , "Article.CategoryList:false");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ArticleSection SectionGet(Guid articleGuid, string sectionName, bool adminFlag)
        {
            if (string.IsNullOrEmpty(sectionName))
            {
                Model.Article article = ArticleGet(articleGuid, adminFlag);
                sectionName = article.DefaultSection;
            }
            if (!string.IsNullOrEmpty(sectionName))
            {
                string cacheKey = "Section:ArticleGuid:" + articleGuid.ToString() + ":" + sectionName + ":" + adminFlag.ToString().ToLower();
                if (_useCacheFlag && Helpers.CacheContains(cacheKey))
                {
                    return Helpers.CacheRetrieve<Model.ArticleSection>(cacheKey);
                }
                else
                {
                    Model.ArticleSection articleSection = _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid && o.Name == sectionName).FirstOrDefault();
                    Helpers.CacheAddUpdate(cacheKey, articleSection);
                    return articleSection;
                }
            }
            else
            {
                return null;
            }
        }

        public Model.ArticleSection SectionGet(int articleId, string sectionName, bool adminFlag)
        {
            Guid articleGuid = Guid.Empty;
            Model.Article article = ArticleGet(articleId, adminFlag);
            if (article != null)
            {
                articleGuid = article.Guid;
                if (string.IsNullOrEmpty(sectionName))
                {
                    sectionName = article.DefaultSection;
                }
                if (articleGuid != Guid.Empty)
                {
                    string cacheKey = "Section:ArticleID:" + articleId.ToString() + ":" + sectionName + ":" + adminFlag.ToString().ToLower();
                    if (_useCacheFlag && Helpers.CacheContains(cacheKey))
                    {
                        return Helpers.CacheRetrieve<Model.ArticleSection>(cacheKey);
                    }
                    else
                    {
                        Model.ArticleSection articleSection = null;
                        if (!string.IsNullOrEmpty(sectionName))
                        {
                            articleSection = _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid && o.Name == sectionName).FirstOrDefault();
                        }
                        else
                        {
                            articleSection = _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid).OrderBy(o => o.SortOrder).FirstOrDefault();
                        }
                        Helpers.CacheAddUpdate(cacheKey, articleSection);
                        return articleSection;
                    }
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        public Model.ArticleSection SectionGet(Guid sectionGuid)
        {
            string cacheKey = "Section:Guid:" + sectionGuid.ToString();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<Model.ArticleSection>(cacheKey);
            }
            else
            {
                Model.ArticleSection articleSection = _dbContext.ArticleSections.Where(o => o.Guid == sectionGuid).FirstOrDefault();
                Helpers.CacheAddUpdate(cacheKey, articleSection);
                return articleSection;
            }
        }

        public ArticleWithSection ArticleSectionGet(string articleUniqueName, string sectionUniqueName, bool adminFlag)
        {
            string sectionName = string.Empty;
            string cacheKey = "ArticleSection:ArticleName:" + articleUniqueName + ":" + sectionUniqueName + ":" + adminFlag.ToString().ToLower();
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<ArticleWithSection>(cacheKey);
            }
            else
            {
                Model.Article article = ArticleGet(articleUniqueName, adminFlag);
                if (article != null)
                {
                    Model.ArticleSection section = null;
                    if (string.IsNullOrEmpty(sectionUniqueName))
                    {
                        sectionName = article.DefaultSection;
                        if (!string.IsNullOrEmpty(sectionName))
                        {
                            section = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid &&
                                o.Name == sectionName).FirstOrDefault();
                        }
                        else
                        {
                            section = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid)
                                .OrderBy(o => o.SortOrder).FirstOrDefault();
                        }
                    }
                    else
                    {
                        section = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid &&
                            o.UniqueName == sectionUniqueName).FirstOrDefault();
                    }
                    if (section != null)
                    {
                        ArticleWithSection articleWithSection = new ArticleWithSection(article, section);
                        Helpers.CacheAddUpdate(cacheKey, articleWithSection);
                        return articleWithSection;
                    }
                }
            }
            return null;
        }

        public Model.ArticleSection SectionGet(string articleUniqueName, string sectionUniqueName, bool adminFlag)
        {
            string sectionName = string.Empty;
            Model.Article article = ArticleGet(articleUniqueName, adminFlag);
            if (article != null)
            {
                if (string.IsNullOrEmpty(sectionUniqueName))
                {
                    sectionName = article.DefaultSection;
                }
                string cacheKey = "Section:ArticleName:" + articleUniqueName + ":" + sectionUniqueName + ":" + adminFlag.ToString().ToLower();
                if (_useCacheFlag && Helpers.CacheContains(cacheKey))
                {
                    return Helpers.CacheRetrieve<Model.ArticleSection>(cacheKey);
                }
                else
                {
                    Model.ArticleSection articleSection = _dbContext.ArticleSections.Where(o => o.ArticleGuid == article.Guid &&
                        (o.UniqueName == sectionUniqueName || o.Name == sectionName)).FirstOrDefault();
                    Helpers.CacheAddUpdate(cacheKey, articleSection);
                    return articleSection;
                }
            }
            return null;
        }

        public List<Model.ArticleSection> SectionList(Guid articleGuid)
        {
            return _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid).ToList();
        }

        public void SectionDelete(Guid sectionGuid)
        {
            _useCacheFlag = false;
            Model.ArticleSection target = SectionGet(sectionGuid);
            if (target != null)
            {
                _dbContext.ArticleSections.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("Section:ArticleGuid:" + target.Article.Guid.ToString() + ":" + target.Name + ":true"
                    , "Section:ArticleGuid:" + target.Article.Guid.ToString() + ":" + target.Name + ":false"
                    , "Section:ArticleGuid:" + target.Article.Guid.ToString() + "::true"
                    , "Section:ArticleGuid:" + target.Article.Guid.ToString() + "::false"
                    , "Section:ArticleID:" + (target.Article.LegacyID.HasValue ? target.Article.LegacyID.ToString() : "DummyLegacyID") + ":" + target.Name + ":true"
                    , "Section:ArticleID:" + (target.Article.LegacyID.HasValue ? target.Article.LegacyID.ToString() : "DummyLegacyID") + ":" + target.Name + ":false"
                    , "Section:ArticleID:" + (target.Article.LegacyID.HasValue ? target.Article.LegacyID.ToString() : "DummyLegacyID") + "::true"
                    , "Section:ArticleID:" + (target.Article.LegacyID.HasValue ? target.Article.LegacyID.ToString() : "DummyLegacyID") + "::false"
                    , "Section:Guid:" + target.Guid.ToString()
                    , "ArticleSection:ArticleName:" + target.Article.UniqueName + ":" + target.UniqueName + ":true"
                    , "ArticleSection:ArticleName:" + target.Article.UniqueName + ":" + target.UniqueName + ":false"
                    , "ArticleSection:ArticleName:" + target.Article.UniqueName + "::true"
                    , "ArticleSection:ArticleName:" + target.Article.UniqueName + "::false"
                    , "Section:ArticleName:" + target.Article.UniqueName + ":" + target.UniqueName + ":true"
                    , "Section:ArticleName:" + target.Article.UniqueName + ":" + target.UniqueName + ":false"
                    , "Section:ArticleName:" + target.Article.UniqueName + "::true"
                    , "Section:ArticleName:" + target.Article.UniqueName + "::false"
                );
            }
            _useCacheFlag = true;
        }

        public void SectionInvertDelete(Guid articleGuid, List<Guid> currentSectionGuids)
        {
            _useCacheFlag = false;
            _dbContext.ArticleSections.Where(o => o.ArticleGuid == articleGuid)
                .ToList().ForEach(o =>
            {
                if (!currentSectionGuids.Contains(o.Guid))
                {
                    SectionDelete(o.Guid);
                    Helpers.CacheDelete("Section:ArticleGuid:" + o.Article.Guid.ToString() + ":" + o.Name + ":true"
                        , "Section:ArticleGuid:" + o.Article.Guid.ToString() + ":" + o.Name + ":false"
                        , "Section:ArticleGuid:" + o.Article.Guid.ToString() + "::true"
                        , "Section:ArticleGuid:" + o.Article.Guid.ToString() + "::false"
                        , "Section:ArticleID:" + (o.Article.LegacyID.HasValue ? o.Article.LegacyID.ToString() : "DummyLegacyID") + ":" + o.Name + ":true"
                        , "Section:ArticleID:" + (o.Article.LegacyID.HasValue ? o.Article.LegacyID.ToString() : "DummyLegacyID") + ":" + o.Name + ":false"
                        , "Section:ArticleID:" + (o.Article.LegacyID.HasValue ? o.Article.LegacyID.ToString() : "DummyLegacyID") + "::true"
                        , "Section:ArticleID:" + (o.Article.LegacyID.HasValue ? o.Article.LegacyID.ToString() : "DummyLegacyID") + "::false"
                        , "Section:Guid:" + o.Guid.ToString()
                        , "ArticleSection:ArticleName:" + o.Article.UniqueName + ":" + o.UniqueName + ":true"
                        , "ArticleSection:ArticleName:" + o.Article.UniqueName + ":" + o.UniqueName + ":false"
                        , "ArticleSection:ArticleName:" + o.Article.UniqueName + "::true"
                        , "ArticleSection:ArticleName:" + o.Article.UniqueName + "::false"
                        , "Section:ArticleName:" + o.Article.UniqueName + ":" + o.UniqueName + ":true"
                        , "Section:ArticleName:" + o.Article.UniqueName + ":" + o.UniqueName + ":false"
                        , "Section:ArticleName:" + o.Article.UniqueName + "::true"
                        , "Section:ArticleName:" + o.Article.UniqueName + "::false"
                    );
                }
            });
            _useCacheFlag = true;
        }

        public Model.ArticleSection SectionSave(Model.ArticleSection entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.ArticleSection retvalue = null;
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Section Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Data))
            {
                errors.Add("Section Content is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ArticleSection();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                    retvalue.ArticleGuid = entity.ArticleGuid;
                    retvalue.UniqueName = Helpers.GenerateUniqueName(entity.Name);
                    List<Model.ArticleSection> dupes = _dbContext.ArticleSections
                        .Where(o => o.ArticleGuid == retvalue.ArticleGuid && o.UniqueName.StartsWith(retvalue.UniqueName))
                        .ToList();
                    if (dupes != null && dupes.Count > 0)
                    {
                        int uniqueCounter = dupes.Count + 1;
                        bool uniqueFound = false;
                        while (!uniqueFound)
                        {
                            string uniqueName = retvalue.UniqueName + "-" + uniqueCounter.ToString();
                            if (dupes.Where(o => o.UniqueName == uniqueName).Count() > 0)
                            {
                                uniqueCounter++;
                            }
                            else
                            {
                                retvalue.UniqueName = uniqueName;
                                uniqueFound = true;
                            }
                        }
                    }
                }
                else
                {
                    retvalue = SectionGet(entity.Guid);
                }
                retvalue.Name = entity.Name;
                retvalue.Data = entity.Data;
                retvalue.SortOrder = entity.SortOrder;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ArticleSections.Add(retvalue);
                }
                _dbContext.SaveChanges();
                if (retvalue.Article != null)
                {
                    Helpers.CacheDelete("Section:ArticleGuid:" + retvalue.Article.Guid.ToString() + ":" + retvalue.Name + ":true"
                        , "Section:ArticleGuid:" + retvalue.Article.Guid.ToString() + ":" + retvalue.Name + ":false"
                        , "Section:ArticleGuid:" + retvalue.Article.Guid.ToString() + "::true"
                        , "Section:ArticleGuid:" + retvalue.Article.Guid.ToString() + "::false"
                        , "Section:ArticleID:" + (retvalue.Article.LegacyID.HasValue ? retvalue.Article.LegacyID.ToString() : "DummyLegacyID") + ":" + retvalue.Name + ":true"
                        , "Section:ArticleID:" + (retvalue.Article.LegacyID.HasValue ? retvalue.Article.LegacyID.ToString() : "DummyLegacyID") + ":" + retvalue.Name + ":false"
                        , "Section:ArticleID:" + (retvalue.Article.LegacyID.HasValue ? retvalue.Article.LegacyID.ToString() : "DummyLegacyID") + "::true"
                        , "Section:ArticleID:" + (retvalue.Article.LegacyID.HasValue ? retvalue.Article.LegacyID.ToString() : "DummyLegacyID") + "::false"
                        , "Section:Guid:" + retvalue.Guid.ToString()
                        , "ArticleSection:ArticleName:" + retvalue.Article.UniqueName + ":" + retvalue.UniqueName + ":true"
                        , "ArticleSection:ArticleName:" + retvalue.Article.UniqueName + ":" + retvalue.UniqueName + ":false"
                        , "ArticleSection:ArticleName:" + retvalue.Article.UniqueName + "::true"
                        , "ArticleSection:ArticleName:" + retvalue.Article.UniqueName + "::false"
                        , "Section:ArticleName:" + retvalue.Article.UniqueName + ":" + retvalue.UniqueName + ":true"
                        , "Section:ArticleName:" + retvalue.Article.UniqueName + ":" + retvalue.UniqueName + ":false"
                        , "Section:ArticleName:" + retvalue.Article.UniqueName + "::true"
                        , "Section:ArticleName:" + retvalue.Article.UniqueName + "::false"
                    );
                }
                else
                {
                    Model.Article article = ArticleGet(retvalue.ArticleGuid, true);
                    Helpers.CacheDelete("Section:ArticleGuid:" + article.Guid.ToString() + ":" + retvalue.Name + ":true"
                        , "Section:ArticleGuid:" + article.Guid.ToString() + ":" + retvalue.Name + ":false"
                        , "Section:ArticleGuid:" + article.Guid.ToString() + "::true"
                        , "Section:ArticleGuid:" + article.Guid.ToString() + "::false"
                        , "Section:ArticleID:" + (article.LegacyID.HasValue ? article.LegacyID.ToString() : "DummyLegacyID") + ":" + retvalue.Name + ":true"
                        , "Section:ArticleID:" + (article.LegacyID.HasValue ? article.LegacyID.ToString() : "DummyLegacyID") + ":" + retvalue.Name + ":false"
                        , "Section:ArticleID:" + (article.LegacyID.HasValue ? article.LegacyID.ToString() : "DummyLegacyID") + "::true"
                        , "Section:ArticleID:" + (article.LegacyID.HasValue ? article.LegacyID.ToString() : "DummyLegacyID") + "::false"
                        , "Section:Guid:" + retvalue.Guid.ToString()
                        , "ArticleSection:ArticleName:" + article.UniqueName + ":" + retvalue.UniqueName + ":true"
                        , "ArticleSection:ArticleName:" + article.UniqueName + ":" + retvalue.UniqueName + ":false"
                        , "ArticleSection:ArticleName:" + article.UniqueName + "::true"
                        , "ArticleSection:ArticleName:" + article.UniqueName + "::false"
                        , "Section:ArticleName:" + article.UniqueName + ":" + retvalue.UniqueName + ":true"
                        , "Section:ArticleName:" + article.UniqueName + ":" + retvalue.UniqueName + ":false"
                        , "Section:ArticleName:" + article.UniqueName + "::true"
                        , "Section:ArticleName:" + article.UniqueName + "::false"
                    );
                }
            }
            _useCacheFlag = true;
            return retvalue;
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
