﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CuttingEdge.ServiceLayerHelpers;

namespace PEngine4.Core.Services
{
    public class ResumeService : IDisposable
    {
        private Model.PEngineContext _dbContext = Database.Context();
        private bool _useCacheFlag = true;

        public Model.ResumePersonal PersonalGet(Guid personalGuid)
        {
            return _dbContext.ResumePersonals.Where(o => o.Guid == personalGuid).FirstOrDefault();
        }

        public List<Model.ResumePersonal> PersonalList()
        {
            string cacheKey = "ResumePersonal:List";
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<List<Model.ResumePersonal>>(cacheKey);
            }
            else
            {
                List<Model.ResumePersonal> resumePersonals = _dbContext.ResumePersonals.OrderBy(o => o.CreatedUTC).ThenBy(o => o.FullName).ToList();
                Helpers.CacheAddUpdate(cacheKey, resumePersonals);
                return resumePersonals;
            }
        }

        public void PersonalDelete(Guid personalGuid)
        {
            _useCacheFlag = false;
            Model.ResumePersonal target = PersonalGet(personalGuid);
            if (target != null)
            {
                _dbContext.ResumePersonals.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumePersonal:List");
            }
            _useCacheFlag = true;
        }

        public Model.ResumePersonal PersonalSave(Model.ResumePersonal entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.ResumePersonal retvalue = null;
            if (string.IsNullOrEmpty(entity.FullName))
            {
                errors.Add("Personal: Name is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Email))
            {
                errors.Add("Personal: Email is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumePersonal();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = PersonalGet(entity.Guid);
                }
                retvalue.Address1 = entity.Address1;
                retvalue.Address2 = entity.Address2;
                retvalue.City = entity.City;
                retvalue.Email = entity.Email;
                retvalue.Fax = entity.Fax;
                retvalue.FullName = entity.FullName;
                retvalue.Phone = entity.Phone;
                retvalue.State = entity.State;
                retvalue.WebsiteURL = entity.WebsiteURL;
                retvalue.Zip = entity.Zip;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumePersonals.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumePersonal:List");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ResumeEducation EducationGet(Guid educationGuid)
        {
            return _dbContext.ResumeEducations.Where(o => o.Guid == educationGuid).FirstOrDefault();
        }

        public List<Model.ResumeEducation> EducationList()
        {
            string cacheKey = "ResumeEducation:List";
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<List<Model.ResumeEducation>>(cacheKey);
            }
            else
            {
                List<Model.ResumeEducation> resumeEducations = _dbContext.ResumeEducations.OrderByDescending(o => o.Started).ThenByDescending(o => o.Completed).ToList();
                Helpers.CacheAddUpdate(cacheKey, resumeEducations);
                return resumeEducations;
            }
        }

        public void EducationDelete(Guid educationGuid)
        {
            _useCacheFlag = false;
            Model.ResumeEducation target = EducationGet(educationGuid);
            if (target != null)
            {
                _dbContext.ResumeEducations.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeEducation:List");
            }
            _useCacheFlag = true;
        }

        public void EducationInvertDelete(List<Guid> currentEducationGuids)
        {
            _useCacheFlag = false;
            _dbContext.ResumeEducations
                .ToList().ForEach(o =>
                {
                    if (!currentEducationGuids.Contains(o.Guid))
                    {
                        EducationDelete(o.Guid);
                    }
                });
            _useCacheFlag = true;
        }

        public Model.ResumeEducation EducationSave(Model.ResumeEducation entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.ResumeEducation retvalue = null;
            if (string.IsNullOrEmpty(entity.Institute))
            {
                errors.Add("Education: Institute is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Program))
            {
                errors.Add("Education: Program is a required field!");
            }
            if (!entity.Started.HasValue || entity.Started.Value == DateTime.MinValue)
            {
                errors.Add("Education: Date Started is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeEducation();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = EducationGet(entity.Guid);
                }
                retvalue.Completed = entity.Completed;
                retvalue.Institute = entity.Institute;
                retvalue.InstituteURL = entity.InstituteURL;
                retvalue.Program = entity.Program;
                retvalue.Started = entity.Started;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeEducations.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeEducation:List");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ResumeObjective ObjectiveGet(Guid objectiveGuid)
        {
            return _dbContext.ResumeObjectives.Where(o => o.Guid == objectiveGuid).FirstOrDefault();
        }

        public List<Model.ResumeObjective> ObjectiveList()
        {
            string cacheKey = "ResumeObjective:List";
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<List<Model.ResumeObjective>>(cacheKey);
            }
            else
            {
                List<Model.ResumeObjective> resumeObjectives = _dbContext.ResumeObjectives.OrderBy(o => o.CreatedUTC).ToList();
                Helpers.CacheAddUpdate(cacheKey, resumeObjectives);
                return resumeObjectives;
            }
        }

        public void ObjectiveDelete(Guid objectiveGuid)
        {
            _useCacheFlag = false;
            Model.ResumeObjective target = ObjectiveGet(objectiveGuid);
            if (target != null)
            {
                _dbContext.ResumeObjectives.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeObjective:List");
            }
            _useCacheFlag = true;
        }

        public Model.ResumeObjective ObjectiveSave(Model.ResumeObjective entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.ResumeObjective retvalue = null;
            if (string.IsNullOrEmpty(entity.Data))
            {
                errors.Add("Objective: Content is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeObjective();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = ObjectiveGet(entity.Guid);
                }
                retvalue.Data = entity.Data;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeObjectives.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeObjective:List");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ResumeSkill SkillGet(Guid skillGuid)
        {
            return _dbContext.ResumeSkills.Where(o => o.Guid == skillGuid).FirstOrDefault();
        }

        public List<Model.ResumeSkill> SkillList()
        {
            string cacheKey = "ResumeSkill:List";
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<List<Model.ResumeSkill>>(cacheKey);
            }
            else
            {
                List<Model.ResumeSkill> resumeSkills = _dbContext.ResumeSkills.OrderBy(o => o.Type).ThenBy(o => o.Name).ToList();
                Helpers.CacheAddUpdate(cacheKey, resumeSkills);
                return resumeSkills;
            }
        }

        public void SkillDelete(Guid skillGuid)
        {
            _useCacheFlag = false;
            Model.ResumeSkill target = SkillGet(skillGuid);
            if (target != null)
            {
                _dbContext.ResumeSkills.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeSkill:List");
            }
            _useCacheFlag = true;
        }

        public void SkillInvertDelete(List<Guid> currentSkillGuids)
        {
            _useCacheFlag = false;
            _dbContext.ResumeSkills
                .ToList().ForEach(o =>
                {
                    if (!currentSkillGuids.Contains(o.Guid))
                    {
                        SkillDelete(o.Guid);
                    }
                });
            Helpers.CacheDelete("ResumeSkill:List");
            _useCacheFlag = true;
        }

        public Model.ResumeSkill SkillSave(Model.ResumeSkill entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.ResumeSkill retvalue = null;
            if (string.IsNullOrEmpty(entity.Type))
            {
                errors.Add("Skill: Type is a required field!");
            }
            if (string.IsNullOrEmpty(entity.Name))
            {
                errors.Add("Skill: Name is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeSkill();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = SkillGet(entity.Guid);
                }
                retvalue.Hint = entity.Hint != null ? entity.Hint : string.Empty;
                retvalue.Name = entity.Name;
                retvalue.Type = entity.Type;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeSkills.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeSkill:List");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        public Model.ResumeWorkHistory WorkHistoryGet(Guid workHistoryGuid)
        {
            return _dbContext.ResumeWorkHistories.Where(o => o.Guid == workHistoryGuid).FirstOrDefault();
        }

        public List<Model.ResumeWorkHistory> WorkHistoryList()
        {
            string cacheKey = "ResumeWorkHistory:List";
            if (_useCacheFlag && Helpers.CacheContains(cacheKey))
            {
                return Helpers.CacheRetrieve<List<Model.ResumeWorkHistory>>(cacheKey);
            }
            else
            {
                List<Model.ResumeWorkHistory> resumeWorkHistories = _dbContext.ResumeWorkHistories.OrderByDescending(o => o.Started).ThenBy(o => o.Completed).ThenBy(o => o.Employer).ToList();
                Helpers.CacheAddUpdate(cacheKey, resumeWorkHistories);
                return resumeWorkHistories;
            }
        }

        public void WorkHistoryDelete(Guid workHistoryGuid)
        {
            _useCacheFlag = false;
            Model.ResumeWorkHistory target = WorkHistoryGet(workHistoryGuid);
            if (target != null)
            {
                _dbContext.ResumeWorkHistories.Remove(target);
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeWorkHistory:List");
            }
            _useCacheFlag = true;
        }

        public void WorkHistoryInvertDelete(List<Guid> currentWorkHistoryGuids)
        {
            _useCacheFlag = false;
            _dbContext.ResumeWorkHistories
                .ToList().ForEach(o =>
                {
                    if (!currentWorkHistoryGuids.Contains(o.Guid))
                    {
                        WorkHistoryDelete(o.Guid);
                    }
                });
            Helpers.CacheDelete("ResumeWorkHistory:List");
            _useCacheFlag = true;
        }

        public Model.ResumeWorkHistory WorkHistorySave(Model.ResumeWorkHistory entity, ref List<string> errors)
        {
            _useCacheFlag = false;
            Model.ResumeWorkHistory retvalue = null;
            if (string.IsNullOrEmpty(entity.Employer))
            {
                errors.Add("Work History: Employer is a required field!");
            }
            if (string.IsNullOrEmpty(entity.JobTitle))
            {
                errors.Add("Work History: Job Title is a required field!");
            }
            if (string.IsNullOrEmpty(entity.JobDescription))
            {
                errors.Add("Work History: Job Description is a required field!");
            }
            if (!entity.Started.HasValue || entity.Started.Value == DateTime.MinValue)
            {
                errors.Add("Work History: Date Started is a required field!");
            }
            if (errors.Count <= 0)
            {
                if (entity.Guid == Guid.Empty)
                {
                    retvalue = new Model.ResumeWorkHistory();
                    retvalue.Guid = Guid.NewGuid();
                    retvalue.CreatedUTC = DateTime.UtcNow;
                }
                else
                {
                    retvalue = WorkHistoryGet(entity.Guid);
                }
                retvalue.Completed = entity.Completed;
                retvalue.Employer = entity.Employer;
                retvalue.EmployerURL = entity.EmployerURL;
                retvalue.JobDescription = entity.JobDescription;
                retvalue.JobTitle = entity.JobTitle;
                retvalue.Started = entity.Started;
                retvalue.ModifiedUTC = DateTime.UtcNow;
                if (entity.Guid == Guid.Empty)
                {
                    _dbContext.ResumeWorkHistories.Add(retvalue);
                }
                _dbContext.SaveChanges();
                Helpers.CacheDelete("ResumeWorkHistory:List");
            }
            _useCacheFlag = true;
            return retvalue;
        }

        void IDisposable.Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
