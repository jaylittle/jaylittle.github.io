﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEngine4.Core.TempClasses
{
    public class ResumeComplete
    {
        public List<Model.ResumePersonal> Personal { get; set; }
        public List<Model.ResumeObjective> Objective { get; set; }
        public List<Model.ResumeEducation> Education { get; set; }
        public List<Model.ResumeSkill> Skill { get; set; }
        public List<Model.ResumeWorkHistory> WorkHistory { get; set; }

        public ResumeComplete()
        {
            Personal = new List<Model.ResumePersonal>();
            Objective = new List<Model.ResumeObjective>();
            Education = new List<Model.ResumeEducation>();
            Skill = new List<Model.ResumeSkill>();
            WorkHistory = new List<Model.ResumeWorkHistory>();
        }
    }
}
