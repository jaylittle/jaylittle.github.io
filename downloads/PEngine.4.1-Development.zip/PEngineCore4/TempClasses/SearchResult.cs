﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PEngine4.Core.TempClasses
{
    public class SearchResult
    {
        public Guid Guid { get; set; }
        public string Link { get; set; }
        public PEngine4.Core.Helpers.ResourceType Type { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string Content { get; set; }
        public DateTime? Date { get; set; }
        public string Creator { get; set; }
        public Guid CreatorGuid { get; set; }

        public SearchResult(Guid guid, string link, PEngine4.Core.Helpers.ResourceType type, string title, string subTitle, string content, DateTime? date)
        {
            this.Guid = guid;
            this.Link = link;
            this.Type = type;
            this.Title = title;
            this.SubTitle = subTitle;
            this.Content = content;
            this.Date = date;
            this.Creator = "Admin";
            this.CreatorGuid = Guid.Empty;
        }

        public SearchResult(Guid guid, string link, PEngine4.Core.Helpers.ResourceType type, string title, string subTitle, string content, DateTime? date, string creator, Guid creatorGuid)
        {
            this.Guid = guid;
            this.Link = link;
            this.Type = type;
            this.Title = title;
            this.SubTitle = subTitle;
            this.Content = content;
            this.Date = date;
            this.Creator = creator;
            this.CreatorGuid = creatorGuid;
        }

        public bool IsCreator
        {
            get
            {
                if (HttpContext.Current.Session["access"] == null)
                {
                    HttpContext.Current.Session["access"] = new PEngine4.Core.Security.Token();
                }
                PEngine4.Core.Security.Token token = (PEngine4.Core.Security.Token)HttpContext.Current.Session["access"];
                switch (this.Type)
                {
                    case Helpers.ResourceType.Forum:
                        if (this.CreatorGuid.Equals(token.ForumUserGuid))
                        {
                            return true;
                        }
                        break;
                    default:
                        return true;
                        break;
                }
                return false;
            }
        }
    }
}
