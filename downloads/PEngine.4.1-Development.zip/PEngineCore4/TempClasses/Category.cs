﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEngine4.Core.TempClasses
{
    public class Category
    {
        public string Name { get; set; }
        public string LinkURL { get; set; }

        public Category(string name, string linkURL)
        {
            this.Name = name;
            this.LinkURL = linkURL;
        }
    }

    public class CategoryComparer : EqualityComparer<Category>
    {
        public override bool Equals(Category x, Category y)
        {
            return (x.Name.Equals(y.Name) && x.LinkURL.Equals(y.LinkURL));
        }

        public override int GetHashCode(Category obj)
        {
            return (obj.Name + "|" + obj.LinkURL).GetHashCode();
        }
    }
}
