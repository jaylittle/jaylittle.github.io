﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEngine4.Core.TempClasses
{
    public class ArticleWithSection
    {
        public Model.Article Article { get; set; }
        public Model.ArticleSection Section { get; set; }

        public ArticleWithSection(Model.Article article, Model.ArticleSection section)
        {
            this.Article = article;
            this.Section = section;
        }
    }
}
