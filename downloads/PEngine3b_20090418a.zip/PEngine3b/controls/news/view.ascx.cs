using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_news_view : System.Web.UI.UserControl
{
    private int m_newsid = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            News_Init();
            News_Display(m_newsid);
        }
    }

    private void News_Init()
    {
        if (!string.IsNullOrEmpty(Request["id"]))
        {
            m_newsid = Convert.ToInt32(Request["id"]);
        }
    }

    private void News_Display(int id)
    {
        news newsobj = new news(system.conn_pengine);
        DataTable newslist = null;
        if (id > 0)
        {
            newslist = newsobj.news_get(id);
        }
        else
        {
            newslist = newsobj.news_current();
        }
        newsobj.close();
        rptnews.DataSource = newslist;
        rptnews.DataBind();
    }

    protected void rptnews_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (has_admin())
        {
            int id = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName.ToLower())
            {
                case "new":
                    Response.Redirect(system.url_base + "default.aspx?cmd=news&sub=edit");
                    break;
                case "edit":
                    Response.Redirect(system.url_base + "default.aspx?cmd=news&sub=edit&id=" + id.ToString());
                    break;
                case "delete":
                    news newobj = new news(system.conn_pengine);
                    newobj.news_delete(id);
                    newobj.close();
                    if (m_newsid > 0)
                    {
                        News_Display(m_newsid);
                    }
                    else
                    {
                        Response.Redirect(Request.Url.ToString());
                    }
                    break;
            }
        }
    }

    public bool has_admin()
    {
        access token = (access) Session["token"];
        if (token.has(system.access_level.admin))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public string browse_link()
    {
        return system.url_base + "?cmd=news&sub=browse";
    }

    public string icon_build(DataRowView drow)
    {
        if ((drow.DataView.Table.Columns.Contains("iconfilename"))
            && (!Convert.IsDBNull(drow["iconfilename"])))
        {
            return system.html_icon((string)drow["iconfilename"]);
        }
        else
        {
            return string.Empty;
        }
    }

    protected string Confirm_Delete(string title)
    {
        return "return click_confirm_pass('Are you sure you wish to delete \\'"
            + system.javascript_escape(title) + "\\'?');";
    }

    protected bool quote_show()
    {
        if ((m_newsid > 0)
                || ((bool)pengine.settings.query(settings.app_setting_key.app_exclude_quotes) == true))
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    protected bool quote_toggle()
    {
        if ((m_newsid > 0)
                || ((bool)pengine.settings.query(settings.app_setting_key.app_notoggle_quote) == true))
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    protected string quote_title()
    {
        if (quote_show())
        {
            return (string)pengine.settings.query(settings.app_setting_key.app_label_quote);
        }
        else
        {
            return string.Empty;
        }
    }

    protected string quote_get()
    {
        if (quote_show())
        {
            pengine.quote qobj = new pengine.quote(pengine.system.conn_pengine);
            return qobj.quote_random().Replace("<br>","<br/>").Replace("<BR>","<br/>");
        }
        else
        {
            return string.Empty;
        }
    }
}
