using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_search_list : System.Web.UI.UserControl
{
    private enum source
    {
        none,
        pengine,
        forum
    }

    private source m_source = source.none;
    private int m_uid = 0;
    private string m_queryterm = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(Request["source"]))
        {
            switch (Request["source"].ToLower())
            {
                case "news":
                case "article":
                case "pengine":
                    m_source = source.pengine;
                    break;
                case "forum":
                    if (!(bool)settings.query(settings.app_setting_key.app_exclude_forum))
                    {
                        m_source = source.forum;
                    }
                    break;
            }
        }
        if ((!string.IsNullOrEmpty(Request["uid"])) && (system.IsNumeric(Request["uid"])))
        {
            m_uid = Convert.ToInt32(Request["uid"]);
        }
        if (!string.IsNullOrEmpty(Request["queryterm"]))
        {
            m_queryterm = Request["queryterm"];
        }
        if (!this.IsPostBack)
        {
            Search_Bind();
        }
    }

    private void Search_Bind()
    {
        DataTable results = Search_Get();
        if (results != null)
        {
            grdresults.PageSize = (int)settings.query(settings.app_setting_key.app_recpage_search_results);
            grdresults.DataSource = results;
            grdresults.DataBind();
        }
    }

    private DataTable Search_Get()
    {
        DataTable results = null;
        search objsea = null;
        switch (m_source)
        {
            case source.forum:
                objsea = new search(system.conn_forum);
                results = objsea.search_exec(m_queryterm, m_uid, true);
                if (results != null)
                {
                    lblHeader.Text = "Forum search results (" + results.Rows.Count.ToString() + " items)";
                }
                objsea.close();
                break;
            case source.pengine:
                objsea = new search(system.conn_pengine);
                results = objsea.search_exec(m_queryterm, m_uid, false);
                if (results != null)
                {
                    lblHeader.Text = "Article & News search results (" + results.Rows.Count.ToString() + " items)";
                }
                objsea.close();
                break;
        }
        return results;
    }

    protected void grdresults_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdresults.PageIndex = e.NewPageIndex;
        Search_Bind();
    }

    protected void grdresults_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }

    protected void grdresults_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView cRow = (DataRowView)e.Row.DataItem;
            Button btnView = (Button)e.Row.FindControl("btnView");
            if (btnView != null)
            {
                switch (((string) cRow["Type"]).ToUpper())
                {
                    case "ARTICLE":
                        btnView.Attributes.Add("onclick", "click_go('" + search.search_link((int) cRow["ID"]
                            , search.search_type.Article, "&section=" + (string)cRow["SectionName"]) + "'); return false;");
                        break;
                    case "NEWS":
                        btnView.Attributes.Add("onclick", "click_go('" + search.search_link((int)cRow["ID"]
                            , search.search_type.News) + "'); return false;");
                        break;
                    case "FORUM":
                        btnView.Attributes.Add("onclick", "click_go('" + search.search_link((int)cRow["ID"]
                            , search.search_type.Forum, "#" + ((int)cRow["ID"]).ToString()) + "'); return false;");
                        break;
                }
            }
        }
    }

    protected void grdresults_Sorting(object sender, GridViewSortEventArgs e)
    {

    }
}
