using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_article_view : System.Web.UI.UserControl
{
    private int m_articleid = 0;
    private string m_section = string.Empty;
    private string m_lsection = string.Empty;
    private string m_nsection = string.Empty;
    private string m_category = string.Empty;
    protected bool m_hidedd = false;
    protected string m_data = string.Empty;
    protected string m_title = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        Article_Init();
        if (!this.IsPostBack)
        {
            Article_Display(m_articleid, m_section);
            this.lblHeader.Text = "Viewing Existing Article \"" + m_title;
            if ((m_section != string.Empty) && (m_section != m_title) && (m_hidedd))
            {
                this.lblHeader.Text += " - " + m_section + "\"";
            }
            else
            {
                this.lblHeader.Text += "\"";
            }
            btndelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this article?')");
        }
    }

    protected void lstsection_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect(Article_URL(m_articleid, lstsection.SelectedValue));
    }

    protected void lstsection2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect(Article_URL(m_articleid, lstsection2.SelectedValue));
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        Response.Redirect(system.url_base + "default.aspx?cmd=article&sub=edit&id=" + (m_articleid).ToString());
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        article artobj = new article(system.conn_pengine);
        artobj.article_delete(m_articleid);
        artobj.close();
        Response.Redirect(system.url_base + "?cmd=article&sub=browse&category=" + Server.UrlEncode(m_category));
    }

    private string Article_URL(int id, string section)
    {
        if (section != string.Empty)
        {
            return system.url_base + "?cmd=article&sub=display&id="
                + id.ToString() + "&section=" + Server.UrlEncode(section);
        }
        else
        {
            return string.Empty;
        }
    }

    private void Article_Init()
    {
        if (!string.IsNullOrEmpty(Request["id"]))
        {
            m_articleid = Convert.ToInt32(Request["id"]);
        }
        if (!string.IsNullOrEmpty(Request["section"]))
        {
            m_section = Request["section"];
        }
    }

    private void Article_Display(int id, string section)
    {
        article artobj = new article(system.conn_pengine);
        this.lstsection.Items.Clear();
        this.lstsection2.Items.Clear();
        if (string.IsNullOrEmpty(m_section))
        {
            m_section = artobj.section_default(id);
        }
        DataTable artdata = artobj.article_get(id);
        DataTable secdata = artobj.section_get(id, m_section);
        if ((artdata != null) && (artdata.Rows.Count > 0)
            && (secdata != null) && (secdata.Rows.Count > 0))
        {
            if (((bool)artdata.Rows[0]["Visible"] == true) || (has_admin()))
            {
                DataTable seclist = artobj.section_getall(m_articleid);
                m_category = (string)artdata.Rows[0]["Category"];
                m_title = (string)artdata.Rows[0]["Name"];
                if (seclist.Rows.Count == 1)
                {
                    m_hidedd = true;
                }
                else
                {
                    m_hidedd = Convert.ToBoolean(artdata.Rows[0]["HideDropDown"]);
                }
                for (int secptr = 0; secptr < seclist.Rows.Count; secptr++)
                {
                    string name = (string)seclist.Rows[secptr]["Name"];
                    if (name == m_section)
                    {
                        m_data = (string)seclist.Rows[secptr]["Data"];
                        if (secptr + 1 < seclist.Rows.Count)
                        {
                            m_nsection = (string)seclist.Rows[secptr + 1]["Name"];
                        }
                        if (secptr > 0)
                        {
                            m_lsection = (string)seclist.Rows[secptr - 1]["Name"];
                        }
                    }
                    lstsection.Items.Add(new ListItem(name, name));
                    lstsection2.Items.Add(new ListItem(name, name));
                }
                lstsection.SelectedValue = m_section;
                lstsection2.SelectedValue = m_section;
            }
            else
            {
                m_data = "<CENTER><H2>This resource no longer exists, or does it?</H2></CENTER>";
                m_title = "Dust in the Wind - 404 Style";
            }
        }
        artobj.close();
    }

    public bool has_admin()
    {
        access token = (access)Session["token"];
        if (token.has(system.access_level.admin))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public string next_link()
    {
        return Article_URL(m_articleid, m_nsection);
    }

    public string back_link()
    {
        return Article_URL(m_articleid, m_lsection);
    }

    protected string Confirm_Delete(string title)
    {
        return "return click_confirm_pass('Are you sure you wish to delete \\'"
            + system.javascript_escape(title) + "\\'?');";
    }
}
