using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_article_edit : System.Web.UI.UserControl
{
    private int m_id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((!string.IsNullOrEmpty(Request["id"])) && (system.IsNumeric(Request["id"])))
        {
            m_id = Convert.ToInt32(Request["id"]);
        }
        if (!this.IsPostBack)
        {
            Article_Load();
            btnDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this article?')");
            btnSectionDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete this section?')");
        }
        lblErrors.Visible = false;
        lblErrors.Text = string.Empty;
    }

    private void Section_Load()
    {
        List<string> errors = new List<string>();
        if ((m_id > 0) && (this.lstSection.SelectedIndex != 0))
        {
            article artobj = new article(system.conn_pengine);
            DataTable secdata = artobj.section_get(m_id, this.lstSection.SelectedValue);
            if ((secdata != null) && (secdata.Rows.Count > 0))
            {
                this.btnSectionDelete.Enabled = true;
                this.txtSectionName.Text = (string) secdata.Rows[0]["Name"];
                this.txtSectionOrder.Text = ((int)secdata.Rows[0]["SortOrder"]).ToString();
                this.txtSectionData.Text = (string)secdata.Rows[0]["Data"];
            }
            else
            {
                errors.Add("The specified article section with a name of '"
                    + this.lstSection.SelectedValue + "' does not exist.");
            }
            artobj.close();
        }
        system.error_display(lblErrors, errors);
    }

    private void Section_Delete()
    {
        article artobj = new article(system.conn_pengine);
        artobj.section_delete(m_id, this.lstSection.SelectedValue);
        artobj.close();
        Article_Load();
        Section_Clear();
    }

    private void Section_Clear()
    {
        this.btnSectionDelete.Enabled = false;
        this.txtSectionData.Text = string.Empty;
        this.txtSectionName.Text = string.Empty;
        this.txtSectionOrder.Text = "0";
    }

    private void Article_Delete()
    {
        article artobj = new article(system.conn_pengine);
        artobj.article_delete(m_id);
        artobj.close();
        Response.Redirect(system.url_base + "?cmd=article&sub=browse&category=" + Server.UrlEncode(this.txtCategory.Text));
    }

    private void Article_Load()
    {
        List<string> errors = new List<string>();
        if (m_id > 0)
        {
            article artobj = new article(system.conn_pengine);
            DataTable seclist = artobj.section_getall(m_id);
            if (seclist != null)
            {
                this.lstDefaultSection.Items.Clear();
                this.lstSection.Items.Clear();
                this.lstDefaultSection.Items.Add(new ListItem(string.Empty, string.Empty));
                this.lstSection.Items.Add(new ListItem("New", string.Empty));
                for (int secptr = 0; secptr < seclist.Rows.Count; secptr++)
                {
                    string name = (string) seclist.Rows[secptr]["Name"];
                    this.lstSection.Items.Add(new ListItem(name, name));
                    this.lstDefaultSection.Items.Add(new ListItem(name, name));
                }
                if (this.lstSection.Items.Count > 1)
                {
                    this.lstSection.SelectedIndex = 1;
                    Section_Load();
                }
                else
                {
                    this.lstSection.SelectedIndex = 0;
                    Section_Clear();
                }
            }
            DataTable artdata = artobj.article_get(m_id);
            if ((artdata != null) && (artdata.Rows.Count > 0))
            {
                this.btnDelete.Enabled = true;
                lblHeader.Text = "Editing Existing Article #" + m_id.ToString() + " '" + (string)artdata.Rows[0]["Name"] + "'";
                this.txtName.Text = (string)artdata.Rows[0]["Name"];
                this.txtDescription.Text = (string)artdata.Rows[0]["Description"];
                this.txtCategory.Text = (string)artdata.Rows[0]["Category"];
                if (!Convert.IsDBNull(artdata.Rows[0]["http"]))
                {
                    this.txtHTTP.Text = (string)artdata.Rows[0]["http"];
                }
                else
                {
                    this.txtHTTP.Text = string.Empty;
                }
                if (this.lstDefaultSection.Items.FindByValue((string)artdata.Rows[0]["DefaultSection"]) != null)
                {
                    this.lstDefaultSection.SelectedValue = (string)artdata.Rows[0]["DefaultSection"];
                }
                else
                {
                    this.lstDefaultSection.SelectedIndex = 0;
                }
                this.chkVisible.Checked = (bool)artdata.Rows[0]["Visible"];
                this.chkHideDropDown.Checked = (bool)artdata.Rows[0]["HideDropDown"];
                this.chkHideButtons.Checked = (bool)artdata.Rows[0]["HideButtons"];
                if (!Convert.IsDBNull(artdata.Rows[0]["AdminPass"]))
                {
                    this.txtAdminPass.Text = (string)artdata.Rows[0]["AdminPass"];
                }
            }
            else
            {
                errors.Add("The specified article record with an id of "
                    + m_id.ToString() + " does not exist.");
            }
            artobj.close();
        }
        else
        {
            Article_Clear();
        }
        system.error_display(lblErrors, errors);
    }

    private void Article_Clear()
    {
        this.btnDelete.Enabled = false;
        this.btnSectionDelete.Enabled = false;
        this.txtAdminPass.Text = string.Empty;
        this.txtCategory.Text = string.Empty;
        this.txtDescription.Text = string.Empty;
        this.txtHTTP.Text = string.Empty;
        this.txtName.Text = string.Empty;
        this.lstSection.Items.Clear();
        this.lstSection.Items.Insert(0, new ListItem("New", string.Empty));
        this.lstSection.SelectedIndex = 0;
        this.lstDefaultSection.Items.Clear();
        this.lstSection.Items.Insert(0, new ListItem(string.Empty, string.Empty));
        this.lstDefaultSection.SelectedIndex = 0;
        this.chkHideButtons.Checked = false;
        this.chkHideDropDown.Checked = false;
        this.chkVisible.Checked = false;
        lblHeader.Text = "Adding Article";
    }

    private void Article_Save()
    {
        bool forward = false;
        List<string> errors = new List<string>();
        article artobj = new article(system.conn_pengine);
        if (m_id <= 0)
        {
            forward = true;
        }
        errors = artobj.article_save(ref m_id, this.txtName.Text
            , this.txtDescription.Text, this.txtCategory.Text, this.txtHTTP.Text
            , this.lstDefaultSection.SelectedValue, this.chkVisible.Checked
            , this.chkHideDropDown.Checked, this.chkHideButtons.Checked, this.txtAdminPass.Text);
        if (errors.Count <= 0)
        {
            string csection = this.txtSectionName.Text;
            if ((this.lstSection.SelectedIndex != 0) || (this.txtSectionName.Text != string.Empty))
            {
                errors = artobj.section_save(ref m_id, lstSection.SelectedValue
                    , this.txtSectionName.Text, this.txtSectionData.Text, this.txtSectionOrder.Text);
            }
            artobj.close();
            if (errors.Count <= 0)
            {
                Article_Load();
                if (csection != string.Empty)
                {
                    if (this.lstSection.Items.FindByValue(csection) != null)
                    {
                        this.lstSection.SelectedValue = csection;
                        Section_Load();
                    }
                    else
                    {
                        Section_Clear();
                    }
                }
                else
                {
                    Section_Clear();
                }
            }
        }
        else
        {
            artobj.close();
        }
        if (errors.Count > 0)
        {
            system.error_display(lblErrors, errors);
            lblErrors.Visible = true;
        }
        else if (forward)
        {
            Article_Edit();
        }
    }

    private void Article_Display()
    {
        Response.Redirect(system.url_base + "?cmd=article&sub=display&id=" + m_id.ToString());
    }

    private void Article_Edit()
    {
        Response.Redirect(system.url_base + "?cmd=article&sub=edit&id=" + m_id.ToString());
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Article_Save();
    }

    protected void lstSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.lstSection.SelectedIndex != 0)
        {
            Section_Load();
        }
        else
        {
            Section_Clear();
        }
    }

    protected void btnSectionDelete_Click(object sender, EventArgs e)
    {
        if (this.lstSection.SelectedIndex != 0)
        {
            Section_Delete();
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (m_id > 0)
        {
            Article_Delete();
        }
    }

    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        Article_Display();
    }
}
