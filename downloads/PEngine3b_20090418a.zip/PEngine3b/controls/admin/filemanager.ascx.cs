using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_admin_filemanager : System.Web.UI.UserControl
{
    private string m_CurrentPath = string.Empty;
    private int m_CurrentDepth = 0;
    private string m_EditName = string.Empty;
    private string m_EditType = string.Empty;
    private string[] m_Board = { };
    private bool m_CutFlag = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (ViewState["CurrentPath"] != null)
        {
            m_CurrentPath = (string)ViewState["CurrentPath"];
        }
        if (ViewState["CurrentDepth"] != null)
        {
            m_CurrentDepth = (int)ViewState["CurrentDepth"];
        }
        if (ViewState["EditName"] != null)
        {
            m_EditName = (string)ViewState["EditName"];
        }
        if (ViewState["EditType"] != null)
        {
            m_EditType = (string)ViewState["EditType"];
        }
        if (ViewState["Board"] != null)
        {
            m_Board = (string[])ViewState["Board"];
        }
        if (ViewState["CutFlag"] != null)
        {
            m_CutFlag = (bool)ViewState["CutFlag"];
        }
        if (!this.IsPostBack)
        {
            btnDelete.Attributes.Add("onclick", "return click_confirm_pass('Are you sure you wish to delete \\'"
                + "the currently selected files and directories?');");
            File_Bind();
        }
        ScriptManager.GetCurrent(Page).RegisterPostBackControl(btnUpload);
        lblErrors.Text = string.Empty;
    }

    private void File_Bind()
    {
        DataTable filelist = File_Get();
        grdfiles.DataSource = filelist;
        grdfiles.DataBind();
        if (m_CurrentPath != string.Empty)
        {
            this.lblHeader.Text = "Uploader: " + m_CurrentPath;
        }
        else
        {
            this.lblHeader.Text = "Uploader";
        }
        this.pnlEdit.Visible = false;
    }

    private DataTable File_Get()
    {
        DataTable filelist = new DataTable();
        filelist.Columns.Add("Name", typeof(string));
        filelist.Columns.Add("Date", typeof(DateTime));
        filelist.Columns.Add("Count", typeof(int));
        filelist.Columns.Add("URL", typeof(string));
        filelist.Columns.Add("Type", typeof(string));
        filelist.Columns.Add("Key", typeof(string));
        if (m_CurrentPath != string.Empty)
        {
            string actpath = Server.MapPath(system.url_base + m_CurrentPath);
            System.IO.DirectoryInfo actdir = new System.IO.DirectoryInfo(actpath);
            System.IO.DirectoryInfo[] dirs = actdir.GetDirectories();
            System.IO.FileInfo[] files = actdir.GetFiles();
            if (m_CurrentDepth > 0)
            {
                DataRow newrec = filelist.NewRow();
                newrec["Name"] = "..";
                newrec["Date"] = DateTime.MinValue;
                newrec["Count"] = 0;
                newrec["URL"] = Path_Parent();
                newrec["Type"] = "Directory";
                newrec["Key"] = ".." + "|Directory";
                filelist.Rows.Add(newrec);
            }
            for (int dirptr = 0; dirptr < dirs.Length; dirptr++)
            {
                DataRow newrec = filelist.NewRow();
                newrec["Name"] = dirs[dirptr].Name;
                newrec["Date"] = dirs[dirptr].LastWriteTime;
                newrec["Count"] = dirs[dirptr].GetFiles().Length + dirs[dirptr].GetDirectories().Length;
                newrec["URL"] = m_CurrentPath + dirs[dirptr].Name + "/";
                newrec["Type"] = "Directory";
                newrec["Key"] = dirs[dirptr].Name + "|Directory";
                filelist.Rows.Add(newrec);
            }
            for (int fileptr = 0; fileptr < files.Length; fileptr++)
            {
                DataRow newrec = filelist.NewRow();
                newrec["Name"] = files[fileptr].Name;
                newrec["Date"] = files[fileptr].LastWriteTime;
                newrec["Count"] = files[fileptr].Length;
                newrec["URL"] = m_CurrentPath + files[fileptr].Name;
                newrec["Type"] = "File";
                newrec["Key"] = files[fileptr].Name + "|File";
                filelist.Rows.Add(newrec);
            }
            if (m_Board.Length > 0)
            {
                this.btnPaste.Enabled = true;
            }
            else
            {
                this.btnPaste.Enabled = false;
            }
            this.btnCopy.Enabled = true;
            this.btnCut.Enabled = true;
            this.btnDelete.Enabled = true;
            this.btnUpload.Enabled = true;
            this.uplGeneral.Enabled = true;
        }
        else
        {
            for (int recptr = 0; recptr < 2; recptr++)
            {
                DataRow newrec = filelist.NewRow();
                System.IO.DirectoryInfo basedir = null;
                switch (recptr)
                {
                    case 0:
                        basedir = new System.IO.DirectoryInfo(Server.MapPath(system.url_base + "images/"));
                        newrec["Name"] = "Images";
                        break;
                    case 1:
                        basedir = new System.IO.DirectoryInfo(Server.MapPath(system.url_base + "downloads/"));
                        newrec["Name"] = "Downloads";
                        break;
                }
                if (basedir.Exists)
                {
                    newrec["Date"] = basedir.LastWriteTime;
                    newrec["Count"] = basedir.GetFiles().Length + basedir.GetDirectories().Length;
                    newrec["Type"] = "Directory";
                    filelist.Rows.Add(newrec);
                }
            }
            this.btnPaste.Enabled = false;
            this.btnCopy.Enabled = false;
            this.btnCut.Enabled = false;
            this.btnDelete.Enabled = false;
            this.btnUpload.Enabled = false;
            this.uplGeneral.Enabled = false;
        }
        ViewState["CurrentPath"] = m_CurrentPath;
        ViewState["CurrentDepth"] = m_CurrentDepth;
        return filelist;
    }

    private string[] File_Selected()
    {
        List<string> retvalue = new List<string>();
        for (int rowptr = 0; rowptr < grdfiles.Rows.Count; rowptr++)
        {
            CheckBox chkselect = (CheckBox) grdfiles.Rows[rowptr].FindControl("chkSelect");
            if ((chkselect != null) && (chkselect.Checked))
            {
                retvalue.Add((string) grdfiles.DataKeys[rowptr].Value);
            }
        }
        return retvalue.ToArray();
    }

    private void File_Delete()
    {
        List<string> errors = new List<string>();
        string[] list = File_Selected();
        for (int rowptr = 0; rowptr < list.Length; rowptr++)
        {
            string[] strdata = list[rowptr].Split('|');
            string path = Server.MapPath(m_CurrentPath + strdata[0]);
            if (System.IO.File.Exists(path))
            {
                try
                {
                    System.IO.File.Delete(path);
                }
                catch (Exception ex)
                {
                    errors.Add(ex.Message);
                }
            }
        }
        pengine.system.error_display(lblErrors, errors);
        if (errors.Count <= 0)
        {
            File_Bind();
        }
    }

    private void File_Copy(bool cutflag)
    {
        string[] list = File_Selected();
        List<string> urls = new List<string>();
        for (int rowptr = 0; rowptr < list.Length; rowptr++)
        {
            string[] strdata = list[rowptr].Split('|');
            string path = m_CurrentPath + strdata[0];
            string type = strdata[1];
            if (System.IO.File.Exists(Server.MapPath(path)) && ((type == "File") || (cutflag)))
            {
                urls.Add(path + "|" + type);
            }
        }
        if (urls.Count > 0)
        {
            ViewState["Board"] = urls.ToArray();
            ViewState["CutFlag"] = cutflag;
            this.btnPaste.Enabled = true;
            this.btnPaste.Text = "Paste (" + urls.Count.ToString() + ")";
        }
        else
        {
            ViewState["Board"] = null;
            ViewState["CutFlag"] = null;
            this.btnPaste.Enabled = false;
            this.btnPaste.Text = "Paste";
        }
    }

    private void File_Paste()
    {
        List<string> errors = new List<string>();
        if ((m_Board.Length > 0) && (m_CurrentPath != string.Empty))
        {
            string dstpath = Server.MapPath(m_CurrentPath);
            for (int bptr = 0; bptr < m_Board.Length; bptr++)
            {
                string[] srcdata = m_Board[bptr].Split('|');
                if (srcdata.Length > 1)
                {
                    string srcpath = Server.MapPath(srcdata[0]);
                    string srctype = srcdata[1];
                    if (srctype == "File")
                    {
                        System.IO.FileInfo myfile = new System.IO.FileInfo(srcpath);
                        try
                        {
                            if (m_CutFlag)
                            {
                                myfile.MoveTo(dstpath + myfile.Name);
                            }
                            else
                            {
                                myfile.CopyTo(dstpath + myfile.Name);
                            }
                        }
                        catch (Exception ex)
                        {
                            errors.Add(ex.Message);
                        }
                    }
                    else
                    {
                        System.IO.DirectoryInfo mydir = new System.IO.DirectoryInfo(srcpath);
                        try
                        {
                            mydir.MoveTo(dstpath + mydir.Name);
                        }
                        catch (Exception ex)
                        {
                            errors.Add(ex.Message);
                        }
                    }
                }
            }
        }
        pengine.system.error_display(lblErrors, errors);
        if (errors.Count <= 0)
        {
            btnPaste.Enabled = false;
            this.btnPaste.Text = "Paste";
            File_Bind();
        }
    }

    private void File_Edit(string Name, string Type)
    {
        string path = m_CurrentPath + Name;
        this.pnlEdit.Visible = true;
        this.lblItem.Text = path;
        this.txtRenameTo.Text = string.Empty;
        ViewState["EditName"] = Name;
        ViewState["EditType"] = Type;
    }

    private void File_Rename(string Name)
    {
        List<string> errors = new List<string>();
        string srcpath = Server.MapPath(m_CurrentPath + m_EditName);
        string dstpath = Server.MapPath(m_CurrentPath + Name);
        try
        {
            if (m_EditType == "File")
            {
                System.IO.File.Move(srcpath, dstpath);
            }
            else
            {
                System.IO.Directory.Move(srcpath, dstpath);
            }
        }
        catch (Exception ex)
        {
            errors.Add(ex.Message);
        }
        pengine.system.error_display(lblErrors, errors);
        if (errors.Count <= 0)
        {
            File_Bind();
        }
    }

    private void File_Upload()
    {
        List<string> errors = new List<string>();
        if (uplGeneral.FileName != string.Empty)
        {
            string path = Server.MapPath(m_CurrentPath + uplGeneral.FileName);
            try
            {
                if (System.IO.File.Exists(path))
                {
                    System.IO.File.Delete(path);
                }
                uplGeneral.SaveAs(path);
            }
            catch (Exception ex)
            {
                errors.Add(ex.Message);
            }
        }
        else
        {
            errors.Add("You must select a file to upload before clicking the upload button.");
        }
        pengine.system.error_display(lblErrors, errors);
        if (errors.Count <= 0)
        {
            File_Bind();
        }
    }

    private string Path_Parent()
    {
        string retvalue = string.Empty;
        if ((m_CurrentPath != string.Empty) && (m_CurrentDepth > 1))
        {
            int pos = m_CurrentPath.LastIndexOf("/", m_CurrentPath.Length - 2);
            if (pos > 0)
            {
                retvalue = m_CurrentPath.Substring(0, pos + 1);
            }
        }
        return retvalue;
    }

    protected void grdfiles_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView cRow = (DataRowView) e.Row.DataItem;
            Button btnView = (Button) e.Row.FindControl("btnView");
            if (btnView != null)
            {
                if ((string)cRow["Type"] == "File")
                {
                    btnView.Attributes.Add("onclick", "click_window_go('" + (string) cRow["URL"] + "'); return false;");
                }
            }
        }
    }

    protected void grdfiles_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable filelist = File_Get();
        system.grid_sortfield(ViewState, ref filelist, e, "FileDir", "FileExp");
    }

    protected void grdfiles_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName.ToLower())
        {
            case "viewitem":
                if ((string) e.CommandArgument == "..")
                {
                    m_CurrentPath = Path_Parent();
                    m_CurrentDepth--;
                }
                else
                {
                    if (m_CurrentPath != string.Empty)
                    {
                        m_CurrentPath += e.CommandArgument + "/";
                    }
                    else
                    {
                        m_CurrentPath = system.url_base + e.CommandArgument + "/";
                    }
                    m_CurrentDepth++;
                }
                File_Bind();
                break;
            case "edititem":
                string[] props = ((string)e.CommandArgument).Split('|');
                if (props.Length > 1)
                {
                    File_Edit(props[0], props[1]);
                }
                break;
        }
    }

    protected void grdfiles_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdfiles.PageIndex = e.NewPageIndex;
        File_Bind();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        File_Delete();
    }

    protected void btnCut_Click(object sender, EventArgs e)
    {
        File_Copy(true);
    }

    protected void btnCopy_Click(object sender, EventArgs e)
    {
        File_Copy(false);
    }

    protected void btnPaste_Click(object sender, EventArgs e)
    {
        File_Paste();
    }

    protected void btnRenameTo_Click(object sender, EventArgs e)
    {
        File_Rename(this.txtRenameTo.Text);
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        File_Upload();
    }
}
