using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using pengine;

public partial class controls_admin_settings : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Settings_Init();
            Settings_Load();
            if (system.flag_loaded == false)
            {
                lblHeader.Text = "System Settings (current settings require repair)";
            }
            else
            {
                lblHeader.Text = "System Settings";
            }
        }
        this.lblErrors.Text = string.Empty;
    }

    private void Settings_Init()
    {
        List<string> tlist = theme.theme_list();
        this.lstDefaultTheme.Items.Clear();
        for (int tptr = 0; tptr < tlist.Count; tptr++)
        {
            this.lstDefaultTheme.Items.Add(new ListItem(tlist[tptr]));
        }
    }

    private void Settings_Save()
    {
        string[] keys = Enum.GetNames(typeof(settings.app_setting_key));
        Configuration config = settings.snapshot();
        List<string> errors = new List<string>();
        for (int kptr = 0; kptr < keys.Length; kptr++)
        {
            settings.app_setting_key key = (settings.app_setting_key)Enum.Parse(typeof(settings.app_setting_key), keys[kptr], true);
            settings.app_setting_type type = settings.gettype(key);
            switch (key)
            {
                case settings.app_setting_key.app_db_name:
                    settings.update(key, this.txtAppDBName.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_default_theme:
                    settings.update(key, this.lstDefaultTheme.SelectedValue, ref config, false);
                    break;
                case settings.app_setting_key.app_default_title:
                    settings.update(key, this.txtDefaultTitle.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_forum:
                    settings.update(key, this.chkExcludeForum.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_leet:
                    settings.update(key, this.chkExcludeLeet.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_quotes:
                    settings.update(key, this.chkExcludeQuotes.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_resume:
                    settings.update(key, this.chkExcludeResume.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_rss:
                    settings.update(key, this.chkExcludeRSS.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_search:
                    settings.update(key, this.chkExcludeSearch.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_theme:
                    settings.update(key, this.chkExcludeTheme.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_exclude_print:
                    settings.update(key, this.chkExcludePrint.Checked, ref config, false);
                    break;
                case settings.app_setting_key.app_label_admin:
                    settings.update(key, this.txtLabelAdmin.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_admin2:
                    settings.update(key, this.txtLabelAdmin2.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_home:
                    settings.update(key, this.txtLabelHome.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_leet:
                    settings.update(key, this.txtLabelLeet.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_leet2:
                    settings.update(key, this.txtLabelLeet2.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_resume:
                    settings.update(key, this.txtLabelResume.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_theme:
                    settings.update(key, this.txtLabelTheme.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_print:
                    settings.update(key, this.txtLabelPrint.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_label_quote:
                    settings.update(key, this.txtLabelQuote.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_logo_frontpage:
                    settings.update(key, this.txtLogoFrontPage.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_owner_email:
                    settings.update(key, this.txtOwnerEmail.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_owner_name:
                    settings.update(key, this.txtOwnerName.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_recpage_forum_posts:
                    settings.update(key, this.txtRecpageForumPosts.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_recpage_news:
                    settings.update(key, this.txtRecpageNews.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_recpage_news_summary:
                    settings.update(key, this.txtRecpageNewsSummary.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_recpage_rss:
                    settings.update(key, this.txtRecpageRSS.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_recpage_search_results:
                    settings.update(key, this.txtRecpageSearchResults.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_timelimit_admin_login:
                    settings.update(key, this.txtTimeLimitAdminLogin.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_timelimit_forum_edit:
                    settings.update(key, this.txtTimeLimitForumEdit.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_timelimit_forum_login:
                    settings.update(key, this.txtTimeLimitForumLogin.Text, ref config, false);
                    break;
                case settings.app_setting_key.app_notoggle_quote:
                    settings.update(key, this.chkNoToggleQuotes.Checked, ref config, false);
                    break;
            }
        }
        errors = settings.save(ref config);
        if (errors.Count == 0)
        {
            settings.load();
            errors.Add("The runtime.config file for the application has been updated.");
        }
        system.error_display(lblErrors, errors);
    }

    private void Settings_Load()
    {
        string[] keys = Enum.GetNames(typeof(settings.app_setting_key));
        Configuration config = settings.snapshot();
        for (int kptr = 0; kptr < keys.Length; kptr++)
        {
            settings.app_setting_key key = (settings.app_setting_key) Enum.Parse(typeof(settings.app_setting_key), keys[kptr], true);
            settings.app_setting_type type = settings.gettype(key);
            object value = settings.query(key, ref config);
            switch (key)
            {
                case settings.app_setting_key.app_db_name:
                    this.txtAppDBName.Text = (string)value;
                    break;
                case settings.app_setting_key.app_default_theme:
                    if (this.lstDefaultTheme.Items.FindByValue((string)value) != null)
                    {
                        this.lstDefaultTheme.SelectedValue = (string)value;
                    }
                    break;
                case settings.app_setting_key.app_default_title:
                    this.txtDefaultTitle.Text = (string)value;
                    break;
                case settings.app_setting_key.app_exclude_forum:
                    this.chkExcludeForum.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_leet:
                    this.chkExcludeLeet.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_quotes:
                    this.chkExcludeQuotes.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_resume:
                    this.chkExcludeResume.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_rss:
                    this.chkExcludeRSS.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_search:
                    this.chkExcludeSearch.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_theme:
                    this.chkExcludeTheme.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_exclude_print:
                    this.chkExcludePrint.Checked = (bool)value;
                    break;
                case settings.app_setting_key.app_label_admin:
                    this.txtLabelAdmin.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_admin2:
                    this.txtLabelAdmin2.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_home:
                    this.txtLabelHome.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_leet:
                    this.txtLabelLeet.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_leet2:
                    this.txtLabelLeet2.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_resume:
                    this.txtLabelResume.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_theme:
                    this.txtLabelTheme.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_print:
                    this.txtLabelPrint.Text = (string)value;
                    break;
                case settings.app_setting_key.app_label_quote:
                    this.txtLabelQuote.Text = (string)value;
                    break;
                case settings.app_setting_key.app_logo_frontpage:
                    this.txtLogoFrontPage.Text = (string)value;
                    break;
                case settings.app_setting_key.app_owner_email:
                    this.txtOwnerEmail.Text = (string)value;
                    break;
                case settings.app_setting_key.app_owner_name:
                    this.txtOwnerName.Text = (string)value;
                    break;
                case settings.app_setting_key.app_recpage_forum_posts:
                    this.txtRecpageForumPosts.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_recpage_news:
                    this.txtRecpageNews.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_recpage_news_summary:
                    this.txtRecpageNewsSummary.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_recpage_rss:
                    this.txtRecpageRSS.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_recpage_search_results:
                    this.txtRecpageSearchResults.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_timelimit_admin_login:
                    this.txtTimeLimitAdminLogin.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_timelimit_forum_edit:
                    this.txtTimeLimitForumEdit.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_timelimit_forum_login:
                    this.txtTimeLimitForumLogin.Text = ((int)value).ToString();
                    break;
                case settings.app_setting_key.app_notoggle_quote:
                    this.chkNoToggleQuotes.Checked = (bool)value;
                    break;
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Settings_Save();
    }
}
