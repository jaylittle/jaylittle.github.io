using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_layout_menu : System.Web.UI.UserControl
{
    private int m_articleid = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        Article_Init();

        access token = (access) Session["token"];

        //Display Home Button
        Button_Create((string)settings.query(settings.app_setting_key.app_label_home)
            , system.url_base);

        //Display Theme Button
        if ((bool)settings.query(settings.app_setting_key.app_exclude_theme) == false)
        {
            Button_Create((string)settings.query(settings.app_setting_key.app_label_theme)
            , system.url_base + "?cmd=theme&sub=select");
        }

        //Display Resume Button
        if ((bool)settings.query(settings.app_setting_key.app_exclude_resume) == false)
        {
            Button_Create((string)settings.query(settings.app_setting_key.app_label_resume)
            , system.url_base + "?cmd=resume&sub=display");
        }

        //Display Article Category Buttons
        DataTable catlist = null;
        article artobj = new article(system.conn_pengine);
        if (token.has(system.access_level.admin))
        {
            catlist = artobj.category_list(true);
        }
        else
        {
            catlist = artobj.category_list(false);
        }
        artobj.close();
        if (catlist != null)
        {
            for (int catptr = 0; catptr < catlist.Rows.Count; catptr++)
            {
                string link = string.Empty;
                if ((!Convert.IsDBNull(catlist.Rows[catptr]["http"]))
                    && ((string)catlist.Rows[catptr]["http"] != string.Empty))
                {
                    link = (string)catlist.Rows[catptr]["http"];
                }
                else
                {
                    link = system.url_base + "?cmd=article&sub=browse&category=" + Server.UrlEncode((string)catlist.Rows[catptr]["category"]);
                }
                Button_Create((string)catlist.Rows[catptr]["category"], link);
            }
        }

        //Display Admin Buttons
        if (!token.has(system.access_level.admin))
        {
            Button_Create((string)settings.query(settings.app_setting_key.app_label_admin)
            , system.url_base + "?cmd=login");
        }
        else
        {
            Button_Create(string.Empty, string.Empty);
            Button_Create("New Article", system.url_base + "?cmd=article&sub=edit");
            Button_Create("Settings", system.url_base + "?cmd=settings&sub=edit");
            Button_Create("Uploader", system.url_base + "?cmd=file&sub=browse");
            Button_Create((string)settings.query(settings.app_setting_key.app_label_admin2)
            , system.url_base + "?cmd=logout");
        }

        //Display Forum Button
        if ((bool)settings.query(settings.app_setting_key.app_exclude_forum) == false)
        {
            Button_Create(string.Empty, string.Empty);
            Button_Create("Forums", system.url_base + "?cmd=forum&sub=browse");
        }

        //Display Elite Button
        if ((bool)settings.query(settings.app_setting_key.app_exclude_leet) == false)
        {
            if ((Session["leetflag"] == null) || ((bool)Session["leetflag"] == false))
            {
                Button_Create((string)settings.query(settings.app_setting_key.app_label_leet)
                    , system.url_base + "?cmd=elite");
            }
            else
            {
                Button_Create((string)settings.query(settings.app_setting_key.app_label_leet2)
                    , system.url_base + "?cmd=elite");
            }
        }

        //Display Print Button
        if ((bool)settings.query(settings.app_setting_key.app_exclude_print) == false)
        {
            if (Request.Url.Query != string.Empty)
            {
                Button_Create((string)settings.query(settings.app_setting_key.app_label_print)
                , "#", "click_window_go('" + system.javascript_escape(Request.Url.ToString()) + "&popup=1'); return false;");
            }
            else
            {
                Button_Create((string)settings.query(settings.app_setting_key.app_label_print)
                , "#", "click_window_go('" + system.javascript_escape(Request.Url.ToString()) + "?popup=1'); return false;");
            }
        }

        if (m_articleid > 0)
        {
            //Display Article Section Buttons
            Article_Display(m_articleid);
        }

        //Display Quote Button
        //Not Implemented Yet Due to Probable Implementation Changes
    }

    private void Button_Create(string text, string url)
    {
        Button_Create(text, url, string.Empty);
    }

    private void Button_Create(string text, string url, string onclick)
    {
        Control mbutton = LoadControl("~/controls/layout/menubutton.ascx");
        mbutton.EnableViewState = false;
        ((controls_layout_menubutton)mbutton).URL = url;
        ((controls_layout_menubutton)mbutton).Text = text;
        ((controls_layout_menubutton)mbutton).OnClick = onclick;
        this.plcMenu.Controls.Add(mbutton);
    }

    private void Article_Init()
    {
        if (!string.IsNullOrEmpty(Request["cmd"]))
        {
            string cmd = Request["cmd"];
            if (cmd.ToLower() == "article")
            {
                if (!string.IsNullOrEmpty(Request["id"]))
                {
                    m_articleid = Convert.ToInt32(Request["id"]);
                }
            }
        }
    }

    private void Article_Display(int articleid)
    {
        article artobj = new article(system.conn_pengine);
        DataTable artdata = artobj.article_get(articleid);
        if ((artdata != null) && (artdata.Rows.Count > 0))
        {
            Page.Title += " - " + (string)artdata.Rows[0]["category"] + ": " + (string)artdata.Rows[0]["name"];
            if (Convert.ToBoolean(artdata.Rows[0]["hidebuttons"]) == false)
            {
                DataTable seclist = artobj.section_getall(articleid);
                if (seclist.Rows.Count > 1)
                {
                    Button_Create(string.Empty, string.Empty);
                    for (int secptr = 0; secptr < seclist.Rows.Count; secptr++)
                    {
                        string link = system.url_base + "?cmd=article&sub=display&id=" + articleid.ToString()
                            + "&section=" + Server.UrlEncode((string)seclist.Rows[secptr]["Name"]);
                        Button_Create((string)seclist.Rows[secptr]["Name"], link);
                    }
                }
            }
        }
        artobj.close();
    }
}
