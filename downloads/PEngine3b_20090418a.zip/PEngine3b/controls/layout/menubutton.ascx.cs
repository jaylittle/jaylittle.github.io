using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class controls_layout_menubutton : System.Web.UI.UserControl
{
    public string URL = string.Empty;
    public string Text = string.Empty;
    public string OnClick = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        //Server.HtmlEncode
    }

    public bool button_mode()
    {
        if ((URL != string.Empty) || (Text != string.Empty) || (OnClick != string.Empty))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
