using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using pengine;

public partial class controls_resume_view : System.Web.UI.UserControl
{
    private string m_otype = string.Empty;
    private int m_tctr = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Resume_Load();
        }
    }

    protected void rptTypes_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.FindControl("rptSkills") != null)
        {
            DataRowView typedata = (DataRowView) e.Item.DataItem;
            resumeparts resobj = new resumeparts(system.conn_pengine);
            DataTable skidata = resobj.skill_list((string) typedata["Type"]);
            Repeater rptSkills = (Repeater)e.Item.FindControl("rptSkills");
            rptSkills.DataSource = skidata;
            rptSkills.DataBind();
            resobj.close();
        }
    }

    private void Resume_Load()
    {
        resumeparts resobj = new resumeparts(system.conn_pengine);
        
        DataTable objdata = resobj.objective_list();
        rptObjective.DataSource = objdata;
        rptObjective.DataBind();

        DataTable perdata = resobj.personal_list();
        rptPerson.DataSource = perdata;
        rptPerson.DataBind();

        DataTable stdata = resobj.skill_type_list();
        rptTypes.DataSource = stdata;
        rptTypes.DataBind();

        DataTable eddata = resobj.education_list();
        rptEducation.DataSource = eddata;
        rptEducation.DataBind();

        DataTable whdata = resobj.workhistory_list();
        rptWorkHistory.DataSource = whdata;
        rptWorkHistory.DataBind();
        resobj.close();
    }

    protected string Skill_GetName(string type, string name)
    {
        string retvalue = string.Empty;
        if (type != m_otype)
        {
            m_tctr = 1;
            m_otype = type;
        }
        else
        {
            m_tctr++;
        }
        if (m_tctr == 1)
        {
            retvalue = system.elite_convert(name);
        }
        else
        {
            retvalue = ", " + system.elite_convert(name);
        }
        return retvalue;
    }

    public bool has_admin()
    {
        access token = (access)Session["token"];
        if (token.has(system.access_level.admin))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        Response.Redirect(system.url_base + "default.aspx?cmd=resume&sub=edit");
    }
}
