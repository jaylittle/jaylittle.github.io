using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

/// <summary>
/// Summary description for article
/// </summary>

namespace pengine
{
    public class article : pengine.dbaccess
    {
        public article(string mycstring) : base(mycstring)
        {
        }

        public DataTable category_list(bool admin)
        {
            DataTable retvalue = null;
            if (admin)
            {
                retvalue = data_load("Select category,http from Articles Group By category,http"
                    , true, cache.cache_type.category, cache.cache_subtype.listadmin, string.Empty);
            }
            else
            {
                retvalue = data_load("Select category,http from Articles where visible = true group by category,http"
                    , true, cache.cache_type.category, cache.cache_subtype.list, string.Empty);
            }
            return retvalue;
        }

        public DataTable article_list(string category, bool admin)
        {
            DataTable retvalue = null;
            if (!admin)
            {
                if (category != string.Empty)
                {
                    retvalue = data_load("Select ID,Name,Description from Articles where category='"
                        + category + "' and visible=true order by name ASC"
                        , true, cache.cache_type.article, cache.cache_subtype.listadmin, category);
                }
                else
                {
                    retvalue = data_load("Select ID,Name,Description from Articles where visible=true order by name ASC"
                        , true, cache.cache_type.article, cache.cache_subtype.listadmin, string.Empty);
                }
            }
            else
            {
                if (category != string.Empty)
                {
                    retvalue = data_load("Select ID,Name,Description from Articles where category='"
                        + category + "' order by name ASC"
                        , true, cache.cache_type.article, cache.cache_subtype.list, category);
                }
                else
                {
                    retvalue = data_load("Select ID,Name,Description from Articles order by name ASC"
                        , true, cache.cache_type.article, cache.cache_subtype.list, string.Empty);
                }
            }
            return retvalue;
        }

        public DataTable article_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * From Articles where id = " + id.ToString()
                , true, cache.cache_type.article, cache.cache_subtype.none, id.ToString());
            return retvalue;
        }

        public List<string> article_save(ref int id, string name, string description, string category, string http, string defaultsection, bool visible, bool hidedropdown, bool hidebuttons, string adminpass)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(name))
            {
                errors.Add("You must supply a name for this article.");
            }
            if (string.IsNullOrEmpty(description))
            {
                errors.Add("You must supply a description for this article.");
            }
            if (string.IsNullOrEmpty(category))
            {
                errors.Add("You must supply a category for this article.");
            }
            if (errors.Count <= 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from Articles where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from Articles"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Name"] = name;
                record["Description"] = description;
                record["Category"] = category;
                if (!string.IsNullOrEmpty(http))
                {
                    record["http"] = http;
                }
                record["DefaultSection"] = defaultsection;
                record["Visible"] = visible;
                record["HideButtons"] = hidebuttons;
                record["HideDropDown"] = hidedropdown;
                record["AdminPass"] = adminpass;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                cache.index_del(cache.cache_type.article, cache.cache_subtype.list, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.article, cache.cache_subtype.listadmin, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.article, cache.cache_subtype.none, string.Empty, id.ToString(), 0);
                cache.index_del(cache.cache_type.category, cache.cache_subtype.list, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.category, cache.cache_subtype.listadmin, string.Empty, string.Empty, 0);
            }
            return errors;
        }

        public bool article_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from Articles where ID = " + id.ToString());
                sql_execute("Delete from ArticleSection where ArticleID = " + id.ToString());
                cache.index_del(cache.cache_type.article, cache.cache_subtype.listadmin, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.article, cache.cache_subtype.listadmin, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.article, cache.cache_subtype.none, string.Empty, id.ToString(), 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.list, string.Empty, id.ToString(), 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.none, string.Empty, id.ToString(), 0);
                cache.index_del(cache.cache_type.category, cache.cache_subtype.list, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.category, cache.cache_subtype.listadmin, string.Empty, string.Empty, 0);
                return true;
            }
            else
            {
                return false;
            }
        }

        public string article_category(int articleid)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select category from Articles where id = " + articleid.ToString());
            return retvalue;
        }

        public bool article_hidemenu(int articleid)
        {
            bool retvalue = false;
            retvalue = (bool)scalar_get("Select hidebuttons from Articles where id = " + articleid.ToString());
            return retvalue;
        }

        public string article_title(int articleid)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select name from Articles where id = " + articleid.ToString());
            return retvalue;
        }

        static public string article_buildhtml(string secdata, bool forum)
        {
            return article_buildhtml(secdata, forum, 0);
        }

        static public string article_buildhtml(string secdata, bool forum, int articleid)
        {
            int lpos = 0;
            string tag = string.Empty;
            string tagname = string.Empty;
            string tagdata = string.Empty;
            int tagspace = 0;
            string[] tagelements = { };
            bool rawhtmlflag = false;
            int rawhtmlstart = 0;
            int rawhtmlend = 0;
            string outdata = string.Empty;
            string[] resforumtags = {"SCRIPT", "/SCRIPT", "IFRAME", "/IFRAME", "EMBED", "BLINK"
            , "TR", "TD", "TABLE", "/TR", "/TD", "/TABLE", "FRAMESET", "/FRAMESET"};
            bool restagflag = false;
            string outputhtml = string.Empty;
            //Filter for obfusacated tags if forum flag is true
            //Remove HTML Content if Forum Flag is true
            if (forum)
            {
                while (secdata.IndexOf("[" + Environment.NewLine) >= 0)
                {
                    secdata.Replace("[" + Environment.NewLine, "[ ");
                }
                while (secdata.IndexOf("<" + Environment.NewLine) >= 0)
                {
                    secdata.Replace("<" + Environment.NewLine, "< ");
                }
                while (secdata.IndexOf("[ ") >= 0)
                {
                    secdata.Replace("[ ", "[");
                }
                while (secdata.IndexOf("< ") >= 0)
                {
                    secdata.Replace("< ", "<");
                }
                for (int cpos = secdata.IndexOf("<"); cpos >= 0; cpos = secdata.IndexOf("<", cpos + 1))
                {
                    lpos = secdata.IndexOf(">", cpos + 1);
                    if (lpos >= 0)
                    {
                        secdata = secdata.Substring(0, cpos) + secdata.Substring(lpos, secdata.Length - lpos);
                    }
                }
            }
            lpos = -1;
            for (int cpos = secdata.IndexOf("["); cpos >= 0; cpos = secdata.IndexOf("[", lpos + 1))
            {
                if (!rawhtmlflag)
                {
                    outdata = secdata.Substring(lpos + 1, cpos - (lpos + 1));
                    outdata = system.elite_convert(outdata);
                    for (int eptr = 0; eptr < Environment.NewLine.Length; eptr++)
                    {
                        if (outdata.IndexOf(Environment.NewLine[eptr]) >= 0)
                        {
                            outdata = outdata.Replace(Environment.NewLine[eptr].ToString(), "<br/>" + Environment.NewLine);
                            eptr = Environment.NewLine.Length;
                        }
                    }
                    outputhtml += outdata;
                }
                lpos = secdata.IndexOf("]", cpos + 1);
                if (lpos > cpos)
                {
                    tag = secdata.Substring(cpos + 1, lpos - (cpos + 1));
                    tagspace = tag.IndexOf(" ");
                    if (tagspace >= 0)
                    {
                        tagname = tag.Substring(0, tagspace).ToUpper();
                        tagdata = tag.Substring(tagspace + 1, tag.Length - (tagspace + 1));
                    }
                    else
                    {
                        tagname = tag.ToUpper();
                    }
                    if ((!rawhtmlflag) || (tagname == "/RAWHTML"))
                    {
                        switch (tagname)
                        {
                            case "CENTER":
                                outputhtml += "<p style=\"text-align: center\">";
                                break;
                            case "/CENTER":
                                outputhtml += "</p>";
                                break;
                            case "IMAGE":
                                if ((tagdata.ToUpper().IndexOf("HTTP") >= 0)
                                    || (tagdata.Substring(0, 2) == "./") || (tagdata.Substring(0, 1) == "/"))
                                {
                                    outputhtml += "<img src=\"" + tagdata + "\" alt=\"outside image\" />";
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(system.url_base))
                                    {
                                        outputhtml += "<img src=\"" + system.url_base + "images/articles/" + tagdata + "\" alt=\"article image\" />";
                                    }
                                    else
                                    {
                                        outputhtml += "<img src=\"./images/articles/" + tagdata + "\" alt=\"article image\" />";
                                    }
                                }
                                break;
                            case "SUBHEADER":
                                if (!forum)
                                {
                                    outputhtml += system.html_subheader(tagdata);
                                }
                                break;
                            case "LINK":
                                tagelements = tagdata.Split(' ');
                                outputhtml += "<a href=\"" + tagelements[0] + "\">";
                                if (tagelements.Length > 1)
                                {
                                    for (int teptr = 1; teptr < tagelements.Length; teptr++)
                                    {
                                        if (teptr > 1)
                                        {
                                            outputhtml += " " + tagelements[teptr];
                                        }
                                        else
                                        {
                                            outputhtml += tagelements[teptr];
                                        }
                                    }
                                }
                                else
                                {
                                    outputhtml += tagelements[0];
                                }
                                outputhtml += "</a>";
                                break;
                            case "ICON":
                                outputhtml += system.html_icon(system.url_base + "images/icons/" + tagdata);
                                break;
                            case "SYSTEMIMAGE":
                                if (!string.IsNullOrEmpty(system.url_base))
                                {
                                    outputhtml += "<img src=\"" + system.url_base + "images/system/" + tagdata + "\" alt=\"system image\" />";
                                }
                                else
                                {
                                    outputhtml += "<img src=\"./images/system/" + tagdata + "\" alt=\"system image\" />";
                                }
                                break;
                            case "RAWHTML":
                                rawhtmlflag = true;
                                rawhtmlstart = cpos + 9;
                                rawhtmlend = rawhtmlstart;
                                break;
                            case "/RAWHTML":
                                rawhtmlflag = false;
                                rawhtmlend = cpos;
                                outputhtml += secdata.Substring(rawhtmlstart, rawhtmlend - rawhtmlstart);
                                break;
                            case "QUOTE":
                                outputhtml += "<blockquote><table><tr><td class=\"contenttext\">";
                                break;
                            case "/QUOTE":
                                outputhtml += "</td></tr></table></blockquote>";
                                break;
                            default:
                                restagflag = false;
                                if (forum)
                                {
                                    for (int fptr = 0; fptr < resforumtags.Length; fptr++)
                                    {
                                        if (resforumtags[fptr].ToUpper() == tagname)
                                        {
                                            restagflag = true;
                                        }
                                    }
                                }
                                if (!restagflag)
                                {
                                    outputhtml += "<" + tag + ">";
                                }
                                break;
                        }
                    }
                }
            }
            if (lpos >= -1)
            {
                outdata = secdata.Substring(lpos + 1, secdata.Length - (lpos + 1));
                if (!rawhtmlflag)
                {
                    outdata = system.elite_convert(outdata);
                    for (int eptr = 0; eptr < Environment.NewLine.Length; eptr++)
                    {
                        if (outdata.IndexOf(Environment.NewLine[eptr]) >= 0)
                        {
                            outdata = outdata.Replace(Environment.NewLine[eptr].ToString(), "<br/>" + Environment.NewLine);
                            eptr = Environment.NewLine.Length;
                        }
                    }
                    outputhtml += outdata;
                }
                else
                {
                    outputhtml += outdata;
                }
            }
            if (outputhtml == string.Empty)
            {
                outputhtml = "There was no data to convert.";
            }
            return outputhtml;
        }

        public DataTable section_get(int id, string section)
        {
            DataTable artlist = null;
            DataTable retvalue = null;
            string dsection = string.Empty;
            artlist = article_get(id); 
            if (artlist.Rows.Count > 0)
            {
                if (string.IsNullOrEmpty(section))
                {
                    dsection = (string)artlist.Rows[0]["DefaultSection"];
                }
                else
                {
                    dsection = section;
                }
                if (string.IsNullOrEmpty(dsection))
                {
                    retvalue = data_load("Select TOP 1 * from ArticleSection where ArticleID = "
                        + id.ToString() + " order by sortorder,name"
                        , true, cache.cache_type.section, cache.cache_subtype.none, id.ToString());
                }
                else
                {
                    retvalue = data_load("Select TOP 1 * from ArticleSection where ArticleID = "
                        + id.ToString() + " and name = '" + dsection + "' order by sortorder,name"
                        , true, cache.cache_type.section, cache.cache_subtype.none, id.ToString() + "|" + section);
                }
            }
            else
            {
                //Article Data Not Found
            }
            return retvalue;
        }

        public DataTable section_getall(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ArticleSection where ArticleID = " + id.ToString()
                + " order by SortOrder ASC, Name ASC", true, cache.cache_type.section
                , cache.cache_subtype.list, id.ToString());
            return retvalue;
        }

        public List<string> section_save(ref int articleid, string oldname, string name, string data, string sortorder)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            int isortorder = 0;
            if (string.IsNullOrEmpty(name))
            {
                errors.Add("You must supply a name for this section.");
            }
            if (string.IsNullOrEmpty(data))
            {
                errors.Add("You must supply data for this section.");
            }
            if (!system.IsNumeric(sortorder))
            {
                errors.Add("Sort Order should be a numeric value.");
            }
            else
            {
                isortorder = Convert.ToInt32(sortorder);
            }
            if (errors.Count <= 0)
            {
                if (!string.IsNullOrEmpty(oldname))
                {
                    table = data_load("Select * from ArticleSection where Name = '" + oldname
                        + "' and ArticleID = " + articleid.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select * from ArticleSection"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["ArticleID"] = articleid;
                record["Name"] = name;
                record["Data"] = data;
                record["SortOrder"] = isortorder;
                if (string.IsNullOrEmpty(oldname))
                {
                    table.Rows.Add(record);
                }
                data_update(ref table);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.none, string.Empty, articleid.ToString(), 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.none, string.Empty, articleid.ToString()
                    + "|" + name, 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.none, string.Empty, articleid.ToString()
                    + "|" + oldname, 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.list, string.Empty, articleid.ToString(), 0);
            }
            return errors;
        }

        static public string section_cleanname(string sectionname)
        {
            string retvalue = sectionname.Replace('_', ' ').ToLower();
            for (int ptr = 0; ptr < pengine.system.banned.Length; ptr++)
            {
                retvalue = retvalue.Replace(pengine.system.banned[ptr].ToString(), string.Empty);
            }
            return retvalue;
        }

        public bool section_delete(int articleid, string sectionname)
        {
            if ((articleid > 0) && (!string.IsNullOrEmpty(sectionname)))
            {
                sql_execute("Delete from ArticleSection where Name = '" + sectionname + "' and ArticleID = " + articleid.ToString());
                cache.index_del(cache.cache_type.section, cache.cache_subtype.none, string.Empty, articleid.ToString(), 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.none, string.Empty, articleid.ToString()
                    + "|" + sectionname, 0);
                cache.index_del(cache.cache_type.section, cache.cache_subtype.list, string.Empty, articleid.ToString(), 0);
                return true;
            }
            else
            {
                return false;
            }
        }

        public string section_default(int articleid)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select defaultsection from Articles where ID = " + articleid.ToString());
            if (string.IsNullOrEmpty(retvalue))
            {
                retvalue = (string)scalar_get("Select top 1 name from ArticleSection where ArticleID = " + articleid.ToString() + " order by sortorder,name asc");
            }
            return retvalue;
        }

        public int category_count(string category, bool admin)
        {
            int retvalue = 0;
            if (admin)
            {
                if (!string.IsNullOrEmpty(category))
                {
                    retvalue = (int)scalar_get("Select count(*) from Articles where category='" + category + "'");
                }
                else
                {
                    retvalue = (int)scalar_get("Select count(*) from Articles");
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(category))
                {
                    retvalue = (int)scalar_get("Select count(*) from Articles where category='" + category + "' and visible=true");
                }
                else
                {
                    retvalue = (int)scalar_get("Select count(*) from Articles where visible=true");
                }
            }
            return retvalue;
        }
    }
}