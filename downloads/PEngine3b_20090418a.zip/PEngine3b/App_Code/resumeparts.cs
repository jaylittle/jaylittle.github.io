using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

/// <summary>
/// Summary description for resumeparts
/// </summary>
namespace pengine
{
    public class resumeparts : pengine.dbaccess
    {
        public resumeparts(string mycstring)
            : base(mycstring)
        {
        }

        public DataTable personal_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ResumePersonal"
                , true, cache.cache_type.resume, cache.cache_subtype.personal, string.Empty);
            return retvalue;
        }

        public DataTable personal_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select TOP 1 * from ResumePersonal where id = " + id.ToString()
                , true, cache.cache_type.resume, cache.cache_subtype.personal, id.ToString());
            return retvalue;
        }

        public List<string> personal_save(ref int id, string name, string address, string city
            , string state, string zip, string phone, string fax, string email
            , string web)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(name))
            {
                errors.Add("You must supply a name for the personal information.");
            }
            if (string.IsNullOrEmpty(email))
            {
                errors.Add("You must supply an email address for the personal information.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from ResumePersonal where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from ResumePersonal"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Name"] = name;
                record["Address"] = address;
                record["City"] = city;
                record["State"] = state;
                record["Zip"] = zip;
                record["Phone"] = phone;
                record["Fax"] = fax;
                record["Email"] = email;
                record["Web"] = web;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.personal, string.Empty, string.Empty, 0);
            }
            return errors;
        }

        public bool personal_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from ResumePersonal where ID = " + id.ToString());
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.personal, string.Empty, string.Empty, 0);
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable objective_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ResumeObjective"
                , true, cache.cache_type.resume, cache.cache_subtype.objective, string.Empty);
            return retvalue;
        }

        public DataTable objective_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select TOP 1 * from ResumeObjective where id = " + id.ToString()
                , true, cache.cache_type.resume, cache.cache_subtype.objective, id.ToString());
            return retvalue;
        }

        public List<string> objective_save(ref int id, string description)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(description))
            {
                errors.Add("You must provide a description for this objective.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from ResumeObjective where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from ResumeObjective"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Description"] = description;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.objective, string.Empty, string.Empty, 0); 
            }
            return errors;
        }

        public bool objective_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from ResumeObjective where ID = " + id.ToString());
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.objective, string.Empty, string.Empty, 0);
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable skill_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ResumeSkills order by Type ASC"
                , true, cache.cache_type.resume, cache.cache_subtype.skill, string.Empty);
            return retvalue;
        }

        public DataTable skill_list(string type)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ResumeSkills where Type = '" + type + "' order by Type ASC"
                , true, cache.cache_type.resume, cache.cache_subtype.skill, type);
            return retvalue;
        }

        public DataTable skill_type_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select Distinct Type from ResumeSkills order by Type ASC"
                , true, cache.cache_type.resume, cache.cache_subtype.skill_types, string.Empty);
            return retvalue;
        }

        public DataTable skill_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select TOP 1 * from ResumeSkills where id = " + id.ToString()
                , true, cache.cache_type.resume, cache.cache_subtype.skill, id.ToString());
            return retvalue;
        }

        public List<string> skill_save(ref int id, string name, string type)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            if (string.IsNullOrEmpty(name))
            {
                errors.Add("You must supply a name for the skill.");
            }
            if (string.IsNullOrEmpty(type))
            {
                errors.Add("You must supply a type for the skill to be listed with.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from ResumeSkills where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from ResumeSkills"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Name"] = name;
                record["Type"] = type;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.skill, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.skill_types, string.Empty, string.Empty, 0);
            }
            return errors;
        }

        public bool skill_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from ResumeSkills where ID = " + id.ToString());
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.skill, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.skill_types, string.Empty, string.Empty, 0);
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable education_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ResumeEducation order by DateStarted DESC"
                , true, cache.cache_type.resume, cache.cache_subtype.education, string.Empty);
            return retvalue;
        }

        public DataTable education_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select TOP 1 * from ResumeEducation where id = " + id.ToString()
                , true, cache.cache_type.resume, cache.cache_subtype.education, id.ToString());
            return retvalue;
        }

        public List<string> education_save(ref int id, string institute, string http
            , string program, string started, string left)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            DateTime dtleft = DateTime.MinValue;
            DateTime dtstarted = DateTime.MinValue;
            try
            {
                dtleft = DateTime.Parse(left);
            }
            catch
            {
                errors.Add("Left Date must be provided in valid format.");
            }
            try
            {
                dtstarted = DateTime.Parse(started);
            }
            catch
            {
                errors.Add("Started Date must be provided in valid format.");
            }
            if (string.IsNullOrEmpty(institute))
            {
                errors.Add("You must supply the name of the an institute for this education record.");
            }
            if (string.IsNullOrEmpty(program))
            {
                errors.Add("You must supply a program of study for this education record.");
            }
            if (string.IsNullOrEmpty(http))
            {
                errors.Add("You must provide a URL for this institute.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from ResumeEducation where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from ResumeEducation"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Institute"] = institute;
                record["HTTP"] = http;
                record["Program"] = program;
                record["DateStarted"] = dtstarted.ToShortDateString();
                record["DateLeft"] = dtleft.ToShortDateString();
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.education, string.Empty, string.Empty, 0);
            }
            return errors;
        }

        public bool education_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from ResumeEducation where ID = " + id.ToString());
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.education, string.Empty, string.Empty, 0);
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable workhistory_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from ResumeWorkHistory order by DateStarted DESC"
                , true, cache.cache_type.resume, cache.cache_subtype.workhistory, string.Empty);
            return retvalue;
        }

        public DataTable workhistory_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select TOP 1 * from ResumeWorkHistory where id = " + id.ToString()
                , true, cache.cache_type.resume, cache.cache_subtype.workhistory, id.ToString());
            return retvalue;
        }

        public List<string> workhistory_save(ref int id, string employer, string http
            , string title, string started, string left, string description)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            DateTime dtleft = DateTime.MinValue;
            DateTime dtstarted = DateTime.MinValue;
            try
            {
                dtleft = DateTime.Parse(left);
            }
            catch
            {
                errors.Add("Left Date must be provided in valid format.");
            }
            try
            {
                dtstarted = DateTime.Parse(started);
            }
            catch
            {
                errors.Add("Started Date must be provided in valid format.");
            }
            if (string.IsNullOrEmpty(employer))
            {
                errors.Add("You must supply an employer name for this work history record.");
            }
            if (string.IsNullOrEmpty(title))
            {
                errors.Add("You must supply a title name for this work history record.");
            }
            if (string.IsNullOrEmpty(description))
            {
                errors.Add("You must supply a description for this work history record.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from ResumeWorkHistory where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select * from ResumeWorkHistory"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Employer"] = employer;
                record["HTTP"] = http;
                record["Title"] = title;
                record["DateStarted"] = dtstarted.ToShortDateString();
                record["DateLeft"] = dtleft.ToShortDateString();
                record["Description"] = description;
                if (id > 0)
                {
                    data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.workhistory, string.Empty, string.Empty, 0);
            }
            return errors;
        }

        public bool workhistory_delete(int id)
        {
            if (id > 0)
            {
                sql_execute("Delete from ResumeWorkHistory where ID = " + id.ToString());
                cache.index_del(cache.cache_type.resume, cache.cache_subtype.workhistory, string.Empty, string.Empty, 0);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}