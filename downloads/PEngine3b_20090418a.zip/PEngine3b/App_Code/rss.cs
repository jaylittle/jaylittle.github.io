using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for rss
/// </summary>
namespace pengine
{
    public static class rss
    {
        public static void generate()
        {
            int rssperpage = (int) settings.query(settings.app_setting_key.app_recpage_rss);
            generate(rssperpage);
        }

        public static void generate(int count)
        {
            bool excluderss = (bool)settings.query(settings.app_setting_key.app_exclude_rss);
            if (!excluderss)
            {
                string rsspath = system.path_base + "rss.xml";
                if (System.IO.File.Exists(rsspath))
                {
                    System.IO.File.Delete(rsspath);
                }
                string location = (string)HttpContext.Current.Request.ServerVariables["SERVER_NAME"]
                    + ":" + HttpContext.Current.Request.ServerVariables["SERVER_PORT"]
                    + HttpContext.Current.Request.ApplicationPath;
                string title = (string)settings.query(settings.app_setting_key.app_default_title);
                string logo = (string)settings.query(settings.app_setting_key.app_logo_frontpage);
                string framexml = string.Empty;
                System.Xml.XmlDocument rssfeed = new System.Xml.XmlDocument();
                System.Xml.XmlNode rsschannel;

                framexml += "<rss version=\"2.0\"><channel><title>"
                    + title + "</title>" + "<link>http://" + location + "</link><description>"
                    + title + "</description><lastBuildDate>" + String.Format("{0:R}", DateTime.Now)
                    + " " + "</lastBuildDate><language>en-us</language>";
                if (!string.IsNullOrEmpty(logo))
                {
                    framexml += "<image><title>" + title + "</title><link>http://" + location + "</link>"
                        + "<url>http://" + location + "/images/system/" + logo + "</url></image>";
                }
                framexml += "</channel></rss>";
                rssfeed.LoadXml(framexml);
                rsschannel = rssfeed.SelectSingleNode("/rss/channel");
                news newobj = new news(system.conn_pengine);
                newobj.open();
                DataTable updates = newobj.news_range(-1, count, false);
                if ((updates != null) && (updates.Rows.Count > 0))
                {
                    for (int newptr = 0; newptr < updates.Rows.Count; newptr++)
                    {
                        DateTime pubdate = (DateTime)updates.Rows[newptr]["timeposted"];
                        rsschannel.InnerXml += "<item><title>"
                            + HttpContext.Current.Server.HtmlEncode((string)updates.Rows[newptr]["title"])
                            + "</title>" + "<link>http://" + location + "/default.aspx?cmd=news&amp;sub=display&amp;id="
                            + updates.Rows[newptr]["ID"] + "</link><pubDate>" + String.Format("{0:R}", pubdate)
                            + "</pubDate><description>"
                            + HttpContext.Current.Server.HtmlEncode(news.news_truncate((string)updates.Rows[newptr]["articledata"], -1))
                            + "</description></item>";
                    }
                    rssfeed.Save(rsspath);
                }
                newobj.close();
            }
        }
    }
}
