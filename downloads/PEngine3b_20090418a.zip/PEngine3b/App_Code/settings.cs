using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Collections.Generic;

namespace pengine
{
    public static class settings
    {

        public enum app_setting_type
        {
            none,
            type_int,
            type_string,
            type_bool
        }

        public enum app_setting_key
        {
            none,
            old_db_path,
            app_owner_name,
            app_owner_email,
            app_default_title,
            app_default_theme,
            app_logo_frontpage,
            app_recpage_news_summary,
            app_recpage_news,
            app_recpage_search_results,
            app_recpage_forum_posts,
            app_recpage_rss,
            app_timelimit_forum_edit,
            app_timelimit_forum_login,
            app_timelimit_admin_login,
            app_exclude_resume,
            app_exclude_theme,
            app_exclude_leet,
            app_exclude_quotes,
            app_exclude_search,
            app_exclude_forum,
            app_exclude_rss,
            app_exclude_print,
            app_label_home,
            app_label_theme,
            app_label_resume,
            app_label_leet,
            app_label_leet2,
            app_label_admin,
            app_label_admin2,
            app_label_print,
            app_label_quote,
            app_notoggle_quote,
            app_db_name,
            app_pass_admin,
            app_pass_god
        }

        public static void reset(ref System.Configuration.Configuration config, bool nooverwrite)
        {
            update(app_setting_key.app_owner_name, "PEngine User", ref config, nooverwrite);
            update(app_setting_key.app_owner_email, "pengineuser@pengine.com", ref config, nooverwrite);
            update(app_setting_key.app_default_title, "Presentation Engine 3.5b", ref config, nooverwrite);
            update(app_setting_key.app_default_theme, "default", ref config, nooverwrite);
            update(app_setting_key.app_logo_frontpage, "penginelogo.png", ref config, nooverwrite);
            update(app_setting_key.app_recpage_news_summary, 10, ref config, nooverwrite);
            update(app_setting_key.app_recpage_news, 5, ref config, nooverwrite);
            update(app_setting_key.app_recpage_search_results, 20, ref config, nooverwrite);
            update(app_setting_key.app_recpage_forum_posts, 15, ref config, nooverwrite);
            update(app_setting_key.app_recpage_rss, 20, ref config, nooverwrite);
            update(app_setting_key.app_timelimit_forum_edit, 30, ref config, nooverwrite);
            update(app_setting_key.app_timelimit_admin_login, 30, ref config, nooverwrite);
            update(app_setting_key.app_timelimit_forum_login, 30, ref config, nooverwrite);
            update(app_setting_key.app_exclude_resume, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_theme, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_leet, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_quotes, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_search, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_forum, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_rss, false, ref config, nooverwrite);
            update(app_setting_key.app_exclude_print, false, ref config, nooverwrite);
            update(app_setting_key.app_label_home, "Home", ref config, nooverwrite);
            update(app_setting_key.app_label_theme, "Theme", ref config, nooverwrite);
            update(app_setting_key.app_label_leet, "I am Elite", ref config, nooverwrite);
            update(app_setting_key.app_label_leet2, "I am a Loser", ref config, nooverwrite);
            update(app_setting_key.app_label_admin, "Admin", ref config, nooverwrite);
            update(app_setting_key.app_label_admin2, "Standard", ref config, nooverwrite);
            update(app_setting_key.app_label_print, "Print", ref config, nooverwrite);
            update(app_setting_key.app_label_quote, "Quote of the Day", ref config, nooverwrite);
            update(app_setting_key.app_notoggle_quote, false, ref config, nooverwrite);
            update(app_setting_key.app_db_name, "pengine.mdb", ref config, nooverwrite);
            update(app_setting_key.app_pass_admin, string.Empty, ref config, nooverwrite);
            update(app_setting_key.app_pass_god, string.Empty, ref config, nooverwrite);
            update(app_setting_key.old_db_path, string.Empty, ref config, nooverwrite);
        }

        public static app_setting_type gettype(app_setting_key key)
        {
            app_setting_type retvalue;
            switch (key)
            {
                case app_setting_key.app_exclude_resume:
                case app_setting_key.app_exclude_theme:
                case app_setting_key.app_exclude_leet:
                case app_setting_key.app_exclude_quotes:
                case app_setting_key.app_exclude_search:
                case app_setting_key.app_exclude_forum:
                case app_setting_key.app_exclude_rss:
                case app_setting_key.app_exclude_print:
                case app_setting_key.app_notoggle_quote:
                    retvalue = app_setting_type.type_bool;
                    break;
                case app_setting_key.app_recpage_news_summary:
                case app_setting_key.app_recpage_news:
                case app_setting_key.app_recpage_search_results:
                case app_setting_key.app_recpage_forum_posts:
                case app_setting_key.app_recpage_rss:
                case app_setting_key.app_timelimit_forum_edit:
                case app_setting_key.app_timelimit_admin_login:
                case app_setting_key.app_timelimit_forum_login:
                    retvalue = app_setting_type.type_int;
                    break;
                case app_setting_key.none:
                    retvalue = app_setting_type.none;
                    break;
                default:
                    retvalue = app_setting_type.type_string;
                    break;
            }
            return retvalue;
        }

        public static object query(app_setting_key key)
        {
            System.Configuration.Configuration config = snapshot();
            return query(key, ref config);
        }

        public static object query(app_setting_key key, ref System.Configuration.Configuration config)
        {
            object retvalue = null;
            string name = key.ToString();
            string value = query(name, ref config);
            switch (gettype(key))
            {
                case app_setting_type.type_bool:
                    if ((value == "true") || (value == "1"))
                    {
                        retvalue = true;
                    }
                    else
                    {
                        retvalue = false;
                    }
                    break;
                case app_setting_type.type_int:
                    if (system.IsNumeric(value))
                    {
                        retvalue = Convert.ToInt32(value);
                    }
                    else
                    {
                        retvalue = (int) 0;
                    }
                    break;
                case app_setting_type.type_string:
                    retvalue = value;
                    break;
                case app_setting_type.none:
                    retvalue = null;
                    break;
            }
            return retvalue;
        }

        private static string query(string name)
        {
            System.Configuration.Configuration config = snapshot();
            return query(name, ref config);
        }

        private static string query(string name, ref System.Configuration.Configuration config)
        {
            if (config.AppSettings.Settings[name] != null)
            {
                return config.AppSettings.Settings[name].Value;
            }
            else
            {
                return string.Empty;
            }
        }

        public static void update(app_setting_key key, object value, ref System.Configuration.Configuration config, bool nooverwrite)
        {
            switch (key)
            {
                case app_setting_key.old_db_path:
                    system.url_olddb = (string) value;
                    break;
                default:
                    string strvalue = string.Empty;
                    string name = key.ToString();
                    bool skipflag = false;
                    switch (gettype(key))
                    {
                        case app_setting_type.type_bool:
                            if (value is bool)
                            {
                                if (((bool)value) == true)
                                {
                                    strvalue = "true";
                                }
                                else
                                {
                                    strvalue = "false";
                                }
                            }
                            else if (value is string)
                            {
                                strvalue = ((string)value).ToLower();
                                if ((strvalue == "true") || (strvalue == "1"))
                                {
                                    strvalue = "true";
                                }
                                else
                                {
                                    strvalue = "false";
                                }
                            }
                            break;
                        case app_setting_type.type_int:
                            if (value is int)
                            {
                                strvalue = ((int)value).ToString();
                            }
                            else if (value is string)
                            {
                                if (system.IsNumeric((string)value))
                                {
                                    strvalue = (string)value;
                                }
                                else
                                {
                                    strvalue = "0";
                                }
                            }
                            break;
                        case app_setting_type.type_string:
                            strvalue = (string)value;
                            break;
                        case app_setting_type.none:
                            skipflag = true;
                            break;
                    }
                    if (skipflag == false)
                    {
                        if (config.AppSettings.Settings[name] != null)
                        {
                            if (!nooverwrite)
                            {
                                config.AppSettings.Settings[name].Value = strvalue;
                            }
                        }
                        else
                        {
                            config.AppSettings.Settings.Add(name, strvalue);
                        }
                    }
                    break;
            }
        }

        public static void update(string name, object value, ref System.Configuration.Configuration config, bool nooverwrite)
        {
            app_setting_key key = translate(name);
            update(key, value, ref config, nooverwrite);
        }

        public static System.Configuration.Configuration snapshot()
        {
            return System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("~");
        }

        static private app_setting_key translate(string name)
        {
            app_setting_key retvalue;
            switch (name.ToLower())
            {
                case "ownername":
                    retvalue = app_setting_key.app_owner_name;
                    break;
                case "owneremail":
                    retvalue = app_setting_key.app_owner_email;
                    break;
                case "defaultpagetitle":
                    retvalue = app_setting_key.app_default_title;
                    break;
                case "defaulttheme":
                    retvalue = app_setting_key.app_default_theme;
                    break;
                case "frontpagelogo":
                    retvalue = app_setting_key.app_logo_frontpage;
                    break;
                case "newssummaryperpage":
                    retvalue = app_setting_key.app_recpage_news_summary;
                    break;
                case "newsperpage":
                    retvalue = app_setting_key.app_recpage_news;
                    break;
                case "searchresultsperpage":
                    retvalue = app_setting_key.app_recpage_search_results;
                    break;
                case "forumpostsperpage":
                    retvalue = app_setting_key.app_recpage_forum_posts;
                    break;
                case "forumeditlimit":
                    retvalue = app_setting_key.app_timelimit_forum_edit;
                    break;
                case "excluderesume":
                    retvalue = app_setting_key.app_exclude_resume;
                    break;
                case "excludetheme":
                    retvalue = app_setting_key.app_exclude_theme;
                    break;
                case "excludeleet":
                    retvalue = app_setting_key.app_exclude_leet;
                    break;
                case "excludequotes":
                    retvalue = app_setting_key.app_exclude_quotes;
                    break;
                case "excludesearch":
                    retvalue = app_setting_key.app_exclude_search;
                    break;
                case "excludeprint":
                    retvalue = app_setting_key.app_exclude_print;
                    break;
                case "homelabel":
                    retvalue = app_setting_key.app_label_home;
                    break;
                case "themelabel":
                    retvalue = app_setting_key.app_label_theme;
                    break;
                case "resumelabel":
                    retvalue = app_setting_key.app_label_resume;
                    break;
                case "leetlabel":
                    retvalue = app_setting_key.app_label_leet;
                    break;
                case "leetlabel2":
                    retvalue = app_setting_key.app_label_leet2;
                    break;
                case "adminlabel":
                    retvalue = app_setting_key.app_label_admin;
                    break;
                case "adminlabel2":
                    retvalue = app_setting_key.app_label_admin2;
                    break;
                case "dbrelativepath":
                    retvalue = app_setting_key.old_db_path;
                    break;
                case "dbfilename":
                    retvalue = app_setting_key.app_db_name;
                    break;
                case "timeout":
                    retvalue = app_setting_key.app_timelimit_admin_login;
                    break;
                case "adminpass":
                    retvalue = app_setting_key.app_pass_admin;
                    break;
                case "godpass":
                    retvalue = app_setting_key.app_pass_god;
                    break;
                case "excludeforum":
                    retvalue = app_setting_key.app_exclude_forum;
                    break;
                default:
                    try
                    {
                        retvalue = (app_setting_key)Enum.Parse(typeof(app_setting_key), name, true);
                    }
                    catch
                    {
                        retvalue = app_setting_key.none;
                    }
                    break;
            }
            return retvalue;
        }

        public static bool load()
        {
            System.Configuration.Configuration config = snapshot();
            return load(ref config);
        }

        public static bool load(ref System.Configuration.Configuration config)
        {
            bool retvalue = true;
            //Check for old pre 3.5 config file and load and convert if required.
            if (File.Exists(HttpContext.Current.Server.MapPath("~/settings.asp")))
            {
                reset(ref config, false);
                string[] records = File.ReadAllLines(HttpContext.Current.Server.MapPath("~/settings.asp"));
                for (int rptr = 0; rptr < records.Length; rptr++)
                {
                    if (records[rptr].StartsWith("'"))
                    {
                        records[rptr] = records[rptr].Substring(1, records[rptr].Length - 1);
                        string[] fields = records[rptr].Split(',');
                        update(fields[0], fields[1], ref config, false);
                    }
                }
                List<string> errors = save(ref config);
                if (errors.Count <= 0)
                {
                    System.IO.File.Delete(HttpContext.Current.Server.MapPath("~/settings.asp"));
                }
                else
                {
                    retvalue = false;
                    //throw new Exception("Default PEngine Settings do not meet data type requirements and contain errors.");
                }
            }
            else
            {
                reset(ref config, true);
                List<string> errors = save(ref config);
                if (errors.Count > 0)
                {
                    retvalue = false;
                }
            }

            system.conn_pengine = "PROVIDER=Microsoft.Jet.OLEDB.4.0;"
                + "Jet OLEDB:Database Locking Mode=1;Data Source=" + pengine.system.path_db
                + (string)query(app_setting_key.app_db_name);
            if (((bool)query(app_setting_key.app_exclude_forum) == false)
                && (File.Exists(pengine.system.path_db + "forum.mdb")))
            {
                system.conn_forum = "PROVIDER=Microsoft.Jet.OLEDB.4.0;"
                    + "Jet OLEDB:Database Locking Mode=1;Data Source=" + pengine.system.path_db + "forum.mdb";
                system.active_forum = true;
            }
            else
            {
                system.active_forum = false;
            }
            system.flag_loaded = retvalue;
            return retvalue;
        }

        public static bool isvalid(app_setting_key key, string value)
        {
            bool retvalue = false;
            switch (gettype(key))
            {
                case app_setting_type.type_bool:
                    switch (value.ToLower())
                    {
                        case "true":
                        case "false":
                        case "1":
                        case "0":
                            retvalue = true;
                            break;
                        default:
                            retvalue = false;
                            break;
                    }
                    break;
                case app_setting_type.type_int:
                    retvalue = system.IsNumeric(value);
                    break;
                case app_setting_type.type_string:
                    retvalue = true;
                    break;
                case app_setting_type.none:
                    retvalue = true;
                    break;
            }
            return retvalue;
        }

        public static List<string> save(ref System.Configuration.Configuration config)
        {
            List<string> Errors = new List<string>();
            int[] keyvals = (int[])Enum.GetValues(typeof(app_setting_key));
            for (int keyptr = 0; keyptr < keyvals.Length; keyptr++)
            {
                app_setting_key key = (app_setting_key) Enum.ToObject(typeof(app_setting_key), keyvals[keyptr]);
                app_setting_type type = gettype(key);
                string name = key.ToString();
                string value = query(name, ref config);
                if (!isvalid(key, value))
                {
                    Errors.Add("Invalid data type value provided for setting, '" + name + "'");
                }
            }
            
            string dbpath = system.path_db + (string) query(app_setting_key.app_db_name, ref config);
            if (File.Exists(dbpath) == false)
            {
                if ((string.IsNullOrEmpty(system.path_olddb()))
                    || (File.Exists(system.path_olddb() + (string)query(app_setting_key.app_db_name, ref config)) == false))
                {
                    Errors.Add("The combination of the database path and filename point to a non-existant file.");
                }
            }
            if (Errors.Count == 0)
            {
                try
                {
                    config.Save(ConfigurationSaveMode.Modified);
                }
                catch (Exception ex)
                {
                    Errors.Add("Unable to save runtime.config changes: " + ex.Message);
                }
            }
            return Errors;
        }
    }

}