using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

/// <summary>
/// Summary description for news
/// </summary>
namespace pengine
{
    public class news : pengine.dbaccess
    {
        public news(string mycstring)
            : base(mycstring)
        {
        }

        public DataTable news_get(int id)
        {
            DataTable retvalue = null;
            retvalue = data_load("Select TOP 1 * from SystemNews where id = " + id.ToString() + " order by timeposted DESC"
                ,true, cache.cache_type.news, cache.cache_subtype.none, id.ToString());
            return retvalue;
        }

        public DataTable news_list()
        {
            DataTable retvalue = null;
            retvalue = data_load("Select * from SystemNews order by timeposted DESC"
                ,true, cache.cache_type.news, cache.cache_subtype.list, string.Empty);
            return retvalue;
        }

        public DataTable news_current()
        {
            DataTable retvalue = null;
            int count = (int)settings.query(settings.app_setting_key.app_recpage_news);
            retvalue = data_load("Select TOP " + count.ToString() + " * from SystemNews order by timeposted DESC"
                ,true, cache.cache_type.news, cache.cache_subtype.current, "current");
            return retvalue;
        }

        public DataTable news_range(int lastid, int count, bool reverse)
        {
            DataTable retvalue = null;
            int startid = -1;
            if ((lastid > 0) && (reverse))
            {
                retvalue = data_load("Select TOP " + count.ToString()
                    + " * from SystemNews where ID > " + lastid.ToString() + " order by timeposted ASC"
                    , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                if (retvalue.Rows.Count > 0)
                {
                    for (int rowptr = 0; rowptr < retvalue.Rows.Count; rowptr++)
                    {
                        startid = (int)retvalue.Rows[rowptr]["ID"];
                    }
                    retvalue = data_load("Select TOP " + count.ToString()
                        + " * from SystemNews where ID <= " + startid.ToString() + " order by timeposted DESC"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                }
            }
            else
            {
                startid = lastid;
                if (startid > 0)
                {
                    retvalue = data_load("Select TOP " + count.ToString()
                        + " * from SystemNews where ID < " + startid.ToString() + " order by timeposted DESC"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                }
                else
                {
                    retvalue = data_load("Select TOP " + count.ToString()
                        + " * from SystemNews order by timeposted DESC"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                }
            }
            return retvalue;
        }

        public int news_topid()
        {
            int retvalue = 0;
            retvalue = (int)scalar_get("Select TOP 1 ID from SystemNews order by timeposted DESC");
            return retvalue;
        }

        public int news_bottomid()
        {
            int retvalue = 0;
            retvalue = (int)scalar_get("Select TOP 1 ID from SystemNews order by timeposted ASC");
            return retvalue;
        }

        public string news_title(int id)
        {
            string retvalue = string.Empty;
            retvalue = (string)scalar_get("Select TOP 1 title from SystemNews where id = " + id.ToString() + " order by timeposted ASC");
            return retvalue;
        }

        static public string news_truncate(string data)
        {
            return news_truncate(data, 75);
        }

        static public string news_truncate(string data, int length)
        {
            string retvalue = string.Empty;
            data = data.Replace("[", string.Empty);
            data = data.Replace("]", string.Empty);
            data = data.Replace("<", string.Empty);
            data = data.Replace(">", string.Empty);
            if (length > 0)
            {
                if (data.Length > length)
                {
                    retvalue = data.Substring(0, length) + "...";
                }
                else
                {
                    retvalue = data;
                }
            }
            else
            {
                int strptr = data.IndexOf(Environment.NewLine);
                if (strptr >= 0)
                {
                    retvalue = data.Substring(0, strptr);
                }
            }
            return retvalue;
        }

        public List<string> news_save(ref int id, string title, string date, string time, string text, string icon)
        {
            List<string> errors = new List<string>();
            DataRow record;
            DataTable table;
            DateTime timestamp = DateTime.MinValue;
            bool dbflag = false;
            try
            {
                timestamp = DateTime.Parse(date + " " + time);
            }
            catch
            {
                errors.Add("Date and Time must be provided in valid formats.");
            }
            if (string.IsNullOrEmpty(title))
            {
                errors.Add("You must supply a title for this news posting.");
            }
            if (string.IsNullOrEmpty(text))
            {
                errors.Add("You must supply some text for this news posting.");
            }
            if (errors.Count == 0)
            {
                if (id > 0)
                {
                    table = data_load("Select * from SystemNews where ID = " + id.ToString()
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.Rows[0];
                }
                else
                {
                    table = data_load("Select TOP 1 * from SystemNews"
                        , false, cache.cache_type.all, cache.cache_subtype.all, string.Empty);
                    record = table.NewRow();
                }
                record["Title"] = title;
                record["ArticleData"] = text;
                record["timeposted"] = timestamp.ToShortDateString() + " " + timestamp.ToShortTimeString();
                record["IconFileName"] = icon;
                if (id > 0)
                {
                    dbflag = data_update(ref table);
                }
                else
                {
                    table.Rows.Add(record);
                    dbflag = data_update(ref table);
                    id = (int)scalar_get("SELECT @@IDENTITY");
                }
                if (!dbflag)
                {
                    errors.Add("A database error occurred preventing the update from taking place.");
                }
                cache.index_del(cache.cache_type.news, cache.cache_subtype.none, string.Empty, id.ToString(), 0);
                cache.index_del(cache.cache_type.news, cache.cache_subtype.list, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.news, cache.cache_subtype.current, string.Empty, string.Empty, 0);
                rss.generate();
            }
            return errors;
        }

        public bool news_delete(int id)
        {
            bool dbflag = false;
            if (id > 0)
            {
                dbflag = sql_execute("Delete from SystemNews where ID = " + id.ToString());
                cache.index_del(cache.cache_type.news, cache.cache_subtype.none, string.Empty, id.ToString(), 0);
                cache.index_del(cache.cache_type.news, cache.cache_subtype.list, string.Empty, string.Empty, 0);
                cache.index_del(cache.cache_type.news, cache.cache_subtype.current, string.Empty, string.Empty, 0);
                rss.generate();
            }
            else
            {
                dbflag = false;
            }
            return dbflag;
        }

        static public string[] icon_list()
        {
            List<string> retvalue = new List<string>();
            System.IO.DirectoryInfo icondir = new System.IO.DirectoryInfo(system.path_base + "images\\icons");
            System.IO.FileSystemInfo[] icons = icondir.GetFileSystemInfos();
            for (int icnptr = 0; icnptr < icons.Length; icnptr++)
            {
                retvalue.Add(icons[icnptr].Name);
            }
            return retvalue.ToArray();
        }
    }
}