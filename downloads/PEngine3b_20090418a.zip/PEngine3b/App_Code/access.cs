using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

namespace pengine
{
    /// <summary>
    /// Summary description for access
    /// </summary>
    public class access
    {
        private Dictionary<system.access_level, bool> levels = new Dictionary<system.access_level, bool>();
        private Dictionary<int, bool> articles = new Dictionary<int, bool>();

        public DateTime session_start = new DateTime();
        public int forum_userid = 0;
        //public int article_lastid = 0;

        public access()
        {
            add(system.access_level.none);
            rebuild();
            session_start = DateTime.Now;
        }

        public void rebuild()
        {
            //Rebuild access token using Cookie values
            HttpRequest MyRequest = HttpContext.Current.Request;
            for (int cptr = 0; cptr < MyRequest.Cookies.Count; cptr++)
            {
                cookie_check(MyRequest.Cookies[cptr]);
            }
        }

        public void add(system.access_level alevel, bool cookie, int n_objid)
        {
            if (!levels.ContainsKey(alevel))
            {
                levels.Add(alevel, true);
                if ((alevel == system.access_level.forum) && (n_objid > 0))
                {
                    forum_userid = n_objid;
                }
                if (cookie)
                {
                    switch (alevel)
                    {
                        case system.access_level.admin:
                            cookie_add(system.login_type.system, "admin");
                            break;
                        case system.access_level.god:
                            cookie_add(system.login_type.system, "god");
                            break;
                        case system.access_level.forum:
                            cookie_add(system.login_type.forum, forum_userid.ToString());
                            break;
                    }
                }
            }
        }

        public void add(system.access_level alevel)
        {
            add(alevel, false);
        }

        public void add(system.access_level alevel, bool cookie)
        {
            if (alevel != system.access_level.forum)
            {
                add(alevel, cookie, 0);
            }
            else
            {
                throw new Exception("Single parameter access level add function cannot be called for the forum level.");
            }
        }

        public bool has(system.access_level alevel)
        {
            return levels.ContainsKey(alevel);
        }

        public void remove(system.access_level alevel)
        {
            if (levels.ContainsKey(alevel))
            {
                levels.Remove(alevel);
                switch (alevel)
                {
                    case system.access_level.admin:
                        cookie_del(system.login_type.system, "admin");
                        break;
                    case system.access_level.god:
                        cookie_del(system.login_type.system, "god");
                        break;
                    case system.access_level.forum:
                        cookie_del(system.login_type.forum, forum_userid.ToString());
                        break;
                }
            }
        }

        public void article_add(int id)
        {
            article_add(id, false);
        }

        public void article_add(int id, bool cookie)
        {
            if (!articles.ContainsKey(id))
            {
                articles.Add(id, true);
                if (cookie)
                {
                    cookie_add(system.login_type.article, id.ToString());
                }
            }
        }

        public bool article_has(int id)
        {
            return articles.ContainsKey(id);
        }

        public void article_remove(int id)
        {
            if (articles.ContainsKey(id))
            {
                articles.Remove(id);
                cookie_del(system.login_type.article, id.ToString());
            }
        }

        private void cookie_add(system.login_type log_type, string parameter)
        {
            string value = cookie_value(log_type, parameter);
            if (!string.IsNullOrEmpty(value))
            {
                HttpCookie mycookie = new HttpCookie("login:" + log_type.ToString() + ":" + parameter, value);
                mycookie.Expires = DateTime.Now.AddDays(30);
                HttpContext.Current.Response.Cookies.Add(mycookie);
            }
        }

        private void cookie_del(system.login_type log_type, string parameter)
        {
            if (HttpContext.Current.Response.Cookies["login:" + log_type.ToString() + ":" + parameter] != null)
            {
                HttpContext.Current.Response.Cookies["login:" + log_type.ToString() + ":" + parameter].Expires = DateTime.Now.AddDays(-1);
            }
        }

        private string cookie_value(system.login_type log_type, string parameter)
        {
            string retvalue = string.Empty;
            switch (log_type)
            {
                case system.login_type.article:
                    article artobj = new article(system.conn_pengine);
                    DataTable article = artobj.article_get(Convert.ToInt32(parameter));
                    artobj.close();
                    if ((article != null) && (article.Rows.Count > 0))
                    {
                        retvalue = (string)article.Rows[0]["AdminPass"];
                    }
                    break;
                case system.login_type.forum:
                    forum frmobj = new forum(system.conn_forum);
                    frmobj.open();
                    DataTable user = frmobj.user_get(forum_userid);
                    if ((user != null) && (user.Rows.Count > 0))
                    {
                        retvalue = (string)user.Rows[0]["UserPass"];
                    }
                    frmobj.close();
                    break;
                case system.login_type.system:
                    if (parameter == "admin")
                    {
                        retvalue = (string)settings.query(settings.app_setting_key.app_pass_admin);
                    }
                    else if (parameter == "god")
                    {
                        retvalue = (string)settings.query(settings.app_setting_key.app_pass_god);
                    }
                    break;
            }
            return retvalue;
        }

        private void cookie_check(HttpCookie cookie)
        {
            string[] keys = cookie.Name.Split(':');
            if ((keys.Length == 3) && (keys[0] == "login"))
            {
                system.login_type ltype = system.login_type.none;
                try
                {
                    ltype = (system.login_type) Enum.Parse(typeof(system.login_type), keys[1], true);
                }
                catch
                {
                    ltype = system.login_type.none;
                }
                if (ltype != system.login_type.none)
                {
                    string param = keys[2];
                    string value = cookie_value(ltype, param);
                    if ((!string.IsNullOrEmpty(value)) && (value == cookie.Value))
                    {
                        //Add appropriate access level for cookie as it has been verified
                        switch (ltype)
                        {
                            case system.login_type.article:
                                article_add(Convert.ToInt32(param));
                                break;
                            case system.login_type.forum:
                                int userid = Convert.ToInt32(param);
                                add(system.access_level.forum, false, userid);
                                forum frmobj = new forum(system.conn_forum);
                                frmobj.open();
                                DataTable user = frmobj.user_get(userid);
                                if ((user != null) && (user.Rows.Count > 0) && (Convert.ToBoolean(user.Rows[0]["ModeratorFlag"])))
                                {
                                    add(system.access_level.forumadmin, false, userid);
                                }
                                frmobj.close();
                                break;
                            case system.login_type.system:
                                if (param.ToLower() == "god")
                                {
                                    add(system.access_level.god);
                                    add(system.access_level.admin);
                                }
                                else if (param.ToLower() == "admin")
                                {
                                    add(system.access_level.admin);
                                }
                                break;
                        }
                    }
                    else
                    {
                        //Cookie Value is invalid - delete on response
                        cookie_del(ltype, param);
                    }
                }
            }
        }
    }
}