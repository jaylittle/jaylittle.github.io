using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

namespace pengine
{
    public class dbaccess
    {
        private OleDbConnection peconn = null;
        private OleDbDataAdapter pedap = null;
        private string cstring = string.Empty;
        private bool cflag = false;

        public dbaccess(string mycstring)
        {
            init(mycstring);
        }

        ~dbaccess()
        {
            if (cflag)
            {
                close();
            }
        }

        public void init(string mycstring)
        {
            cstring = mycstring;
        }

        public bool open()
        {
            if (!cflag)
            {
                try
                {
                    peconn = new OleDbConnection(cstring);
                    peconn.Open();
                    cflag = true;
                }
                catch
                {
                    cflag = false;
                    close();
                }
            }
            return cflag;
        }

        public void close()
        {
            if (cflag)
            {
                pedap = null;
                try
                {
                    peconn.Close();
                    peconn = null;
                }
                catch
                {
                    peconn = null;
                }
                finally
                {
                    cflag = false;
                }
            }
        }

        public DataTable data_load(string SQL, bool wcache, cache.cache_type type
            , cache.cache_subtype subtype, string parameter)
        {
            bool cached = false;
            DataTable retvalue = null;
            if ((wcache) && (cache.index_count(SQL) > 0))
            {
                retvalue = cache.index_retrieve(SQL);
                cached = true;
            }
            else
            {
                DataSet tempds = new DataSet();
                if (open())
                {
                    try
                    {
                        pedap = new OleDbDataAdapter(SQL, peconn);
                        pedap.Fill(tempds);
                    }
                    catch 
                    {
                        tempds = null;
                    }
                }
                if ((tempds != null) && (tempds.Tables.Count > 0))
                {
                    retvalue = tempds.Tables[0];
                }
                else
                {
                    retvalue = null;
                }
            }
            if ((wcache) && (!cached) && (retvalue != null))
            {
                cache.index_add(type, subtype, SQL, parameter, retvalue);
            }
            return retvalue;
        }

        public bool data_update(ref DataTable MyData)
        {
            bool retvalue = false;
            if (open())
            {
                try
                {
                    OleDbCommandBuilder pecmd = new OleDbCommandBuilder(pedap);
                    pedap.Update(MyData);
                    retvalue = true;
                }
                catch
                {
                    retvalue = false;
                }
            }
            return retvalue;
        }

        public object scalar_get(string SQL)
        {
            object retvalue = null;
            if (open())
            {
                try
                {
                    OleDbCommand pecmd = new OleDbCommand(SQL, peconn);
                    retvalue = pecmd.ExecuteScalar();
                    pecmd = null;
                }
                catch
                {
                    retvalue = null;
                }
            }
            return retvalue;
        }

        public bool sql_execute(string SQL)
        {
            bool retvalue = false;
            if (open())
            {
                try
                {
                    OleDbCommand pecmd = new OleDbCommand(SQL, peconn);
                    pecmd.ExecuteNonQuery();
                    pecmd = null;
                    retvalue = true;
                }
                catch
                {
                    retvalue = false;
                }
            }
            return retvalue;
        }
    }
}
